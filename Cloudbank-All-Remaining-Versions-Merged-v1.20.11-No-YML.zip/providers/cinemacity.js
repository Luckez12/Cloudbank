// Imported provider: cinemacity; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
'use strict';const _0x2ef61b=_0x5249;(function(_0x2dcbb7,_0x294b43){const _0x29bac5={_0x5a98d5:0x105,_0x4834f5:0xcf,_0x38a20e:0x97,_0x12241e:0x14f},_0x343ce3=_0x5249,_0x5204d4=_0x2dcbb7();while(!![]){try{const _0x527ddd=parseInt(_0x343ce3(0x123))/0x1*(-parseInt(_0x343ce3(_0x29bac5._0x5a98d5))/0x2)+parseInt(_0x343ce3(0xf4))/0x3+parseInt(_0x343ce3(0xf3))/0x4+parseInt(_0x343ce3(_0x29bac5._0x4834f5))/0x5+parseInt(_0x343ce3(_0x29bac5._0x38a20e))/0x6+-parseInt(_0x343ce3(0x12a))/0x7*(parseInt(_0x343ce3(_0x29bac5._0x12241e))/0x8)+-parseInt(_0x343ce3(0x139))/0x9;if(_0x527ddd===_0x294b43)break;else _0x5204d4['push'](_0x5204d4['shift']());}catch(_0x2346e7){_0x5204d4['push'](_0x5204d4['shift']());}}}(_0x1e7f,0xeb08d));var __defProp=Object['defineProperty'],__defProps=Object['defineProperties'],__getOwnPropDescs=Object[_0x2ef61b(0xc1)],__getOwnPropNames=Object['getOwnPropertyNames'],__getOwnPropSymbols=Object['getOwnPropertySymbols'],__hasOwnProp=Object['prototype'][_0x2ef61b(0x146)],__propIsEnum=Object['prototype']['propertyIsEnumerable'],__defNormalProp=(_0xdab9b3,_0x1dd603,_0x36fe77)=>_0x1dd603 in _0xdab9b3?__defProp(_0xdab9b3,_0x1dd603,{'enumerable':!![],'configurable':!![],'writable':!![],'value':_0x36fe77}):_0xdab9b3[_0x1dd603]=_0x36fe77,__spreadValues=(_0x183299,_0x3dd95c)=>{const _0x1b131f=_0x2ef61b;for(var _0x15c8d9 in _0x3dd95c||(_0x3dd95c={}))if(__hasOwnProp['call'](_0x3dd95c,_0x15c8d9))__defNormalProp(_0x183299,_0x15c8d9,_0x3dd95c[_0x15c8d9]);if(__getOwnPropSymbols)for(var _0x15c8d9 of __getOwnPropSymbols(_0x3dd95c)){if(__propIsEnum[_0x1b131f(0x106)](_0x3dd95c,_0x15c8d9))__defNormalProp(_0x183299,_0x15c8d9,_0x3dd95c[_0x15c8d9]);}return _0x183299;},__spreadProps=(_0x2afe07,_0x161bf0)=>__defProps(_0x2afe07,__getOwnPropDescs(_0x161bf0)),__objRest=(_0x240b67,_0x493002)=>{const _0x5d9ba6={_0x4fab3d:0x135},_0x447a9a=_0x2ef61b;var _0x2cc41d={};for(var _0x4e53dc in _0x240b67)if(__hasOwnProp['call'](_0x240b67,_0x4e53dc)&&_0x493002[_0x447a9a(_0x5d9ba6._0x4fab3d)](_0x4e53dc)<0x0)_0x2cc41d[_0x4e53dc]=_0x240b67[_0x4e53dc];if(_0x240b67!=null&&__getOwnPropSymbols)for(var _0x4e53dc of __getOwnPropSymbols(_0x240b67)){if(_0x493002['indexOf'](_0x4e53dc)<0x0&&__propIsEnum['call'](_0x240b67,_0x4e53dc))_0x2cc41d[_0x4e53dc]=_0x240b67[_0x4e53dc];}return _0x2cc41d;},__commonJS=(_0x3ce32a,_0x37a603)=>function _0x5db633(){return _0x37a603||(0x0,_0x3ce32a[__getOwnPropNames(_0x3ce32a)[0x0]])((_0x37a603={'exports':{}})['exports'],_0x37a603),_0x37a603['exports'];},__async=(_0x2587a3,_0x176649,_0x33073c)=>{return new Promise((_0x558c06,_0x3dbd5e)=>{const _0x430f41=_0x5249;var _0x414856=_0x285f87=>{try{_0x5033ef(_0x33073c['next'](_0x285f87));}catch(_0x531771){_0x3dbd5e(_0x531771);}},_0x1e7838=_0x98f932=>{try{_0x5033ef(_0x33073c['throw'](_0x98f932));}catch(_0xf23c38){_0x3dbd5e(_0xf23c38);}},_0x5033ef=_0x2c80eb=>_0x2c80eb[_0x430f41(0x144)]?_0x558c06(_0x2c80eb[_0x430f41(0x98)]):Promise['resolve'](_0x2c80eb[_0x430f41(0x98)])[_0x430f41(0xc7)](_0x414856,_0x1e7838);_0x5033ef((_0x33073c=_0x33073c[_0x430f41(0x136)](_0x2587a3,_0x176649))['next']());});},require_formatter=__commonJS({'src/formatter.js'(_0x178bba,_0x5d81f0){const _0x1f2784={_0x2de62b:0xdc,_0x399874:0xfd,_0x30011b:0x14a,_0xef748c:0x14a,_0x582229:0xc0,_0x4c89b9:0xe6,_0x36f342:0xc6,_0x59eb73:0xf7,_0x510f5e:0x122,_0x45588a:0x11b,_0x45d64c:0xb3,_0x3db720:0x9b,_0x486b00:0x110,_0xc72332:0xb7,_0x2bc486:0xe8,_0x104213:0x10b,_0xd022e4:0xe0,_0x252981:0x124,_0x4a7bf9:0xd1,_0x323dff:0xe0,_0x38931c:0xd1,_0x5c8572:0x149,_0x1f651a:0xe0,_0x53e363:0x149,_0x27ae6d:0x14c,_0x1ad2c6:0xdc,_0x3a132b:0x10b,_0x56e3f5:0x10b,_0x15fc54:0x14e},_0xf1c5f1={_0x8a5b93:0xf7},_0x1188a9={_0x282b0a:0xab,_0x34e1d9:0x121,_0x2f502a:0x14a,_0x454f85:0xa3,_0x1f014c:0x127,_0x33677c:0x130},_0xfd428a={_0x14aaee:0x13c,_0x3299c8:0xa1,_0x1d52dd:0xd3,_0x3e52b3:0x120,_0x5989fc:0x96,_0x21b0e7:0xfc,_0x1829e3:0xa8,_0x56a996:0x11e},_0xafabd2=_0x2ef61b;function _0x2576a2(_0x550760){const _0x34d61c=_0x5249;if(!_0x550760||typeof _0x550760!==_0x34d61c(_0xfd428a._0x14aaee))return _0x550760;const _0x3e55be={};for(const [_0x47ef7c,_0x3693c8]of Object[_0x34d61c(_0xfd428a._0x3299c8)](_0x550760)){if(_0x3693c8==null)continue;const _0x264984=String(_0x47ef7c)['toLowerCase']();if(_0x264984===_0x34d61c(0x14e))_0x3e55be[_0x34d61c(_0xfd428a._0x1d52dd)]=_0x3693c8;else{if(_0x264984===_0x34d61c(_0xfd428a._0x3e52b3)||_0x264984===_0x34d61c(_0xfd428a._0x5989fc))_0x3e55be[_0x34d61c(0x118)]=_0x3693c8;else{if(_0x264984==='origin')_0x3e55be[_0x34d61c(_0xfd428a._0x21b0e7)]=_0x3693c8;else{if(_0x264984===_0x34d61c(0x90))_0x3e55be[_0x34d61c(_0xfd428a._0x1829e3)]=_0x3693c8;else{if(_0x264984===_0x34d61c(0xbe))_0x3e55be[_0x34d61c(_0xfd428a._0x56a996)]=_0x3693c8;else _0x3e55be[_0x47ef7c]=_0x3693c8;}}}}}return _0x3e55be;}function _0x501550(_0x595d63,_0x68de0c,_0x265dea,_0x48cb77){const _0x40d1b8=_0x5249,_0x293b17=[_0x595d63==null?void 0x0:_0x595d63['url'],_0x595d63==null?void 0x0:_0x595d63[_0x40d1b8(_0x1188a9._0x282b0a)],_0x595d63==null?void 0x0:_0x595d63['title'],_0x595d63==null?void 0x0:_0x595d63[_0x40d1b8(_0x1188a9._0x34e1d9)],_0x68de0c][_0x40d1b8(0x95)](Boolean)[_0x40d1b8(0xc9)]('\x20')['toLowerCase']();if(_0x293b17[_0x40d1b8(_0x1188a9._0x2f502a)](_0x40d1b8(_0x1188a9._0x454f85))||_0x293b17['includes']('loadm.cam')||_0x293b17[_0x40d1b8(_0x1188a9._0x2f502a)](_0x40d1b8(_0x1188a9._0x1f014c))||_0x293b17['includes'](_0x40d1b8(_0x1188a9._0x33677c)))return!![];return![];}function _0x2cafda(_0x16a35a){const _0x46c2b7=_0x5249,_0x9b2a3d=String(_0x16a35a||'')['trim']()['toLowerCase']()[_0x46c2b7(_0xf1c5f1._0x8a5b93)](/[^a-z0-9]+/g,'');return _0x9b2a3d||void 0x0;}function _0x5f4b70(_0x409086,_0x33b529,_0x418bb8=null){const _0x34cac4=_0x5249;if(!_0x409086)return _0x409086;let _0x2f2179=(_0x409086['quality']||'1080p')[_0x34cac4(_0x1f2784._0x2de62b)](),_0x10d7a1=_0x34cac4(_0x1f2784._0x399874),_0x2e1a1e='🔥';if(_0x2f2179['includes']('4k')||_0x2f2179[_0x34cac4(0x14a)]('2160'))_0x2e1a1e='🌟',_0x10d7a1='4K';else{if(_0x2f2179[_0x34cac4(_0x1f2784._0x30011b)]('1080'))_0x2e1a1e='🔥',_0x10d7a1='1080p';else{if(_0x2f2179[_0x34cac4(0x14a)](_0x34cac4(0xee)))_0x2e1a1e='💎',_0x10d7a1=_0x34cac4(0xb6);else _0x2f2179[_0x34cac4(_0x1f2784._0xef748c)]('480')?(_0x2e1a1e='📱',_0x10d7a1=_0x34cac4(_0x1f2784._0x582229)):(_0x2e1a1e='📺',_0x10d7a1=_0x409086['quality']||_0x34cac4(0xfd));}}const _0x351d7d=_0x33b529||_0x409086[_0x34cac4(_0x1f2784._0x4c89b9)]||_0x409086['name']||'CinemaCity';let _0x39fa87=_0x418bb8&&_0x418bb8['title']?_0x418bb8[_0x34cac4(0x14b)]:_0x409086[_0x34cac4(0xfa)]||_0x409086[_0x34cac4(0x14b)]||_0x409086[_0x34cac4(_0x1f2784._0x36f342)]||'Stream';_0x39fa87=String(_0x39fa87)[_0x34cac4(_0x1f2784._0x59eb73)](/^[\u2000-\u3300\ud83c-\udbff\udcc0-\udfff\u2011-\u2017\u2190-\u21FF\u2600-\u27BF\u2300-\u23EF\u2934-\u2b55]\s*/gi,'')[_0x34cac4(_0x1f2784._0x510f5e)](),_0x39fa87=_0x39fa87['replace'](/\s+\d+x\d+$/i,'')[_0x34cac4(0xf7)](/\s+S\d+E\d+$/i,'')['trim']();const _0x473866=_0x418bb8&&_0x418bb8[_0x34cac4(0xce)]?_0x418bb8['year']:_0x409086[_0x34cac4(0xce)],_0x2a6a7a=_0x473866?'\x20-\x20('+_0x473866+')':'';let _0x5d726d='';const _0x386193=_0x418bb8&&_0x418bb8['mediaType']==='tv'||_0x409086[_0x34cac4(_0x1f2784._0x45588a)]||_0x409086['season']!=null;if(_0x386193){const _0x17388b=_0x418bb8&&_0x418bb8['season']!=null?_0x418bb8['season']:_0x409086[_0x34cac4(_0x1f2784._0x45d64c)]!=null?_0x409086['season']:0x1,_0x32bb1e=_0x418bb8&&_0x418bb8[_0x34cac4(0xba)]!=null?_0x418bb8[_0x34cac4(0xba)]:_0x409086['episode']!=null?_0x409086['episode']:0x1;_0x5d726d='🎬\x20'+_0x39fa87+_0x2a6a7a+'\x20|\x20S'+_0x17388b+'E'+_0x32bb1e;}else _0x5d726d=_0x34cac4(0xeb)+_0x39fa87+_0x2a6a7a;const _0x981bf8=_0x418bb8&&_0x418bb8[_0x34cac4(_0x1f2784._0x3db720)]?_0x418bb8['runtime']:_0x409086[_0x34cac4(0x9b)],_0x3cdeb4=_0x981bf8?_0x34cac4(_0x1f2784._0x486b00)+_0x981bf8+'m':'',_0xab1e84=''+_0x2e1a1e+_0x10d7a1+'\x20|\x20🔉\x20Multi-Audio'+_0x3cdeb4,_0x152282=_0x34cac4(_0x1f2784._0xc72332),_0x1ad4f6='🔗\x20'+_0x351d7d+'\x20[Server\x201]',_0x11ee8e=[_0x5d726d,_0xab1e84,_0x152282,_0x1ad4f6][_0x34cac4(0x95)](Boolean)[_0x34cac4(0xc9)]('\x0a'),_0x113e2e=_0x351d7d+_0x34cac4(0xa0)+_0x10d7a1+_0x34cac4(_0x1f2784._0x2bc486),_0x1374b3=_0x409086[_0x34cac4(0x10b)]&&typeof _0x409086['behaviorHints']===_0x34cac4(0x13c)?__spreadValues({},_0x409086[_0x34cac4(_0x1f2784._0x104213)]):{};let _0x37a165=Object[_0x34cac4(_0x1f2784._0xd022e4)]({},_0x409086['headers']||{});if(_0x1374b3[_0x34cac4(_0x1f2784._0x252981)]&&_0x1374b3[_0x34cac4(0x124)][_0x34cac4(_0x1f2784._0x4a7bf9)])Object[_0x34cac4(_0x1f2784._0x323dff)](_0x37a165,_0x1374b3['proxyHeaders'][_0x34cac4(_0x1f2784._0x38931c)]);else _0x1374b3[_0x34cac4(_0x1f2784._0x5c8572)]&&Object[_0x34cac4(_0x1f2784._0x1f651a)](_0x37a165,_0x1374b3[_0x34cac4(_0x1f2784._0x53e363)]);Object['keys'](_0x37a165)[_0x34cac4(_0x1f2784._0x27ae6d)]===0x0?_0x37a165=null:_0x37a165=_0x2576a2(_0x37a165);const _0x1f3c68=String(_0x33b529||'')[_0x34cac4(_0x1f2784._0x1ad2c6)]()===_0x34cac4(0xbc)||String((_0x409086==null?void 0x0:_0x409086['name'])||'')[_0x34cac4(_0x1f2784._0x2de62b)]()['includes'](_0x34cac4(0xbc));_0x1f3c68&&!_0x37a165&&(delete _0x1374b3['proxyHeaders'],delete _0x1374b3['headers'],delete _0x1374b3['notWebReady']);_0x37a165&&(_0x1374b3['proxyHeaders']=_0x1374b3['proxyHeaders']||{},_0x1374b3['proxyHeaders']['request']=_0x37a165,_0x1374b3['headers']=_0x37a165);const _0x45fa2c=_0x409086[_0x34cac4(_0x1f2784._0x3a132b)]&&'notWebReady'in _0x409086[_0x34cac4(_0x1f2784._0x56e3f5)],_0x3cc6c7=_0x501550(_0x409086,_0x33b529,_0x37a165,_0x1374b3);if(!_0x1f3c68&&_0x3cc6c7)_0x1374b3[_0x34cac4(0x113)]=!![];else!_0x45fa2c&&delete _0x1374b3['notWebReady'];const _0x330ccb=_0x409086['referer']||(_0x37a165==null?void 0x0:_0x37a165['Referer'])||(_0x37a165==null?void 0x0:_0x37a165[_0x34cac4(0x120)]),_0x5f15d5=_0x409086[_0x34cac4(0x151)]||(_0x37a165==null?void 0x0:_0x37a165[_0x34cac4(0xd3)])||(_0x37a165==null?void 0x0:_0x37a165[_0x34cac4(_0x1f2784._0x15fc54)]),_0xebcf11=__spreadValues({},_0x409086);return delete _0xebcf11['quality'],delete _0xebcf11['language'],__spreadProps(_0xebcf11,{'name':_0x113e2e,'title':_0x11ee8e,'size':_0x11ee8e,'description':_0x11ee8e,'_nuvio_formatted':!![],'behaviorHints':_0x1374b3,'provider':_0x409086[_0x34cac4(0xca)]||_0x2cafda(_0x33b529),'referer':_0x330ccb,'userAgent':_0x5f15d5,'headers':_0x37a165});}_0x5d81f0[_0xafabd2(0x158)]={'formatStream':_0x5f4b70};}}),require_fetch_helper=__commonJS({'src/fetch_helper.js'(_0x17f0fe,_0x338f37){const _0x149c86={_0x27bb88:0x147,_0x277236:0x119,_0x1f8c00:0x11d,_0x3aaf5e:0x11d,_0x4314ed:0xab,_0x20aefd:0xea},_0x1e0aa4={_0x3c6dc3:0x119};var _0x46629f=0x7530;function _0x394cc9(_0x20d4d4){const _0x5a154f={_0x1e4893:0x159},_0x1e4ae4=_0x5249,_0x3e6b85=Number[_0x1e4ae4(0xfb)](String(_0x20d4d4),0xa);if(!Number['isFinite'](_0x3e6b85)||_0x3e6b85<=0x0)return{'signal':void 0x0,'cleanup':null,'timed':![]};if(typeof AbortSignal!=='undefined'&&typeof AbortSignal['timeout']===_0x1e4ae4(_0x1e0aa4._0x3c6dc3))return{'signal':AbortSignal[_0x1e4ae4(0xf0)](_0x3e6b85),'cleanup':null,'timed':!![]};if(typeof AbortController!==_0x1e4ae4(0x147)&&typeof setTimeout===_0x1e4ae4(_0x1e0aa4._0x3c6dc3)){const _0x4067de=new AbortController(),_0x5d93f2=setTimeout(()=>{const _0x539dbf=_0x1e4ae4;_0x4067de[_0x539dbf(_0x5a154f._0x1e4893)]();},_0x3e6b85);return{'signal':_0x4067de['signal'],'cleanup':()=>clearTimeout(_0x5d93f2),'timed':!![]};}return{'signal':void 0x0,'cleanup':null,'timed':![]};}function _0x3e8312(_0x1c03ad){return __async(this,arguments,function*(_0x4a56b4,_0x257d4d={}){const _0x567ca6=_0x5249;if(typeof fetch==='undefined')throw new Error(_0x567ca6(0xf8));const _0x167029=_0x257d4d,{timeout:_0x559ba3}=_0x167029,_0x34abef=__objRest(_0x167029,['timeout']),_0x8793fc=_0x559ba3||_0x46629f,_0x28032c=_0x394cc9(_0x8793fc),_0x3aef26=__spreadValues({},_0x34abef);if(_0x28032c['signal']){if(_0x3aef26['signal']&&typeof AbortSignal!==_0x567ca6(_0x149c86._0x27bb88)&&typeof AbortSignal[_0x567ca6(0x12e)]===_0x567ca6(_0x149c86._0x277236))_0x3aef26[_0x567ca6(_0x149c86._0x1f8c00)]=AbortSignal['any']([_0x3aef26['signal'],_0x28032c['signal']]);else!_0x3aef26[_0x567ca6(_0x149c86._0x1f8c00)]&&(_0x3aef26[_0x567ca6(_0x149c86._0x3aaf5e)]=_0x28032c['signal']);}try{const _0x531b5b=yield fetch(_0x4a56b4,_0x3aef26);return _0x531b5b;}catch(_0x3c4d1a){if(_0x3c4d1a&&_0x3c4d1a[_0x567ca6(_0x149c86._0x4314ed)]===_0x567ca6(0xe9)&&_0x28032c[_0x567ca6(_0x149c86._0x20aefd)])throw new Error('Request\x20to\x20'+_0x4a56b4+_0x567ca6(0x143)+_0x8793fc+'ms');throw _0x3c4d1a;}finally{typeof _0x28032c[_0x567ca6(0xd0)]==='function'&&_0x28032c[_0x567ca6(0xd0)]();}});}_0x338f37['exports']={'fetchWithTimeout':_0x3e8312,'createTimeoutSignal':_0x394cc9};}}),{formatStream}=require_formatter(),{fetchWithTimeout}=require_fetch_helper(),BASE64_CHARS=_0x2ef61b(0x12c);function base64Decode(_0x59a17c){const _0x205de0={_0x226ee1:0x10e},_0x3d11b7=_0x2ef61b;try{if(typeof atob==='function')return decodeURIComponent(escape(atob(_0x59a17c)));}catch(_0x3e29b0){}try{let _0x1db19f='',_0x2e5f72=0x0,_0x338b44=0x0;const _0x512f24=String(_0x59a17c||'')[_0x3d11b7(0xf7)](/[^A-Za-z0-9+/=]/g,'');for(let _0x583533=0x0;_0x583533<_0x512f24[_0x3d11b7(0x14c)];_0x583533++){const _0x55ecaf=_0x512f24[_0x3d11b7(0xd8)](_0x583533);if(_0x55ecaf==='=')break;const _0x9b9b61=BASE64_CHARS[_0x3d11b7(0x135)](_0x55ecaf);if(_0x9b9b61<0x0)continue;_0x2e5f72=_0x2e5f72<<0x6|_0x9b9b61,_0x338b44+=0x6,_0x338b44>=0x8&&(_0x338b44-=0x8,_0x1db19f+=String['fromCharCode'](_0x2e5f72>>_0x338b44&0xff));}try{return decodeURIComponent(escape(_0x1db19f));}catch(_0x573be2){return _0x1db19f;}}catch(_0x5eebde){return console[_0x3d11b7(_0x205de0._0x226ee1)]('[CinemaCity]\x20Base64\x20decode\x20error:',_0x5eebde),'';}}var BASE_URL=base64Decode('aHR0cHM6Ly9jaW5lbWFjaXR5LmNj'),USER_AGENT='Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/125.0.0.0\x20Safari/537.36',FETCH_TIMEOUT=0x2710,TMDB_API_KEY=_0x2ef61b(0xd6),SITEMAP_URL=BASE_URL+_0x2ef61b(0xaa),SITEMAP_CACHE_MS=0x3c*0x3c*0x3e8,sitemapCache=null;function _0x5249(_0x3404ab,_0x55b7b8){_0x3404ab=_0x3404ab-0x8e;const _0x1e7fc9=_0x1e7f();let _0x5249e7=_0x1e7fc9[_0x3404ab];if(_0x5249['LhqtoH']===undefined){var _0x307554=function(_0x19bbc3){const _0x2d79e9='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0xdab9b3='',_0x1dd603='';for(let _0x36fe77=0x0,_0x183299,_0x3dd95c,_0x15c8d9=0x0;_0x3dd95c=_0x19bbc3['charAt'](_0x15c8d9++);~_0x3dd95c&&(_0x183299=_0x36fe77%0x4?_0x183299*0x40+_0x3dd95c:_0x3dd95c,_0x36fe77++%0x4)?_0xdab9b3+=String['fromCharCode'](0xff&_0x183299>>(-0x2*_0x36fe77&0x6)):0x0){_0x3dd95c=_0x2d79e9['indexOf'](_0x3dd95c);}for(let _0x2afe07=0x0,_0x161bf0=_0xdab9b3['length'];_0x2afe07<_0x161bf0;_0x2afe07++){_0x1dd603+='%'+('00'+_0xdab9b3['charCodeAt'](_0x2afe07)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x1dd603);};_0x5249['etYDaE']=_0x307554,_0x5249['OOZfUS']={},_0x5249['LhqtoH']=!![];}const _0x3006ca=_0x1e7fc9[0x0],_0xd0f0a7=_0x3404ab+_0x3006ca,_0x969458=_0x5249['OOZfUS'][_0xd0f0a7];return!_0x969458?(_0x5249e7=_0x5249['etYDaE'](_0x5249e7),_0x5249['OOZfUS'][_0xd0f0a7]=_0x5249e7):_0x5249e7=_0x969458,_0x5249e7;}function getMappingApiUrl(){return'https://animemapping.realbestia.com';}function normalizeConfigBoolean(_0x4aeb1a){const _0x1540f3={_0x17bfa2:0x141},_0x282f66=_0x2ef61b;if(_0x4aeb1a===!![])return!![];const _0x3e3f8c=String(_0x4aeb1a||'')['trim']()['toLowerCase']();return['1',_0x282f66(_0x1540f3._0x17bfa2),'yes','on','enabled','checked'][_0x282f66(0x14a)](_0x3e3f8c);}function getMappingLanguage(_0x3d9b88=null){const _0x41101e=String((_0x3d9b88==null?void 0x0:_0x3d9b88['mappingLanguage'])||'')['trim']()['toLowerCase']();if(_0x41101e==='it')return'it';return normalizeConfigBoolean(_0x3d9b88==null?void 0x0:_0x3d9b88['easyCatalogsLangIt'])?'it':null;}function fetchViaWorker(_0x278ca0){const _0x3b0e83={_0xb74923:0x11c,_0x2b9354:0xa2};return __async(this,null,function*(){const _0x1621b7=_0x5249,_0x112145=_0x278ca0[_0x1621b7(_0x3b0e83._0xb74923)]('http')?new URL(_0x278ca0)['pathname']+new URL(_0x278ca0)[_0x1621b7(_0x3b0e83._0x2b9354)]:_0x278ca0,_0x4cb750=('https://'+base64Decode('Y2MucmVhbGJlc3RpYS5jb20='))['replace'](/\/+$/,'')+(_0x112145[_0x1621b7(_0x3b0e83._0xb74923)]('/')?_0x112145:'/'+_0x112145),_0x472bd6=yield fetchWithTimeout(_0x4cb750,{'timeout':FETCH_TIMEOUT,'headers':{'User-Agent':USER_AGENT}});if(!_0x472bd6['ok'])throw new Error(_0x1621b7(0x10d)+_0x472bd6[_0x1621b7(0xd4)]);return yield _0x472bd6['text']();});}function decodeHtmlEntities(_0x2515ff){const _0x3a934d={_0x3879d4:0xf7},_0x5461be=_0x2ef61b;return String(_0x2515ff||'')['replace'](/&#(\d+);/g,(_0x3ff40b,_0x41e08f)=>String[_0x5461be(0x101)](Number(_0x41e08f)))[_0x5461be(_0x3a934d._0x3879d4)](/&#x([0-9a-f]+);/gi,(_0x1c5e25,_0x5b2c74)=>String['fromCharCode'](parseInt(_0x5b2c74,0x10)))[_0x5461be(0xf7)](/&quot;/g,'\x22')[_0x5461be(0xf7)](/&#039;/g,'\x27')[_0x5461be(_0x3a934d._0x3879d4)](/&amp;/g,'&')['replace'](/&lt;/g,'<')[_0x5461be(0xf7)](/&gt;/g,'>')['replace'](/&ndash;|&mdash;/g,'-')['replace'](/\u2013|\u2014/g,'-');}function getHttpStatusFromError(_0x377a62){const _0x4bf765={_0x461366:0x112,_0x5256cb:0x13f,_0x54b13c:0xfb},_0x102f50=_0x2ef61b;var _0x23e72e;const _0x287a3d=Number['parseInt'](String(((_0x23e72e=_0x377a62==null?void 0x0:_0x377a62[_0x102f50(0x115)])==null?void 0x0:_0x23e72e['status'])||''),0xa);if(Number[_0x102f50(_0x4bf765._0x461366)](_0x287a3d))return _0x287a3d;const _0xe54533=String(_0x377a62&&_0x377a62['message']?_0x377a62['message']:_0x377a62)[_0x102f50(_0x4bf765._0x5256cb)](/HTTP\s+(\d+)/i);return _0xe54533?Number[_0x102f50(_0x4bf765._0x54b13c)](_0xe54533[0x1],0xa):null;}function isCloudflareBlockedError(_0x34ce10){const _0x2a64af=_0x2ef61b;var _0x2f2c38,_0x561cb8,_0x400567;const _0x314cb9=[_0x34ce10==null?void 0x0:_0x34ce10['message'],(_0x561cb8=(_0x2f2c38=_0x34ce10==null?void 0x0:_0x34ce10[_0x2a64af(0x115)])==null?void 0x0:_0x2f2c38['data'])==null?void 0x0:_0x561cb8['message'],(_0x400567=_0x34ce10==null?void 0x0:_0x34ce10[_0x2a64af(0x115)])==null?void 0x0:_0x400567['data']]['filter'](Boolean)['join']('\x20');return/Cloudflare has blocked this request|Error solving the challenge/i[_0x2a64af(0x11a)](_0x314cb9);}function normalizeTitle(_0x59eaf1){const _0x2356b9={_0x27300e:0x14d,_0x5dda12:0xf7},_0xacaf6f=_0x2ef61b;return decodeHtmlEntities(String(_0x59eaf1||''))[_0xacaf6f(0xe7)](_0xacaf6f(_0x2356b9._0x27300e))['replace'](/[\u0300-\u036f]/g,'')['toLowerCase']()['replace'](/\([^)]*\)/g,'\x20')[_0xacaf6f(_0x2356b9._0x5dda12)](/[^a-z0-9]+/g,'\x20')[_0xacaf6f(0x122)]();}function compactTitle(_0x3d347f){const _0x566b9e={_0x24553a:0xf7},_0x1ca5bb=_0x2ef61b;return normalizeTitle(_0x3d347f)[_0x1ca5bb(_0x566b9e._0x24553a)](/\s+/g,'');}function extractYearFromMetadata(_0x27a691){const _0x2955b0={_0x449090:0x112},_0x39ec99=_0x2ef61b,_0x851074=(_0x27a691==null?void 0x0:_0x27a691['release_date'])||(_0x27a691==null?void 0x0:_0x27a691[_0x39ec99(0x142)])||'',_0x9a9510=Number[_0x39ec99(0xfb)](String(_0x851074)[_0x39ec99(0xae)](0x0,0x4),0xa);return Number[_0x39ec99(_0x2955b0._0x449090)](_0x9a9510)?_0x9a9510:null;}function getSignificantTokens(_0x5a7142){const _0x5a7ffe={_0x530e10:0xe2,_0x4db8e2:0xf5,_0x52b8c0:0xe5,_0x1a85ee:0x91},_0x394115=_0x2ef61b,_0x59eff0=new Set([_0x394115(_0x5a7ffe._0x530e10),'a','an','of',_0x394115(_0x5a7ffe._0x4db8e2),'in','on','to','for','at','by','is','it','il','lo','la',_0x394115(0x9d),'le','un',_0x394115(0xbf),_0x394115(_0x5a7ffe._0x52b8c0),'di','da',_0x394115(0x99),_0x394115(0x129),'dei','e','o','con',_0x394115(0xb8),'su',_0x394115(_0x5a7ffe._0x1a85ee),'fra']);return normalizeTitle(_0x5a7142)['split'](/\s+/)['filter'](_0x2801ad=>_0x2801ad[_0x394115(0x14c)]>0x1&&!_0x59eff0[_0x394115(0x108)](_0x2801ad));}function parseSitemapEntries(_0x5eaec0){const _0x541d55={_0x357543:0xb9,_0x1c423d:0x13f},_0x21bcde=_0x2ef61b,_0x471567=[],_0x1e8cb2=/<loc>(https:\/\/cinemacity\.cc\/(movies|tv-series)\/\d+-([a-z0-9-]+)\.html)<\/loc>/gi;let _0x52c88f;while((_0x52c88f=_0x1e8cb2[_0x21bcde(_0x541d55._0x357543)](String(_0x5eaec0||'')))!==null){const _0x22b77d=_0x52c88f[0x1],_0x1b6303=_0x52c88f[0x2],_0x58e5eb=_0x52c88f[0x3],_0xdbbcc1=_0x58e5eb[_0x21bcde(_0x541d55._0x1c423d)](/-(\d{4})$/),_0xb8229d=_0xdbbcc1?Number['parseInt'](_0xdbbcc1[0x1],0xa):null,_0x31e899=_0xdbbcc1?_0x58e5eb['slice'](0x0,-0x5):_0x58e5eb,_0x315cd8=_0x31e899[_0x21bcde(0xf7)](/-/g,'\x20');_0x471567[_0x21bcde(0xd9)]({'url':_0x22b77d,'kind':_0x1b6303,'title':_0x315cd8,'normalizedTitle':normalizeTitle(_0x315cd8),'compactTitle':compactTitle(_0x315cd8),'tokens':getSignificantTokens(_0x315cd8),'year':Number['isInteger'](_0xb8229d)?_0xb8229d:null});}return _0x471567;}function fetchSitemapEntries(_0x1acbb3=null){const _0x43e413={_0x126ae6:0xa6,_0x55b10b:0xa1,_0x4b4ee1:0x12b,_0x286345:0x11c,_0x5f40c1:0xff,_0x471872:0xae,_0x15edcb:0x157,_0x338a9c:0xe3,_0x1107f5:0xac,_0x35d753:0x13e,_0x2738d1:0xda,_0x161eb4:0x156,_0xde1aad:0xbd,_0x1b4b38:0x137,_0x3e38a9:0x10c};return __async(this,null,function*(){const _0x18e461={_0x466145:0x111},_0x216ea8=_0x5249;if(sitemapCache&&sitemapCache[_0x216ea8(_0x43e413._0x126ae6)]>Date[_0x216ea8(0x156)]())return sitemapCache[_0x216ea8(_0x43e413._0x55b10b)];console['log'](_0x216ea8(_0x43e413._0x4b4ee1));let _0x356aa2='https://'+base64Decode(_0x216ea8(0xc2));const _0xac8235=SITEMAP_URL[_0x216ea8(_0x43e413._0x286345)]('http')?new URL(SITEMAP_URL)[_0x216ea8(_0x43e413._0x5f40c1)]:SITEMAP_URL;if(_0x356aa2){const _0x4e4a52=_0x356aa2['endsWith']('/')?''+_0x356aa2[_0x216ea8(_0x43e413._0x471872)](0x0,-0x1)+_0xac8235+'?page=1&perPage=500':''+_0x356aa2+_0xac8235+_0x216ea8(_0x43e413._0x15edcb);console[_0x216ea8(0x137)](_0x216ea8(_0x43e413._0x338a9c)+_0x4e4a52);const _0xcc9727=yield fetchWithTimeout(_0x4e4a52,{'timeout':FETCH_TIMEOUT,'headers':{'User-Agent':USER_AGENT}});if(_0xcc9727['ok']){const _0x3cd2ab=parseInt(_0xcc9727['headers'][_0x216ea8(0x128)]('x-total-entries')||'0',0xa),_0x231b0e=yield _0xcc9727[_0x216ea8(_0x43e413._0x1107f5)]();let _0x18634b=parseSitemapEntries(_0x231b0e);if(_0x3cd2ab>0x0){const _0x1e75f0=0x1f4,_0x4b3d6c=Math['ceil'](_0x3cd2ab/_0x1e75f0),_0x59194b=[];for(let _0x510c20=0x2;_0x510c20<=_0x4b3d6c;_0x510c20++){const _0x305f61=_0x356aa2[_0x216ea8(0xbd)]('/')?''+_0x356aa2['slice'](0x0,-0x1)+_0xac8235+'?page='+_0x510c20+'&perPage=500':''+_0x356aa2+_0xac8235+'?page='+_0x510c20+_0x216ea8(_0x43e413._0x35d753);_0x59194b['push'](fetchWithTimeout(_0x305f61,{'timeout':FETCH_TIMEOUT,'headers':{'User-Agent':USER_AGENT}})[_0x216ea8(0xc7)](_0x1ab514=>_0x1ab514['ok']?_0x1ab514[_0x216ea8(0xac)]():'')[_0x216ea8(0xc7)](_0x29e941=>{const _0x10281a=_0x216ea8;if(_0x29e941)_0x18634b=_0x18634b[_0x10281a(_0x18e461._0x466145)](parseSitemapEntries(_0x29e941));})[_0x216ea8(0x109)](()=>{}));}yield Promise['all'](_0x59194b);}else{if(_0x18634b['length']>=0x708)return console['log'](_0x216ea8(_0x43e413._0x2738d1)+_0x18634b[_0x216ea8(0x14c)]+_0x216ea8(0x13b)),sitemapCache={'entries':_0x18634b,'expiresAt':Date[_0x216ea8(0x156)]()+SITEMAP_CACHE_MS},_0x18634b;}if(_0x18634b['length']>0x0)return sitemapCache={'entries':_0x18634b,'expiresAt':Date[_0x216ea8(_0x43e413._0x161eb4)]()+SITEMAP_CACHE_MS},console['log'](_0x216ea8(0x10c)+_0x18634b['length']+_0x216ea8(0xcd)),_0x18634b;}const _0x215727=_0x356aa2[_0x216ea8(_0x43e413._0xde1aad)]('/')?''+_0x356aa2+_0xac8235['replace'](/^\//,''):''+_0x356aa2+_0xac8235;console[_0x216ea8(_0x43e413._0x1b4b38)]('[CinemaCity]\x20Fetching\x20sitemap\x20via\x20CF\x20Proxy\x20(full):\x20'+_0x215727);const _0x49168d=yield fetchWithTimeout(_0x215727,{'timeout':FETCH_TIMEOUT,'headers':{'User-Agent':USER_AGENT}});if(!_0x49168d['ok'])throw new Error('Proxy\x20HTTP\x20'+_0x49168d[_0x216ea8(0xd4)]);const _0x2e2e3f=yield _0x49168d[_0x216ea8(_0x43e413._0x1107f5)](),_0xf2b999=parseSitemapEntries(_0x2e2e3f);return sitemapCache={'entries':_0xf2b999,'expiresAt':Date[_0x216ea8(0x156)]()+SITEMAP_CACHE_MS},console['log']('[CinemaCity]\x20Sitemap\x20catalog\x20loaded:\x20'+_0xf2b999[_0x216ea8(0x14c)]+_0x216ea8(0xcd)),_0xf2b999;}else{const _0x319987=yield fetchWithTimeout(SITEMAP_URL,{'timeout':FETCH_TIMEOUT,'headers':{'User-Agent':USER_AGENT}});if(!_0x319987['ok'])throw new Error('HTTP\x20'+_0x319987[_0x216ea8(0xd4)]);const _0x43c5cd=yield _0x319987['text'](),_0x282bcf=parseSitemapEntries(_0x43c5cd);return sitemapCache={'entries':_0x282bcf,'expiresAt':Date[_0x216ea8(_0x43e413._0x161eb4)]()+SITEMAP_CACHE_MS},console['log'](_0x216ea8(_0x43e413._0x3e38a9)+_0x282bcf['length']+'\x20entries'),_0x282bcf;}});}function _0x1e7f(){const _0x91bc51=['C3rHCNrZv2L0Aa','C2LNBMfS','qwnJzxb0luXHBMD1ywDL','Dg9tDhjPBMC','CMvMzxjLCG','C2vYDMvY','DhjPBq','mvvSuvrxza','ChjVEhLizwfKzxjZ','l3b1yMXPy19MAwXLCY8','Dg1KyL9LCgLZB2rL','BwL4zhjVCa','z2v0','zgvSBge','n3zhuLLOza','w0nPBMvTyunPDhLDiezLDgnOAw5NihnPDgvTyxaGy2f0ywXVzY4UlG','qujdrevgr0HjsKTmtu5puffsu1rvvLDywvPHyMnKzwzNAgLQA2XTBM9WCxjZDhv2D3H5EJaXmJm0nty3odKRlZ0','BwvZC2fNzq','yw55','l2v4DgvYBMfSx2LKCZ9HCgLFA2v5pq','BxHJB250zw50','zw50CNK','C2vYAwvZ','AwrZ','lM0ZDtG','Aw5KzxHpzG','yxbWBhK','Bg9N','w0nPBMvTyunPDhLDierPCMvJDcbZDhjLyw06ia','mJu5ndyYndrgAu1xtMC','w0nPBMvTyunPDhLDieLnrgiGy2HLy2SGzxjYB3iGzM9Yia','igvUDhjPzxmP','B2jQzwn0','AxnbCNjHEq','jNbLCLbHz2u9ntaW','Bwf0y2G','w0nPBMvTyunPDhLDifnPDgvTyxaGsu1eyIbTAxnTyxrJAdOG','Dhj1zq','zMLYC3rFywLYx2rHDgu','ihrPBwvKig91DcbHzNrLCIa','zg9Uzq','zMLSzvXZkJPCCYONkfXBlIO/xf0PjW','AgfZt3DUuhjVCgvYDhK','Dw5KzwzPBMvK','txvSDgKTqxvKAw8','AgvHzgvYCW','Aw5JBhvKzxm','DgL0Bgu','BgvUz3rO','tKzlra','DxnLCI1Hz2vUDa','ndu2mdyXnM54CNbnua','DhyTC2vYAwvZ','DxnLCKfNzw50','D2fYBG','Dg1KyKLK','w0nPBMvTyunPDhLDifnPDgvTyxaGBM8Gy29UzMLKzw50ig1HDgnOigzVCIa','Ahr0Chm6lY9JAw5LBwfJAxr5lMnJlW','BM93','p3bHz2u9mszWzxjqywDLptuWma','zxHWB3j0CW','ywjVCNq','Bw92Awu','zxbPC29Kzu51BwjLCG','ywnJzxb0','DhjH','zMLUza','BM9YBwfSAxPLzfrPDgXL','w0nPBMvTyunPDhLDifrnreiGBwv0ywrHDgeGzxjYB3i6','zMLSDgvY','CMvMzxjYzxi','otC0mJaYnLbgDMTwtq','DMfSDwu','zgvS','C3vI','CNvUDgLTzq','BgfUzW','z2XP','igHHCYa','AxrHBgLHBG','ihWG','zw50CMLLCW','C2vHCMnO','Bg9Hzg0','w0nPBMvTyunPDhLDifbHz2uGyMXVy2TLzcbVCIbLBxb0EsaO','C3vIC3rYAw5N','zxHWAxjLC0f0','lM00yq','qwnJzxb0','C2v0','l25LD3nFCgfNzxmUEg1S','BMfTzq','Dgv4Da','w0nPBMvTyunPDhLDieTPDhn1ig1HChbPBMCGzxjYB3i6','C2XPy2u','y29TCgfJDfrPDgXL','w0nPBMvTyunPDhLDifnPDgvTyxaGBwf0y2GGBM90ieLnrgiGDMvYAwzPzwqGzM9Yia','BM9YBwfSAxPLzeLK','ic0+ia','C2vHC29U','p2fWAv9RzxK9','Dw5RBM93BI9dBg91zgzSyxjL','nZiWCa','8j+oNU+4JYbns1yGFcdIMQeGseXtihWG8j+tPsbxruiTreW','CgvY','zxHLyW','zxbPC29Kzq','Aw1KyL9Pza','C3rYzwfTAw5Ny29TBxvUAxr5','zw5KC1DPDgG','ywnJzxb0lwXHBMD1ywDL','Dw5V','ndGWCa','z2v0t3DUuhjVCgvYDhLezxnJCMLWDg9YCW','wtjnDwnTvMHIr0PSyZnsCfLtnwPImJa9','CMf3rxbPC29Kzu51BwjLCG','zxbPC29Kzxm','lM1Wna','B3jPz2LUywXuAxrSzq','DgHLBG','zxbPC29Kzv9YDw5FDgLTzq','AM9PBG','ChjVDMLKzxi','l3nLyxnVBI8','DxjS','igvUDhjPzxm','EwvHCG','odG1mJeWmhL0Eu5TBG','y2XLyw51Ca','CMvXDwvZDa','zMLSzq','vxnLCI1bz2vUDa','C3rHDhvZ','CMf3rxbPC29Kzq','nJHLmdK0nJK5nti1yJe4ytCWyMfImMy4nMiXzMe3mdy','BwfWCgLUz3m','y2HHCKf0','ChvZAa','w0nPBMvTyunPDhLDiez1BgWGC2L0zw1HCcbYzwnLAxzLzcaO','Dg9Rzw5Z','Dg9mB3DLCKnHC2u','lNvYBhnLDc9Tyxn0zxiUBtn1oa','w0nPBMvTyunPDhLDieLnrgiGy2HLy2SG','ANnVBG','yxnZAwDU','AxrHBgLHBM8','DgHL','w0nPBMvTyunPDhLDiezLDgnOAw5NihnPDgvTyxaGCgfNzsaXihzPysbdrIbqCM94EtOG','Bwf4','Dw5H','ChjVDMLKzxjoyw1L','BM9YBwfSAxPL','ihWGtxvSDgKTqxvKAw8','qwjVCNrfCNjVCG','DgLTzwq','8j+oRca','ifTZy29Yzt0','AxrH','nZiW','BwfWCgvKrxbPC29Kzq','DgLTzw91Da','icHIzxn0pq','Dg1KyKvWAxnVzgu','ntyZmti4mhDpz3jkwq','ndaXntCYmNzuzfzKEq','yw5K','Dg1KyG','CMvWBgfJzq','tM8GzMv0y2GGAw1WBgvTzw50yxrPB24GzM91BMqH','w0nPBMvTyunPDhLDifDVCMTLCIbMzxrJAcbMywLSzwq6ia','zgLZCgXHEvrPDgXL','CgfYC2vjBNq','t3jPz2LU','mta4mha','AgXZ','Cgf0Ag5HBwu','AgfZsxrHBgLHBG','zNjVBunOyxjdB2rL','C2nVCMu','ic8G','Aw1KyG','mZq0otu4mNvvrNzRwG','y2fSBa','l2TPDhn1lW','AgfZ','y2f0y2G','C2vHC29UuhjVDMLKzwq','yMvOyxzPB3jiAw50CW','w0nPBMvTyunPDhLDifnPDgvTyxaGy2f0ywXVzYbSB2fKzwq6ia','v29YA2vYieHuvfaG','zxjYB3i','Aw1KyKLK','ihWG4OYBia','y29Uy2f0','AxnjBNrLz2vY','BM90v2vIuMvHzhK','C3bSAxq','CMvZCg9UC2u','C2vHC29UtNvTyMvY','zxbPC29Kzv9UDw1Izxi','uMvMzxjLCG','zNvUy3rPB24','DgvZDa','AxnuDG'];_0x1e7f=function(){return _0x91bc51;};return _0x1e7f();}function scoreSitemapEntry(_0x8a46b2,_0x24e662,_0x2b75ff){const _0x213728={_0x482e34:0x93,_0x2c3524:0xaf,_0x18bcc5:0x11c,_0x2651a9:0xaf,_0x3833c7:0xdb,_0x547eb3:0x14c,_0x3c57a0:0x14c},_0xbf1ad2=_0x2ef61b;let _0x4d2738=0x0;for(const _0x352452 of _0x24e662){const _0x4a0144=normalizeTitle(_0x352452),_0x38010b=compactTitle(_0x352452);if(!_0x4a0144||!_0x38010b)continue;let _0x32d82a=0x0;if(_0x8a46b2[_0xbf1ad2(_0x213728._0x482e34)]===_0x4a0144||_0x8a46b2[_0xbf1ad2(_0x213728._0x2c3524)]===_0x38010b)_0x32d82a=0x3e8;else{if(_0x8a46b2['normalizedTitle'][_0xbf1ad2(_0x213728._0x18bcc5)](_0x4a0144)||_0x4a0144[_0xbf1ad2(_0x213728._0x18bcc5)](_0x8a46b2['normalizedTitle']))_0x32d82a=0x1f4;else{if(_0x8a46b2['compactTitle']['includes'](_0x38010b)||_0x38010b['includes'](_0x8a46b2[_0xbf1ad2(_0x213728._0x2651a9)]))_0x32d82a=0x1a4;else{const _0x410994=getSignificantTokens(_0x352452);if(_0x410994['length']>0x0&&_0x8a46b2[_0xbf1ad2(_0x213728._0x3833c7)]['length']>0x0){let _0x4fda8d=0x0;const _0x15c38c=new Set(_0x8a46b2['tokens']);for(const _0x46dfa8 of _0x410994){if(_0x15c38c['has'](_0x46dfa8))_0x4fda8d++;}const _0x5227c4=_0x4fda8d/_0x410994['length'],_0x3d72fb=Math[_0xbf1ad2(0xe4)](0x0,_0x8a46b2[_0xbf1ad2(0xdb)]['length']-_0x410994[_0xbf1ad2(_0x213728._0x547eb3)]);_0x32d82a=_0x5227c4*0x12c-_0x3d72fb*0x14-Math['abs'](_0x8a46b2['tokens']['length']-_0x410994[_0xbf1ad2(_0x213728._0x3c57a0)])*0x2;}}}}_0x2b75ff&&_0x8a46b2['year']&&(_0x32d82a+=_0x8a46b2['year']===_0x2b75ff?0x32:-Math['abs'](_0x8a46b2[_0xbf1ad2(0xce)]-_0x2b75ff)*0x3),_0x4d2738=Math['max'](_0x4d2738,_0x32d82a);}return _0x4d2738;}function extractImdbIdFromHtml(_0x4823fb){const _0x2297d8={_0x132554:0x13f,_0x2a4744:0x11a},_0x1efcb6=_0x2ef61b,_0x40388a=String(_0x4823fb||'')[_0x1efcb6(_0x2297d8._0x132554)](/\btt\d{5,}\b/gi)||[];for(const _0xf9b991 of _0x40388a){if(/^tt\d{5,}$/i[_0x1efcb6(_0x2297d8._0x2a4744)](_0xf9b991))return _0xf9b991['toLowerCase']();}return null;}function verifyCandidateImdb(_0xddfcc5,_0x675698){const _0x42fd69={_0x12613f:0x137,_0x573757:0xde,_0x12020d:0x10e,_0x3a1040:0x13a};return __async(this,null,function*(){const _0x4fc1ff=_0x5249,_0x235751=String(_0x675698||'')['trim']()['toLowerCase']();if(!/^tt\d{5,}$/['test'](_0x235751))return null;try{const _0x549738=yield fetchViaWorker(_0xddfcc5),_0x5cae69=extractImdbIdFromHtml(_0x549738);return _0x5cae69&&console[_0x4fc1ff(_0x42fd69._0x12613f)](_0x4fc1ff(_0x42fd69._0x573757)+_0xddfcc5+':\x20'+_0x5cae69),_0x5cae69;}catch(_0x100631){const _0x28b9b4=getHttpStatusFromError(_0x100631);return _0x28b9b4!==0x193&&_0x28b9b4!==0x1f7&&!isCloudflareBlockedError(_0x100631)&&console[_0x4fc1ff(_0x42fd69._0x12020d)](_0x4fc1ff(_0x42fd69._0x3a1040)+_0xddfcc5+':',_0x100631),null;}});}function searchBySitemap(_0x3a8922,_0x3514a8,_0x71024c=null){const _0x28ad8a={_0x225f71:0x14c,_0xa3df63:0x150,_0x1ad1d7:0x9b,_0x5b41fa:0xc8,_0x45e1bf:0x12d,_0xf9c23a:0x154,_0x855816:0xcc,_0x1e6084:0x137,_0x4b4a7e:0xb2,_0x188727:0x131,_0x59f058:0xce,_0x121ded:0x140,_0x45d731:0xcc,_0xe3af80:0x9e,_0x193f08:0xc9,_0x2940c0:0xf1,_0x46bce2:0xec};return __async(this,null,function*(){const _0xd18956=_0x5249,_0x4ae077=/^tt\d{5,}$/i['test'](String(_0x3a8922||'')['trim']())?String(_0x3a8922)[_0xd18956(0x122)]()['toLowerCase']():null,_0x287b54=yield getTmdbMetadata(_0x3a8922,_0x3514a8),_0xf910d4=Array['from'](new Set([_0x287b54==null?void 0x0:_0x287b54[_0xd18956(0x14b)],_0x287b54==null?void 0x0:_0x287b54['name'],_0x287b54==null?void 0x0:_0x287b54['original_title'],_0x287b54==null?void 0x0:_0x287b54['original_name']][_0xd18956(0x95)](Boolean)));if(_0xf910d4[_0xd18956(_0x28ad8a._0x225f71)]===0x0)return null;const _0xe2fd24=extractYearFromMetadata(_0x287b54),_0x2dd696=_0x3514a8===_0xd18956(0x8e)?'movies':_0xd18956(_0x28ad8a._0xa3df63);let _0x53a899=null;if(_0x287b54){if(typeof _0x287b54['runtime']==='number'&&_0x287b54[_0xd18956(_0x28ad8a._0x1ad1d7)]>0x0)_0x53a899=_0x287b54[_0xd18956(_0x28ad8a._0x1ad1d7)];else Array['isArray'](_0x287b54[_0xd18956(_0x28ad8a._0x5b41fa)])&&_0x287b54['episode_run_time'][_0xd18956(0x14c)]>0x0&&(_0x53a899=_0x287b54[_0xd18956(0xc8)][0x0]);}let _0x4a1e91;try{_0x4a1e91=yield fetchSitemapEntries(_0x71024c);}catch(_0x905535){const _0x51387b=getHttpStatusFromError(_0x905535);return _0x51387b===0x193||_0x51387b===0x194||_0x51387b===0x1f7||isCloudflareBlockedError(_0x905535)?console[_0xd18956(0x152)]('[CinemaCity]\x20Sitemap\x20fetch\x20failed:\x20HTTP\x20'+(_0x51387b||_0xd18956(0xb5))):console['warn']('[CinemaCity]\x20Sitemap\x20fetch\x20failed:\x20'+(_0x905535[_0xd18956(_0x28ad8a._0x45e1bf)]||_0x905535)),null;}let _0x33d2a3=null,_0x48d40b=-Infinity;const _0x56fc93=[];for(const _0x30e611 of _0x4a1e91){if(_0x30e611['kind']!==_0x2dd696)continue;const _0x43c803=scoreSitemapEntry(_0x30e611,_0xf910d4,_0xe2fd24);_0x43c803>=0xfa&&_0x56fc93['push']({'entry':_0x30e611,'score':_0x43c803}),_0x43c803>_0x48d40b&&(_0x48d40b=_0x43c803,_0x33d2a3=_0x30e611);}if(!_0x33d2a3||_0x48d40b<0xfa)return console[_0xd18956(0x137)](_0xd18956(_0x28ad8a._0xf9c23a)+_0xf910d4['join'](_0xd18956(0x103))+_0xd18956(0xf1)+Math['round'](_0x48d40b)+')'),null;if(_0x4ae077){_0x56fc93['sort']((_0xd9274b,_0x36fbb8)=>_0x36fbb8[_0xd18956(0x102)]-_0xd9274b['score']);const _0x5aa2b2=_0x56fc93[_0xd18956(0xae)](0x0,0x3);for(const _0x29ac56 of _0x5aa2b2){const _0x2a8e85=yield verifyCandidateImdb(_0x29ac56['entry'][_0xd18956(_0x28ad8a._0x855816)],_0x4ae077);if(_0x2a8e85===_0x4ae077)return console[_0xd18956(_0x28ad8a._0x1e6084)]('[CinemaCity]\x20Sitemap\x20IMDb\x20verified:\x20'+_0xf910d4[0x0]+_0xd18956(_0x28ad8a._0x4b4a7e)+_0x29ac56['entry']['url']),{'url':_0x29ac56[_0xd18956(_0x28ad8a._0x188727)]['url'],'title':_0xf910d4[0x0]||_0x29ac56['entry']['title'],'year':_0xe2fd24||_0x29ac56[_0xd18956(0x131)][_0xd18956(_0x28ad8a._0x59f058)],'runtime':_0x53a899};if(_0x2a8e85&&_0x2a8e85!==_0x4ae077){console[_0xd18956(_0x28ad8a._0x1e6084)](_0xd18956(_0x28ad8a._0x121ded)+_0x29ac56[_0xd18956(_0x28ad8a._0x188727)][_0xd18956(_0x28ad8a._0x45d731)]+_0xd18956(_0x28ad8a._0xe3af80)+_0x2a8e85+',\x20expected\x20'+_0x4ae077);continue;}}const _0x197c6e=_0x48d40b>=0x3b6;if(!_0x197c6e)return console['log'](_0xd18956(0xb0)+_0xf910d4[_0xd18956(_0x28ad8a._0x193f08)]('\x20/\x20')+_0xd18956(_0x28ad8a._0x2940c0)+Math['round'](_0x48d40b)+')'),null;}return console['log']('[CinemaCity]\x20Sitemap\x20match:\x20'+_0xf910d4[0x0]+_0xd18956(0xb2)+_0x33d2a3[_0xd18956(_0x28ad8a._0x855816)]+_0xd18956(_0x28ad8a._0x46bce2)+Math['round'](_0x48d40b)+']'),{'url':_0x33d2a3['url'],'title':_0xf910d4[0x0]||_0x33d2a3['title'],'year':_0xe2fd24||_0x33d2a3['year'],'runtime':_0x53a899};});}function getTmdbMetadata(_0x5bbefe,_0x366e02){const _0x475ed0={_0x3a1e2e:0x8e};return __async(this,null,function*(){const _0x3433f2=_0x5249;try{let _0x542500=String(_0x5bbefe||'')[_0x3433f2(0x122)](),_0x494f1d=_0x366e02===_0x3433f2(0x8e)?_0x3433f2(_0x475ed0._0x3a1e2e):'tv',_0x30ab92=null;if(/^tt\d+$/i['test'](_0x542500)){const _0x1face6='https://api.themoviedb.org/3/find/'+encodeURIComponent(_0x542500)+'?api_key='+TMDB_API_KEY+'&external_source=imdb_id&language=en-US',_0x5c98d6=yield fetchWithTimeout(_0x1face6,{'timeout':FETCH_TIMEOUT});if(_0x5c98d6['ok']){const _0x54bb46=yield _0x5c98d6[_0x3433f2(0xdf)](),_0x1b4907=_0x494f1d==='movie'?_0x54bb46==null?void 0x0:_0x54bb46['movie_results']:_0x54bb46==null?void 0x0:_0x54bb46['tv_results'];Array[_0x3433f2(0x13d)](_0x1b4907)&&_0x1b4907['length']>0x0&&(_0x30ab92=_0x1b4907[0x0]['id']);}}else/^\d+$/['test'](_0x542500)&&(_0x30ab92=_0x542500);if(_0x30ab92){const _0x16e7b3='https://api.themoviedb.org/3/'+_0x494f1d+'/'+_0x30ab92+'?api_key='+TMDB_API_KEY+'&language=en-US',_0x36838b=yield fetchWithTimeout(_0x16e7b3,{'timeout':FETCH_TIMEOUT});if(_0x36838b['ok'])return yield _0x36838b[_0x3433f2(0xdf)]();}return null;}catch(_0x898689){return console[_0x3433f2(0x10e)](_0x3433f2(0x94),_0x898689),null;}});}function getEpisodeTitle(_0xf4325a,_0x285a76,_0x247843){const _0x4f2ca7={_0x310ad6:0xcb,_0x15c955:0xc4};return __async(this,null,function*(){const _0x4de4b3=_0x5249;try{const _0x31cbdc=yield fetchWithTimeout('https://api.themoviedb.org/3/tv/'+encodeURIComponent(_0xf4325a)+_0x4de4b3(_0x4f2ca7._0x310ad6)+_0x285a76+'?api_key='+TMDB_API_KEY,{'timeout':FETCH_TIMEOUT});if(_0x31cbdc['ok']){const _0x101d27=yield _0x31cbdc['json']();if(_0x101d27&&Array['isArray'](_0x101d27[_0x4de4b3(_0x4f2ca7._0x15c955)])){const _0x3dada6=parseInt(_0x247843,0xa),_0x3cf2d1=_0x101d27['episodes']['find'](_0x735a0b=>_0x735a0b['episode_number']===_0x3dada6);if(_0x3cf2d1&&_0x3cf2d1['name'])return _0x3cf2d1['name'];}}}catch(_0x1a8709){}return'';});}function getIdsFromKitsu(_0x57539e,_0x576407,_0x1d5402,_0x81ea3d=null){const _0x115ffc={_0x12713d:0xfb,_0x135647:0xa9,_0x1ddf41:0xa9,_0x57d114:0x133,_0xd7491a:0x126,_0x4a3bc0:0xf2,_0x39b394:0x122,_0x37a24d:0x104,_0x105494:0x117,_0x1d5f08:0x10e,_0x5b4b70:0xad};return __async(this,null,function*(){const _0x2ef4e2=_0x5249;try{if(!_0x57539e)return null;const _0xd3b1e4=new URLSearchParams(),_0xc96a49=Number['parseInt'](String(_0x1d5402||''),0xa),_0x4f12b6=Number[_0x2ef4e2(_0x115ffc._0x12713d)](String(_0x576407||''),0xa);_0xd3b1e4[_0x2ef4e2(_0x115ffc._0x135647)]('ep',Number['isInteger'](_0xc96a49)&&_0xc96a49>0x0?String(_0xc96a49):'1');Number['isInteger'](_0x4f12b6)&&_0x4f12b6>=0x0&&_0xd3b1e4[_0x2ef4e2(_0x115ffc._0x1ddf41)]('s',String(_0x4f12b6));const _0x54d49b=getMappingLanguage(_0x81ea3d);_0x54d49b&&_0xd3b1e4['set'](_0x2ef4e2(0x9c),_0x54d49b);const _0x2f5e59=getMappingApiUrl()+_0x2ef4e2(0x107)+encodeURIComponent(String(_0x57539e)[_0x2ef4e2(0x122)]())+'?'+_0xd3b1e4['toString'](),_0x1c467e=yield fetchWithTimeout(_0x2f5e59,{'timeout':FETCH_TIMEOUT});if(!_0x1c467e['ok'])return null;const _0x3f08af=yield _0x1c467e[_0x2ef4e2(0xdf)](),_0x2b24d9=_0x3f08af&&_0x3f08af['mappings']&&_0x3f08af['mappings'][_0x2ef4e2(0x133)]?_0x3f08af[_0x2ef4e2(0xd7)][_0x2ef4e2(_0x115ffc._0x57d114)]:{},_0x571576=_0x3f08af&&_0x3f08af['mappings']&&(_0x3f08af[_0x2ef4e2(0xd7)][_0x2ef4e2(_0x115ffc._0xd7491a)]||_0x3f08af['mappings'][_0x2ef4e2(_0x115ffc._0x4a3bc0)])||_0x3f08af&&(_0x3f08af['tmdb_episode']||_0x3f08af[_0x2ef4e2(0xf2)])||null,_0x117482=_0x2b24d9&&/^\d+$/['test'](String(_0x2b24d9['tmdb']||'')['trim']())?String(_0x2b24d9[_0x2ef4e2(0xf6)])[_0x2ef4e2(0x122)]():null,_0x12bed9=_0x2b24d9&&/^tt\d+$/i['test'](String(_0x2b24d9['imdb']||'')[_0x2ef4e2(_0x115ffc._0x39b394)]())?String(_0x2b24d9[_0x2ef4e2(_0x115ffc._0x37a24d)])[_0x2ef4e2(0x122)]():null,_0x2b8d00=Number[_0x2ef4e2(_0x115ffc._0x12713d)](String(_0x571576&&(_0x571576[_0x2ef4e2(0xb3)]||_0x571576[_0x2ef4e2(0x116)]||_0x571576['season_number'])||''),0xa),_0x58722a=Number['parseInt'](String(_0x571576&&(_0x571576['episode']||_0x571576[_0x2ef4e2(0x8f)]||_0x571576[_0x2ef4e2(_0x115ffc._0x105494)])||''),0xa),_0x598191=Number[_0x2ef4e2(_0x115ffc._0x12713d)](String(_0x571576&&(_0x571576[_0x2ef4e2(0xc3)]||_0x571576['raw_episode_number']||_0x571576[_0x2ef4e2(0xd5)])||''),0xa);return{'tmdbId':_0x117482,'imdbId':_0x12bed9,'mappedSeason':Number['isInteger'](_0x2b8d00)&&_0x2b8d00>0x0?_0x2b8d00:null,'mappedEpisode':Number['isInteger'](_0x58722a)&&_0x58722a>0x0?_0x58722a:null,'rawEpisodeNumber':Number[_0x2ef4e2(0x112)](_0x598191)&&_0x598191>0x0?_0x598191:null};}catch(_0x9f6278){return console[_0x2ef4e2(_0x115ffc._0x1d5f08)](_0x2ef4e2(_0x115ffc._0x5b4b70),_0x9f6278),null;}});}function parseCompositeSeriesId(_0x3043f2,_0x3a4bab,_0x136cee){const _0x2e686d={_0x34eaef:0x122,_0x30b17f:0xfb,_0x48728b:0xfb,_0x5ae188:0xba},_0x3a44e2=_0x2ef61b,_0x1401b4={'normalizedId':String(_0x3043f2||'')[_0x3a44e2(_0x2e686d._0x34eaef)](),'season':Number['isInteger'](_0x3a4bab)?_0x3a4bab:Number[_0x3a44e2(_0x2e686d._0x30b17f)](_0x3a4bab,0xa)||0x1,'episode':Number['isInteger'](_0x136cee)?_0x136cee:Number[_0x3a44e2(_0x2e686d._0x48728b)](_0x136cee,0xa)||0x1},_0x506fb6=_0x1401b4[_0x3a44e2(0xb1)][_0x3a44e2(0x13f)](/^(tt\d+|\d+|tmdb:\d+):(\d+):(\d+)$/i);return _0x506fb6&&(_0x1401b4['normalizedId']=_0x506fb6[0x1],_0x1401b4['season']=Number['parseInt'](_0x506fb6[0x2],0xa)||_0x1401b4[_0x3a44e2(0xb3)],_0x1401b4[_0x3a44e2(_0x2e686d._0x5ae188)]=Number['parseInt'](_0x506fb6[0x3],0xa)||_0x1401b4['episode']),_0x1401b4;}function buildDownloadUrl(_0x10dbd0,_0x32df4e){const _0x414afc={_0x53c585:0x14c,_0x11b7a0:0x92,_0x4c2031:0x92,_0xf9f66b:0x92,_0x40e22c:0xdd},_0x3e8927=_0x2ef61b,_0x3cfd5c=_0x10dbd0['indexOf']('/public_files/');if(_0x3cfd5c===-0x1)return null;const _0x4a4354=_0x10dbd0[_0x3e8927(0xa5)](0x0,_0x3cfd5c+_0x3e8927(0x125)[_0x3e8927(_0x414afc._0x53c585)]),_0x1b6856=_0x10dbd0['substring'](_0x3cfd5c+'/public_files/'['length']),_0x154d8c=_0x1b6856[_0x3e8927(0x114)](','),_0x37f4ae=_0x154d8c[_0x3e8927(_0x414afc._0x11b7a0)](_0xdbad30=>_0xdbad30['includes'](_0x3e8927(0xfd))&&_0xdbad30['endsWith'](_0x3e8927(0xc5)))||_0x154d8c[_0x3e8927(_0x414afc._0x4c2031)](_0x41f5c5=>_0x41f5c5['endsWith'](_0x3e8927(0xc5)));if(!_0x37f4ae)return null;const _0x1a6e95=_0x154d8c[_0x3e8927(_0x414afc._0xf9f66b)](_0x4c463d=>/italian|italiano/i['test'](_0x4c463d)&&_0x4c463d[_0x3e8927(0xbd)](_0x3e8927(0xa7))),_0x3baada=_0x154d8c['find'](_0x548fa3=>_0x548fa3['includes'](_0x3e8927(0x134))),_0x4a10df=_0x4a4354+_0x1b6856+(_0x3baada?'':_0x3e8927(_0x414afc._0x40e22c));return{'url':_0x4a10df,'hasItalian':!!_0x1a6e95};}function extractStreamFromAtob(_0x2ac4a8,_0x505ccc,_0x1eaeb8,_0x3406e8){const _0xaf6586={_0x5deb83:0x14c},_0x371cb9=_0x2ef61b,_0x52f96f=/atob\s*\(\s*['"]([^"']{20,})['"]\s*\)/gi;let _0x33d095;while((_0x33d095=_0x52f96f['exec'](_0x2ac4a8))!==null){try{const _0x5cf89e=base64Decode(_0x33d095[0x1]);if(!_0x5cf89e||_0x5cf89e[_0x371cb9(_0xaf6586._0x5deb83)]<0x14)continue;const _0x4b7a59=_0x5cf89e['match'](new RegExp(_0x371cb9(0x145),'s'));if(_0x4b7a59)try{const _0x6bd3a0=JSON['parse'](_0x4b7a59[0x1]);if(Array[_0x371cb9(0x13d)](_0x6bd3a0)&&_0x6bd3a0['length']>0x0){if(_0x6bd3a0[0x0]['folder']&&Array['isArray'](_0x6bd3a0[0x0]['folder'])){const _0x2433d0=(_0x1eaeb8||0x1)-0x1,_0x3347ab=_0x6bd3a0[_0x2433d0];if(_0x3347ab&&_0x3347ab['folder']){const _0x1ba5cb=(_0x3406e8||0x1)-0x1,_0x40d114=_0x3347ab['folder'][_0x1ba5cb];if(_0x40d114&&_0x40d114['file']){const _0x1122d2=buildDownloadUrl(_0x40d114[_0x371cb9(0xd2)],_0x505ccc);if(_0x1122d2)return _0x1122d2;}}}const _0xac1822=_0x6bd3a0[0x0][_0x371cb9(0xd2)];if(_0xac1822&&_0xac1822['startsWith']('http')){const _0x4d440b=buildDownloadUrl(_0xac1822,_0x505ccc);if(_0x4d440b)return _0x4d440b;}}}catch(_0x5a7897){}}catch(_0x42d8f8){}}return null;}function extractDownloadLinks(_0x4a3de6){const _0x2632a3={_0xa3b03b:0x122,_0x416ba4:0x14c},_0x464076=_0x2ef61b,_0x55933c=[],_0x8d8963=/<a\s[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;let _0x48e66b;while((_0x48e66b=_0x8d8963[_0x464076(0xb9)](_0x4a3de6))!==null){const _0x434faf=_0x48e66b[0x1][_0x464076(_0x2632a3._0xa3b03b)](),_0x2bcd7a=_0x48e66b[0x2]['replace'](/<[^>]+>/g,'')['trim']();if(!/\.(mp4|m3u8|mkv|avi|mov|webm)([?#].*)?$/i['test'](_0x434faf))continue;if(_0x434faf[_0x464076(_0x2632a3._0x416ba4)]<0xa)continue;_0x55933c[_0x464076(0xd9)]({'url':_0x434faf,'text':_0x2bcd7a['toLowerCase']()});}return _0x55933c;}function resolveUrl(_0x4421ac,_0x17d239){const _0x589a58=_0x2ef61b;try{return new URL(_0x17d239,_0x4421ac)[_0x589a58(0x11f)]();}catch(_0x23e9f2){return _0x17d239;}}function getStreams(_0x41dacb,_0x720e67,_0x330564,_0x3c7c01,_0x422a0f=null){const _0x90c14={_0x2096c3:0x8e,_0x38d486:0x11a,_0x33b623:0x10a,_0x4d65ce:0x11c,_0x24a956:0x13f,_0x8a91a7:0xef,_0x461f45:0xc3,_0x3d9284:0xb4,_0x4eef60:0xdf,_0x1d16e2:0x14a,_0x273204:0xa4,_0x14ba3e:0x100,_0x3948e9:0x14a,_0x263ed7:0xed,_0x392a57:0x9f,_0xd3ba53:0xcc,_0x53957f:0xac,_0x3c95da:0x9a,_0x17d888:0x148,_0x89e151:0x10e};return __async(this,null,function*(){const _0x394365=_0x5249,_0x1bfba2=parseCompositeSeriesId(_0x41dacb,_0x330564,_0x3c7c01);_0x41dacb=_0x1bfba2[_0x394365(0xb1)],_0x330564=_0x1bfba2['season'],_0x3c7c01=_0x1bfba2['episode'];let _0xaf616a=String(_0x41dacb||'')[_0x394365(0x122)]();const _0x5ac481=_0x720e67==='tv'||_0x720e67===_0x394365(0x132)||_0x720e67==='anime'?'tv':_0x394365(_0x90c14._0x2096c3),_0x1da1f7=_0x422a0f&&/^\d+$/['test'](String(_0x422a0f[_0x394365(0x153)]||''))?String(_0x422a0f['tmdbId']):null,_0x2e8164=_0x422a0f&&/^tt\d+$/i[_0x394365(_0x90c14._0x38d486)](String(_0x422a0f['imdbId']||''))?String(_0x422a0f['imdbId']):null,_0x4a0be7=_0x422a0f&&/^\d+$/['test'](String(_0x422a0f['kitsuId']||''))?String(_0x422a0f['kitsuId']):null,_0x22a906=_0x422a0f&&_0x422a0f[_0x394365(_0x90c14._0x33b623)]===!![];if(_0xaf616a[_0x394365(_0x90c14._0x4d65ce)]('kitsu:')||_0x4a0be7){const _0x57bd82=_0x4a0be7||((_0xaf616a[_0x394365(_0x90c14._0x24a956)](/^kitsu:(\d+)/i)||[])[0x1]||null),_0x45ff7c=_0x22a906?_0x330564:null,_0x1a004c=_0x57bd82?yield getIdsFromKitsu(_0x57bd82,_0x45ff7c,_0x3c7c01,_0x422a0f):null;if(_0x1a004c){if(_0x1a004c['imdbId'])_0xaf616a=_0x1a004c[_0x394365(0x10f)];else _0x1a004c['tmdbId']&&(_0xaf616a=_0x1a004c['tmdbId']);if(_0x1a004c['mappedSeason']&&_0x1a004c[_0x394365(_0x90c14._0x8a91a7)])_0x330564=_0x1a004c['mappedSeason'],_0x3c7c01=_0x1a004c[_0x394365(0xef)];else _0x1a004c['rawEpisodeNumber']&&(_0x3c7c01=_0x1a004c[_0x394365(_0x90c14._0x461f45)]);}}if(!_0xaf616a[_0x394365(0x11c)]('tt')&&_0x2e8164)_0xaf616a=_0x2e8164;else!/^\d+$/[_0x394365(0x11a)](_0xaf616a)&&_0x1da1f7&&(_0xaf616a=_0x1da1f7);let _0x2f605c=_0xaf616a[_0x394365(0xf7)](/\D/g,'');if(!_0xaf616a['startsWith']('tt')){if(_0x422a0f&&_0x422a0f[_0x394365(0x10f)]&&_0x422a0f['imdbId']['startsWith']('tt'))_0xaf616a=_0x422a0f[_0x394365(0x10f)];else try{const _0xffb582=_0x2f605c;if(_0xffb582){let _0x59b9f1='';_0x5ac481==='movie'?_0x59b9f1='https://api.themoviedb.org/3/movie/'+_0xffb582+_0x394365(_0x90c14._0x3d9284)+TMDB_API_KEY:_0x59b9f1='https://api.themoviedb.org/3/tv/'+_0xffb582+_0x394365(0x12f)+TMDB_API_KEY;const _0xeae01e=yield fetchWithTimeout(_0x59b9f1,{'timeout':FETCH_TIMEOUT});if(_0xeae01e['ok']){const _0x493c65=yield _0xeae01e[_0x394365(_0x90c14._0x4eef60)]();_0x493c65[_0x394365(0xbb)]&&(_0xaf616a=_0x493c65['imdb_id']);}}}catch(_0x541acd){console[_0x394365(0x10e)]('[CinemaCity]\x20TMDB\x20to\x20IMDb\x20resolution\x20error:',_0x541acd);}}if(!_0xaf616a[_0x394365(0x11c)]('tt'))return[];try{let _0x22a44c=yield searchBySitemap(_0xaf616a,_0x5ac481,_0x422a0f);if(!_0x22a44c||!_0x22a44c['url'])return[];const _0x4236c7=_0x22a44c['url'],_0x5089b2=(_0x22a44c['title']||_0xaf616a)['replace'](/\s*\(.*?\)\s*/g,'')[_0x394365(0x122)]();let _0x103121='';_0x5ac481==='tv'&&_0x2f605c&&(_0x103121=yield getEpisodeTitle(_0x2f605c,_0x330564,_0x3c7c01));let _0x451a5b;try{_0x451a5b=yield fetchViaWorker(_0x4236c7);}catch(_0x3ec4f1){return console['warn'](_0x394365(0xf9)+_0x3ec4f1['message']),[];}if(_0x451a5b['length']<0x1f4||_0x451a5b[_0x394365(_0x90c14._0x1d16e2)]('Just\x20a\x20moment')||_0x451a5b[_0x394365(0x14a)]('admin')&&_0x451a5b['includes']('Unlimited'))return console['warn'](_0x394365(_0x90c14._0x273204)+_0x451a5b[_0x394365(0x14c)]+'\x20chars)'),[];const _0x2454ee=extractDownloadLinks(_0x451a5b);let _0x3955c5=![];if(_0x2454ee[_0x394365(0x14c)]===0x0){const _0x2caabe=_0x5ac481==='tv'?_0x330564:null,_0x14809a=_0x5ac481==='tv'?_0x3c7c01:null,_0x2dab09=extractStreamFromAtob(_0x451a5b,_0x5089b2,_0x2caabe,_0x14809a);_0x2dab09&&(_0x2454ee[_0x394365(0xd9)]({'url':_0x2dab09['url'],'text':''}),_0x3955c5=_0x2dab09[_0x394365(_0x90c14._0x14ba3e)]);}let _0x2ade03=null;if(_0x2454ee[_0x394365(0x14c)]===0x0)return console['log']('[CinemaCity]\x20No\x20streams\x20available'),[];for(const _0x4c57b2 of _0x2454ee){const _0x205f3b=_0x4c57b2[_0x394365(0xac)];if(_0x205f3b[_0x394365(_0x90c14._0x3948e9)](_0x394365(_0x90c14._0x263ed7))||_0x205f3b[_0x394365(0x14a)](_0x394365(_0x90c14._0x392a57))||_0x205f3b[_0x394365(0x14a)](_0x394365(0xe1))){_0x2ade03=_0x4c57b2[_0x394365(_0x90c14._0xd3ba53)],_0x3955c5=!![];break;}}if(!_0x2ade03)for(const _0x8bae0a of _0x2454ee){if(_0x8bae0a['text'][_0x394365(_0x90c14._0x3948e9)]('eng')||_0x8bae0a[_0x394365(_0x90c14._0x53957f)]['includes'](_0x394365(_0x90c14._0x3c95da)))continue;_0x2ade03=_0x8bae0a['url'];break;}if(!_0x2ade03)_0x2ade03=_0x2454ee[0x0]['url'];const _0x2ba831=resolveUrl(_0x4236c7,_0x2ade03);console['log'](_0x394365(0x138)+_0x2ba831);const _0x5caa19={'title':_0x5089b2,'year':_0x22a44c['year'],'mediaType':_0x5ac481,'season':_0x5ac481==='tv'?_0x330564:null,'episode':_0x5ac481==='tv'?_0x3c7c01:null,'episodeTitle':_0x103121,'runtime':_0x22a44c['runtime']},_0x11831c={'name':'CinemaCity','title':_0x5089b2,'year':_0x22a44c[_0x394365(0xce)],'season':_0x5ac481==='tv'?_0x330564:null,'episode':_0x5ac481==='tv'?_0x3c7c01:null,'isTv':_0x5ac481==='tv','url':_0x2ba831,'quality':'1080p','type':_0x394365(0xfe),'language':_0x394365(_0x90c14._0x17d888),'runtime':_0x22a44c['runtime'],'behaviorHints':{'notWebReady':!![]},'headers':{'Referer':_0x394365(0x155),'User-Agent':'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/125.0.0.0\x20Safari/537.36'}};return[formatStream(_0x11831c,'CinemaCity',_0x5caa19)];}catch(_0x372518){return console[_0x394365(_0x90c14._0x89e151)]('[CinemaCity]\x20Error:',_0x372518),[];}});}module[_0x2ef61b(0x158)]={'getStreams':getStreams};

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "cinemacity", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_VERSION_MERGE_ADAPTER_START */
function cloudbankVersionMerge(engines, providerId) {
  var primary = engines[0].provider;
  var merged = Object.assign({}, primary);
  function platform(args) {
    var options = args[4];
    var hint = options && options.platform || (typeof globalThis !== 'undefined' && (globalThis.VUEO_PLATFORM || globalThis.PLATFORM || globalThis.platform));
    if (!hint && typeof navigator !== 'undefined') hint = navigator.userAgent;
    hint = String(hint || '').toLowerCase();
    if (/ios|iphone|ipad/.test(hint)) return 'ios';
    if (/android/.test(hint)) return 'android';
    return hint;
  }
  function available(engine, args) {
    if (!engine.enabled) return false;
    if (!engine.disabledPlatforms.length) return true;
    var current = platform(args);
    // Preserve source platform restrictions when the host cannot identify its platform.
    return !!current && engine.disabledPlatforms.indexOf(current) < 0;
  }
  function key(value) {
    if (value == null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return '[' + value.map(key).join(',') + ']';
    return '{' + Object.keys(value).sort().map(function(k) { return JSON.stringify(k) + ':' + key(value[k]); }).join(',') + '}';
  }
  function combine(results) {
    var seen = Object.create(null), out = [];
    results.forEach(function(rows) {
      if (!Array.isArray(rows)) return;
      rows.forEach(function(stream) {
        if (!stream || typeof stream.url !== 'string' || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return;
        var identity;
        try { identity = key([stream.url, stream.name || '', stream.headers || {}, stream.subtitles || [], stream.audio || stream.language || '', stream.quality || '']); }
        catch (_) { identity = String(stream.url) + '/' + String(stream.name || ''); }
        if (seen[identity]) return;
        seen[identity] = true;
        out.push(Object.assign({}, stream, { provider: providerId }));
      });
    });
    return out;
  }
  merged.getStreams = function(id, type, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    type = type === 'series' ? 'tv' : type;
    if (!String(id || '').trim() || (type !== 'movie' && type !== 'tv')) return Promise.resolve([]);
    if (type === 'tv' && (!Number.isInteger(Number(season)) || Number(season) < 0 || !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(id); args[1] = type;
    if (type === 'tv') { args[2] = Number(season); args[3] = Number(episode); }
    var deadline = Date.now() + 18500;
    var active = engines.filter(function(engine) { return available(engine, args); });
    var results = active.map(function() { return []; });
    return new Promise(function(resolve) {
      var done = false, primaryDone = false, alternateStarted = false, alternateDone = false;
      var timers = [];
      function finish() {
        if (done) return; done = true;
        timers.forEach(clearTimeout);
        resolve(combine(results));
      }
      function attempt(index, ms, next) {
        if (done || Date.now() >= deadline) { next(); return; }
        var settled = false;
        var timer = setTimeout(function() { settle([]); }, Math.min(ms, deadline - Date.now())); timers.push(timer);
        function settle(rows) {
          if (settled || done) return; settled = true; clearTimeout(timer);
          results[index] = Array.isArray(rows) ? rows : [];
          next();
        }
        Promise.resolve().then(function() { return active[index].provider.getStreams.apply(active[index].provider, args); }).then(settle, function() { settle([]); });
      }
      function alternate(index) {
        if (done) return;
        if (index >= active.length) { alternateDone = true; if (primaryDone) finish(); return; }
        attempt(index, 6000, function() {
          if (combine([results[index]]).length) { alternateDone = true; if (primaryDone) finish(); }
          else alternate(index + 1);
        });
      }
      function startAlternate() {
        if (alternateStarted || done) return; alternateStarted = true; alternate(1);
      }
      if (!active.length) { finish(); return; }
      timers.push(setTimeout(finish, 18500));
      // A fast successful primary starts no duplicate engine. A slow or failed one unlocks the fallback.
      timers.push(setTimeout(startAlternate, 5000));
      attempt(0, 18500, function() {
        primaryDone = true;
        if (combine([results[0]]).length) { finish(); return; }
        startAlternate();
        if (alternateDone) finish();
      });
    });
  };
  // Preserve primary settings and add missing alternate controls/options under the same provider ID.
  if (engines.some(function(engine) { return engine.enabled && typeof engine.provider.onSettings === 'function'; })) {
    merged.onSettings = function() {
      var args = arguments;
      return Promise.all(engines.filter(function(engine) { return engine.enabled && typeof engine.provider.onSettings === 'function'; }).map(function(engine) {
        return new Promise(function(resolve) {
          var timer = setTimeout(function() { resolve([]); }, 1500);
          Promise.resolve().then(function() { return engine.provider.onSettings.apply(engine.provider, args); }).then(function(value) { clearTimeout(timer); resolve(value); }, function() { clearTimeout(timer); resolve([]); });
        });
      })).then(function(values) {
        if (values.length && !Array.isArray(values[0])) return values[0];
        var out = [], keys = Object.create(null), headers = Object.create(null);
        values.forEach(function(rows) {
          if (!Array.isArray(rows)) return;
          rows.forEach(function(setting) {
            if (!setting || typeof setting !== 'object') return;
            if (!setting.key) {
              var identity = key(setting); if (!headers[identity]) { headers[identity] = true; out.push(setting); } return;
            }
            var existing = keys[setting.key];
            if (!existing) { existing = Object.assign({}, setting); if (Array.isArray(setting.options)) existing.options = setting.options.slice(); keys[setting.key] = existing; out.push(existing); return; }
            if (existing.type === setting.type && Array.isArray(existing.options) && Array.isArray(setting.options)) {
              setting.options.forEach(function(option) { if (!existing.options.some(function(current) { return current.value === option.value; })) existing.options.push(option); });
            }
          });
        });
        return out;
      });
    };
  }
  return merged;
}
function cloudbankMergedBudgetFetch(nativeFetch, deadline) {
  function bounded(run) {
    var remaining = Math.min(2200, deadline - Date.now());
    if (remaining <= 0) return Promise.reject(new Error('Merged engine budget exhausted'));
    return new Promise(function(resolve, reject) {
      var timer = setTimeout(function() { reject(new Error('Merged engine request timeout')); }, remaining);
      Promise.resolve().then(run).then(function(value) { clearTimeout(timer); resolve(value); }, function(error) { clearTimeout(timer); reject(error); });
    });
  }
  return function(url, options) {
    return bounded(function() { return nativeFetch(url, options); }).then(function(response) {
      return { ok: response.ok, status: response.status, statusText: response.statusText, url: response.url, headers: response.headers,
        text: function() { return bounded(function() { return response.text(); }); },
        json: function() { return bounded(function() { return response.json(); }); },
        arrayBuffer: function() { return bounded(function() { return response.arrayBuffer(); }); } };
    });
  };
}
function cloudbankMergedMetadataFetch(nativeFetch) {
  return function(url, options) {
    var raw = typeof url === 'string' ? url : url && url.url;
    var match = typeof raw === 'string' && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(raw);
    if (!match || options && options.method && String(options.method).toUpperCase() !== 'GET' || typeof vueoSharedTmdb !== 'function') return nativeFetch(url, options);
    var context = typeof globalThis !== 'undefined' ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof context === 'string') { try { context = JSON.parse(context); } catch (_) { context = null; } }
    var contextId = context && (context.tmdbId || context.tmdb && context.tmdb.id);
    if (contextId && String(contextId) !== match[2]) return nativeFetch(url, options);
    return vueoSharedTmdb(raw, function() {
      return nativeFetch(url, options).then(function(response) { if (!response.ok) throw new Error('TMDB HTTP ' + response.status); return response.json(); });
    }).then(function(data) {
      var body = JSON.stringify(data);
      return { ok: true, status: 200, url: raw, headers: { get: function(name) { return String(name).toLowerCase() === 'content-type' ? 'application/json' : null; } },
        json: function() { return Promise.resolve(JSON.parse(body)); }, text: function() { return Promise.resolve(body); } };
    });
  };
}
/* CLOUDBANK_VERSION_MERGE_ADAPTER_END */

var cloudbankMergedEngines = [{ id: "cinemacity", enabled: true, disabledPlatforms: [], provider: module.exports }];
cloudbankMergedEngines.push({ id: "cinemacity-v2", enabled: true, disabledPlatforms: [], provider: (function() {
  function createEngine(deadline) {
  var embedded = { exports: {} };
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported merged module: " + name);
    return require(name);
  }
  (function(module, exports, require, fetch, global) {
/* CLOUDBANK_MERGED_ENGINE_START:cinemacity-v2 */
/**
 * cinemacity - Built from src/cinemacity/
 * Generated: 2026-06-01T14:20:20.706Z
 */
var __create = Object.create;
var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// src/cinemacity/index.js
var import_cheerio_without_node_native = __toESM(require("cheerio-without-node-native"));

// src/cinemacity/constants.js
var MAIN_URL = "https://cinemacity.cc";
var HEADERS = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36",
  "Cookie": "dle_user_id=32729; dle_password=894171c6a8dab18ee594d5c652009a35;",
  "Referer": "https://cinemacity.cc/"
};
var TMDB_API_KEY = "1865f43a0549ca50d341dd9ab8b29f49";

// src/cinemacity/utils.js
var atobPolyfill = (str) => {
  try {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    let output = "";
    str = String(str).replace(/[=]+$/, "");
    if (str.length % 4 === 1)
      return "";
    for (let bc = 0, bs = 0, buffer, i = 0; buffer = str.charAt(i++); ~buffer && (bs = bc % 4 ? bs * 64 + buffer : buffer, bc++ % 4) ? output += String.fromCharCode(255 & bs >> (-2 * bc & 6)) : 0) {
      buffer = chars.indexOf(buffer);
    }
    return output;
  } catch (e) {
    return "";
  }
};
function fetchText(_0) {
  return __async(this, arguments, function* (url, options = {}) {
    const response = yield fetch(url, __spreadValues({
      headers: options.headers || HEADERS,
      skipSizeCheck: true
    }, options));
    return yield response.text();
  });
}
function extractQuality(url) {
  const low = (url || "").toLowerCase();
  if (low.includes("2160p") || low.includes("4k"))
    return "4K";
  if (low.includes("1080p"))
    return "1080p";
  if (low.includes("720p"))
    return "720p";
  if (low.includes("480p"))
    return "480p";
  if (low.includes("360p"))
    return "360p";
  return "HD";
}

// src/cinemacity/index.js
function getStreams(tmdbId, mediaType, season, episode) {
  return __async(this, null, function* () {
    var _a;
    const streams = [];
    try {
      const tmdbUrl = `https://api.themoviedb.org/3/${mediaType === "tv" ? "tv" : "movie"}/${tmdbId}?api_key=${TMDB_API_KEY}&append_to_response=external_ids`;
      const tmdbRes = yield fetch(tmdbUrl, { skipSizeCheck: true });
      const tmdbData = yield tmdbRes.json();
      const imdbId = ((_a = tmdbData.external_ids) == null ? void 0 : _a.imdb_id) || tmdbData.imdb_id;
      const animeTitle = mediaType === "movie" ? tmdbData.title : tmdbData.name;
      if (!animeTitle && !imdbId)
        return [];
      const searchQuery = imdbId || animeTitle;
      const searchUrl = `${MAIN_URL}/?do=search&subaction=search&search_start=0&full_search=0&story=${encodeURIComponent(searchQuery)}`;
      console.log(`[CinemaCity] Searching for: ${searchQuery}`);
      const searchHtml = yield fetchText(searchUrl);
      const $search = import_cheerio_without_node_native.default.load(searchHtml);
      let mediaUrl = null;
      $search("div.dar-short_item").each((i, el) => {
        if (mediaUrl)
          return;
        const anchor = $search(el).find("a").filter((idx, a) => ($search(a).attr("href") || "").includes(".html")).first();
        if (!anchor.length)
          return;
        const href = anchor.attr("href");
        const foundTitle = anchor.text().toLowerCase();
        if (imdbId && searchHtml.includes(imdbId)) {
          mediaUrl = href;
        } else if (foundTitle.includes(animeTitle.toLowerCase()) || animeTitle.toLowerCase().includes(foundTitle)) {
          mediaUrl = href;
        }
      });
      if (!mediaUrl && imdbId && searchQuery !== animeTitle) {
        console.log(`[CinemaCity] IMDB search failed, falling back to title search: ${animeTitle}`);
        const titleSearchUrl = `${MAIN_URL}/?do=search&subaction=search&search_start=0&full_search=0&story=${encodeURIComponent(animeTitle)}`;
        const titleSearchHtml = yield fetchText(titleSearchUrl);
        const $titleSearch = import_cheerio_without_node_native.default.load(titleSearchHtml);
        $titleSearch("div.dar-short_item").each((i, el) => {
          if (mediaUrl)
            return;
          const anchor = $titleSearch(el).find("a").filter((idx, a) => ($titleSearch(a).attr("href") || "").includes(".html")).first();
          if (anchor.length)
            mediaUrl = anchor.attr("href");
        });
      }
      if (!mediaUrl) {
        console.log(`[CinemaCity] No media found for ${animeTitle}`);
        return [];
      }
      console.log(`[CinemaCity] Loading media page: ${mediaUrl}`);
      const pageHtml = yield fetchText(mediaUrl);
      const $page = import_cheerio_without_node_native.default.load(pageHtml);
      let fileData = null;
      let globalSubtitleData = null;
      $page("script").each((i, el) => {
        if (fileData)
          return;
        const html = $page(el).html();
        if (html && html.includes("atob")) {
          const regex = /atob\s*\(\s*(['"])(.*?)\1\s*\)/g;
          let match;
          while ((match = regex.exec(html)) !== null) {
            try {
              const decoded = atobPolyfill(match[2]);
              const fileMatch = decoded.match(new RegExp(`file\\s*:\\s*(['"])(.*?)\\1`, "s")) || decoded.match(new RegExp("file\\s*:\\s*(\\[.*?\\])", "s")) || decoded.match(new RegExp("file\\s*:\\s*(\\{.*?\\})", "s"));
              const subMatch = decoded.match(new RegExp(`subtitle\\s*:\\s*(['"])(.*?)\\1`, "s"));
              if (fileMatch) {
                let rawFile = fileMatch[2] || fileMatch[1];
                if (rawFile && rawFile.length > 5) {
                  if (rawFile.startsWith("[") || rawFile.startsWith("{")) {
                    try {
                      const unescaped = rawFile.replace(/\\(.)/g, "$1");
                      fileData = JSON.parse(unescaped);
                    } catch (e) {
                      try {
                        fileData = JSON.parse(rawFile);
                      } catch (e2) {
                        fileData = rawFile;
                      }
                    }
                  } else {
                    fileData = rawFile;
                  }
                }
              }
              if (subMatch) {
                globalSubtitleData = subMatch[2];
              }
              if (fileData)
                break;
            } catch (err) {
            }
          }
        }
      });
      if (!fileData) {
        console.log(`[CinemaCity] Failed to extract player data`);
        return [];
      }
      const parseSubtitles = (raw) => {
        const subtitles = [];
        if (!raw || typeof raw !== "string")
          return subtitles;
        raw.split(",").forEach((entry) => {
          const match = entry.trim().match(/\[(.+?)\](https?:\/\/.+)/);
          if (match) {
            subtitles.push({
              url: match[2],
              language: match[1],
              name: match[1],
              headers: { Referer: "https://cinemacity.cc/" }
            });
          }
        });
        return subtitles;
      };
      const addStream = (url, title, quality, subtitles) => {
        if (!url || !url.startsWith("http") || url.length < 15)
          return;
        streams.push({
          name: "CinemaCity",
          title,
          url,
          quality: quality || extractQuality(url),
          headers: __spreadProps(__spreadValues({}, HEADERS), {
            Referer: "https://cinemacity.cc/"
          }),
          subtitles: subtitles || []
        });
      };
      const processStr = (str, title, subtitles) => {
        if (str.includes(".urlset/master.m3u8")) {
          addStream(str, title, "Auto", subtitles);
        } else {
          const urls = str.includes("[") ? str.split(",") : [str];
          urls.forEach((u) => {
            const m = u.match(/\[(.*?)\](.*)/);
            if (m)
              addStream(m[2], title, m[1], subtitles);
            else
              addStream(u, title, extractQuality(u), subtitles);
          });
        }
      };
      if (mediaType === "movie") {
        if (Array.isArray(fileData)) {
          const obj = fileData.find((f) => !f.folder && f.file) || fileData[0];
          if (obj && obj.file) {
            const subs = parseSubtitles(obj.subtitle || globalSubtitleData);
            processStr(obj.file, animeTitle, subs);
          }
        } else if (typeof fileData === "string") {
          const subs = parseSubtitles(globalSubtitleData);
          processStr(fileData, animeTitle, subs);
        }
      } else {
        if (Array.isArray(fileData)) {
          const sLabel = `Season ${season}`;
          const sObj = fileData.find((s) => (s.title || "").includes(sLabel) || (s.title || "").includes(`S${season}`));
          if (sObj && sObj.folder) {
            const eLabel = `Episode ${episode}`;
            const eObj = sObj.folder.find((e) => (e.title || "").includes(eLabel) || (e.title || "").includes(`E${episode}`));
            if (eObj && eObj.file) {
              const subs = parseSubtitles(eObj.subtitle || sObj.subtitle || globalSubtitleData);
              processStr(eObj.file, `${animeTitle} S${season}E${episode}`, subs);
            }
          }
        }
      }
      console.log(`[CinemaCity] Successfully processed ${streams.length} streams`);
      return streams;
    } catch (error) {
      console.error(`[CinemaCity] Error in getStreams: ${error.message}`);
      return [];
    }
  });
}
module.exports = { getStreams };

/* CLOUDBANK_MERGED_ENGINE_END:cinemacity-v2 */
  })(embedded, embedded.exports, portableRequire, cloudbankMergedBudgetFetch(cloudbankMergedMetadataFetch(fetch), deadline), typeof globalThis !== "undefined" ? globalThis : global);
  return Object.assign({}, embedded.exports);
  }
  var settingsProvider = createEngine(Date.now() + 6000);
  return Object.assign({}, settingsProvider, { getStreams: function() {
    // A fresh request scope prevents an expired scan from borrowing a later scan's deadline.
    var engine = createEngine(Date.now() + 6000);
    return engine.getStreams.apply(engine, arguments);
  } });
})() });
module.exports = cloudbankVersionMerge(cloudbankMergedEngines, "cinemacity");
if (typeof globalThis !== "undefined") { globalThis.getStreams = module.exports.getStreams; if (module.exports.onSettings) globalThis.onSettings = module.exports.onSettings; }

/* CLOUDBANK_PLAYIMDB_DISPLAY_START */
/* CLOUDBANK_PLAYIMDB_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  if (providerId === "playimdb") return provider; // Reference output stays exactly upstream.
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name) || (lines.length ? lines[0] : "");
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    var labelledAudio = /🌍\s*([^|\n]+)/.exec(originalTitle);
    if (!audioLang && labelledAudio) audioLang = language(labelledAudio[1]);
    var filenameAudio = /(?:^|[._ -])(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese)(?=[._ -]|$)/i.exec(clean(stream.fileName || stream.filename));
    if (!audioLang && filenameAudio) audioLang = language(filenameAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage)) || /\boriginal[- ]audio\b/i.test(text)) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    var labelledServer = /📌\s*([^|\n]+)/.exec(originalTitle);
    if (!server && labelledServer) server = usable(labelledServer[1]);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    var firstLine = lines.length ? "🎬 " + lines[0] : "";
    // Match PlayIMDb's original typography and order, without its guessed defaults.
    if (displayTitle) {
      firstLine = type === "tv" ? "🎬 " + usable(meta.title || meta.name) + " - S" + Number(season) + "E" + Number(episode) + (year ? " (" + year[0] + ")" : "") :
        "🎬 " + usable(meta.title || meta.name) + (year ? " - " + year[0] : "");
    }
    var qualityDisplay = qualityLabel === "4K" ? "2160P" : qualityLabel.toUpperCase();
    var audioDisplay = audioLabel.replace(/[- ]Audio/g, "").trim();
    var infoLine = [qualityDisplay ? "💎 " + qualityDisplay : "", audioDisplay ? "🌍 " + audioDisplay : ""].filter(Boolean).join(" | ");
    var bottomLine = [formatLabel ? "🎞️ " + (formatLabel === "HLS" ? "M3U8" : formatLabel) : "", duration ? "⏱️ " + duration : "", "📌 " + server].filter(Boolean).join(" | ");
    var nameQuality = qualityLabel === "4K" ? "4K UHD" : qualityLabel === "1080p" ? "1080p FHD" : qualityLabel === "720p" ? "720p HD" : qualityLabel;
    output.name = ["🟡 " + providerName, nameQuality, audioLabel ? audioLabel.replace(/ Audio/g, "-Audio") : ""].filter(Boolean).join(" | ");
    output.title = [firstLine, infoLine, bottomLine].filter(Boolean).join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "CinemaCity", "cinemacity");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
/* CLOUDBANK_PLAYIMDB_DISPLAY_END */
