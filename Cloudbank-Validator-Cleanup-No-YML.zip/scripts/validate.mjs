import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { createRequire } from 'node:module';
const nodeRequire = createRequire(import.meta.url);
const runtimeModules = new Set(['cheerio-without-node-native', 'crypto-js']);

const root = process.cwd();
const fail = message => {
  console.error(`Validation failed: ${message}`);
  process.exit(1);
};

const readJson = relativePath => {
  const fullPath = path.join(root, relativePath);
  if (!fs.existsSync(fullPath)) fail(`Missing ${relativePath}`);
  try {
    return JSON.parse(fs.readFileSync(fullPath, 'utf8'));
  } catch (error) {
    fail(`Invalid JSON in ${relativePath}: ${error.message}`);
  }
};

const manifest = readJson('manifest.json');
if (typeof manifest.name !== 'string' || !manifest.name.trim()) fail('manifest.name is required');
if (!/^\d+\.\d+\.\d+$/.test(manifest.version || '')) fail('manifest.version must use semantic versioning');
if (!Array.isArray(manifest.scrapers)) fail('manifest.scrapers must be an array');

const ids = new Set();
const filenames = new Set();
const providerDir = path.join(root, 'providers');
const actualProviderFiles = fs.existsSync(providerDir)
  ? fs.readdirSync(providerDir)
      .filter(name => name.endsWith('.js') && name !== '_template.js')
      .map(name => `providers/${name}`)
      .sort()
  : [];

const requiredFields = [
  'id', 'name', 'description', 'version', 'author',
  'supportedTypes', 'filename', 'enabled'
];

for (const scraper of manifest.scrapers) {
  for (const field of requiredFields) {
    if (scraper[field] === undefined || scraper[field] === null) fail(`Provider is missing ${field}`);
  }

  if (!/^[a-z0-9][a-z0-9-]*$/.test(scraper.id)) fail(`Invalid provider id: ${scraper.id}`);
  if (ids.has(scraper.id)) fail(`Duplicate provider id: ${scraper.id}`);
  ids.add(scraper.id);

  for (const field of ['id', 'name', 'description', 'version', 'author', 'filename']) {
    if (typeof scraper[field] !== 'string' || !scraper[field].trim()) fail(`${scraper.id}: ${field} must be a nonempty string`);
  }
  if (typeof scraper.enabled !== 'boolean') fail(`${scraper.id}: enabled must be boolean`);
  if (!Number.isInteger(scraper.runtimeTimeoutMs) || scraper.runtimeTimeoutMs < 1 || scraper.runtimeTimeoutMs > 20000) {
    fail(`${scraper.id}: runtimeTimeoutMs must be an integer from 1 to 20000`);
  }

  if (!/^\d+\.\d+\.\d+$/.test(scraper.version)) fail(`Invalid version for ${scraper.id}`);

  if (!Array.isArray(scraper.supportedTypes) || scraper.supportedTypes.length === 0) {
    fail(`supportedTypes is required for ${scraper.id}`);
  }

  const allowedTypes = new Set(['movie', 'tv']);
  for (const type of scraper.supportedTypes) {
    if (!allowedTypes.has(type)) fail(`Unsupported media type ${type} in ${scraper.id}`);
  }

  if (typeof scraper.filename !== 'string' || !/^providers\/[a-z0-9][a-z0-9-]*\.js$/.test(scraper.filename)) {
    fail(`Invalid filename for ${scraper.id}`);
  }

  if (filenames.has(scraper.filename)) {
    fail(`Duplicate provider filename: ${scraper.filename}`);
  }
  filenames.add(scraper.filename);

  const providerPath = path.join(root, scraper.filename);
  if (!fs.existsSync(providerDir)) fail('Missing providers directory');
  if (fs.lstatSync(providerDir).isSymbolicLink()) fail('providers directory must not be a symlink');
  if (!fs.existsSync(providerPath)) fail(`Missing ${scraper.filename}`);

  if (fs.lstatSync(providerPath).isSymbolicLink()) fail(`Provider cannot be a symlink: ${scraper.filename}`);
  const source = fs.readFileSync(providerPath, 'utf8');

  // Validate the provider interface, not historical marker comments,
  // helper names, or provider-specific implementation choices.
  const moduleObject = { exports: {} };

  const sandbox = {
    module: moduleObject,
    exports: moduleObject.exports,
    require: name => {
      if (!runtimeModules.has(name)) throw new Error(`Unsupported embedded runtime module: ${name}`);
      return nodeRequire(name);
    },
    console,
    Promise,
    URL,
    URLSearchParams,
    setTimeout,
    clearTimeout,
    Buffer,
    process: { env: {} },
    fetch: () => { throw new Error('Network access is forbidden during static validation'); },
    atob: globalThis.atob,
    btoa: globalThis.btoa
  };

  // React Native style provider compatibility.
  // Some existing Nuvio-compatible providers reference global/globalThis.
  sandbox.global = sandbox;
  sandbox.globalThis = sandbox;

  try {
    vm.runInNewContext(source, sandbox, {
      filename: scraper.filename,
      timeout: 2000
    });
  } catch (error) {
    fail(`Cannot load ${scraper.filename}: ${error.message}`);
  }

  if (typeof moduleObject.exports.getStreams !== 'function') {
    fail(`${scraper.filename} must export getStreams`);
  }
}

const manifestFiles = [...filenames].sort();

for (const providerFile of actualProviderFiles) {
  if (!filenames.has(providerFile)) {
    fail(`Provider file is not listed in manifest: ${providerFile}`);
  }
}

for (const manifestFile of manifestFiles) {
  if (!actualProviderFiles.includes(manifestFile)) {
    fail(`Manifest references missing provider file: ${manifestFile}`);
  }
}

console.log(`Validated Cloudbank with ${manifest.scrapers.length} provider(s).`);
