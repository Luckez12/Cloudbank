# Nuvio Plugins - Compiled by =[D3adly]=

A collection of high-quality local scrapers for the Nuvio streaming application. These scrapers allow you to fetch premium streams from various sources directly within the app.

# My Other Repo's
- **All Anime** - https://github.com/D3adlyRocket/Anime-Nuvio
- **All Hindi** - https://github.com/D3adlyRocket/Hindi-Nuvio
- **Android TV** - https://github.com/D3adlyRocket/Nuvio-TV
- **Showbox Private** - https://github.com/D3adlyRocket/ShowboxTV

## Installation

1. Open **Nuvio** app
2. Go to **Settings → Local Scrapers**
3. Add this repository URL:
   ```
   https://raw.githubusercontent.com/NuvioPlugin/All-in-One-Nuvio/refs/heads/main/manifest.json
   ```
4. Enable the scrapers you want to use

## Available Scrapers 

| Provider | Language | Content | Quality | NuvioApp | NuvioTV |
|---|---|---|---|---|---|
| [![4khdhub.png](https://i.postimg.cc/Z5B7RF79/4khdhub.png)](https://postimg.cc/21YF9vfm) 4KHDHub | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇮🇳 | Film & Serial | 4K / 1080p / 720p | ✅ | ✅ |
| [![animekai.png](https://i.postimg.cc/cLCqcnFV/animekai.png)](https://postimg.cc/9r6Nmr5p) AnimeKai | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇯🇵 | Anime | 1080p / 720p | ✅ | ✅ |
[![animepahe.png](https://i.postimg.cc/SKQFpzFY/animepahe.png)](https://postimg.cc/MnLr7HGz) AnimePahe | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇯🇵 | Anime | 1080p / 720p | ✅ | ✅ |
| [![allwish.png](https://i.postimg.cc/sgPDCG12/allwish.png)](https://postimg.cc/jD5rz5HV) AllWish | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇯🇵 | Anime | 1080p / 720p | ✅ | ✅ |
| [![animesalt.png](https://i.postimg.cc/Bn5QfPtt/animesalt.png)](https://postimg.cc/TKwXrwVX) AnimeSalt | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇮🇳 | Anime | 1080p / 720p | ✅ | ✅ |
| [![animesama.png](https://i.postimg.cc/nhKcf9Mz/animesama.png)](https://postimg.cc/qNRd8RsV) AnimeSama | 🇫🇷 | Anime | 1080p / 720p | ✅ | ✅ |
| [![animeworld.png](https://i.postimg.cc/8zdPgfsc/animeworld.png)](https://postimg.cc/cvHNQHRG) AnimeWorld | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇮🇳 | Anime | 1080p / 720p | ✅ | ✅ |
[![anidb.png](https://i.postimg.cc/448mQF9x/anidb.png)](https://postimg.cc/grZzYssC) AniDB | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇯🇵 | Anime | 1080p / 720p | ✅ | ✅ |
[![castle.png](https://i.postimg.cc/4yqkvYvX/castle.png)](https://postimg.cc/gLVTmkB7) Castle | 🏴󠁧󠁢󠁥󠁮󠁧󠁿  | Film & Serial | 1080p / 720p | ✅ | ✅ |
[![cinefreak.png](https://i.postimg.cc/NfmLvGnK/cinefreak.png)](https://postimg.cc/fJWMxsDs) CineFreak | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇮🇳  | Film & Serial | 4K / 1080p / 720p | ✅ | ✅ |
[![dhamermovies.png](https://i.postimg.cc/jdZ9VgDq/dhamermovies.png)](https://postimg.cc/svGK7JPb) Dahmermovies | 🏴󠁧󠁢󠁥󠁮󠁧󠁿  | Film & Serial | 4K / 1080p / 720p | ✅ | ✅ |
[![dooflix.png](https://i.postimg.cc/B6Q28JSt/dooflix.png)](https://postimg.cc/Y4ZvZKmw)  DooFlix | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇮🇳 | Film & Serial | 1080p / 720p | ✅ | ✅ |
| [![download-(2).png](https://i.postimg.cc/cJ6s6jq8/download-(2).png)](https://postimg.cc/CZTyQcxF) HDHub4U | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇮🇳 | Film & Serial | 4K / 1080p / 720p | ✅ | ✅ |
| [![kisskh.png](https://i.postimg.cc/Qdwzkn9d/kisskh.png)](https://postimg.cc/K17QmfD6) KissKH | 🇰🇷 🇨🇳 🇯🇵 | Asian Movies / Drama | 1080p / 720p | ✅ | ✅ |
[![movieblast.png](https://i.postimg.cc/5yhYZ3DZ/movieblast.png)](https://postimg.cc/5Qm2zw43) MovieBlast | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇮🇳 | Film & Serial | 1080p / 720p | ✅ | ✅ |
[![moviesdrive.png](https://i.postimg.cc/PrKhFqtK/moviesdrive.png)](https://postimg.cc/56HZXbQF) MoviesDrive | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 | Film & Serial | 4K / 1080p / 720p | ✅ | ✅ |
[![movieshunt.png](https://i.postimg.cc/CMZsDDRd/movieshunt.png)](https://postimg.cc/RqBtxWQz) MoviesHunt | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇮🇳 | Film & Serial | 4K / 1080p / 720p | ✅ | ✅ |
[![movix.jpg](https://i.postimg.cc/VNrWycrg/movix.jpg)](https://postimg.cc/CZ0qDX4n) Movix | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇫🇷 | Film & Serial | 1080p / 720p | ✅ | ✅ |
[![netmirror.png](https://i.postimg.cc/sXFMmJyg/netmirror.png)](https://postimg.cc/B8gZQHXr) Netmirror | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 | Film & Serial | 1080p / 720p | ✅ | ✅ |
[![onetouchtv.png](https://i.postimg.cc/MKsp4xjy/onetouchtv.png)](https://postimg.cc/kBbC60s4) OneTouchTV | 🇰🇷 🇨🇳 🇯🇵 | Asian Movies / Drama | 720p | ✅ | ✅ |
[![onlykdrama.jpg](https://i.postimg.cc/7PjN888q/onlykdrama.jpg)](https://postimg.cc/DmdGLNwN) OnlyKDrama | 🇰🇷 | Asian Movies / Drama | 1080p/ 720p | ✅ | ✅ |
[![showbox.png](https://i.postimg.cc/nzzVyqYQ/showbox.png)](https://postimg.cc/67kNR2P9) ShowBox | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 | Film & Serial | 4K 1080p / 720p | ✅ | ✅ |
[![streamflix.png](https://i.postimg.cc/sXFMmJyD/streamflix.png)](https://postimg.cc/McDZKVvh) Streamflix | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 | Film & Serial | 1080p / 720p | ✅ | ✅ |
| [![uhdmovies.png](https://i.postimg.cc/VkCg1svN/uhdmovies.png)](https://postimg.cc/3k3mFTgM) UHDMovies | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 🇮🇳 | Film & Serial | 4K / 1080p / 720p | ✅ | ✅ |
| [![videasy.png](https://i.postimg.cc/MpML0kPV/videasy.png)](https://postimg.cc/VJw41hck) VidEasy | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 | Film & Serial | 1080p / 720p | ✅ | ✅ |
| 🎥 VidSrc | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 | Film & Serial | 1080p / 720p | ✅ | ✅ |
| 🎬 VidLink | 🏴󠁧󠁢󠁥󠁮󠁧󠁿 | Film & Serial | 1080p / 720p | ✅ | ✅ |


## Features

- 🎬 Movies and TV Shows support
- 🎯 Automatic TMDB integration
- 📊 Multiple quality options
- 🌍 Multi-language support
- ⚡ Fast and reliable scraping
- 🔒 Proper headers and referer handling

## Performance

- **Average Search Time**: 5-15 seconds
- **Success Rate**: 85%+
- **Quality Support**: Up to 4K (2160p)
- **Concurrent Requests**: Optimized for stability

## License

This project is licensed under the GNU General Public License v3.0 - see the LICENSE file for details.

## Disclaimer

This project is for educational purposes only. Users are responsible for ensuring their use complies with applicable laws and regulations in their jurisdiction.

## Credits

A masive shoutout to all the developers who have created these plugins.
- **Yoruix**, **Paregi12**, **Phisher98**, **Wooodyhood**, **Piratezoro9 (Kabir)**, **KennethJYS**, **Real-Morpheus**, **Xyr0nX/Antonio**, **Yatin-Code**, **RaymondNoodles**

## Support & Donation

If you enjoy these scrapers and want to support ongoing development and maintenance, you can donate on Ko-fi:

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/paregi)

- **Ko-fi**: [https://ko-fi.com/paregi](https://ko-fi.com/paregi)

---

**Created with ❤️ for Nuvio**
