// Imported provider: purstream; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
function _0x506c(){var _0x3aa6ed=['AxrLBxm','l3nLyxjJAc1IyxiVC2vHCMnOlW','jMXHBMD1ywDLpwvUlvvt','ntm0mJmWowvqA3LqCG','ihWG8j+xO++4JYa','l2fWAs92mq','Bw92AwvZ','mJaZmda5odbPEe1wzxq','C291CMnLx25HBwu','nZiW','EwvHCG','odG0mdrMshPpAuS','DxjSCW','rhvHBc1bDwrPBW','DgL0Bgu','mJmXntC0neXfCe1NAW','ndGYmdzRvgDfvgC','otK4mJK1Dejvq3D0','Dg9vChbLCKnHC2u','ChvYC3rYzwfT','B3jPz2LUywXFDgL0Bgu','y2X1yG','nKnKywXqtq','Btn1oa','m2TArLPACq','B3jPzW','Ahr0Chm6lY9HCgKUDgHLBw92AwvKyI5VCMCVmY90DI8','C3bSAxq','tvvmveK','l3nLyxnVBI8','CMvMzxjLCG','Ahr0Chm6lY9HCgKUChvYC3rYzwfTlG','Bw92Awu','ic0G','zMLYC3rFywLYx2rHDgu','C291CMnLCW','mta4mha','ANnVBG','Dg9mB3DLCKnHC2u','CMvSzwfZzv9KyxrL','rfvbta','wdi2nq','DxjS','iokaOIa','Ahr0Chm6lY9HCgKUDgHLBw92AwvKyI5VCMCVmY8','zgf0yq','zM9YBwf0','zxHWB3j0CW','zhvYyxrPB24','uhvYC3rYzwfTihWG','vK9tva','BMfTzq','nZiWCa','8j+hQ/cFH7C','vK9tvezs','ttnvoa','DgHLBG','sc4YnJu','zxbPC29Kzv9YDw5FDgLTzq','Bwf0y2G','ihWG','BgvUz3rO','ywjZ','nZjXCg1srMC','l2vWAxnVzguV','mteXndi5u1vrDNHt','sc4YnJq','CMvWBgfJzq','Aw5KzxHpzG','z2v0u3rYzwfTCW','l21LzgLHlW','p2fWAv9RzxK9','CNvUDgLTzq','l3nOzwv0','y2f0y2G','l3n0CMvHBs8'];_0x506c=function(){return _0x3aa6ed;};return _0x506c();}var _0x580258=_0x1911;(function(_0x38a1c2,_0x17aa85){var _0x51a50e={_0x56420f:0x22a,_0x2a43bc:0x22e,_0x4d4e63:0x230,_0x31df36:0x222,_0x1785d0:0x212,_0x5c1eac:0x226},_0x1dc573=_0x1911,_0x1bffda=_0x38a1c2();while(!![]){try{var _0x1b9042=-parseInt(_0x1dc573(0x1eb))/0x1*(-parseInt(_0x1dc573(0x22f))/0x2)+-parseInt(_0x1dc573(_0x51a50e._0x56420f))/0x3+-parseInt(_0x1dc573(_0x51a50e._0x2a43bc))/0x4+-parseInt(_0x1dc573(_0x51a50e._0x4d4e63))/0x5+parseInt(_0x1dc573(0x235))/0x6*(-parseInt(_0x1dc573(_0x51a50e._0x31df36))/0x7)+parseInt(_0x1dc573(_0x51a50e._0x1785d0))/0x8*(-parseInt(_0x1dc573(0x214))/0x9)+parseInt(_0x1dc573(_0x51a50e._0x5c1eac))/0xa;if(_0x1b9042===_0x17aa85)break;else _0x1bffda['push'](_0x1bffda['shift']());}catch(_0x3ce656){_0x1bffda['push'](_0x1bffda['shift']());}}}(_0x506c,0x66790));var DOMAINS_URL='https://raw.githubusercontent.com/wooodyhood/nuvio-repo/main/domains.json',PURSTREAM_FALLBACK=_0x580258(0x234),PURSTREAM_API='https://api.purstream.'+PURSTREAM_FALLBACK+_0x580258(0x224),PURSTREAM_REFERER='https://purstream.'+PURSTREAM_FALLBACK+'/',PURSTREAM_UA='Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/120.0.0.0\x20Safari/537.36',TMDB_KEY='f3d757824f08ea2cff45eb8f47ca3a1e',_cachedEndpoint=null;function getTmdbDetails(_0x2f23a7,_0x21f96b){var _0x51a677={_0x304943:0x1f3,_0x2c882c:0x21a,_0x13bce8:0x221},_0x511197={_0x43fc6a:0x206,_0x706d36:0x21b},_0x2d3d5f={_0x2046ce:0x1f8},_0x117f97=_0x580258,_0x2f14da='https://api.themoviedb.org/3/'+(_0x21f96b==='tv'?'tv':_0x117f97(_0x51a677._0x304943))+'/'+_0x2f23a7+_0x117f97(_0x51a677._0x2c882c)+TMDB_KEY+_0x117f97(_0x51a677._0x13bce8);return fetch(_0x2f14da)['then'](function(_0x4c9287){var _0x2c9698=_0x117f97;return _0x4c9287[_0x2c9698(_0x2d3d5f._0x2046ce)]();})['then'](function(_0x273189){var _0x48ac8a=_0x117f97,_0x2c562c=_0x273189[_0x48ac8a(0x1fa)]||_0x273189['first_air_date']||'';return{'enName':_0x273189['title']||_0x273189[_0x48ac8a(_0x511197._0x43fc6a)]||'Purstream','year':_0x2c562c?_0x2c562c[_0x48ac8a(0x1ee)]('-')[0x0]:'','duration':_0x21f96b==='movie'&&_0x273189[_0x48ac8a(_0x511197._0x706d36)]?_0x273189[_0x48ac8a(_0x511197._0x706d36)]+'\x20min':_0x21f96b==='tv'&&_0x273189[_0x48ac8a(0x20d)]&&_0x273189[_0x48ac8a(0x20d)][_0x48ac8a(0x210)]>0x0?_0x273189['episode_run_time'][0x0]+'\x20min':''};})[_0x117f97(0x21d)](function(){return{'enName':'Purstream','year':'','duration':''};});}function getEpisodeInfo(_0x525c63,_0x3fa140,_0x45d76b){var _0x458986={_0x4ccced:0x213,_0x13d35c:0x20b},_0x2e20d5={_0x102ad0:0x206},_0x41680b=_0x580258;if(!_0x525c63||!_0x3fa140||!_0x45d76b)return Promise['resolve'](null);var _0x31e309=_0x41680b(0x1ed)+_0x525c63+_0x41680b(0x1f0)+_0x3fa140+_0x41680b(_0x458986._0x4ccced)+_0x45d76b+'?api_key='+TMDB_KEY+'&language=en-US';return fetch(_0x31e309)['then'](function(_0x4507ae){var _0x5d4da4=_0x41680b;return _0x4507ae[_0x5d4da4(0x1f8)]();})[_0x41680b(_0x458986._0x13d35c)](function(_0x4fc03a){var _0x22c940=_0x41680b;return{'name':_0x4fc03a[_0x22c940(_0x2e20d5._0x102ad0)]||null,'duration':_0x4fc03a['runtime']?_0x4fc03a['runtime']+'\x20min':null};})[_0x41680b(0x21d)](function(){return null;});}function buildPurstreamTitle(_0x24c2f6,_0x310b87,_0x2a3025,_0x3c8c25,_0x159a42,_0x480a76,_0x3e322a,_0x45fd1d){var _0x4f39b4={_0x18495a:0x208,_0x2c7450:0x231,_0x15d8dd:0x1fb,_0x5c503c:0x229,_0xcb2aa9:0x20a,_0x354e3a:0x231,_0x3b9acf:0x215,_0x470736:0x217,_0x4b0b3a:0x20c,_0x24c330:0x203,_0x4a70af:0x20f,_0xa79864:0x1fe},_0xdadf3c=_0x580258,_0x33741f=_0x310b87['toLowerCase']()['replace'](/p/g,'')+'p',_0x201113='🔥',_0x31c5b6='VF',_0x4ca89f=_0xdadf3c(_0x4f39b4._0x18495a),_0x13dd2c=(String(_0x45fd1d)+'\x20'+String(_0x2a3025))[_0xdadf3c(_0x4f39b4._0x2c7450)]();if(_0x13dd2c[_0xdadf3c(0x217)](_0xdadf3c(0x1ef))!==-0x1||_0x13dd2c['indexOf'](_0xdadf3c(_0x4f39b4._0x15d8dd))!==-0x1)_0x31c5b6='Dual-Audio',_0x4ca89f='🇺🇸\x20•\x20🇫🇷';else _0x13dd2c['indexOf'](_0xdadf3c(0x205))!==-0x1&&(_0x31c5b6='VOSTFR',_0x4ca89f='🇺🇸\x20•\x20🇫🇷');var _0x4b9c9f='🎬\x20';_0x159a42&&_0x480a76?_0x4b9c9f+='S'+_0x159a42+'\x20E'+_0x480a76+(_0x3e322a&&_0x3e322a[_0xdadf3c(0x206)]?_0xdadf3c(0x1f4)+_0x3e322a['name']:'')+'\x20|\x20'+_0x24c2f6['enName']:_0x4b9c9f+=_0x24c2f6['enName']+(_0x24c2f6[_0xdadf3c(_0x4f39b4._0x5c503c)]?'\x20-\x20'+_0x24c2f6['year']:'');var _0x555470=_0x201113+'\x20'+_0x33741f+'\x20|\x20🔊\x20'+_0x31c5b6+_0xdadf3c(0x223)+_0x4ca89f,_0x176d23=(_0x3c8c25||_0xdadf3c(_0x4f39b4._0xcb2aa9))[_0xdadf3c(_0x4f39b4._0x354e3a)](),_0x41647d=_0xdadf3c(_0x4f39b4._0x3b9acf);(_0x13dd2c['indexOf']('HEVC')!==-0x1||_0x13dd2c['indexOf'](_0xdadf3c(0x1fc))!==-0x1||_0x13dd2c[_0xdadf3c(_0x4f39b4._0x470736)]('H265')!==-0x1)&&(_0x41647d=_0xdadf3c(_0x4f39b4._0x4b0b3a));var _0x3109f5=_0x3e322a&&_0x3e322a[_0xdadf3c(0x203)]?_0x3e322a[_0xdadf3c(_0x4f39b4._0x24c330)]:_0x24c2f6[_0xdadf3c(_0x4f39b4._0x24c330)],_0x446916=_0x3109f5?_0xdadf3c(_0x4f39b4._0x4a70af)+_0x3109f5:'',_0x2ba5be='🎯\x20'+_0x176d23+_0xdadf3c(_0x4f39b4._0xa79864)+_0x41647d+'\x20|\x20🎧\x20AAC'+_0x446916;return _0x4b9c9f+'\x0a'+_0x555470+'\x0a'+_0x2ba5be;}function detectPurstreamDomain(){var _0x27cee8={_0x2cecd8:0x20b,_0x278a89:0x21d},_0x3a49ed={_0x53d990:0x232,_0x35f2c1:0x1f2,_0x132ccc:0x224},_0x37cf5b=_0x580258;if(_cachedEndpoint)return Promise['resolve'](_cachedEndpoint);return fetch(DOMAINS_URL)['then'](function(_0x4b1733){if(!_0x4b1733['ok'])throw new Error();return _0x4b1733['json']();})[_0x37cf5b(_0x27cee8._0x2cecd8)](function(_0x464d75){var _0x354ff4=_0x37cf5b,_0x18f47a=_0x464d75[_0x354ff4(_0x3a49ed._0x53d990)]||PURSTREAM_FALLBACK;return _cachedEndpoint={'api':_0x354ff4(_0x3a49ed._0x35f2c1)+_0x18f47a+_0x354ff4(_0x3a49ed._0x132ccc),'referer':'https://purstream.'+_0x18f47a+'/'},_cachedEndpoint;})[_0x37cf5b(_0x27cee8._0x278a89)](function(){return{'api':'https://api.purstream.'+PURSTREAM_FALLBACK+'/api/v1','referer':'https://purstream.'+PURSTREAM_FALLBACK+'/'};});}function applyPurstreamDomain(_0x5d8c19){var _0x4e111c={_0x320bdd:0x1f1},_0x4b4f98=_0x580258;PURSTREAM_API=_0x5d8c19['api'],PURSTREAM_REFERER=_0x5d8c19[_0x4b4f98(_0x4e111c._0x320bdd)];}function cleanTitle(_0xfec9ff){var _0x526636={_0x19a70b:0x216,_0x10348d:0x216,_0x23b993:0x216},_0x32ec58=_0x580258;if(!_0xfec9ff)return'';return _0xfec9ff[_0x32ec58(0x1f9)]()['replace'](/[àáâãäå]/g,'a')['replace'](/[èéêë]/g,'e')[_0x32ec58(0x216)](/[ìíîï]/g,'i')[_0x32ec58(_0x526636._0x19a70b)](/[òóôõö]/g,'o')[_0x32ec58(0x216)](/[ùúûü]/g,'u')[_0x32ec58(_0x526636._0x10348d)](/[^a-z0-9\s]/g,'')[_0x32ec58(_0x526636._0x23b993)](/\s+/g,'\x20')['trim']();}function extractYear(_0x43b6be){var _0x171acd={_0x393eef:0x20e},_0x11dca0=_0x580258;if(!_0x43b6be)return null;var _0x3d72f1=String(_0x43b6be)[_0x11dca0(_0x171acd._0x393eef)](/(\d{4})/);return _0x3d72f1?parseInt(_0x3d72f1[0x1],0xa):null;}function getTmdbSearchMeta(_0x4db8fc,_0x5cb50d){var _0x4bc6b7={_0x373f41:0x20b},_0x106500={_0x102a6a:0x1f5},_0x2fef99=_0x580258,_0x184968=_0x5cb50d==='tv'?'tv':'movie',_0x331138=_0x2fef99(0x1ff)+_0x184968+'/'+_0x4db8fc+'?language=fr-FR&api_key='+TMDB_KEY;return fetch(_0x331138)[_0x2fef99(_0x4bc6b7._0x373f41)](function(_0x4d2459){return _0x4d2459['json']();})[_0x2fef99(0x20b)](function(_0x45e527){var _0xea40de=_0x2fef99;return{'fr':_0x45e527['title']||_0x45e527['name'],'orig':_0x45e527[_0xea40de(0x233)]||_0x45e527['original_name'],'year':extractYear(_0x45e527[_0xea40de(0x1fa)]||_0x45e527[_0xea40de(_0x106500._0x102a6a)])};});}function findPurstreamIdByTitle(_0x280b47,_0x29fc0e,_0x4d2ef){var _0x40c267={_0x250093:0x220},_0x3e3e7e={_0x3184eb:0x200,_0x19ba3e:0x225,_0x1a10ba:0x21f},_0x328754=_0x580258,_0x31b960=encodeURIComponent(_0x280b47);return fetch(PURSTREAM_API+_0x328754(_0x40c267._0x250093)+_0x31b960,{'headers':{'User-Agent':PURSTREAM_UA,'Referer':PURSTREAM_REFERER}})['then'](function(_0x2812dc){return _0x2812dc['json']();})['then'](function(_0x53e343){var _0x5100a0={_0x4d379d:0x22d,_0x20fb3c:0x211},_0x1e5831=_0x328754,_0x21b847=_0x53e343[_0x1e5831(_0x3e3e7e._0x3184eb)]['items'][_0x1e5831(_0x3e3e7e._0x19ba3e)]&&_0x53e343['data'][_0x1e5831(_0x3e3e7e._0x1a10ba)][_0x1e5831(_0x3e3e7e._0x19ba3e)][_0x1e5831(0x21f)]?_0x53e343['data']['items'][_0x1e5831(0x225)]['items']:[];if(_0x21b847['length']===0x0)throw new Error();var _0x998c7=cleanTitle(_0x280b47),_0x2a29b2=_0x21b847['find'](function(_0x1715a5){var _0xff3abe=_0x1e5831,_0x1d013f=extractYear(_0x1715a5['release_date']);return cleanTitle(_0x1715a5[_0xff3abe(_0x5100a0._0x4d379d)])===_0x998c7&&(Math[_0xff3abe(_0x5100a0._0x20fb3c)](_0x4d2ef-_0x1d013f)<=0x1||!_0x4d2ef);})||_0x21b847[0x0];return _0x2a29b2['id'];});}function fetchMovieSources(_0x49430b){var _0x4c2d0b={_0x50c9e8:0x219,_0x531ce5:0x21c},_0x554abb={_0xd3fcd6:0x1f8},_0x8dafd7=_0x580258;return fetch(PURSTREAM_API+_0x8dafd7(_0x4c2d0b._0x50c9e8)+_0x49430b+_0x8dafd7(_0x4c2d0b._0x531ce5),{'headers':{'User-Agent':PURSTREAM_UA,'Referer':PURSTREAM_REFERER}})[_0x8dafd7(0x20b)](function(_0x46650d){var _0xdaec5b=_0x8dafd7;return _0x46650d[_0xdaec5b(_0x554abb._0xd3fcd6)]();})['then'](function(_0x245ec2){var _0x244c94=_0x8dafd7;return _0x245ec2['data']['items'][_0x244c94(0x22b)]||[];});}function fetchEpisodeSources(_0x259bef,_0x1b9d37,_0x2dd536){var _0x32d93e={_0x4d7262:0x21e,_0x21445a:0x20b},_0x751dc3={_0x363a56:0x1f8},_0x12b369=_0x580258;return fetch(PURSTREAM_API+_0x12b369(_0x32d93e._0x4d7262)+_0x259bef+'/episode?season='+(_0x1b9d37||0x1)+'&episode='+(_0x2dd536||0x1),{'headers':{'User-Agent':PURSTREAM_UA,'Referer':PURSTREAM_REFERER}})[_0x12b369(_0x32d93e._0x21445a)](function(_0x4b363d){var _0x3e2e7a=_0x12b369;return _0x4b363d[_0x3e2e7a(_0x751dc3._0x363a56)]();})['then'](function(_0x57ed4f){var _0x366a6f=_0x12b369;return _0x57ed4f[_0x366a6f(0x200)]['items'][_0x366a6f(0x1f6)]||[];});}function parseLang(_0x1b1bbc){var _0x12fd0c={_0x288936:0x231,_0x404031:0x217,_0x4a566e:0x209},_0x32fbcc=_0x580258,_0x58076f=(_0x1b1bbc||'')[_0x32fbcc(_0x12fd0c._0x288936)]();if(_0x58076f[_0x32fbcc(_0x12fd0c._0x404031)]('VOSTFR')!==-0x1)return _0x32fbcc(_0x12fd0c._0x4a566e);if(_0x58076f[_0x32fbcc(_0x12fd0c._0x404031)]('VF')!==-0x1)return'VF';return _0x32fbcc(0x22c);}function parseQuality(_0x11d4c6){var _0x1c4e1e={_0x4dce8f:0x217,_0x4aa00c:0x228,_0x360d99:0x207},_0x2718b2=_0x580258,_0x364254=(_0x11d4c6||'')[_0x2718b2(0x231)]();if(_0x364254[_0x2718b2(_0x1c4e1e._0x4dce8f)]('4K')!==-0x1)return'4K';if(_0x364254[_0x2718b2(0x217)]('1080')!==-0x1)return _0x2718b2(0x1f7);if(_0x364254[_0x2718b2(0x217)](_0x2718b2(_0x1c4e1e._0x4aa00c))!==-0x1)return _0x2718b2(_0x1c4e1e._0x360d99);return'HD';}function normalizeMovieSources(_0x29ba99,_0x22ed47){var _0x175a0e={_0x25f6be:0x236},_0x86ce77={_0x3c58b8:0x20e};return _0x29ba99['filter'](function(_0x4fc8fa){var _0x4b0294=_0x1911;return _0x4fc8fa[_0x4b0294(0x1fd)]&&(_0x4fc8fa['url']['match'](/\.m3u8/i)||_0x4fc8fa['url'][_0x4b0294(_0x86ce77._0x3c58b8)](/\.mp4/i));})['map'](function(_0x1e197e){var _0x269d05=_0x1911,_0x56fac8=parseQuality(_0x1e197e['name']),_0x168dce=_0x1e197e['url']['match'](/\.mp4/i)?'mp4':_0x269d05(_0x175a0e._0x25f6be),_0x53c8d3=parseLang(_0x1e197e['name']),_0x217d9a=buildPurstreamTitle(_0x22ed47,_0x56fac8,_0x53c8d3,_0x168dce,null,null,null,_0x1e197e['name']);return{'name':'Purstream\x20|\x20'+_0x56fac8['toLowerCase']()+_0x269d05(0x20f)+_0x53c8d3,'title':_0x217d9a,'size':_0x217d9a,'description':_0x217d9a,'url':_0x1e197e[_0x269d05(0x1fd)],'quality':'','language':'','format':_0x168dce,'headers':{'User-Agent':PURSTREAM_UA,'Referer':PURSTREAM_REFERER}};});}function _0x1911(_0x5d112d,_0x4880d7){_0x5d112d=_0x5d112d-0x1eb;var _0x506c76=_0x506c();var _0x191140=_0x506c76[_0x5d112d];if(_0x1911['WKkMLS']===undefined){var _0x2654f8=function(_0x412246){var _0x31a8f7='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';var _0x2f23a7='',_0x21f96b='';for(var _0x2f14da=0x0,_0x4c9287,_0x273189,_0x2c562c=0x0;_0x273189=_0x412246['charAt'](_0x2c562c++);~_0x273189&&(_0x4c9287=_0x2f14da%0x4?_0x4c9287*0x40+_0x273189:_0x273189,_0x2f14da++%0x4)?_0x2f23a7+=String['fromCharCode'](0xff&_0x4c9287>>(-0x2*_0x2f14da&0x6)):0x0){_0x273189=_0x31a8f7['indexOf'](_0x273189);}for(var _0x525c63=0x0,_0x3fa140=_0x2f23a7['length'];_0x525c63<_0x3fa140;_0x525c63++){_0x21f96b+='%'+('00'+_0x2f23a7['charCodeAt'](_0x525c63)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x21f96b);};_0x1911['DEJoAK']=_0x2654f8,_0x1911['PhDUJk']={},_0x1911['WKkMLS']=!![];}var _0x129e7d=_0x506c76[0x0],_0x3a8f72=_0x5d112d+_0x129e7d,_0xd390b7=_0x1911['PhDUJk'][_0x3a8f72];return!_0xd390b7?(_0x191140=_0x1911['DEJoAK'](_0x191140),_0x1911['PhDUJk'][_0x3a8f72]=_0x191140):_0x191140=_0xd390b7,_0x191140;}function normalizeEpisodeSources(_0x3ffa77,_0x296e79,_0x46ea42,_0x42f2bb,_0x38e282){var _0x464bdd={_0x5a3d3d:0x201,_0x4513e4:0x204};return _0x3ffa77['map'](function(_0x533f4c){var _0x5f38de=_0x1911,_0xcb09c0=parseQuality(_0x533f4c[_0x5f38de(0x227)]),_0x40dc85=_0x533f4c[_0x5f38de(_0x464bdd._0x5a3d3d)]||'m3u8',_0xa6c753=parseLang(_0x533f4c[_0x5f38de(0x227)]),_0x2f09cb=buildPurstreamTitle(_0x296e79,_0xcb09c0,_0xa6c753,_0x40dc85,_0x46ea42,_0x42f2bb,_0x38e282,_0x533f4c['source_name']);return{'name':_0x5f38de(_0x464bdd._0x4513e4)+_0xcb09c0[_0x5f38de(0x1f9)]()+'\x20|\x20'+_0xa6c753,'title':_0x2f09cb,'size':_0x2f09cb,'description':_0x2f09cb,'url':_0x533f4c['stream_url'],'quality':'','language':'','format':_0x40dc85,'headers':{'User-Agent':PURSTREAM_UA,'Referer':PURSTREAM_REFERER}};});}function getStreams(_0x4baaaa,_0x126066,_0x539bb1,_0x523727){var _0x145974={_0xe84e73:0x1ec},_0x14929b=_0x580258;return Promise['all']([getTmdbDetails(_0x4baaaa,_0x126066),_0x126066==='tv'?getEpisodeInfo(_0x4baaaa,_0x539bb1,_0x523727):Promise['resolve'](null),detectPurstreamDomain(),getTmdbSearchMeta(_0x4baaaa,_0x126066)])[_0x14929b(0x20b)](function(_0x765f04){var _0x3b4f6b={_0x983d65:0x20b},_0x4caf4e=_0x14929b,_0x558699=_0x765f04[0x0],_0x3f90af=_0x765f04[0x1],_0x455d6e=_0x765f04[0x2],_0x400448=_0x765f04[0x3];return applyPurstreamDomain(_0x455d6e),findPurstreamIdByTitle(_0x400448['fr'],_0x126066,_0x400448['year'])[_0x4caf4e(0x21d)](function(){var _0x113277=_0x4caf4e;return findPurstreamIdByTitle(_0x400448[_0x113277(_0x145974._0xe84e73)],_0x126066,_0x400448['year']);})['then'](function(_0x2cac7b){var _0x2c0ec2=_0x4caf4e;return _0x126066==='tv'?fetchEpisodeSources(_0x2cac7b,_0x539bb1,_0x523727)[_0x2c0ec2(_0x3b4f6b._0x983d65)](function(_0x5cea48){return normalizeEpisodeSources(_0x5cea48,_0x558699,_0x539bb1,_0x523727,_0x3f90af);}):fetchMovieSources(_0x2cac7b)['then'](function(_0x5023fe){return normalizeMovieSources(_0x5023fe,_0x558699);});});})['catch'](function(){return[];});}typeof module!=='undefined'&&module[_0x580258(0x202)]?module[_0x580258(0x202)]={'getStreams':getStreams}:global[_0x580258(0x218)]=getStreams;

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "purstream", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();
