// Imported provider: kurage; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
const _0x58353f=_0x5ea7;function _0x5ea7(_0x5e171b,_0x1dfae9){_0x5e171b=_0x5e171b-0x115;const _0x4ec00a=_0x4ec0();let _0x5ea7db=_0x4ec00a[_0x5e171b];if(_0x5ea7['oAoYdE']===undefined){var _0x390fb4=function(_0x4f087f){const _0x4b9854='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0x4c2529='',_0xf0d22d='';for(let _0xd0f73a=0x0,_0x3f0e1d,_0x2c110c,_0x2385c1=0x0;_0x2c110c=_0x4f087f['charAt'](_0x2385c1++);~_0x2c110c&&(_0x3f0e1d=_0xd0f73a%0x4?_0x3f0e1d*0x40+_0x2c110c:_0x2c110c,_0xd0f73a++%0x4)?_0x4c2529+=String['fromCharCode'](0xff&_0x3f0e1d>>(-0x2*_0xd0f73a&0x6)):0x0){_0x2c110c=_0x4b9854['indexOf'](_0x2c110c);}for(let _0xfee7a9=0x0,_0x2e851a=_0x4c2529['length'];_0xfee7a9<_0x2e851a;_0xfee7a9++){_0xf0d22d+='%'+('00'+_0x4c2529['charCodeAt'](_0xfee7a9)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0xf0d22d);};_0x5ea7['kfSCYg']=_0x390fb4,_0x5ea7['HmzvvQ']={},_0x5ea7['oAoYdE']=!![];}const _0x3a0e15=_0x4ec00a[0x0],_0x5b516c=_0x5e171b+_0x3a0e15,_0x1a2831=_0x5ea7['HmzvvQ'][_0x5b516c];return!_0x1a2831?(_0x5ea7db=_0x5ea7['kfSCYg'](_0x5ea7db),_0x5ea7['HmzvvQ'][_0x5b516c]=_0x5ea7db):_0x5ea7db=_0x1a2831,_0x5ea7db;}(function(_0x309d49,_0x1d1ac2){const _0x11a661={_0x3487df:0x11c,_0x104902:0x163,_0x277bbf:0x157,_0x5b688d:0x135,_0x36df7b:0x160,_0x120afb:0x143,_0x5d063f:0x123,_0x24f2de:0x155,_0xab6507:0x159,_0x41e712:0x15d},_0xc5b68c=_0x5ea7,_0x1e4268=_0x309d49();while(!![]){try{const _0x9b0217=-parseInt(_0xc5b68c(_0x11a661._0x3487df))/0x1*(-parseInt(_0xc5b68c(_0x11a661._0x104902))/0x2)+-parseInt(_0xc5b68c(0x167))/0x3*(parseInt(_0xc5b68c(0x12e))/0x4)+parseInt(_0xc5b68c(0x14e))/0x5*(-parseInt(_0xc5b68c(_0x11a661._0x277bbf))/0x6)+parseInt(_0xc5b68c(_0x11a661._0x5b688d))/0x7*(parseInt(_0xc5b68c(_0x11a661._0x36df7b))/0x8)+parseInt(_0xc5b68c(_0x11a661._0x120afb))/0x9*(parseInt(_0xc5b68c(0x11a))/0xa)+-parseInt(_0xc5b68c(_0x11a661._0x5d063f))/0xb*(-parseInt(_0xc5b68c(_0x11a661._0x24f2de))/0xc)+parseInt(_0xc5b68c(_0x11a661._0xab6507))/0xd*(-parseInt(_0xc5b68c(_0x11a661._0x41e712))/0xe);if(_0x9b0217===_0x1d1ac2)break;else _0x1e4268['push'](_0x1e4268['shift']());}catch(_0xba9abc){_0x1e4268['push'](_0x1e4268['shift']());}}}(_0x4ec0,0x8cb8d));var __defProp=Object[_0x58353f(0x133)],__defProps=Object['defineProperties'],__getOwnPropDescs=Object['getOwnPropertyDescriptors'],__getOwnPropSymbols=Object['getOwnPropertySymbols'],__hasOwnProp=Object[_0x58353f(0x151)]['hasOwnProperty'],__propIsEnum=Object[_0x58353f(0x151)][_0x58353f(0x136)],__defNormalProp=(_0x4c2529,_0xf0d22d,_0xd0f73a)=>_0xf0d22d in _0x4c2529?__defProp(_0x4c2529,_0xf0d22d,{'enumerable':!![],'configurable':!![],'writable':!![],'value':_0xd0f73a}):_0x4c2529[_0xf0d22d]=_0xd0f73a,__spreadValues=(_0x3f0e1d,_0x2c110c)=>{const _0x208ed2=_0x58353f;for(var _0x2385c1 in _0x2c110c||(_0x2c110c={}))if(__hasOwnProp['call'](_0x2c110c,_0x2385c1))__defNormalProp(_0x3f0e1d,_0x2385c1,_0x2c110c[_0x2385c1]);if(__getOwnPropSymbols)for(var _0x2385c1 of __getOwnPropSymbols(_0x2c110c)){if(__propIsEnum[_0x208ed2(0x11f)](_0x2c110c,_0x2385c1))__defNormalProp(_0x3f0e1d,_0x2385c1,_0x2c110c[_0x2385c1]);}return _0x3f0e1d;},__spreadProps=(_0xfee7a9,_0x2e851a)=>__defProps(_0xfee7a9,__getOwnPropDescs(_0x2e851a)),__async=(_0x5c523a,_0x4cf45c,_0xbbf5e1)=>{const _0x48ab50={_0xa9f8e3:0x128};return new Promise((_0x5bc88e,_0x2f6717)=>{const _0x55f25e={_0x23a930:0x121},_0x426d25=_0x5ea7;var _0x5a3fd5=_0x49d615=>{const _0x27aedb=_0x5ea7;try{_0x4a91b3(_0xbbf5e1[_0x27aedb(_0x55f25e._0x23a930)](_0x49d615));}catch(_0x11ea2b){_0x2f6717(_0x11ea2b);}},_0x58b612=_0xf94934=>{const _0x1b7332=_0x5ea7;try{_0x4a91b3(_0xbbf5e1[_0x1b7332(_0x48ab50._0xa9f8e3)](_0xf94934));}catch(_0x28a232){_0x2f6717(_0x28a232);}},_0x4a91b3=_0x2dad2e=>_0x2dad2e['done']?_0x5bc88e(_0x2dad2e['value']):Promise['resolve'](_0x2dad2e[_0x426d25(0x138)])[_0x426d25(0x146)](_0x5a3fd5,_0x58b612);_0x4a91b3((_0xbbf5e1=_0xbbf5e1['apply'](_0x5c523a,_0x4cf45c))['next']());});},KURAGE_BASE='https://kurage.live',TMDB_API_KEY='439c478a771f35c05022f9feabcca01c',ANILIST_URL=_0x58353f(0x166),ARM_BASE='https://arm.haglund.dev/api/v2',CINEMETA_URL='https://v3-cinemeta.strem.io/meta',DEFAULT_HEADERS={'User-Agent':'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/120.0.0.0\x20Safari/537.36','Accept':_0x58353f(0x134),'Accept-Language':_0x58353f(0x14f),'Origin':KURAGE_BASE,'Referer':KURAGE_BASE+'/'};function fetchText(_0x1caee2){return __async(this,arguments,function*(_0x101775,_0x5dba55={}){const _0x48138e=_0x5ea7,_0x4b5f74=yield fetch(_0x101775,__spreadProps(__spreadValues({},_0x5dba55),{'headers':__spreadValues(__spreadValues({},DEFAULT_HEADERS),_0x5dba55[_0x48138e(0x144)]||{})}));if(!_0x4b5f74['ok'])throw new Error('HTTP\x20'+_0x4b5f74[_0x48138e(0x12d)]+':\x20'+_0x101775);return yield _0x4b5f74['text']();});}function fetchJson(_0x1e17b4){return __async(this,arguments,function*(_0x4ad1ec,_0x1cb9ec={}){const _0x1eb7d8=yield fetchText(_0x4ad1ec,_0x1cb9ec);return JSON['parse'](_0x1eb7d8);});}function getSyncInfo(_0x1d852b,_0x151384,_0x2c2ed1,_0x446f5a){const _0x3d6c17={_0x3daeaa:0x168,_0x4bea9b:0x145,_0x330783:0x124,_0x95b324:0x140,_0x595a16:0x130};return __async(this,null,function*(){const _0x3b0964={_0x2bb396:0x13c,_0x171955:0x120,_0xcad33e:0x140,_0x2f5e2b:0x13d,_0x964d8d:0x161,_0x1c75e8:0x169,_0x515d37:0x122},_0x21b968=_0x5ea7,_0x129b2e=_0x415e93=>__async(this,null,function*(){const _0x5e2a30=_0x5ea7,_0x503cc2=_0x151384===_0x5e2a30(0x168)?'movie':'series',_0x42e6c9=CINEMETA_URL+'/'+_0x503cc2+'/'+_0x415e93+'.json';try{const _0x5077dc=yield fetchJson(_0x42e6c9),_0x26f5f0=_0x5077dc['meta'];if(!_0x26f5f0)throw new Error('No\x20Cinemata\x20metadata');if(_0x151384==='movie')return{'date':_0x26f5f0[_0x5e2a30(0x13c)]?_0x26f5f0[_0x5e2a30(_0x3b0964._0x2bb396)][_0x5e2a30(_0x3b0964._0x171955)]('T')[0x0]:null,'title':_0x26f5f0[_0x5e2a30(0x169)],'dayIndex':0x1,'runtime':_0x26f5f0[_0x5e2a30(_0x3b0964._0xcad33e)]||_0x5e2a30(0x12b)};const _0x4d0e73=_0x26f5f0[_0x5e2a30(_0x3b0964._0x2f5e2b)]||[],_0x1076d5=_0x4d0e73['find'](_0x36ec1d=>_0x36ec1d['season']==_0x2c2ed1&&_0x36ec1d['episode']==_0x446f5a);if(!_0x1076d5||!_0x1076d5['released'])return{'date':null,'title':null,'dayIndex':0x1,'runtime':'24m'};const _0x59cef5=_0x1076d5[_0x5e2a30(_0x3b0964._0x2bb396)]['split']('T')[0x0],_0x4a8232=_0x4d0e73['filter'](_0x3ef849=>_0x3ef849['season']==_0x2c2ed1&&_0x3ef849[_0x5e2a30(0x13c)]&&_0x3ef849[_0x5e2a30(0x13c)]['split']('T')[0x0]===_0x59cef5&&parseInt(_0x3ef849['episode'])<parseInt(_0x446f5a))[_0x5e2a30(_0x3b0964._0x964d8d)]+0x1;return{'date':_0x59cef5,'title':_0x1076d5[_0x5e2a30(_0x3b0964._0x1c75e8)]||null,'dayIndex':_0x4a8232,'runtime':_0x26f5f0[_0x5e2a30(_0x3b0964._0xcad33e)]||_0x5e2a30(_0x3b0964._0x515d37)};}catch(_0x24169c){return{'date':null,'title':null,'dayIndex':0x1,'runtime':'24m'};}}),_0x5397c3=_0x21b968(0x148)+(_0x151384==='movie'?'movie':'tv')+'/'+_0x1d852b,[_0x3cd5e6,_0x3a3f1a]=yield Promise['all']([fetchJson(_0x5397c3+(_0x151384===_0x21b968(0x168)?'':'/external_ids')+('?api_key='+TMDB_API_KEY)),fetchJson(_0x5397c3+('?api_key='+TMDB_API_KEY))]);let _0x16c1d6=_0x3cd5e6[_0x21b968(0x132)]||null;const _0x2d0242=_0x3a3f1a['name']||_0x3a3f1a['title']||null;if(!_0x16c1d6)try{const _0x2ca554=yield fetchJson(ARM_BASE+_0x21b968(0x154)+_0x1d852b);_0x16c1d6=Array['isArray'](_0x2ca554)&&_0x2ca554[_0x21b968(0x161)]>0x0?_0x2ca554[0x0][_0x21b968(0x127)]:null;}catch(_0x56b588){}if(!_0x16c1d6)throw new Error('No\x20IMDb\x20ID\x20found\x20for\x20TMDB\x20'+_0x1d852b);const _0x2c3bd5=yield _0x129b2e(_0x16c1d6);let _0x26b763=_0x2c3bd5['date'];if(_0x151384===_0x21b968(_0x3d6c17._0x3daeaa)&&_0x3a3f1a['release_date'])_0x26b763=_0x3a3f1a[_0x21b968(0x11d)];if(!_0x26b763)throw new Error('Could\x20not\x20find\x20release\x20date\x20for\x20ID\x20'+_0x16c1d6);const _0x35ac6c=_0x3a3f1a[_0x21b968(0x140)]?_0x3a3f1a['runtime']+'m':_0x2c3bd5['runtime']?_0x2c3bd5[_0x21b968(0x140)][_0x21b968(_0x3d6c17._0x4bea9b)]()[_0x21b968(_0x3d6c17._0x330783)]('m')?_0x2c3bd5[_0x21b968(_0x3d6c17._0x95b324)]:_0x2c3bd5['runtime']+'m':_0x21b968(0x122);return{'imdbId':_0x16c1d6,'tmdbId':_0x1d852b,'releaseDate':_0x26b763,'title':_0x2d0242,'episodeTitle':_0x2c3bd5[_0x21b968(_0x3d6c17._0x595a16)],'dayIndex':_0x2c3bd5[_0x21b968(0x118)],'episode':_0x446f5a,'duration':_0x35ac6c};});}function resolveAnilistId(_0x3daa3e){const _0x35ec31={_0x3d2229:0x14d,_0x2e8bd1:0x158,_0xef8238:0x13f,_0x515e10:0x147,_0x4fae99:0x162,_0x5ac1c7:0x126,_0x1aa730:0x141,_0x3aad67:0x116,_0x4b16ba:0x139,_0xf5552:0x16b,_0x34f79b:0x141,_0x10e370:0x116,_0x1fc841:0x11e,_0x3a59b3:0x161,_0x18a941:0x150};return __async(this,null,function*(){const _0x32e1b8=_0x5ea7;var _0x3f6201,_0xd41751;const {releaseDate:_0x107e3a,title:_0x43b110,episode:_0x16224b,episodeTitle:_0x443d4b,dayIndex:_0x5cbc04}=_0x3daa3e;if(!_0x107e3a||!/^\d{4}-\d{2}-\d{2}/['test'](_0x107e3a))return null;const _0x28284c='query($search:String){Page(perPage:20){media(search:$search,type:ANIME){id\x20type\x20format\x20title{romaji\x20english}startDate{year\x20month\x20day}endDate{year\x20month\x20day}episodes\x20streamingEpisodes{title}}}}';try{const _0x1edad7=yield fetchJson(ANILIST_URL,{'method':_0x32e1b8(_0x35ec31._0x3d2229),'headers':{'Content-Type':_0x32e1b8(_0x35ec31._0x2e8bd1)},'body':JSON['stringify']({'query':_0x28284c,'variables':{'search':_0x43b110}})}),_0xc6d3bc=((_0xd41751=(_0x3f6201=_0x1edad7['data'])==null?void 0x0:_0x3f6201[_0x32e1b8(_0x35ec31._0xef8238)])==null?void 0x0:_0xd41751['media'])||[];if(_0xc6d3bc[_0x32e1b8(0x161)]===0x0)return null;const _0x4c5b38=new Date(_0x107e3a);for(const _0x142a44 of _0xc6d3bc){const _0x428304=_0x142a44['startDate'],_0x46d78e=_0x428304['year']&&_0x428304['month']&&_0x428304['day']?_0x428304['year']+'-'+String(_0x428304[_0x32e1b8(_0x35ec31._0x515e10)])[_0x32e1b8(0x15a)](0x2,'0')+'-'+String(_0x428304['day'])['padStart'](0x2,'0'):null;if(!_0x46d78e)continue;const _0x1c2fc6=new Date(_0x46d78e),_0x1de188=Math['ceil'](Math[_0x32e1b8(_0x35ec31._0x4fae99)](_0x4c5b38[_0x32e1b8(0x126)]()-_0x1c2fc6[_0x32e1b8(_0x35ec31._0x5ac1c7)]())/(0x3e8*0x3c*0x3c*0x18));let _0x389649=![];if(_0x142a44[_0x32e1b8(_0x35ec31._0x1aa730)]===_0x32e1b8(_0x35ec31._0x3aad67)||_0x142a44[_0x32e1b8(0x141)]===_0x32e1b8(0x12a)||_0x142a44['episodes']===0x1){if(_0x1de188<=0x2)_0x389649=!![];}else{const _0x20bc6a=new Date(_0x1c2fc6);_0x20bc6a['setDate'](_0x20bc6a['getDate']()-0x2);if(_0x4c5b38>=_0x20bc6a){if(_0x142a44['endDate']&&_0x142a44[_0x32e1b8(_0x35ec31._0x4b16ba)]['year']){const _0x299545=new Date(_0x142a44['endDate']['year'],(_0x142a44[_0x32e1b8(0x139)]['month']||0xc)-0x1,_0x142a44[_0x32e1b8(_0x35ec31._0x4b16ba)][_0x32e1b8(_0x35ec31._0xf5552)]||0x1f);_0x299545['setDate'](_0x299545[_0x32e1b8(0x15f)]()+0x2);if(_0x4c5b38<=_0x299545)_0x389649=!![];}else _0x389649=!![];}}if(_0x389649){const _0x2c2600=_0x142a44[_0x32e1b8(_0x35ec31._0x34f79b)]!==_0x32e1b8(_0x35ec31._0x10e370)&&_0x142a44[_0x32e1b8(_0x35ec31._0x34f79b)]!=='SPECIAL'&&_0x142a44[_0x32e1b8(0x131)]!==0x1;let _0x359785=_0x2c2600&&_0x16224b?_0x16224b:_0x5cbc04||0x1;const _0x3415fb=_0x142a44[_0x32e1b8(_0x35ec31._0x1fc841)]||[];if(_0x3415fb['length']>0x1&&_0x443d4b){const _0x356602=_0x443d4b[_0x32e1b8(0x115)]()['replace'](/[^a-z0-9]/g,'');for(let _0x2d1e3e=0x0;_0x2d1e3e<_0x3415fb[_0x32e1b8(_0x35ec31._0x3a59b3)];_0x2d1e3e++){const _0x137cad=(_0x3415fb[_0x2d1e3e]['title']||'')['toLowerCase']()[_0x32e1b8(_0x35ec31._0x18a941)](/[^a-z0-9]/g,'');if(_0x137cad&&(_0x137cad[_0x32e1b8(0x165)](_0x356602)!==-0x1||_0x356602['indexOf'](_0x137cad)!==-0x1)){_0x359785=_0x2d1e3e+0x1;break;}}}return{'alId':_0x142a44['id'],'episode':_0x359785};}}}catch(_0xa3e291){}return null;});}function getStreams(_0x2f293c,_0x307e15,_0x5affbb,_0x20dbd9){const _0x1a6f7d={_0x4ea72c:0x153,_0x422cfc:0x15c,_0x532f03:0x12c,_0x4798fa:0x117,_0xcc78c2:0x119,_0x35a217:0x158,_0x5323e7:0x15e};return __async(this,null,function*(){const _0x46d7b6={_0x3655c1:0x14c},_0x135f8a={_0x1d546d:0x13e,_0x466fc4:0x137,_0x4f353d:0x12f,_0x4d2fbf:0x13a,_0x20f822:0x142,_0x734be3:0x11b,_0x138b89:0x14a,_0x1945f5:0x16a},_0x11c46a=_0x5ea7;try{const _0x595a2f=yield getSyncInfo(_0x2f293c,_0x307e15,_0x5affbb,_0x20dbd9),_0x438e73=yield resolveAnilistId(_0x595a2f);if(!_0x438e73||!_0x438e73['alId'])return console['log'](_0x11c46a(_0x1a6f7d._0x4ea72c)+_0x2f293c),[];const {alId:_0x688ae2,episode:_0x24b8f8}=_0x438e73;console[_0x11c46a(0x13b)](_0x11c46a(_0x1a6f7d._0x422cfc)+_0x688ae2+',\x20Episode:\x20'+_0x24b8f8);const _0x3d0623={'0':{'json':{'id':_0x688ae2}},'1':{'json':{'animeId':_0x688ae2,'episode':_0x24b8f8,'language':_0x11c46a(_0x1a6f7d._0x532f03)}},'2':{'json':{'animeId':_0x688ae2,'episode':_0x24b8f8,'language':_0x11c46a(_0x1a6f7d._0x4798fa)}}},_0x4d504b=KURAGE_BASE+_0x11c46a(_0x1a6f7d._0xcc78c2)+encodeURIComponent(JSON['stringify'](_0x3d0623)),_0x1afd11=yield fetchJson(_0x4d504b,{'headers':{'trpc-accept':_0x11c46a(_0x1a6f7d._0x35a217),'x-trpc-source':_0x11c46a(_0x1a6f7d._0x5323e7)}}),_0x1738e0=[];return _0x1afd11[_0x11c46a(0x16c)](_0x4dc964=>{const _0x2d00fc=_0x11c46a;var _0x1e232e,_0x33736c,_0x3d2c9e;const _0x2cbc91=((_0x3d2c9e=(_0x33736c=(_0x1e232e=_0x4dc964['result'])==null?void 0x0:_0x1e232e['data'])==null?void 0x0:_0x33736c['json'])==null?void 0x0:_0x3d2c9e[_0x2d00fc(_0x46d7b6._0x3655c1)])||[];_0x2cbc91[_0x2d00fc(0x16c)](_0x55a323=>{const _0x3764bf=_0x2d00fc,_0x23e5ac=_0x55a323[_0x3764bf(_0x135f8a._0x1d546d)][_0x3764bf(_0x135f8a._0x466fc4)]('/')?''+KURAGE_BASE+_0x55a323['url']:_0x55a323['url'];let _0x56f05b={};try{const _0x2901e8=new URL(_0x23e5ac),_0x2dcd4=_0x2901e8[_0x3764bf(0x14b)]['get']('headers');_0x2dcd4&&(_0x56f05b=JSON[_0x3764bf(0x152)](atob(_0x2dcd4)));}catch(_0x5e4a24){}const _0x2158a1=(_0x55a323['language']||_0x3764bf(0x12c))[_0x3764bf(0x149)](),_0x5b1fb0=_0x2158a1==='SUB'?'Original\x20(SUB)':_0x3764bf(_0x135f8a._0x4f353d);let _0xd826f1=[];_0x307e15===_0x3764bf(0x168)?_0xd826f1=[_0x3764bf(_0x135f8a._0x4d2fbf)+_0x595a2f['title'],'🎞️\x20MP4\x20|\x20⚡\x20Auto\x20|\x20🌍\x20'+_0x5b1fb0+'\x20|\x20⏱️\x20'+_0x595a2f[_0x3764bf(_0x135f8a._0x20f822)]]:_0xd826f1=[_0x3764bf(_0x135f8a._0x4d2fbf)+_0x595a2f['title'],_0x3764bf(0x125)+_0x5affbb+'E'+_0x20dbd9+'\x20-\x20'+(_0x595a2f['episodeTitle']||_0x3764bf(0x156)+_0x24b8f8),_0x3764bf(0x15b)+_0x5b1fb0+_0x3764bf(_0x135f8a._0x734be3)+_0x595a2f['duration']];const _0x11fa8f=_0xd826f1['join']('\x0a');_0x1738e0[_0x3764bf(0x164)]({'name':_0x3764bf(_0x135f8a._0x138b89)+_0x55a323['label']+']\x20('+_0x2158a1+')','title':_0x11fa8f,'url':_0x23e5ac,'quality':'Auto','headers':__spreadValues(__spreadValues({},DEFAULT_HEADERS),_0x56f05b),'provider':'kurage','type':_0x55a323['sourceType']||_0x3764bf(_0x135f8a._0x1945f5)});});}),_0x1738e0;}catch(_0x4c1fcd){return console['error']('[Kurage]\x20Error:\x20'+_0x4c1fcd[_0x11c46a(0x129)]),[];}});}module['exports']={'getStreams':getStreams};function _0x4ec0(){const _0xaae07e=['Aw5JBhvKzxm','8j+oPsbt','z2v0vgLTzq','Aw1KyG','DgHYB3C','BwvZC2fNzq','u1bfq0Lbta','tI9b','C3vI','C3rHDhvZ','nhrny3Dwrq','rw5NBgLZAcaOrfvckq','DgL0Bgu','zxbPC29Kzxm','Aw1KyL9Pza','zgvMAw5LuhjVCgvYDhK','yxbWBgLJyxrPB24VANnVBIWGDgv4Dc9WBgfPBIWGkI8Q','nJy1whvyChrW','ChjVCgvYDhLjC0vUDw1LCMfIBgu','C3rHCNrZv2L0Aa','DMfSDwu','zw5Krgf0zq','8j+oRca','Bg9N','CMvSzwfZzwq','DMLKzw9Z','DxjS','ugfNzq','CNvUDgLTzq','zM9YBwf0','zhvYyxrPB24','ndC3mtC3m2XytwnTyW','AgvHzgvYCW','Dg9tDhjPBMC','DgHLBG','Bw9UDgG','Ahr0Chm6lY9HCgKUDgHLBw92AwvKyI5VCMCVmY8','Dg9vChbLCKnHC2u','s3vYywDLihWGqxv0BYb8ifS','C2vHCMnOugfYyw1Z','C2vYDMvYCW','ue9tva','nwn1r3nXCW','zw4TvvmSzw47Ct0WlJK','CMvWBgfJzq','ChjVDg90ExbL','CgfYC2u','w0T1CMfNzv0Gq291BgqGBM90ihjLC29SDMuGqw5PtgLZDcbjrcbMB3iGve1eqIa','l3rOzw1VDMLLzgi/Awq9','nte2qKnKqKnz','rxbPC29Kzsa','ntG0ntG2nKv0z0zeDG','yxbWBgLJyxrPB24VANnVBG','mJiWndaXnJfeq3LmBvO','CgfKu3rHCNq','8j+oNU+4JYbnudqGFcdIMQeGqxv0BYb8ipcFJi0G','w0T1CMfNzv0GuMvZB2X2zwqGDg8Gqw5PtgLZDcbjrdOG','mtr3y1PWBgS','BMv4DgPZlxjLywn0','z2v0rgf0zq','odi5mdr3te96uhi','BgvUz3rO','ywjZ','mJi1nJmZmgDAEgf0zG','ChvZAa','Aw5KzxHpzG','Ahr0Chm6lY9NCMfWAhfSlMfUAwXPC3qUy28','mJq0nZC2m3nLwxDoDq','Bw92Awu','BMfTzq','Bxa0','zgf5','zM9YrwfJAa','Dg9mB3DLCKnHC2u','tu9wsuu','zhvI','zgf5sw5KzxG','l2fWAs90CNbJl2nHDgfSB2CUyw5PBgLZDeLUzM8SzxbPC29KzxmUC291CMnLlgvWAxnVzgvZlNnVDxjJzt9IyxrJAd0XjMLUChv0pq','mJbPAKHOzxy','ihWG4O+X77Ipia','mwnuteLduW','CMvSzwfZzv9KyxrL','C3rYzwfTAw5NrxbPC29Kzxm','y2fSBa','C3bSAxq','BMv4Da','mJrT','mJi3nde0EwzhvK9Y'];_0x4ec0=function(){return _0xaae07e;};return _0x4ec0();}

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "kurage", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();
