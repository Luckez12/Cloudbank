// Imported provider: nakios; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
var _0x2eb68e=_0x1a06;(function(_0x8fd2f9,_0x423d16){var _0x37baab={_0x402bdf:0xa4,_0x50f347:0xac,_0x27b5b6:0x9f,_0x37a017:0xd0,_0x54d34d:0xb7,_0x5295af:0xae},_0x448ee2=_0x1a06,_0x5d19a5=_0x8fd2f9();while(!![]){try{var _0x27795c=-parseInt(_0x448ee2(0xb3))/0x1*(-parseInt(_0x448ee2(0xd1))/0x2)+parseInt(_0x448ee2(_0x37baab._0x402bdf))/0x3+-parseInt(_0x448ee2(_0x37baab._0x50f347))/0x4*(parseInt(_0x448ee2(0xcc))/0x5)+parseInt(_0x448ee2(_0x37baab._0x27b5b6))/0x6*(-parseInt(_0x448ee2(_0x37baab._0x37a017))/0x7)+parseInt(_0x448ee2(_0x37baab._0x54d34d))/0x8*(parseInt(_0x448ee2(_0x37baab._0x5295af))/0x9)+parseInt(_0x448ee2(0xbc))/0xa*(parseInt(_0x448ee2(0x9b))/0xb)+-parseInt(_0x448ee2(0xc8))/0xc;if(_0x27795c===_0x423d16)break;else _0x5d19a5['push'](_0x5d19a5['shift']());}catch(_0x3741d7){_0x5d19a5['push'](_0x5d19a5['shift']());}}}(_0x5146,0x41065));var TMDB_KEY='f3d757824f08ea2cff45eb8f47ca3a1e',NAKIOS_UA='Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/120.0.0.0\x20Safari/537.36',DOMAINS_URL='https://raw.githubusercontent.com/wooodyhood/nuvio-repo/main/domains.json',NAKIOS_FALLBACK='click',_cachedEndpoint=null;function getTmdbMetadata(_0x45dacc,_0x547f97){var _0x5a1383={_0x2a1dc8:0xbf},_0x2c795a={_0x558864:0xc4,_0x2ebeef:0xa3,_0x3c13e1:0xa3,_0x447f5c:0xa6,_0x5c4eaf:0xbe},_0x436d67=_0x1a06,_0x2adc87='https://api.themoviedb.org/3/'+(_0x547f97==='tv'?'tv':'movie')+'/'+_0x45dacc+'?api_key='+TMDB_KEY+'&language=en-US';return fetch(_0x2adc87)['then'](function(_0x51291e){var _0x532c3e=_0x1a06;return _0x51291e[_0x532c3e(0xc1)]();})[_0x436d67(0xb2)](function(_0x32fcd0){var _0x10bc82=_0x436d67,_0x308a6b=_0x32fcd0[_0x10bc82(_0x2c795a._0x558864)]||_0x32fcd0[_0x10bc82(0xa8)]||_0x10bc82(0xbf),_0x2a2412=_0x32fcd0[_0x10bc82(0xc7)]||_0x32fcd0[_0x10bc82(0xbd)]||'',_0x230dee=_0x2a2412?_0x2a2412['split']('-')[0x0]:'',_0x46fb31='';if(_0x547f97==='movie'&&_0x32fcd0[_0x10bc82(_0x2c795a._0x2ebeef)])_0x46fb31=_0x32fcd0[_0x10bc82(_0x2c795a._0x3c13e1)]+_0x10bc82(0xc0);else _0x547f97==='tv'&&_0x32fcd0[_0x10bc82(_0x2c795a._0x447f5c)]&&_0x32fcd0['episode_run_time'][_0x10bc82(_0x2c795a._0x5c4eaf)]>0x0&&(_0x46fb31=_0x32fcd0[_0x10bc82(0xa6)][0x0]+'\x20min');return{'name':_0x308a6b,'year':_0x230dee,'duration':_0x46fb31};})[_0x436d67(0xc5)](function(){var _0x38ad19=_0x436d67;return{'name':_0x38ad19(_0x5a1383._0x2a1dc8),'year':'','duration':''};});}function _0x5146(){var _0x497bca=['DgHLBG','mtyWmdC5C3P2tMTT','Ahr0Chm6lY9HCgKU','BMfRAw9Z','Btn1oa','mJr5u3zLz0O','ic0G','CMvMzxjLCG','C2L6zq','vK9tva','nJm0mZbut2X3CLi','zMLYC3rFywLYx2rHDgu','BgvUz3rO','tMfRAw9Z','ig1PBG','ANnVBG','AM9PBG','8j+tUIa','DgL0Bgu','y2f0y2G','tvvmveK','CMvSzwfZzv9KyxrL','nda0mZiWogTpEurzCq','EwvHCG','Bwf0y2G','8j+oNU+4JYa','nZvqD2PABe4','tMfRAw9Zic0G','vK9tvezs','z2v0u3rYzwfTCW','nZa0nZzbwuvvD1O','mNPbC1zHqW','Aw5JBhvKzxm','CMvZB2X2zq','zxHWB3j0CW','ndi5rhzhB2TU','C291CMnLCW','Dg9vChbLCKnHC2u','Ahr0Ca','ntr5q0zVu3q','yMfZzq','ihWG','l3nVDxjJzxmVDhyV','CNvUDgLTzq','nJeZotuZENfmvgfK','BMfRAw9ZlG','zxbPC29Kzv9YDw5FDgLTzq','AxnfBwjLza','BMfTzq','zhvYyxrPB24','Aw5KzxHpzG','Bxa0','mZK5nLz1q3Pizq','l2fWAq','mJKWmJK1B0XgveXJ','p2fWAv9RzxK9','ChvZAa','l3nVDxjJzxmVBw92AwuV'];_0x5146=function(){return _0x497bca;};return _0x5146();}function getEpisodeInfo(_0x250583,_0x289e12,_0x2d109d){var _0x2888b3={_0x205433:0x99},_0x54c375={_0x4cbf4a:0xa3},_0x39877d=_0x1a06;if(!_0x250583||!_0x289e12||!_0x2d109d)return Promise[_0x39877d(_0x2888b3._0x205433)](null);var _0x949365='https://api.themoviedb.org/3/tv/'+_0x250583+'/season/'+_0x289e12+'/episode/'+_0x2d109d+_0x39877d(0xaf)+TMDB_KEY+'&language=en-US';return fetch(_0x949365)['then'](function(_0x250aba){return _0x250aba['json']();})['then'](function(_0x568341){var _0x5c7a24=_0x39877d;return{'name':_0x568341[_0x5c7a24(0xa8)]||null,'duration':_0x568341[_0x5c7a24(_0x54c375._0x4cbf4a)]?_0x568341[_0x5c7a24(0xa3)]+'\x20min':null};})['catch'](function(){return null;});}function buildEndpoint(_0x8995ab){var _0x1f0eb6=_0x1a06,_0x4322a1=_0x8995ab[_0x1f0eb6(0xd2)](_0x1f0eb6(0xb5))?_0x8995ab:_0x1f0eb6(0xa5)+_0x8995ab;return{'base':'https://'+_0x4322a1,'api':_0x1f0eb6(0xb4)+_0x4322a1+_0x1f0eb6(0xad),'referer':'https://'+_0x4322a1+'/'};}function detectEndpoint(){var _0x54cafd=_0x1a06;if(_cachedEndpoint)return Promise['resolve'](_cachedEndpoint);return fetch(DOMAINS_URL)[_0x54cafd(0xb2)](function(_0xeaa3fb){return _0xeaa3fb['ok']?_0xeaa3fb['json']():Promise['reject']();})[_0x54cafd(0xb2)](function(_0x4a6009){return _cachedEndpoint=buildEndpoint(_0x4a6009['nakios']||NAKIOS_FALLBACK),_cachedEndpoint;})[_0x54cafd(0xc5)](function(){return _cachedEndpoint=buildEndpoint(NAKIOS_FALLBACK),_cachedEndpoint;});}function extractOrigin(_0x4aa458){var _0x3f25a9=_0x1a06,_0x4e98d4=_0x4aa458[_0x3f25a9(0xca)](/^(https?:\/\/[^\/]+)/);return _0x4e98d4?_0x4e98d4[0x1]:null;}function resolveSource(_0x11af07,_0x5ed86c){var _0x2a4b69={_0x194925:0x9e,_0x28d619:0xab,_0xc2539c:0xb9,_0x42516e:0xca,_0x22cb1b:0xb6},_0x243c27=_0x1a06,_0x224c51=_0x11af07['url']||'';if(_0x224c51['startsWith'](_0x243c27(_0x2a4b69._0x194925)))return{'url':_0x224c51,'format':_0x11af07['isM3U8']||_0x224c51[_0x243c27(0xaa)]('.m3u8')!==-0x1?'m3u8':_0x243c27(_0x2a4b69._0x28d619),'referer':_0x5ed86c[_0x243c27(_0x2a4b69._0xc2539c)],'origin':_0x5ed86c[_0x243c27(0xa0)]};if(_0x224c51['charAt'](0x0)==='/'){var _0x524f0f=_0x224c51[_0x243c27(_0x2a4b69._0x42516e)](/[?&]url=([^&]+)/);if(!_0x524f0f)return null;var _0x12fe4e;try{_0x12fe4e=decodeURIComponent(_0x524f0f[0x1]);}catch(_0x396c9f){return null;}var _0x208919=extractOrigin(_0x12fe4e);return{'url':_0x12fe4e,'format':_0x243c27(_0x2a4b69._0x22cb1b),'referer':_0x208919?_0x208919+'/':_0x5ed86c['referer'],'origin':_0x208919||_0x5ed86c['base']};}return null;}function normalizeSources(_0x250cd4,_0x46a02a,_0xaf122e,_0x33b35f,_0x4de12e,_0x352f17){var _0x3ef861={_0x17fd03:0xbe,_0x1099f7:0xa7,_0xd469a0:0xa8,_0x2b7405:0xce,_0x3e0871:0xb8,_0x3b892c:0xc9,_0x4115da:0xa9,_0x33d040:0xb0,_0x13f50b:0xc2},_0x2a587d=_0x1a06,_0x423049=[];for(var _0x4026bc=0x0;_0x4026bc<_0x250cd4[_0x2a587d(_0x3ef861._0x17fd03)];_0x4026bc++){var _0x5eb8c2=_0x250cd4[_0x4026bc];if(_0x5eb8c2[_0x2a587d(_0x3ef861._0x1099f7)])continue;var _0x2bc749=resolveSource(_0x5eb8c2,_0x46a02a);if(!_0x2bc749)continue;var _0x20e31d=_0x5eb8c2['quality']||'HD',_0x576bf8=(_0x5eb8c2['lang']||'MULTI')['toUpperCase'](),_0x5d6e29=_0x2bc749['format']['toUpperCase'](),_0x15350e='🇫🇷',_0x252ab6='VF';if(_0x576bf8['indexOf'](_0x2a587d(0xc6))!==-0x1||_0x5eb8c2[_0x2a587d(_0x3ef861._0xd469a0)]&&_0x5eb8c2['name'][_0x2a587d(0x9d)]()['indexOf']('MULTI')!==-0x1)_0x15350e='🌍',_0x252ab6='MULTI';else _0x576bf8['indexOf'](_0x2a587d(0xbb))!==-0x1&&(_0x15350e='🔡',_0x252ab6=_0x2a587d(_0x3ef861._0x2b7405));var _0x5949d1='🎬\x20';if(_0x33b35f&&_0x4de12e){var _0x9aa953=_0x352f17&&_0x352f17['name']?_0x2a587d(_0x3ef861._0x3e0871)+_0x352f17['name']:'';_0x5949d1+='S'+_0x33b35f+'\x20E'+_0x4de12e+_0x9aa953+'\x20|\x20'+_0xaf122e['name'];}else _0x5949d1+=_0xaf122e[_0x2a587d(_0x3ef861._0xd469a0)]+(_0xaf122e[_0x2a587d(_0x3ef861._0x3b892c)]?'\x20-\x20'+_0xaf122e[_0x2a587d(0xc9)]:'');var _0x3a0676=[_0x2a587d(0xc3)+_0x20e31d,_0x15350e+'\x20'+_0x252ab6,_0x2a587d(0xcb)+_0x5d6e29];if(_0x5eb8c2[_0x2a587d(0xba)])_0x3a0676['push']('💾\x20'+_0x5eb8c2['size']);var _0x49da3a=_0x352f17&&_0x352f17[_0x2a587d(_0x3ef861._0x4115da)]?_0x352f17[_0x2a587d(0xa9)]:_0xaf122e[_0x2a587d(0xa9)];if(_0x49da3a)_0x3a0676['push']('⏱️\x20'+_0x49da3a);_0x423049[_0x2a587d(_0x3ef861._0x33d040)]({'name':_0x2a587d(0xcd)+_0x20e31d,'title':_0x5949d1+'\x0a'+_0x3a0676[_0x2a587d(_0x3ef861._0x13f50b)](_0x2a587d(0xa1)),'url':_0x2bc749['url'],'quality':_0x20e31d,'format':_0x2bc749['format'],'headers':{'User-Agent':NAKIOS_UA,'Referer':_0x2bc749['referer'],'Origin':_0x2bc749['origin']}});}return _0x423049;}function _0x1a06(_0x2c9a1c,_0x5d2934){_0x2c9a1c=_0x2c9a1c-0x99;var _0x5146d8=_0x5146();var _0x1a06cd=_0x5146d8[_0x2c9a1c];if(_0x1a06['RsyJjA']===undefined){var _0x157524=function(_0x24f88c){var _0x4c9d0a='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';var _0x45dacc='',_0x547f97='';for(var _0x2adc87=0x0,_0x51291e,_0x32fcd0,_0x308a6b=0x0;_0x32fcd0=_0x24f88c['charAt'](_0x308a6b++);~_0x32fcd0&&(_0x51291e=_0x2adc87%0x4?_0x51291e*0x40+_0x32fcd0:_0x32fcd0,_0x2adc87++%0x4)?_0x45dacc+=String['fromCharCode'](0xff&_0x51291e>>(-0x2*_0x2adc87&0x6)):0x0){_0x32fcd0=_0x4c9d0a['indexOf'](_0x32fcd0);}for(var _0x2a2412=0x0,_0x230dee=_0x45dacc['length'];_0x2a2412<_0x230dee;_0x2a2412++){_0x547f97+='%'+('00'+_0x45dacc['charCodeAt'](_0x2a2412)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x547f97);};_0x1a06['BQQSVh']=_0x157524,_0x1a06['EfuSzt']={},_0x1a06['RsyJjA']=!![];}var _0x411e5c=_0x5146d8[0x0],_0x25013a=_0x2c9a1c+_0x411e5c,_0x2ce21e=_0x1a06['EfuSzt'][_0x25013a];return!_0x2ce21e?(_0x1a06cd=_0x1a06['BQQSVh'](_0x1a06cd),_0x1a06['EfuSzt'][_0x25013a]=_0x1a06cd):_0x1a06cd=_0x2ce21e,_0x1a06cd;}function getStreams(_0x4cb892,_0x4394b5,_0x4ca306,_0x1478d9){var _0x19316a={_0x123d88:0xc5},_0x4dee11={_0x58f418:0xb1,_0x13e1d0:0xb2},_0x4fe12a=_0x1a06;return Promise['all']([getTmdbMetadata(_0x4cb892,_0x4394b5),_0x4394b5==='tv'?getEpisodeInfo(_0x4cb892,_0x4ca306,_0x1478d9):Promise['resolve'](null),detectEndpoint()])['then'](function(_0x368e90){var _0x53f636=_0x1a06,_0x1b9f68=_0x368e90[0x0],_0x5214c9=_0x368e90[0x1],_0x3e704b=_0x368e90[0x2],_0x4e50cd=_0x4394b5==='tv'?_0x3e704b['api']+_0x53f636(0xa2)+_0x4cb892+'/'+(_0x4ca306||0x1)+'/'+(_0x1478d9||0x1):_0x3e704b['api']+_0x53f636(_0x4dee11._0x58f418)+_0x4cb892;return fetch(_0x4e50cd,{'headers':{'User-Agent':NAKIOS_UA,'Referer':_0x3e704b[_0x53f636(0xb9)]}})[_0x53f636(0xb2)](function(_0x4eb8ae){var _0x411625=_0x53f636;return _0x4eb8ae[_0x411625(0xc1)]();})[_0x53f636(_0x4dee11._0x13e1d0)](function(_0x3c19c8){var _0x299c66=_0x53f636;if(!_0x3c19c8['success']||!_0x3c19c8[_0x299c66(0x9c)])return[];var _0x4d3b6e=_0x4394b5==='tv'?_0x4ca306:null,_0xa51308=_0x4394b5==='tv'?_0x1478d9:null;return normalizeSources(_0x3c19c8['sources'],_0x3e704b,_0x1b9f68,_0x4d3b6e,_0xa51308,_0x5214c9);});})[_0x4fe12a(_0x19316a._0x123d88)](function(){return[];});}typeof module!=='undefined'&&module[_0x2eb68e(0x9a)]?module['exports']={'getStreams':getStreams}:global[_0x2eb68e(0xcf)]=getStreams;

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "nakios", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();
