// Imported provider: persianstremio; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
var _0x226edf=_0xe0f7;(function(_0x26ecc8,_0x1d359f){var _0x75b539={_0x424e46:0x195,_0x54ee72:0x180,_0x513888:0x18f,_0x4c9f38:0x199,_0x408640:0x185,_0x2685ba:0x170},_0x4c42b5=_0xe0f7,_0x1dee5d=_0x26ecc8();while(!![]){try{var _0x12853c=parseInt(_0x4c42b5(0x1af))/0x1+-parseInt(_0x4c42b5(_0x75b539._0x424e46))/0x2*(parseInt(_0x4c42b5(0x181))/0x3)+parseInt(_0x4c42b5(_0x75b539._0x54ee72))/0x4+-parseInt(_0x4c42b5(0x1a0))/0x5+parseInt(_0x4c42b5(0x182))/0x6*(parseInt(_0x4c42b5(_0x75b539._0x513888))/0x7)+-parseInt(_0x4c42b5(_0x75b539._0x4c9f38))/0x8*(parseInt(_0x4c42b5(_0x75b539._0x408640))/0x9)+-parseInt(_0x4c42b5(_0x75b539._0x2685ba))/0xa*(parseInt(_0x4c42b5(0x189))/0xb);if(_0x12853c===_0x1d359f)break;else _0x1dee5d['push'](_0x1dee5d['shift']());}catch(_0x1989d0){_0x1dee5d['push'](_0x1dee5d['shift']());}}}(_0x213d,0x9974b));var __async=(_0x44489b,_0x513ad7,_0x17bbab)=>{return new Promise((_0xfaba12,_0x4970ca)=>{var _0x1bfe9d={_0x5f0012:0x16e},_0x1b09cf=_0xe0f7,_0x14fcd8=_0x5d8e00=>{try{_0x2b8ad7(_0x17bbab['next'](_0x5d8e00));}catch(_0x365111){_0x4970ca(_0x365111);}},_0x1dfcd1=_0x296e8a=>{var _0x5aab52=_0xe0f7;try{_0x2b8ad7(_0x17bbab[_0x5aab52(_0x1bfe9d._0x5f0012)](_0x296e8a));}catch(_0x26d4b3){_0x4970ca(_0x26d4b3);}},_0x2b8ad7=_0x5608a2=>_0x5608a2['done']?_0xfaba12(_0x5608a2[_0x1b09cf(0x176)]):Promise[_0x1b09cf(0x1b5)](_0x5608a2['value'])['then'](_0x14fcd8,_0x1dfcd1);_0x2b8ad7((_0x17bbab=_0x17bbab['apply'](_0x44489b,_0x513ad7))[_0x1b09cf(0x19f)]());});},PROVIDER_NAME=_0x226edf(0x1b9),PERSIAN_BASE=_0x226edf(0x16f),TMDB_API_KEY=_0x226edf(0x1ac),FETCH_TIMEOUT=0x2ee0,USER_AGENT='Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/124.0.0.0\x20Safari/537.36';function log(_0x149898){var _0x3c644c={_0x217a55:0x1a1},_0x336321=_0x226edf;console[_0x336321(_0x3c644c._0x217a55)]('['+PROVIDER_NAME+']\x20'+_0x149898);}function err(_0x3da78e){console['error']('['+PROVIDER_NAME+']\x20'+_0x3da78e);}function _0x213d(){var _0x602545=['4PY077Ipia','DMfSDwu','CMvSzwfZzv9KyxrL','qxrTB3m','C3rYzwfTCW','ihm9','p2fWAv9RzxK9','8j+mUca','req1lJe','ipcFLlNWN4Yzia','ihr5Cgu9','mZu2mJK4mgHPyvnvAq','mJy1nJjAwKP0se4','mtjlu2jfD0O','BMfTzq','ihWG','oxPmENz3Ca','8j+sJIa','8j+tNca','ipcFLlKG','mJjHqvfRt2y','ipcFLlKGuW','AgrY','uMv0CNLPBMCGD2L0AcbMywXSyMfJAYbLBMrWB2LUDdOG','v0vclvjPCa','zMLYC3rFywLYx2rHDgu','mZm0nda0n1rXwwrNrW','rMv0y2HPBMCGC3rYzwfTCYbMCM9ToIa','z2v0u3rYzwfTCW','l3n0CMvHBs9TB3zPzs8','sersmta','vhj1zuHe','nhvny0Tssa','zgq1lJe','BgvUz3rO','ANnVBG','nJa1oty4ohLQtKnmuq','yxrTB3m','zxH0zxjUywXFAwrZ','iokaOIa','tM8GC3rYzwfTCYbYzxr1CM5LzcbMCM9TifbLCNnPyw5tDhjLBwLV','ugvYC2LHBLn0CMvTAw8GvgL0Bgu','BMv4Da','nJGXnJi1Evr5AK5X','Bg9N','C2vYAwvZ','ndGWCa','lMPZB24','u0rs','Dhj1zwHK','ihWGrhvHBc1bDwrPBW','Dg9mB3DLCKnHC2u','ic0+ia','DgL0Bgu','l3n0CMvHBs9ZzxjPzxmV','ndm5yZq3oge3nZfMmZvJmduWmJjMowzLywjJy2eWmwm','Aw1KyL9Pza','Cg9W','ndKWnduYC2vJD2LW','ChvZAa','Edi2nq','mta4mha','mtbIAxq','v0vclurm','CMvZB2X2zq','uMvXDwvZDdOGDg1KyKLKpq','8j+pM++4JYa','ipcFLlNWN6E/ia','ugvYC2LHBLn0CMvTAw8','tva0','Aw5KzxHpzG','DgHYB3C','Ahr0Chm6lY9WzxjZAwfUC3rYzw1PBY52zxjJzwWUyxbW','mZK4mJK1mhjlz0THDa','sevwqW','DxjS','mtaTyML0','zxHWB3j0CW'];_0x213d=function(){return _0x602545;};return _0x213d();}function raceTimeout(_0x5f3a4d){return new Promise(function(_0x162460,_0x341542){setTimeout(function(){_0x341542(new Error('Timeout\x20'+_0x5f3a4d+'ms'));},_0x5f3a4d);});}function fetchJson(_0x5eff64){return __async(this,null,function*(){var _0x1d23a0=_0xe0f7;try{var _0x4b935b=fetch(_0x5eff64,{'headers':{'User-Agent':USER_AGENT,'Accept':'application/json'}}),_0x198c46=yield Promise['race']([_0x4b935b,raceTimeout(FETCH_TIMEOUT)]);if(_0x198c46&&_0x198c46['ok'])return yield _0x198c46[_0x1d23a0(0x198)]();}catch(_0x12d83d){err('fetch\x20failed:\x20'+_0x5eff64+_0x1d23a0(0x1a9)+(_0x12d83d['message']||''));}return null;});}function getTMDBDetails(_0x4cfbe0,_0x4adee2){var _0x20e62c={_0x56bed7:0x19e,_0x3d6ffd:0x1aa,_0x55d33f:0x1ad};return __async(this,null,function*(){var _0x3342f9=_0xe0f7,_0x36bc82=_0x4adee2==='tv'||_0x4adee2===_0x3342f9(0x1a2),_0x2d8ff2=_0x36bc82?'tv':'movie',_0x1fcbf0='https://api.themoviedb.org/3/'+_0x2d8ff2+'/'+_0x4cfbe0+_0x3342f9(0x17b)+TMDB_API_KEY+'&append_to_response=external_ids',_0x12f02f=yield fetchJson(_0x1fcbf0);if(!_0x12f02f)return{'title':_0x3342f9(_0x20e62c._0x56bed7),'year':'','imdbId':null};return{'title':(_0x36bc82?_0x12f02f['name']:_0x12f02f[_0x3342f9(_0x20e62c._0x3d6ffd)])||'PersianStremio\x20Title','year':(_0x36bc82?_0x12f02f[_0x3342f9(0x18e)]||'':_0x12f02f[_0x3342f9(0x177)]||'')['split']('-')[0x0],'imdbId':_0x12f02f['imdb_id']||_0x12f02f[_0x3342f9(0x19b)]&&_0x12f02f['external_ids'][_0x3342f9(_0x20e62c._0x55d33f)]||null};});}function buildDropdownMetadata(_0x8b1315,_0xd0cc58,_0x3ce2ce,_0x4031db,_0x456e8d,_0x5d46fb){var _0x2c2fcd={_0xc08232:0x1a8,_0x4de14a:0x187,_0x22990f:0x186,_0xf6fd7c:0x16d,_0x517e1a:0x1b4,_0x3272bb:0x16d,_0x481e01:0x1a5,_0x2eb890:0x1b3,_0x15e823:0x1b1,_0x77634a:0x172,_0x2efe85:0x175,_0xc5f031:0x1b8,_0x4f4476:0x196,_0x2db90c:0x16d,_0x31ecdc:0x1b0,_0x146bc4:0x178,_0xdbbc27:0x19c},_0x132e26=_0x226edf,_0xcdbaa2=_0x8b1315['title']||'PersianStremio\x20Title',_0x6a110d=_0x8b1315['year']||'',_0x27ad12=(_0x5d46fb['title']||'')+'\x20'+(_0x5d46fb[_0x132e26(0x183)]||'')+'\x20'+(_0x5d46fb['url']||''),_0x3529a4=_0x27ad12[_0x132e26(_0x2c2fcd._0xc08232)](),_0x1667db=_0x132e26(_0x2c2fcd._0x4de14a)+_0xcdbaa2;if(_0x6a110d)_0x1667db+=_0x132e26(0x188)+_0x6a110d;_0x3ce2ce&&_0x4031db!=null&&_0x456e8d!=null&&(_0x1667db+=_0x132e26(0x18a)+_0x4031db+'E'+_0x456e8d);var _0x32cb83=_0x132e26(_0x2c2fcd._0x22990f);if(_0xd0cc58[_0x132e26(_0x2c2fcd._0xf6fd7c)]('2160')!==-0x1||_0xd0cc58[_0x132e26(0x16d)]('4k')!==-0x1)_0x32cb83='✨\x20';var _0xc84a08=_0x132e26(_0x2c2fcd._0x517e1a);if(_0x3529a4['indexOf']('web-rip')!==-0x1||_0x3529a4[_0x132e26(0x16d)]('webrip')!==-0x1)_0xc84a08=_0x132e26(0x18d);else{if(_0x3529a4['indexOf']('bluray')!==-0x1||_0x3529a4[_0x132e26(_0x2c2fcd._0x3272bb)]('blu-ray')!==-0x1)_0xc84a08='Blu-Ray';}var _0x20e497=_0x32cb83+_0xd0cc58+_0x132e26(0x17e)+_0xc84a08,_0x12ae7c=_0x132e26(_0x2c2fcd._0x481e01);if(_0x3529a4['indexOf']('hdr10+')!==-0x1)_0x12ae7c='HDR10+';else{if(_0x3529a4[_0x132e26(0x16d)]('hdr10')!==-0x1)_0x12ae7c=_0x132e26(0x193);else{if(_0x3529a4[_0x132e26(_0x2c2fcd._0xf6fd7c)](_0x132e26(0x18b))!==-0x1)_0x12ae7c='HDR';}}var _0x1c4cc5='';(_0x3529a4[_0x132e26(0x16d)](_0x132e26(_0x2c2fcd._0x2eb890))!==-0x1||_0x3529a4['indexOf'](_0x132e26(0x173))!==-0x1)&&(_0x1c4cc5='\x20|\x20🌈\x2010Bit');var _0x507fa4='x264';if(_0x3529a4[_0x132e26(0x16d)]('dv')!==-0x1||_0x3529a4['indexOf']('dovi')!==-0x1||_0x3529a4['indexOf']('dolby\x20vision')!==-0x1)_0x507fa4='DV';else{if(_0x3529a4['indexOf']('hevc')!==-0x1)_0x507fa4=_0x132e26(0x171);else{if(_0x3529a4[_0x132e26(0x16d)]('x265')!==-0x1||_0x3529a4['indexOf']('h265')!==-0x1)_0x507fa4=_0x132e26(_0x2c2fcd._0x15e823);}}var _0x4dc057=_0x5d46fb[_0x132e26(_0x2c2fcd._0x77634a)]&&_0x5d46fb[_0x132e26(0x172)]['indexOf']('.mp4')!==-0x1?_0x132e26(0x16c):'MKV',_0x454773=_0x132e26(_0x2c2fcd._0x2efe85)+_0x12ae7c+_0x1c4cc5+_0x132e26(_0x2c2fcd._0xc5f031)+_0x507fa4+'\x20🔹💠\x20'+_0x4dc057,_0x13aaf2='AAC';if(_0x3529a4['indexOf']('ddp5.1')!==-0x1||_0x3529a4['indexOf']('ddp\x205.1')!==-0x1)_0x13aaf2='DDP5.1';else(_0x3529a4[_0x132e26(0x16d)](_0x132e26(_0x2c2fcd._0x4f4476))!==-0x1||_0x3529a4['indexOf']('dd\x205.1')!==-0x1||_0x3529a4['indexOf']('5.1')!==-0x1)&&(_0x13aaf2=_0x132e26(0x17d));var _0x2d4dd2='🌍\x20Dual-Audio\x20-\x20🇺🇸\x20|\x20🇮🇷\x20🔹🎧\x20'+_0x13aaf2,_0x34cc20=[];if(_0x3529a4[_0x132e26(_0x2c2fcd._0x3272bb)](_0x132e26(0x1a6))!==-0x1)_0x34cc20['push'](_0x132e26(0x194));if(_0x3529a4[_0x132e26(_0x2c2fcd._0x2db90c)](_0x132e26(0x19a))!==-0x1)_0x34cc20[_0x132e26(_0x2c2fcd._0x31ecdc)](_0x132e26(_0x2c2fcd._0x146bc4));_0x34cc20['length']>0x0&&(_0x2d4dd2+='\x20🔹🔊\x20'+_0x34cc20['join'](_0x132e26(_0x2c2fcd._0xdbbc27)));var _0x1f16ba=_0x5d46fb['url']?_0x5d46fb['url']['split']('/')[_0x132e26(0x1ae)]():PROVIDER_NAME;try{_0x1f16ba=decodeURIComponent(_0x1f16ba);}catch(_0x230a8c){}var _0x17855d=_0x132e26(0x1b7)+(_0x5d46fb[_0x132e26(0x1aa)]||_0x1f16ba||PROVIDER_NAME);return _0x1667db+'\x0a'+_0x20e497+'\x0a'+_0x454773+'\x0a'+_0x2d4dd2+'\x0a'+_0x17855d;}function getStreams(_0x4cbac1,_0x51e9db,_0x395c2c,_0xc0c870){var _0x36a50c={_0xc4d59b:0x17a,_0x2907a8:0x1a4,_0x536976:0x1a4,_0x178c2f:0x179,_0x9da3f0:0x197,_0x3d3d24:0x1a7},_0x4711eb={_0x447e67:0x183},_0x30c1fb={_0x4605d4:0x16d};return __async(this,null,function*(){var _0x40b5ec=_0xe0f7,_0x415fbd=_0x51e9db==='tv'||_0x51e9db==='series';log(_0x40b5ec(0x1b6)+_0x4cbac1+_0x40b5ec(0x17f)+_0x51e9db+_0x40b5ec(_0x36a50c._0xc4d59b)+_0x395c2c+'\x20e='+_0xc0c870);var _0x26624d=yield getTMDBDetails(_0x4cbac1,_0x51e9db),_0x32fa61=_0x26624d['imdbId']||_0x4cbac1,_0x3e0677='';if(_0x415fbd){var _0x1dc1cc=_0x395c2c!=null?_0x395c2c:0x1,_0x962507=_0xc0c870!=null?_0xc0c870:0x1;_0x3e0677=PERSIAN_BASE+_0x40b5ec(0x1ab)+_0x32fa61+':'+_0x1dc1cc+':'+_0x962507+_0x40b5ec(_0x36a50c._0x2907a8);}else _0x3e0677=PERSIAN_BASE+'/stream/movie/'+_0x32fa61+_0x40b5ec(_0x36a50c._0x536976);log(_0x40b5ec(0x190)+_0x3e0677);var _0x2463f6=yield fetchJson(_0x3e0677);if((!_0x2463f6||!_0x2463f6['streams']||!_0x2463f6['streams']['length'])&&_0x26624d['imdbId']){var _0x2bfe87=_0x415fbd?PERSIAN_BASE+_0x40b5ec(0x1ab)+_0x4cbac1+':'+(_0x395c2c||0x1)+':'+(_0xc0c870||0x1)+'.json':PERSIAN_BASE+_0x40b5ec(0x192)+_0x4cbac1+'.json';log(_0x40b5ec(0x18c)+_0x2bfe87),_0x2463f6=yield fetchJson(_0x2bfe87);}if(!_0x2463f6||!_0x2463f6['streams']||!_0x2463f6[_0x40b5ec(_0x36a50c._0x178c2f)][_0x40b5ec(_0x36a50c._0x9da3f0)])return log(_0x40b5ec(0x19d)),[];var _0x5740f5=[],_0xe6fa96={};for(var _0x5a422b=0x0;_0x5a422b<_0x2463f6['streams']['length'];_0x5a422b++){var _0x11517e=_0x2463f6['streams'][_0x5a422b],_0x1459df=_0x11517e[_0x40b5ec(0x172)]||_0x11517e['externalUrl'];if(!_0x1459df||_0xe6fa96[_0x1459df])continue;_0xe6fa96[_0x1459df]=!![];var _0x312a58=((_0x11517e[_0x40b5ec(0x1aa)]||'')+'\x20'+(_0x11517e['name']||'')+'\x20'+_0x1459df)['toLowerCase'](),_0xc390a4='1080p';if(_0x312a58['indexOf']('2160')!==-0x1||_0x312a58[_0x40b5ec(0x16d)]('4k')!==-0x1)_0xc390a4='2160p';else{if(_0x312a58['indexOf']('720')!==-0x1)_0xc390a4='720p';else{if(_0x312a58['indexOf']('480')!==-0x1)_0xc390a4=_0x40b5ec(0x1a3);}}var _0x20536a=buildDropdownMetadata(_0x26624d,_0xc390a4,_0x415fbd,_0x395c2c,_0xc0c870,_0x11517e);_0x5740f5['push']({'name':_0x40b5ec(0x17c)+PROVIDER_NAME+_0x40b5ec(0x184)+_0xc390a4+_0x40b5ec(_0x36a50c._0x3d3d24),'title':_0x20536a,'size':_0x20536a,'description':_0x20536a,'url':_0x1459df,'quality':'','language':'','headers':{'User-Agent':USER_AGENT,'Referer':PERSIAN_BASE+'/'}});}function _0x139acb(_0x451f59){var _0xd797f5=_0x40b5ec,_0x33ab7a=_0x451f59[_0xd797f5(0x1a8)]();if(_0x33ab7a['indexOf']('2160p')!==-0x1||_0x33ab7a[_0xd797f5(0x16d)]('4k')!==-0x1)return 0x870;if(_0x33ab7a[_0xd797f5(_0x30c1fb._0x4605d4)](_0xd797f5(0x1b2))!==-0x1)return 0x438;if(_0x33ab7a[_0xd797f5(_0x30c1fb._0x4605d4)]('720p')!==-0x1)return 0x2d0;if(_0x33ab7a['indexOf'](_0xd797f5(0x1a3))!==-0x1)return 0x1e0;return 0x0;}return _0x5740f5['sort'](function(_0x2302ac,_0x34163b){var _0xaf7c6a=_0x40b5ec;return _0x139acb(_0x34163b['name'])-_0x139acb(_0x2302ac[_0xaf7c6a(_0x4711eb._0x447e67)]);}),log('Returning\x20'+_0x5740f5['length']+'\x20sorted\x20streams'),_0x5740f5;});}function _0xe0f7(_0x416102,_0x29ac04){_0x416102=_0x416102-0x16c;var _0x213d4=_0x213d();var _0xe0f7cd=_0x213d4[_0x416102];if(_0xe0f7['OiObII']===undefined){var _0x19848d=function(_0x117ba2){var _0xc18f14='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';var _0x44489b='',_0x513ad7='';for(var _0x17bbab=0x0,_0xfaba12,_0x4970ca,_0x14fcd8=0x0;_0x4970ca=_0x117ba2['charAt'](_0x14fcd8++);~_0x4970ca&&(_0xfaba12=_0x17bbab%0x4?_0xfaba12*0x40+_0x4970ca:_0x4970ca,_0x17bbab++%0x4)?_0x44489b+=String['fromCharCode'](0xff&_0xfaba12>>(-0x2*_0x17bbab&0x6)):0x0){_0x4970ca=_0xc18f14['indexOf'](_0x4970ca);}for(var _0x1dfcd1=0x0,_0x2b8ad7=_0x44489b['length'];_0x1dfcd1<_0x2b8ad7;_0x1dfcd1++){_0x513ad7+='%'+('00'+_0x44489b['charCodeAt'](_0x1dfcd1)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x513ad7);};_0xe0f7['QXBngl']=_0x19848d,_0xe0f7['eCBsUU']={},_0xe0f7['OiObII']=!![];}var _0x12386a=_0x213d4[0x0],_0x381fee=_0x416102+_0x12386a,_0x34a699=_0xe0f7['eCBsUU'][_0x381fee];return!_0x34a699?(_0xe0f7cd=_0xe0f7['QXBngl'](_0xe0f7cd),_0xe0f7['eCBsUU'][_0x381fee]=_0xe0f7cd):_0xe0f7cd=_0x34a699,_0xe0f7cd;}typeof module!=='undefined'&&module[_0x226edf(0x174)]?module[_0x226edf(0x174)]={'getStreams':getStreams}:global[_0x226edf(0x191)]=getStreams;

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "persianstremio", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_PLAYIMDB_DISPLAY_START */
/* CLOUDBANK_PLAYIMDB_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  if (providerId === "playimdb") return provider; // Reference output stays exactly upstream.
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name) || (lines.length ? lines[0] : "");
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    var labelledAudio = /🌍\s*([^|\n]+)/.exec(originalTitle);
    if (!audioLang && labelledAudio) audioLang = language(labelledAudio[1]);
    var filenameAudio = /(?:^|[._ -])(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese)(?=[._ -]|$)/i.exec(clean(stream.fileName || stream.filename));
    if (!audioLang && filenameAudio) audioLang = language(filenameAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage)) || /\boriginal[- ]audio\b/i.test(text)) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    var labelledServer = /📌\s*([^|\n]+)/.exec(originalTitle);
    if (!server && labelledServer) server = usable(labelledServer[1]);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    var firstLine = lines.length ? "🎬 " + lines[0] : "";
    // Match PlayIMDb's original typography and order, without its guessed defaults.
    if (displayTitle) {
      firstLine = type === "tv" ? "🎬 " + usable(meta.title || meta.name) + " - S" + Number(season) + "E" + Number(episode) + (year ? " (" + year[0] + ")" : "") :
        "🎬 " + usable(meta.title || meta.name) + (year ? " - " + year[0] : "");
    }
    var qualityDisplay = qualityLabel === "4K" ? "2160P" : qualityLabel.toUpperCase();
    var audioDisplay = audioLabel.replace(/[- ]Audio/g, "").trim();
    var infoLine = [qualityDisplay ? "💎 " + qualityDisplay : "", audioDisplay ? "🌍 " + audioDisplay : ""].filter(Boolean).join(" | ");
    var bottomLine = [formatLabel ? "🎞️ " + (formatLabel === "HLS" ? "M3U8" : formatLabel) : "", duration ? "⏱️ " + duration : "", "📌 " + server].filter(Boolean).join(" | ");
    var nameQuality = qualityLabel === "4K" ? "4K UHD" : qualityLabel === "1080p" ? "1080p FHD" : qualityLabel === "720p" ? "720p HD" : qualityLabel;
    output.name = ["🟡 " + providerName, nameQuality, audioLabel ? audioLabel.replace(/ Audio/g, "-Audio") : ""].filter(Boolean).join(" | ");
    output.title = [firstLine, infoLine, bottomLine].filter(Boolean).join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "🌸 PersianStremio", "persianstremio");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
/* CLOUDBANK_PLAYIMDB_DISPLAY_END */
