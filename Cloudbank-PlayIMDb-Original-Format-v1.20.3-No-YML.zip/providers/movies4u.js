// Imported provider: movies4u; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
const _0x244354=_0x2859;(function(_0x5c4e00,_0x4cd1fd){const _0xcf8bec={_0x3d5159:0x12f,_0x3c431a:0x18b,_0x840756:0x138,_0x9fafaa:0x19d,_0x17e61a:0x144,_0x3c7041:0x186,_0x53ec87:0x16d},_0x9641d0=_0x2859,_0x43d8ef=_0x5c4e00();while(!![]){try{const _0x46cab5=-parseInt(_0x9641d0(_0xcf8bec._0x3d5159))/0x1*(parseInt(_0x9641d0(_0xcf8bec._0x3c431a))/0x2)+-parseInt(_0x9641d0(0x198))/0x3*(parseInt(_0x9641d0(0x15e))/0x4)+-parseInt(_0x9641d0(_0xcf8bec._0x840756))/0x5+parseInt(_0x9641d0(_0xcf8bec._0x9fafaa))/0x6+parseInt(_0x9641d0(_0xcf8bec._0x17e61a))/0x7+parseInt(_0x9641d0(_0xcf8bec._0x3c7041))/0x8+-parseInt(_0x9641d0(0x18a))/0x9*(-parseInt(_0x9641d0(_0xcf8bec._0x53ec87))/0xa);if(_0x46cab5===_0x4cd1fd)break;else _0x43d8ef['push'](_0x43d8ef['shift']());}catch(_0xbda275){_0x43d8ef['push'](_0x43d8ef['shift']());}}}(_0x4d9a,0x4d927));function _0x2859(_0x44e73f,_0x529224){_0x44e73f=_0x44e73f-0x12c;const _0x4d9a70=_0x4d9a();let _0x285905=_0x4d9a70[_0x44e73f];if(_0x2859['wXSDQz']===undefined){var _0x4949e5=function(_0x1d286a){const _0x313157='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0xe7b8a6='',_0xa6dae8='';for(let _0x22d250=0x0,_0x49c0be,_0x14d8e8,_0x56c2b6=0x0;_0x14d8e8=_0x1d286a['charAt'](_0x56c2b6++);~_0x14d8e8&&(_0x49c0be=_0x22d250%0x4?_0x49c0be*0x40+_0x14d8e8:_0x14d8e8,_0x22d250++%0x4)?_0xe7b8a6+=String['fromCharCode'](0xff&_0x49c0be>>(-0x2*_0x22d250&0x6)):0x0){_0x14d8e8=_0x313157['indexOf'](_0x14d8e8);}for(let _0x3f3092=0x0,_0x2293c1=_0xe7b8a6['length'];_0x3f3092<_0x2293c1;_0x3f3092++){_0xa6dae8+='%'+('00'+_0xe7b8a6['charCodeAt'](_0x3f3092)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0xa6dae8);};_0x2859['NJuBIi']=_0x4949e5,_0x2859['lofBsS']={},_0x2859['wXSDQz']=!![];}const _0x390e57=_0x4d9a70[0x0],_0x4b45cc=_0x44e73f+_0x390e57,_0x54ea0c=_0x2859['lofBsS'][_0x4b45cc];return!_0x54ea0c?(_0x285905=_0x2859['NJuBIi'](_0x285905),_0x2859['lofBsS'][_0x4b45cc]=_0x285905):_0x285905=_0x54ea0c,_0x285905;}function _0x4d9a(){const _0x3a15c7=['C2L6zq','shvIq2XVDwqGuZm','yxvKAw9dB2rLyW','qvrnt1m','8j+oPYberfa1lJe','iokaOIa','req1','qufd','ChjVDg90ExbL','tva0','BwfW','8j+mIcbirfi','8j+oPYbbqum','l21LzgLHl2zPBguUBwT2p3vYBd0','8j+mNYa0sW','mte1ode2mhv0DLv3vq','sevwqW','BgfUz3vHz2u','AgfZ','mZeXneDuDhP6za','ntK3odG2vgrRz0Lt','sc4YnJu','Btr1CgXHEs5ZDg9Yzq','mta4ma','8j+oNU+4JYa','zM9SBg93','Bwf4','mZyW','Dg9mB3DLCKnHC2u','DgHLBG','Aw5JBhvKzxm','Bw92Awu','BwfZDgvYlM0ZDtG','nLnrAxnSsW','Bwf0y2G','DMfSDwu','rfvbta','mJe2ma','mJi0mJiWnLLTzNLjvq','AhvIy2XVDwq','z2v0t3DUuhjVCgvYDhLezxnJCMLWDg9YCW','8j+rGE+4JYbjtufyihWG8j+mKcbnB3zPzxm0Dsb8ipcFK6yG','CMvWBgfJzq','mLbYrxLzBq','zMLSDgvY','vw5RBM93BG','shvIq2XVDwqGrLnmDJi','4PYOieHfvKm','lK1tDwjZ','shvIq2XVDwqGugL4zwWGmtbhyNbZ','DhjPBq','ndGWCa','ndm0mtaWr0rPzw1x','CMvZB2X2zq','8j+rGE+4JYbjtufy','4PYOieGUmJy0','ihWG8j+sVIa','txvSDgKTqxvKAw8','ndGW','ANnVBG','zgf0yq','Bw92AwvZnhu','zNvSBgHK','sdi2nq','mJuWnZy5nfb6D3vPyG','Dg9tDhjPBMC','nZiWCa','BgfIzwW','Ahr0Chm6lY9TnhvWBgf5lNn0B3jL','AgfZt3DUuhjVCgvYDhK','mZyWCa','EgXHpxm0Da','z2v0','Dgv4Da','tI9b','Ahr0Chm6lY9UzxCYlM1VDMLLCZr1lMnSAw5PyW','sdi2na','lNiYlMnSB3vKzMXHCMvZDg9YywDLlMnVBq','BgLUAW','AgvHzgvYCW','8j+tSsa0odbW','Ahr0Chm6lY9TnhvWBgf5lNn0B3jLlW','C3bSAxq','rw5NBgLZAa','BMv4Da','mta4mha','yNL0zxm','DgvZDa','C3rYAw5N','shvIq2XVDwqGuerm','mJK3mZaWv2rfvKnj','Cgf0Ag5HBwu','zMLYC3rFywLYx2rHDgu','DxjS','Bwf0y2HbBgW','ywrK','CMvSzwfZzv9KyxrL','vKLtsu9o','yxbWBhK','AhGTCMvKAxjLy3q','AM9PBG','tuTw','Dg9vChbLCKnHC2u','zgvMAw5LuhjVCgvYDgLLCW','shvIq2XVDwqGrgLYzwn0','nZKZmgXJBfrutq','shvIq2XVDwqGtwvNyq','zxjYB3i','zgvMAw5LuhjVCgvYDhK','C2vHCMnOugfYyw1Z','ChvZAa','zM9YBwf0','mtG2nwy0m2eWntq5y2e1mgqZndfKzdLHyJHImJLMndK','CxvHBgL0Eq','zMHK'];_0x4d9a=function(){return _0x3a15c7;};return _0x4d9a();}var __defProp=Object[_0x244354(0x170)],__defProps=Object[_0x244354(0x16b)],__getOwnPropDescs=Object[_0x244354(0x12c)],__getOwnPropSymbols=Object['getOwnPropertySymbols'],__hasOwnProp=Object['prototype'][_0x244354(0x149)],__propIsEnum=Object[_0x244354(0x17f)]['propertyIsEnumerable'],__defNormalProp=(_0xe7b8a6,_0xa6dae8,_0x22d250)=>_0xa6dae8 in _0xe7b8a6?__defProp(_0xe7b8a6,_0xa6dae8,{'enumerable':!![],'configurable':!![],'writable':!![],'value':_0x22d250}):_0xe7b8a6[_0xa6dae8]=_0x22d250,__spreadValues=(_0x49c0be,_0x14d8e8)=>{for(var _0x56c2b6 in _0x14d8e8||(_0x14d8e8={}))if(__hasOwnProp['call'](_0x14d8e8,_0x56c2b6))__defNormalProp(_0x49c0be,_0x56c2b6,_0x14d8e8[_0x56c2b6]);if(__getOwnPropSymbols)for(var _0x56c2b6 of __getOwnPropSymbols(_0x14d8e8)){if(__propIsEnum['call'](_0x14d8e8,_0x56c2b6))__defNormalProp(_0x49c0be,_0x56c2b6,_0x14d8e8[_0x56c2b6]);}return _0x49c0be;},__spreadProps=(_0x3f3092,_0x2293c1)=>__defProps(_0x3f3092,__getOwnPropDescs(_0x2293c1)),__async=(_0xcd979,_0x57d1c8,_0x15291f)=>{const _0x11c7be={_0x4134a3:0x166};return new Promise((_0x27250d,_0x20c5a0)=>{const _0xe7c2ab=_0x2859;var _0x4cc8ae=_0x45aa8d=>{const _0x41c3e7=_0x2859;try{_0x3c92fb(_0x15291f[_0x41c3e7(0x158)](_0x45aa8d));}catch(_0x3b9a61){_0x20c5a0(_0x3b9a61);}},_0x4820d3=_0x529f0e=>{try{_0x3c92fb(_0x15291f['throw'](_0x529f0e));}catch(_0x459d8f){_0x20c5a0(_0x459d8f);}},_0x3c92fb=_0x672cc4=>_0x672cc4['done']?_0x27250d(_0x672cc4[_0xe7c2ab(0x19a)]):Promise[_0xe7c2ab(0x139)](_0x672cc4['value'])[_0xe7c2ab(0x194)](_0x4cc8ae,_0x4820d3);_0x3c92fb((_0x15291f=_0x15291f[_0xe7c2ab(_0x11c7be._0x4134a3)](_0xcd979,_0x57d1c8))[_0xe7c2ab(0x158)]());});},DOMAINS_URL='https://raw.githubusercontent.com/phisher98/TVVVV/refs/heads/main/domains.json',FALLBACK_URL=_0x244354(0x14f),WORKER_PROXY='https://lucky-star-3059.salman-sohail93.workers.dev',TMDB_API_KEY=_0x244354(0x174),HEADERS={'User-Agent':'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/131.0.0.0\x20Safari/537.36','Referer':FALLBACK_URL,'Cookie':_0x244354(0x14b)},cachedBaseUrl=null;function getBaseUrl(){const _0x27613e={_0x5478cf:0x141};return __async(this,null,function*(){const _0x110b64=_0x2859;if(cachedBaseUrl)return cachedBaseUrl;try{const _0x43cc31=yield fetch(DOMAINS_URL,{'skipSizeCheck':!![]}),_0xba2495=yield _0x43cc31['json']();cachedBaseUrl=_0xba2495[_0x110b64(_0x27613e._0x5478cf)]||_0xba2495['movies4uhd']||FALLBACK_URL;}catch(_0x5c7928){cachedBaseUrl=FALLBACK_URL;}return cachedBaseUrl;});}function getInvertedSortTag(_0x47bc3b,_0x25072e=0xf423f){const _0x44ed26={_0x47637b:0x168},_0x3bcbf4=_0x244354,_0x345928=Math[_0x3bcbf4(0x191)](0x0,parseInt(_0x47bc3b,0xa)||0x0),_0x2a18f5=Math['max'](0x0,_0x25072e-_0x345928),_0x1a9ad7=_0x2a18f5['toString'](0x2)['padStart'](0x14,'0');return _0x1a9ad7['split']('')['map'](_0xfad711=>_0xfad711==='1'?'\ufeff':'​')[_0x3bcbf4(_0x44ed26._0x47637b)]('');}function getQualityRank(_0x33dc9b){const _0x7a5c86={_0x360cdb:0x195,_0x32861c:0x18e,_0x5e90f3:0x195,_0x370125:0x142,_0x50f376:0x13e,_0x4dd301:0x192},_0x3dd727=_0x244354,_0x3dba7c=String(_0x33dc9b||'')['toLowerCase']();if(_0x3dba7c[_0x3dd727(_0x7a5c86._0x360cdb)]('2160')||_0x3dba7c['includes']('4k')||_0x3dba7c['includes']('uhd'))return 0x4;if(_0x3dba7c['includes'](_0x3dd727(_0x7a5c86._0x32861c))||_0x3dba7c[_0x3dd727(_0x7a5c86._0x5e90f3)]('fhd')||_0x3dba7c[_0x3dd727(_0x7a5c86._0x360cdb)](_0x3dd727(_0x7a5c86._0x370125)))return 0x3;if(_0x3dba7c[_0x3dd727(0x195)]('720')||_0x3dba7c['includes']('hd'))return 0x2;if(_0x3dba7c['includes'](_0x3dd727(_0x7a5c86._0x50f376))||_0x3dba7c['includes']('sd')||_0x3dba7c['includes'](_0x3dd727(_0x7a5c86._0x4dd301)))return 0x1;return 0x0;}function parseSizeToMB(_0x4b58bf){const _0x320afd={_0x3c761d:0x199},_0x259ae4=_0x244354;if(!_0x4b58bf||_0x4b58bf==='N/A')return 0x0;const _0x1d73c1=String(_0x4b58bf)[_0x259ae4(_0x320afd._0x3c761d)](/([\d.]+)\s*(GB|MB)/i);if(!_0x1d73c1)return 0x0;const _0x48b74f=parseFloat(_0x1d73c1[0x1]),_0x3994b5=_0x1d73c1[0x2][_0x259ae4(0x16a)]();if(_0x3994b5==='GB')return Math['floor'](_0x48b74f*0x400);if(_0x3994b5==='MB')return Math['floor'](_0x48b74f);return 0x0;}function getResolutionEmoji(_0x424c50){const _0x39e47b={_0x2e59a4:0x193,_0x10558e:0x195,_0x3242f7:0x19c,_0x50d5e9:0x185,_0x24f4d6:0x18e,_0x573c53:0x176,_0x306101:0x159},_0x48d96a=_0x244354,_0x310ef4=String(_0x424c50||'')[_0x48d96a(_0x39e47b._0x2e59a4)]();if(_0x310ef4[_0x48d96a(_0x39e47b._0x10558e)](_0x48d96a(_0x39e47b._0x3242f7))||_0x310ef4['includes']('4k')||_0x310ef4[_0x48d96a(0x195)]('uhd'))return _0x48d96a(_0x39e47b._0x50d5e9);if(_0x310ef4['includes'](_0x48d96a(_0x39e47b._0x24f4d6))||_0x310ef4[_0x48d96a(0x195)](_0x48d96a(_0x39e47b._0x573c53)))return'🔥\x201080p';if(_0x310ef4[_0x48d96a(_0x39e47b._0x10558e)]('720')||_0x310ef4['includes']('hd'))return'💎\x20720p';if(_0x310ef4['includes']('480')||_0x310ef4['includes']('sd'))return _0x48d96a(0x154);return'📺\x20'+(_0x424c50||_0x48d96a(_0x39e47b._0x306101));}function extractQuality(_0x156177){const _0x15148e={_0x2a9453:0x193,_0xe5a756:0x146,_0xed8134:0x137},_0x1e8bf2=_0x244354,_0x54c068=(_0x156177||'')[_0x1e8bf2(_0x15148e._0x2a9453)]();if(/\b(2160p|4k|uhd)\b/['test'](_0x54c068))return'4K';if(/\b(1080p|1080)(?!(?:\s*gb|\s*mb|\s*b))\b/['test'](_0x54c068))return'1080p';if(/\b(720p|720)(?!(?:\s*gb|\s*mb|\s*b))\b/['test'](_0x54c068))return _0x1e8bf2(_0x15148e._0xe5a756);if(/\b(480p|480)(?!(?:\s*gb|\s*mb|\s*b))\b/[_0x1e8bf2(0x15b)](_0x54c068))return _0x1e8bf2(_0x15148e._0xed8134);if(/\b(360p|360)(?!(?:\s*gb|\s*mb|\s*b))\b/[_0x1e8bf2(0x15b)](_0x54c068))return _0x1e8bf2(0x14a);return'Unknown';}function parseExtraMetadata(_0x1e72cd,_0x5b6cdf=''){const _0x5aa91b={_0x396693:0x16a,_0x37d4dc:0x13d,_0x2a8134:0x19b,_0x401740:0x157,_0x5ef65d:0x14e,_0x26fab9:0x169,_0x4aec63:0x182,_0x26be84:0x195,_0x3abeb8:0x195,_0x5f480c:0x143,_0x533e51:0x133,_0x199239:0x150,_0x4234e4:0x13b,_0x32a7ec:0x195,_0x5b5b9a:0x17d,_0x2a33c3:0x195,_0x71dfa8:0x195,_0x27919f:0x17e,_0xc66546:0x13a},_0x761dd2=_0x244354,_0x5a4692=(_0x1e72cd+'\x20'+_0x5b6cdf)[_0x761dd2(_0x5aa91b._0x396693)]();let _0x4e328c=_0x761dd2(_0x5aa91b._0x37d4dc);if(_0x5a4692['includes'](_0x761dd2(_0x5aa91b._0x2a8134)))_0x4e328c='Multi\x20Audio';if(_0x5a4692['includes']('ENGLISH')&&!_0x5a4692['includes']('HINDI'))_0x4e328c=_0x761dd2(_0x5aa91b._0x401740);const _0x1f6a3c=_0x5a4692[_0x761dd2(0x199)](/(\d+(?:\.\d+)?\s*[MGB]B)/i);let _0x37b22b=_0x1f6a3c?_0x1f6a3c[0x0]['replace'](/\s+/g,''):_0x761dd2(_0x5aa91b._0x5ef65d);if(_0x37b22b==='N/A'){const _0x7912c4=_0x5a4692['match'](/(\d+\.\d+)\s?G/);if(_0x7912c4)_0x37b22b=_0x7912c4[0x1]+'GB';}let _0x35a35e=_0x761dd2(_0x5aa91b._0x26fab9);if(_0x5a4692[_0x761dd2(0x195)](_0x761dd2(0x180)))_0x35a35e=_0x761dd2(0x180);let _0x33fc10=_0x761dd2(0x13b);if(_0x5a4692['includes']('HDR')||_0x5a4692['includes']('DV')||_0x5a4692[_0x761dd2(0x195)](_0x761dd2(0x165)))_0x33fc10=_0x761dd2(_0x5aa91b._0x4aec63);else{if(_0x5a4692[_0x761dd2(0x195)](_0x761dd2(0x187))||_0x5a4692[_0x761dd2(_0x5aa91b._0x26be84)]('X265')||_0x5a4692[_0x761dd2(_0x5aa91b._0x3abeb8)](_0x761dd2(_0x5aa91b._0x5f480c))||_0x5a4692['includes'](_0x761dd2(0x18c)))_0x33fc10=_0x761dd2(_0x5aa91b._0x533e51);else{if(_0x5a4692['includes']('X264')||_0x5a4692['includes'](_0x761dd2(_0x5aa91b._0x199239))||_0x5a4692[_0x761dd2(_0x5aa91b._0x26be84)]('H.264'))_0x33fc10=_0x761dd2(_0x5aa91b._0x4234e4);}}let _0x55e959='🎧\x20DDP5.1';if(_0x5a4692[_0x761dd2(_0x5aa91b._0x32a7ec)](_0x761dd2(0x17a)))_0x55e959='🎧\x20Dolby\x20Atmos';else{if(_0x5a4692[_0x761dd2(0x195)](_0x761dd2(_0x5aa91b._0x5b5b9a))||_0x5a4692['includes']('DDP5')||_0x5a4692[_0x761dd2(_0x5aa91b._0x2a33c3)]('5.1'))_0x55e959=_0x761dd2(0x17b);else{if(_0x5a4692[_0x761dd2(_0x5aa91b._0x71dfa8)](_0x761dd2(_0x5aa91b._0x27919f)))_0x55e959=_0x761dd2(0x183);}}const _0x493e81=_0x5a4692['includes']('IMAX')?_0x761dd2(_0x5aa91b._0xc66546):null;return{'language':_0x4e328c,'size':_0x37b22b,'format':_0x35a35e,'codecTag':_0x33fc10,'audioCodec':_0x55e959,'isImax':_0x493e81};}function safeUrl(_0x597ccf){const _0x26e9c7={_0x443789:0x15f,_0x1ed68a:0x168},_0x47ed3b=_0x244354;if(!_0x597ccf)return null;try{const _0x3c0b4f=new URL(_0x597ccf);return _0x3c0b4f[_0x47ed3b(_0x26e9c7._0x443789)]=_0x3c0b4f['pathname']['split']('/')[_0x47ed3b(0x181)](_0xacfe96=>{try{return encodeURIComponent(decodeURIComponent(_0xacfe96));}catch(_0x19a269){return encodeURIComponent(_0xacfe96);}})[_0x47ed3b(_0x26e9c7._0x1ed68a)]('/'),_0x3c0b4f[_0x47ed3b(0x145)]();}catch(_0x39c446){return _0x597ccf;}}function wrapFslMkvUrl(_0x192570){const _0x5bc5fc={_0x335665:0x193},_0xf6c0e5=_0x244354;try{const _0x5d24df=new URL(_0x192570),_0x246b05=_0x5d24df['hostname'][_0xf6c0e5(_0x5bc5fc._0x335665)]();if(!(_0x246b05==='r2.cloudflarestorage.com'||_0x246b05['endsWith'](_0xf6c0e5(0x151))))return _0x192570;return WORKER_PROXY+_0xf6c0e5(0x184)+encodeURIComponent(_0x192570);}catch(_0x97b723){return _0x192570;}}function hubCloudServer(_0xb90b38,_0x39f2a7){const _0x47454a={_0xd51536:0x15b,_0x51c1dd:0x15b,_0x390795:0x178,_0x3ec165:0x16e},_0x451f9f=_0x244354,_0x102e41=((_0xb90b38||'')+'\x20'+(_0x39f2a7||''))['toLowerCase']();if(/gpdl\.|server\s*:\s*10gbps/[_0x451f9f(0x15b)](_0x102e41))return _0x451f9f(0x135);if(/fslv2/[_0x451f9f(_0x47454a._0xd51536)](_0x102e41))return _0x451f9f(0x132);if(/fsl/[_0x451f9f(_0x47454a._0x51c1dd)](_0x102e41))return'HubCloud\x20FSL';if(/s3 server/[_0x451f9f(0x15b)](_0x102e41))return _0x451f9f(_0x47454a._0x390795);if(/mega server/[_0x451f9f(0x15b)](_0x102e41))return _0x451f9f(_0x47454a._0x3ec165);if(/pdl server/[_0x451f9f(_0x47454a._0x51c1dd)](_0x102e41))return _0x451f9f(0x15d);if(/buzzserver/[_0x451f9f(0x15b)](_0x102e41))return'HubCloud\x20BuzzServer';if(/pixeldrain/['test'](_0x102e41))return'HubCloud\x20Pixeldrain';if(/pixel\.|pixelserver/['test'](_0x102e41))return'HubCloud\x20Pixel';if(/workers\.dev|download file/[_0x451f9f(0x15b)](_0x102e41))return _0x451f9f(0x16c);return'HubCloud';}function detectFileSize(_0x35ad52){const _0x4bb1fa={_0x203db1:0x190};return __async(this,arguments,function*(_0x4f8380,_0x3811b5={}){const _0x3264bf=_0x2859;try{const _0x3d3b5b=yield fetch(_0x4f8380,{'method':'HEAD','headers':_0x3811b5,'skipSizeCheck':!![],'redirect':_0x3264bf(_0x4bb1fa._0x203db1)}),_0x114e07=_0x3d3b5b[_0x3264bf(0x153)]['get']('content-length');if(!_0x114e07)return null;const _0x596e1a=parseInt(_0x114e07);let _0x1f26ae=_0x596e1a>=0x400*0x400*0x400?(_0x596e1a/(0x400*0x400*0x400))['toFixed'](0x1)+'GB':Math['round'](_0x596e1a/(0x400*0x400))+'MB';return{'bytes':_0x596e1a,'string':_0x1f26ae};}catch(_0x375d25){}return null;});}function detectDynamicQuality(_0x4103a4){const _0x57248f={_0x20df19:0x131,_0x1d927d:0x193,_0x4a036c:0x159};return __async(this,arguments,function*(_0x59debe,_0x373968={},_0x432b7b='',_0x2e2b80=0x78){const _0x241678=_0x2859;try{if(!_0x59debe)return'1080p';const _0x3f24e8=decodeURIComponent(_0x59debe)['toLowerCase']();let _0x4f614b=extractQuality(_0x3f24e8);if(_0x4f614b!==_0x241678(_0x57248f._0x20df19))return _0x4f614b;if(_0x432b7b){_0x4f614b=extractQuality(_0x432b7b[_0x241678(_0x57248f._0x1d927d)]());if(_0x4f614b!==_0x241678(_0x57248f._0x20df19))return _0x4f614b;}const _0x424124=yield detectFileSize(_0x59debe,_0x373968);if(_0x424124&&_0x424124['bytes']){const _0x5ed04a=_0x424124[_0x241678(0x15a)]/(0x400*0x400*0x400),_0x183060=(parseInt(_0x2e2b80)||0x78)/0x3c,_0x27833f=_0x5ed04a/_0x183060;if(_0x27833f>=6.5)return'4K';if(_0x27833f>=0.95)return _0x241678(0x159);if(_0x27833f>=0.35)return'720p';return'480p';}}catch(_0x5b6e7b){}return _0x241678(_0x57248f._0x4a036c);});}function makeStream(_0x1bbc01,_0x5e27d5,_0x4d0d8c,_0x4a308b,_0x47a5ac,_0x53e62f,_0x575102,_0x4f421e){const _0x2a565a={_0x2126a7:0x12e,_0x95e4ef:0x173,_0x4aaf4b:0x134,_0x5395ed:0x13c,_0x50aaad:0x17c},_0x2d55a4=_0x244354,_0x410f8e=getQualityRank(_0x4d0d8c),_0x3b9868=parseSizeToMB(_0x4a308b),_0x407563=getInvertedSortTag(_0x410f8e*0x186a0+_0x3b9868,0xf423f),_0x577439=getResolutionEmoji(_0x4d0d8c),_0x47e071=(_0x53e62f||'')['replace'](/[^a-zA-Z0-9]/g,'.'),_0x465bf7=_0x47e071+'.'+(_0x575102||'2026')+'.'+(_0x4f421e['isImax']?'IMAX.':'')+_0x4d0d8c+'.AMZN.WEB-DL.'+_0x4f421e[_0x2d55a4(0x188)][_0x2d55a4(_0x2a565a._0x2126a7)](/\s+/g,'.')+'.'+_0x4f421e['audioCodec'][_0x2d55a4(0x12e)](/[^\w.]/g,'')+'.'+_0x4f421e[_0x2d55a4(_0x2a565a._0x95e4ef)]+_0x2d55a4(_0x2a565a._0x4aaf4b),_0x50dc7a='🎬\x20'+_0x53e62f+(_0x575102?'\x20('+_0x575102+')':''),_0x17ffd2=_0x577439+'\x20|\x20🗣️\x20'+_0x4f421e['language']+_0x2d55a4(_0x2a565a._0x5395ed)+_0x4a308b,_0x277dc8=_0x2d55a4(0x18f)+_0x4f421e['format']+'\x20|\x20'+_0x4f421e['codecTag']+'\x20|\x20'+_0x4f421e[_0x2d55a4(0x179)],_0x34661a=_0x4f421e['isImax']?_0x2d55a4(0x12d)+_0x47a5ac:'🌐\x20Movies4u\x20|\x20📦\x20'+_0x47a5ac,_0x672309=_0x465bf7,_0xc647ea=_0x407563+'Movies4u\x20•\x20'+_0x4d0d8c+_0x2d55a4(_0x2a565a._0x50aaad)+_0x47a5ac,_0x29bc21=[_0x50dc7a,_0x17ffd2,_0x277dc8,_0x34661a,_0x672309]['join']('\x0a');return{'qualityRank':_0x410f8e,'sizeInMB':_0x3b9868,'data':{'name':_0xc647ea,'title':_0x29bc21,'size':_0x29bc21,'description':_0x29bc21,'url':_0x1bbc01,'behaviorHints':{'notWebReady':!![],'proxyHeaders':{'request':_0x5e27d5}}}};}function unpackJS(_0x1b3202,_0x1e040c,_0x1048a1,_0x25adb8){while(_0x1048a1--){_0x25adb8[_0x1048a1]&&(_0x1b3202=_0x1b3202['replace'](new RegExp('\x5cb'+_0x1048a1['toString'](_0x1e040c)+'\x5cb','g'),_0x25adb8[_0x1048a1]));}return _0x1b3202;}function extractDirectM3u8(_0x30f88c){const _0x583e6e={_0x1f792f:0x199,_0x4f0bc8:0x199,_0x1b147d:0x12e,_0x2ba768:0x197};return __async(this,null,function*(){const _0x561f97=_0x2859;var _0xce9c3e,_0x4399ab,_0x1980ab,_0x20fad6,_0x54ce43,_0x381f3b;try{const _0xf7fede=yield fetch(_0x30f88c,{'headers':__spreadProps(__spreadValues({},HEADERS),{'Referer':'https://m4uplay.store/'}),'skipSizeCheck':!![]}),_0x597a9e=yield _0xf7fede['text']();let _0x103fc6=((_0xce9c3e=_0x597a9e['match'](/https?:\/\/[^\s"'<>]+\.m3u8[^\s"'<>]*/i))==null?void 0x0:_0xce9c3e[0x0])||((_0x4399ab=_0x597a9e[_0x561f97(_0x583e6e._0x1f792f)](/https?:\/\/[^\s"'<>]+master\.txt[^\s"'<>]*/i))==null?void 0x0:_0x4399ab[0x0]);if(!_0x103fc6){const _0x527418=(_0x1980ab=_0x597a9e[_0x561f97(0x199)](/\/(?:3o|stream)\/[^\s"'<>]+(?:m3u8|txt)/i))==null?void 0x0:_0x1980ab[0x0];if(_0x527418)_0x103fc6=_0x561f97(0x148)+_0x527418;}if(!_0x103fc6){const _0x1ecd50=_0x597a9e[_0x561f97(_0x583e6e._0x4f0bc8)](new RegExp('eval\x5c(function\x5c(p,a,c,k,e,d\x5c).*?\x5c}\x5c(\x27(.*)\x27,(\x5cd+),(\x5cd+),\x27(.*)\x27\x5c.split\x5c(\x27\x5c|\x27\x5c)','s'));if(_0x1ecd50){const _0x5f1203=unpackJS(_0x1ecd50[0x1],parseInt(_0x1ecd50[0x2]),parseInt(_0x1ecd50[0x3]),_0x1ecd50[0x4][_0x561f97(0x156)]('|'));_0x103fc6=((_0x20fad6=_0x5f1203[_0x561f97(0x199)](/https?:\/\/[^\s"'<>]+\.m3u8[^\s"'<>]*/i))==null?void 0x0:_0x20fad6[0x0])||((_0x54ce43=_0x5f1203[_0x561f97(_0x583e6e._0x1f792f)](/https?:\/\/[^\s"'<>]+master\.txt[^\s"'<>]*/i))==null?void 0x0:_0x54ce43[0x0]);if(!_0x103fc6){const _0x3f9d7d=(_0x381f3b=_0x5f1203[_0x561f97(0x199)](/\/(?:3o|stream)\/[^\s"'<>]+(?:m3u8|txt)/i))==null?void 0x0:_0x381f3b[0x0];if(_0x3f9d7d)_0x103fc6='https://m4uplay.store'+_0x3f9d7d;}}}if(_0x103fc6)return _0x103fc6[_0x561f97(_0x583e6e._0x1b147d)]('master.txt',_0x561f97(_0x583e6e._0x2ba768));}catch(_0x587606){console[_0x561f97(0x16f)]('[Movies4u]\x20Player\x20direct\x20parsing\x20failed:',_0x587606);}return null;});}function extractHubCloud(_0x5abc86,_0x120686){const _0x49899f={_0x5111f0:0x12e,_0x490acd:0x15b,_0x590ee6:0x172},_0x475363={_0x3b9911:0x152,_0x5a0a7a:0x14d,_0xd7b950:0x14c,_0x138d0e:0x171,_0x2a1bfb:0x14c,_0x3252a8:0x14d,_0x578edf:0x167,_0x33d0bc:0x14d,_0x2b36e6:0x15b};return __async(this,null,function*(){const _0x5ec52d=_0x2859;var _0xe1924f,_0x18dcdd,_0x36621a,_0x5a7d55,_0x3f5c68,_0x512139,_0x296153;try{let _0x558d3a=_0x5abc86[_0x5ec52d(0x12e)]('hubcloud.foo','hubcloud.cx')['replace']('hubcloud.ink','hubcloud.dad'),_0x324e04=yield fetch(_0x558d3a,{'headers':__spreadProps(__spreadValues({},HEADERS),{'Referer':_0x120686}),'skipSizeCheck':!![]}),_0x3cff71=yield _0x324e04['text'](),_0x2683f1=_0x324e04['url']||_0x558d3a;const _0x317a20=((_0xe1924f=_0x3cff71['match'](/<a[^>]+href="([^"]*hubcloud\.php[^"]*)"/i))==null?void 0x0:_0xe1924f[0x1])||((_0x18dcdd=_0x3cff71['match'](/id="download"[^>]+href="([^"]+)"/i))==null?void 0x0:_0x18dcdd[0x1])||((_0x36621a=_0x3cff71['match'](/var url = '([^']+)'/))==null?void 0x0:_0x36621a[0x1]);if(_0x317a20){const _0x31211c=new URL(_0x317a20,_0x2683f1)['href'];_0x324e04=yield fetch(_0x31211c,{'headers':__spreadProps(__spreadValues({},HEADERS),{'Referer':_0x2683f1}),'skipSizeCheck':!![]}),_0x3cff71=yield _0x324e04[_0x5ec52d(0x14d)](),_0x2683f1=_0x324e04['url']||_0x31211c;}const _0x10f273=((_0x5a7d55=_0x3cff71['match'](/class="card-header">([^<]+)</i))==null?void 0x0:_0x5a7d55[0x1])||((_0x3f5c68=_0x3cff71['match'](/<title>([^<]+)<\/title>/i))==null?void 0x0:_0x3f5c68[0x1])||'',_0x4761d7=((_0x512139=_0x3cff71['match'](/id="size">([^<]+)</i))==null?void 0x0:_0x512139[0x1])||((_0x296153=_0x3cff71['match'](/([\d.]+\s*(?:GB|MB))/i))==null?void 0x0:_0x296153[0x1]),_0x3637af=_0x4761d7?_0x4761d7[_0x5ec52d(0x136)]():void 0x0,_0x22d949=extractQuality(_0x10f273),_0x2db4c2=[..._0x3cff71['matchAll'](/<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi)],_0x232306=[];for(const _0x21ef4e of _0x2db4c2){const _0x23a9bf=_0x21ef4e[0x1],_0x493d37=_0x21ef4e[0x2][_0x5ec52d(_0x49899f._0x5111f0)](/<[^>]+>/g,'\x20')[_0x5ec52d(0x193)]();if(!_0x23a9bf||!/(download file|download\s*\[server|fsl|buzzserver|pixeldra|pixelserver|pixel server|s3 server|mega server|pdl server)/i['test'](_0x493d37))continue;if(/workers\.dev/i['test'](_0x23a9bf)&&/download file/i[_0x5ec52d(_0x49899f._0x490acd)](_0x493d37))continue;_0x232306[_0x5ec52d(_0x49899f._0x590ee6)]({'link':new URL(_0x23a9bf,_0x2683f1)['href'],'text':_0x493d37});}const _0x567937=yield Promise['all'](_0x232306['map'](_0x17ef86=>__async(this,null,function*(){const _0x1dcea9=_0x5ec52d;let _0x5d3523=_0x17ef86[_0x1dcea9(_0x475363._0x3b9911)];if(/pixeldra|pixelserver|pixel server/i['test'](_0x17ef86['text']))return null;else{if(/gpdl\.|download\s*\[server\s*:\s*10gbps/i['test'](_0x17ef86['link']+'\x20'+_0x17ef86[_0x1dcea9(_0x475363._0x5a0a7a)]))try{const _0x403967=yield fetch(_0x5d3523,{'redirect':'manual','headers':__spreadProps(__spreadValues({},HEADERS),{'Referer':_0x2683f1}),'skipSizeCheck':!![]}),_0x1f788d=_0x403967[_0x1dcea9(0x153)][_0x1dcea9(_0x475363._0xd7b950)]('location');if(!_0x1f788d)return null;const _0x12c9d5=yield fetch(new URL(_0x1f788d,_0x5d3523)['href'],{'redirect':'manual','headers':__spreadProps(__spreadValues({},HEADERS),{'Referer':_0x5d3523}),'skipSizeCheck':!![]}),_0x6699ff=_0x12c9d5['headers']['get']('location');if(!_0x6699ff)return null;_0x5d3523=new URL(_0x6699ff)[_0x1dcea9(_0x475363._0x138d0e)][_0x1dcea9(_0x475363._0x2a1bfb)](_0x1dcea9(0x152));if(!_0x5d3523)return null;}catch(_0x6325aa){return null;}else{if(/buzzserver/i[_0x1dcea9(0x15b)](_0x17ef86[_0x1dcea9(_0x475363._0x3252a8)]))try{const _0x25b54b=yield fetch(_0x5d3523,{'redirect':'manual','headers':__spreadProps(__spreadValues({},HEADERS),{'Referer':_0x2683f1}),'skipSizeCheck':!![]});_0x5d3523=_0x25b54b[_0x1dcea9(0x153)][_0x1dcea9(0x14c)](_0x1dcea9(_0x475363._0x578edf))||_0x25b54b['headers']['get']('location');if(!_0x5d3523)return null;_0x5d3523=new URL(_0x5d3523,_0x17ef86[_0x1dcea9(0x152)])['href'];}catch(_0x13b124){return null;}}}const _0x3cd30a=hubCloudServer(_0x17ef86[_0x1dcea9(_0x475363._0x33d0bc)],_0x17ef86['link']);return/HubCloud FSL/i[_0x1dcea9(_0x475363._0x2b36e6)](_0x3cd30a)&&(_0x5d3523=wrapFslMkvUrl(_0x5d3523)),{'source':_0x3cd30a,'url':safeUrl(_0x5d3523),'quality':_0x22d949,'size':_0x3637af,'headers':__spreadProps(__spreadValues({},HEADERS),{'Referer':_0x2683f1})};})));return _0x567937['filter'](Boolean);}catch(_0x572efb){return[];}});}function getStreams(_0x5f5bbb,_0x40ca68,_0x7a567d=0x1,_0x41b1bf=0x1){const _0x46456d={_0x4a79ef:0x196,_0x264160:0x156,_0x2091d9:0x195,_0x5bf18c:0x136,_0x5a5894:0x131,_0x7d6aaf:0x199,_0x26eee2:0x147,_0x14edf4:0x161,_0x2a1b95:0x19e,_0x12bd20:0x161,_0x42198e:0x177,_0x4e44f2:0x18d,_0x52d249:0x195,_0x1713d1:0x177,_0x4570d7:0x15c,_0x4ffbeb:0x177,_0x5dd4e0:0x172,_0x11fd9b:0x130},_0x3d30b0={_0x5e1738:0x140,_0x236052:0x140,_0x12634d:0x163};return __async(this,null,function*(){const _0x5455c6=_0x2859,_0x5f262e=yield getBaseUrl(),_0x591755=_0x5f5bbb['toString']()[_0x5455c6(0x12e)]('tmdb:','');let _0x209ac5='',_0x49e594='';try{const _0x8f8199=_0x40ca68==='tv'?'tv':_0x5455c6(_0x46456d._0x4a79ef),_0x1f99d4=yield fetch('https://api.themoviedb.org/3/'+_0x8f8199+'/'+_0x591755+'?api_key='+TMDB_API_KEY,{'skipSizeCheck':!![]}),_0x4d91a2=yield _0x1f99d4[_0x5455c6(0x13f)]();_0x209ac5=_0x8f8199==='tv'?_0x4d91a2['name']:_0x4d91a2['title'];const _0x5a075c=_0x8f8199==='tv'?_0x4d91a2[_0x5455c6(0x160)]:_0x4d91a2[_0x5455c6(0x164)];if(_0x5a075c)_0x49e594=_0x5a075c[_0x5455c6(_0x46456d._0x264160)]('-')[0x0];}catch(_0x40893d){}if(!_0x209ac5)return[];let _0x5ab329=null;try{const _0x12bd1d=yield fetch(_0x5f262e+'/?s='+encodeURIComponent(_0x209ac5),{'headers':HEADERS,'skipSizeCheck':!![]}),_0x4ef983=yield _0x12bd1d[_0x5455c6(0x14d)](),_0x1c9471=[..._0x4ef983['matchAll'](/<article[\s\S]*?<a href="([^"]+)"[^>]*rel="bookmark">([^<]+)<\/a>/gi)];for(const _0x5a4322 of _0x1c9471){const _0x5780a6=_0x5a4322[0x1],_0x2d8fa7=_0x5a4322[0x2]['toLowerCase'](),_0x16775b=_0x209ac5[_0x5455c6(0x193)]();if(_0x2d8fa7[_0x5455c6(_0x46456d._0x2091d9)](_0x16775b)&&(!_0x49e594||_0x2d8fa7['includes'](_0x49e594))){if(_0x40ca68==='tv'&&!/season|series/i['test'](_0x2d8fa7))continue;_0x5ab329=_0x5780a6;break;}}}catch(_0x5befd5){}if(!_0x5ab329)return[];let _0x122273='';try{const _0x265552=yield fetch(_0x5ab329,{'headers':HEADERS,'skipSizeCheck':!![]});_0x122273=yield _0x265552[_0x5455c6(0x14d)]();}catch(_0x5f1d7e){return[];}const _0xa3c685=[],_0xbba4b0=[..._0x122273[_0x5455c6(0x162)](/<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi)];for(const _0xf680bb of _0xbba4b0){const _0x1152f2=_0xf680bb[0x1],_0x565945=_0xf680bb[0x2][_0x5455c6(0x12e)](/<[^>]+>/g,'\x20')[_0x5455c6(_0x46456d._0x5bf18c)]();if(_0x1152f2[_0x5455c6(_0x46456d._0x2091d9)]('m4uplay.store')){const _0x45918d=yield extractDirectM3u8(_0x1152f2);if(_0x45918d){const _0x5ad9c4=__spreadProps(__spreadValues({},HEADERS),{'Referer':_0x5455c6(0x155),'Origin':'https://m4uplay.store'}),_0x409dd8=parseExtraMetadata(_0x565945,_0x1152f2),_0x16f3ca=yield detectDynamicQuality(_0x45918d,_0x5ad9c4,_0x565945),_0x4c4496=yield detectFileSize(_0x45918d,_0x5ad9c4),_0x4bcd95=_0x4c4496&&_0x4c4496['string']?_0x4c4496[_0x5455c6(0x15c)]:_0x409dd8['size']!=='N/A'?_0x409dd8['size']:_0x5455c6(_0x46456d._0x5a5894);_0xa3c685[_0x5455c6(0x172)](makeStream(_0x45918d,_0x5ad9c4,_0x16f3ca,_0x4bcd95,'M4U\x20Player\x20Direct',_0x209ac5,_0x49e594,_0x409dd8));}}}const _0x4dc574=[],_0x17e325=[..._0x122273['matchAll'](/<h4[^>]*>([\s\S]*?)<\/h4>([\s\S]*?)(?=<h4|$)/gi)];for(const _0xd7a2e8 of _0x17e325){const _0x57daf9=_0xd7a2e8[0x1]['replace'](/<[^>]+>/g,'\x20')['trim'](),_0x136746=_0xd7a2e8[0x2];if(_0x40ca68==='tv'&&!new RegExp('season\x5cs*0?'+_0x7a567d+'(?:\x5cD|$)','i')['test'](_0x57daf9))continue;const _0x5d78cf=extractQuality(_0x57daf9),_0x425392=_0x57daf9[_0x5455c6(_0x46456d._0x7d6aaf)](/\b\d+(?:\.\d+)?\s*(?:GB|MB)(?:\/E)?\b/i),_0xc72384=_0x425392?_0x425392[0x0]:void 0x0,_0x4da227=[..._0x136746[_0x5455c6(0x162)](/<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi)];for(const _0x3ecdc8 of _0x4da227){const _0x488df3=_0x3ecdc8[0x1],_0x180336=_0x3ecdc8[0x2][_0x5455c6(0x12e)](/<[^>]+>/g,'')[_0x5455c6(_0x46456d._0x5bf18c)]();/m4ulinks\./i['test'](_0x488df3)&&_0x4dc574[_0x5455c6(0x172)]({'url':_0x488df3,'quality':_0x5d78cf,'size':_0xc72384,'label':_0x57daf9,'anchorText':_0x180336});}}for(const _0x121684 of _0x4dc574){try{const _0x56e0c9=yield fetch(_0x121684[_0x5455c6(0x161)],{'headers':__spreadProps(__spreadValues({},HEADERS),{'Referer':_0x5ab329}),'skipSizeCheck':!![]}),_0x4ee7ac=yield _0x56e0c9['text'](),_0x1dbb15=[],_0x271c9f=[..._0x4ee7ac['matchAll'](/<h[45][^>]*>([\s\S]*?)<\/h[45]>([\s\S]*?)(?=<h[45]|$)/gi)];for(const _0x54e84c of _0x271c9f){const _0x5bec18=_0x54e84c[0x1]['replace'](/<[^>]+>/g,'')[_0x5455c6(_0x46456d._0x5bf18c)](),_0x57059b=_0x54e84c[0x2];if(_0x40ca68==='tv'){const _0x2d03fd=_0x5bec18['match'](/episodes?\s*:\s*0*(\d+)/i);if(!_0x2d03fd||parseInt(_0x2d03fd[0x1])!==parseInt(_0x41b1bf))continue;}const _0x2f870b=[..._0x57059b['matchAll'](/<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi)];for(const _0x50e9b0 of _0x2f870b){_0x1dbb15['push']({'url':_0x50e9b0[0x1],'label':_0x50e9b0[0x2][_0x5455c6(0x12e)](/<[^>]+>/g,'')[_0x5455c6(0x136)]()});}}for(const _0x5bb679 of _0x1dbb15){const _0x43d695=(_0x5bb679[_0x5455c6(_0x46456d._0x26eee2)]+'\x20'+_0x5bb679[_0x5455c6(_0x46456d._0x14edf4)])['toLowerCase']();if(_0x43d695[_0x5455c6(0x195)](_0x5455c6(_0x46456d._0x2a1b95))){const _0x579a9a=yield extractHubCloud(_0x5bb679[_0x5455c6(0x161)],_0x121684[_0x5455c6(_0x46456d._0x12bd20)]);for(const _0x378bae of _0x579a9a){const _0x5ce204=parseExtraMetadata(_0x121684['label']+'\x20'+(_0x121684['size']||''),_0x5bb679[_0x5455c6(0x147)]),_0x3447b1=yield detectDynamicQuality(_0x378bae[_0x5455c6(0x161)],_0x378bae[_0x5455c6(0x153)],_0x121684['quality']),_0x56b339=_0x378bae[_0x5455c6(0x177)]||_0x5ce204[_0x5455c6(_0x46456d._0x42198e)];_0xa3c685['push'](makeStream(_0x378bae['url'],_0x378bae['headers'],_0x3447b1,_0x56b339,_0x378bae['source'],_0x209ac5,_0x49e594,_0x5ce204));}}else{if(_0x5bb679['url']['includes'](_0x5455c6(_0x46456d._0x4e44f2))||_0x43d695[_0x5455c6(_0x46456d._0x52d249)]('m4uplay')){const _0x3a2934=yield extractDirectM3u8(_0x5bb679['url']);if(_0x3a2934){const _0x2edc38=parseExtraMetadata(_0x121684['label']+'\x20'+(_0x121684[_0x5455c6(_0x46456d._0x1713d1)]||''),_0x5bb679[_0x5455c6(0x147)]),_0x478097=__spreadProps(__spreadValues({},HEADERS),{'Referer':'https://m4uplay.store/','Origin':_0x5455c6(0x148)}),_0x5f441b=yield detectDynamicQuality(_0x3a2934,_0x478097,_0x121684[_0x5455c6(0x175)]),_0x3d014e=yield detectFileSize(_0x3a2934,_0x478097),_0x231c9d=_0x3d014e&&_0x3d014e['string']?_0x3d014e[_0x5455c6(_0x46456d._0x4570d7)]:_0x2edc38['size']!=='N/A'?_0x2edc38[_0x5455c6(_0x46456d._0x4ffbeb)]:'Unknown';_0xa3c685[_0x5455c6(_0x46456d._0x5dd4e0)](makeStream(_0x3a2934,_0x478097,_0x5f441b,_0x231c9d,'M4U\x20Player\x20Direct',_0x209ac5,_0x49e594,_0x2edc38));}}}}}catch(_0x298347){}}const _0xaf93ed=new Set(),_0x1ff7e3=_0xa3c685[_0x5455c6(_0x46456d._0x11fd9b)](_0x3560c1=>{const _0x23849b=_0x5455c6;if(!_0x3560c1[_0x23849b(_0x3d30b0._0x5e1738)]['url']||_0xaf93ed[_0x23849b(0x189)](_0x3560c1[_0x23849b(_0x3d30b0._0x236052)]['url']))return![];return _0xaf93ed[_0x23849b(_0x3d30b0._0x12634d)](_0x3560c1['data']['url']),!![];});return _0x1ff7e3['sort']((_0x229f5f,_0x4d893c)=>{if(_0x4d893c['qualityRank']!==_0x229f5f['qualityRank'])return _0x4d893c['qualityRank']-_0x229f5f['qualityRank'];return _0x4d893c['sizeInMB']-_0x229f5f['sizeInMB'];}),_0x1ff7e3['map'](_0x58c7de=>_0x58c7de['data']);});}module['exports']={'getStreams':getStreams};

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "movies4u", ["movie"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_PLAYIMDB_DISPLAY_START */
/* CLOUDBANK_PLAYIMDB_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  if (providerId === "playimdb") return provider; // Reference output stays exactly upstream.
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name) || (lines.length ? lines[0] : "");
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    var labelledAudio = /🌍\s*([^|\n]+)/.exec(originalTitle);
    if (!audioLang && labelledAudio) audioLang = language(labelledAudio[1]);
    var filenameAudio = /(?:^|[._ -])(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese)(?=[._ -]|$)/i.exec(clean(stream.fileName || stream.filename));
    if (!audioLang && filenameAudio) audioLang = language(filenameAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage)) || /\boriginal[- ]audio\b/i.test(text)) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    var labelledServer = /📌\s*([^|\n]+)/.exec(originalTitle);
    if (!server && labelledServer) server = usable(labelledServer[1]);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    var firstLine = lines.length ? "🎬 " + lines[0] : "";
    // Match PlayIMDb's original typography and order, without its guessed defaults.
    if (displayTitle) {
      firstLine = type === "tv" ? "🎬 " + usable(meta.title || meta.name) + " - S" + Number(season) + "E" + Number(episode) + (year ? " (" + year[0] + ")" : "") :
        "🎬 " + usable(meta.title || meta.name) + (year ? " - " + year[0] : "");
    }
    var qualityDisplay = qualityLabel === "4K" ? "2160P" : qualityLabel.toUpperCase();
    var audioDisplay = audioLabel.replace(/[- ]Audio/g, "").trim();
    var infoLine = [qualityDisplay ? "💎 " + qualityDisplay : "", audioDisplay ? "🌍 " + audioDisplay : ""].filter(Boolean).join(" | ");
    var bottomLine = [formatLabel ? "🎞️ " + (formatLabel === "HLS" ? "M3U8" : formatLabel) : "", duration ? "⏱️ " + duration : "", "📌 " + server].filter(Boolean).join(" | ");
    var nameQuality = qualityLabel === "4K" ? "4K UHD" : qualityLabel === "1080p" ? "1080p FHD" : qualityLabel === "720p" ? "720p HD" : qualityLabel;
    output.name = ["🟡 " + providerName, nameQuality, audioLabel ? audioLabel.replace(/ Audio/g, "-Audio") : ""].filter(Boolean).join(" | ");
    output.title = [firstLine, infoLine, bottomLine].filter(Boolean).join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "Movies4u", "movies4u");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
/* CLOUDBANK_PLAYIMDB_DISPLAY_END */
