// Imported provider: einthusan; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
'use strict';const _0x1441be=_0x2a19;(function(_0x8910e3,_0x522a64){const _0x3c8156={_0x14f49:0x1a0,_0x3a8d3e:0x1b5,_0x4d6854:0x1bb,_0x494d92:0x1a8,_0x542e65:0x1bd},_0x2088a6=_0x2a19,_0x3d69ea=_0x8910e3();while(!![]){try{const _0x5463a7=parseInt(_0x2088a6(_0x3c8156._0x14f49))/0x1+-parseInt(_0x2088a6(0x1a2))/0x2*(parseInt(_0x2088a6(0x199))/0x3)+parseInt(_0x2088a6(0x1a9))/0x4+-parseInt(_0x2088a6(_0x3c8156._0x3a8d3e))/0x5*(parseInt(_0x2088a6(_0x3c8156._0x4d6854))/0x6)+parseInt(_0x2088a6(0x172))/0x7*(parseInt(_0x2088a6(_0x3c8156._0x494d92))/0x8)+-parseInt(_0x2088a6(_0x3c8156._0x542e65))/0x9*(-parseInt(_0x2088a6(0x197))/0xa)+-parseInt(_0x2088a6(0x17d))/0xb*(-parseInt(_0x2088a6(0x1bf))/0xc);if(_0x5463a7===_0x522a64)break;else _0x3d69ea['push'](_0x3d69ea['shift']());}catch(_0x1e9f95){_0x3d69ea['push'](_0x3d69ea['shift']());}}}(_0x4b0c,0x54215));var __defProp=Object['defineProperty'],__defProps=Object[_0x1441be(0x1ae)],__getOwnPropDescs=Object['getOwnPropertyDescriptors'],__getOwnPropSymbols=Object['getOwnPropertySymbols'],__hasOwnProp=Object['prototype'][_0x1441be(0x1ab)],__propIsEnum=Object[_0x1441be(0x184)][_0x1441be(0x1be)],__defNormalProp=(_0x4e0f51,_0x4c3e66,_0x6ec5e9)=>_0x4c3e66 in _0x4e0f51?__defProp(_0x4e0f51,_0x4c3e66,{'enumerable':!![],'configurable':!![],'writable':!![],'value':_0x6ec5e9}):_0x4e0f51[_0x4c3e66]=_0x6ec5e9,__spreadValues=(_0x5ed0d0,_0x425273)=>{const _0x498949=_0x1441be;for(var _0x4279c2 in _0x425273||(_0x425273={}))if(__hasOwnProp['call'](_0x425273,_0x4279c2))__defNormalProp(_0x5ed0d0,_0x4279c2,_0x425273[_0x4279c2]);if(__getOwnPropSymbols)for(var _0x4279c2 of __getOwnPropSymbols(_0x425273)){if(__propIsEnum[_0x498949(0x189)](_0x425273,_0x4279c2))__defNormalProp(_0x5ed0d0,_0x4279c2,_0x425273[_0x4279c2]);}return _0x5ed0d0;},__spreadProps=(_0x3a6abd,_0x5c1c84)=>__defProps(_0x3a6abd,__getOwnPropDescs(_0x5c1c84)),__async=(_0x529aee,_0x59d272,_0x111b3b)=>{return new Promise((_0x16e579,_0x567020)=>{const _0x4b7303={_0x24616c:0x1b9},_0x55bb92=_0x2a19;var _0x235343=_0x53fdbe=>{const _0x314a85=_0x2a19;try{_0x3c52b1(_0x111b3b[_0x314a85(_0x4b7303._0x24616c)](_0x53fdbe));}catch(_0x58b498){_0x567020(_0x58b498);}},_0x3fc91e=_0x1b8684=>{try{_0x3c52b1(_0x111b3b['throw'](_0x1b8684));}catch(_0x227f7e){_0x567020(_0x227f7e);}},_0x3c52b1=_0x44bf2b=>_0x44bf2b[_0x55bb92(0x192)]?_0x16e579(_0x44bf2b[_0x55bb92(0x1c1)]):Promise['resolve'](_0x44bf2b['value'])[_0x55bb92(0x1b6)](_0x235343,_0x3fc91e);_0x3c52b1((_0x111b3b=_0x111b3b['apply'](_0x529aee,_0x59d272))[_0x55bb92(0x1b9)]());});};function onSettings(){const _0x15efe0={_0x3bd153:0x1ac,_0x3de0aa:0x1a5,_0xab4b82:0x1ac,_0x2b3579:0x1bc,_0x1c1f42:0x183,_0x38099d:0x178};return __async(this,null,function*(){const _0x3d0bfc=_0x2a19;return[{'type':'header','label':'Language\x20Preferences'},{'type':_0x3d0bfc(_0x15efe0._0x3bd153),'key':_0x3d0bfc(0x1a6),'label':'Enable\x20Hindi\x20🇮🇳','defaultValue':!![]},{'type':'toggle','key':_0x3d0bfc(_0x15efe0._0x3de0aa),'label':_0x3d0bfc(0x19f),'defaultValue':!![]},{'type':_0x3d0bfc(_0x15efe0._0xab4b82),'key':_0x3d0bfc(_0x15efe0._0x2b3579),'label':'Enable\x20Telugu\x20🇮🇳','defaultValue':!![]},{'type':_0x3d0bfc(_0x15efe0._0x3bd153),'key':_0x3d0bfc(_0x15efe0._0x1c1f42),'label':'Enable\x20Malayalam\x20🇮🇳','defaultValue':!![]},{'type':'toggle','key':'langKannada','label':'Enable\x20Kannada\x20🇮🇳','defaultValue':!![]},{'type':'toggle','key':_0x3d0bfc(_0x15efe0._0x38099d),'label':'Enable\x20Bengali\x20🇧🇩','defaultValue':!![]}];});}var EINTHUSAN_BASE='https://einthusan.asaddon.com',TMDB_API_KEY=_0x1441be(0x188),PROVIDER_NAME='Einthusan',LANGUAGES={'langHindi':{'path':_0x1441be(0x1a7),'label':'Hindi\x20🇮🇳','webCode':_0x1441be(0x1a7)},'langTamil':{'path':_0x1441be(0x1b3),'label':_0x1441be(0x1c5),'webCode':_0x1441be(0x1b3)},'langTelugu':{'path':_0x1441be(0x1b1),'label':'Telugu','webCode':'telugu'},'langMalayalam':{'path':'malayalam','label':'Malayalam','webCode':_0x1441be(0x198)},'langKannada':{'path':_0x1441be(0x182),'label':'Kannada','webCode':'kannada'},'langBengali':{'path':'bengali','label':'Bengali\x20🇧🇩','webCode':_0x1441be(0x19a)}},LANGUAGE_ORDER=['hindi',_0x1441be(0x1b3),'telugu',_0x1441be(0x198),'kannada',_0x1441be(0x19a)],DEFAULT_HEADERS={'User-Agent':_0x1441be(0x191),'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8','Accept-Language':_0x1441be(0x1c3)},sessionCache={};function getSession(_0x5c84e8){const _0x19b855=_0x1441be,_0x8e7a7=sessionCache['session_'+_0x5c84e8];if(!_0x8e7a7)return null;if(Date['now']()-_0x8e7a7['createdAt']>2.5*0x3c*0x3c*0x3e8)return delete sessionCache[_0x19b855(0x1a4)+_0x5c84e8],null;return _0x8e7a7['cookieString'];}function parseAndCombineCookies(_0x1859fb,_0x8095e4){const _0x460241={_0x429f21:0x16d},_0x4d1aa1={_0x7b6ea8:0x16c,_0x3bfde8:0x175},_0x288924=_0x1441be;if(!_0x8095e4)return _0x1859fb;const _0x50b3dd={};_0x1859fb&&_0x1859fb[_0x288924(_0x460241._0x429f21)](';')['forEach'](_0x35f575=>{const _0x1de3bd=_0x288924,_0x16e8d4=_0x35f575[_0x1de3bd(0x16d)]('=');if(_0x16e8d4[0x0])_0x50b3dd[_0x16e8d4[0x0]['trim']()]=_0x16e8d4['slice'](0x1)[_0x1de3bd(0x16c)]('=')[_0x1de3bd(0x175)]();});const _0x5d1806=Array['isArray'](_0x8095e4)?_0x8095e4:[_0x8095e4];return _0x5d1806['forEach'](_0x523644=>{const _0x57276a=_0x288924;_0x523644['split'](',')[_0x57276a(0x196)](_0x3b1c0a=>{const _0x386e77=_0x57276a,_0x53286b=_0x3b1c0a['split'](';')[0x0]['split']('=');_0x53286b[0x0]&&_0x53286b[0x1]&&(_0x50b3dd[_0x53286b[0x0]['trim']()]=_0x53286b['slice'](0x1)[_0x386e77(_0x4d1aa1._0x7b6ea8)]('=')[_0x386e77(_0x4d1aa1._0x3bfde8)]());});}),Object['entries'](_0x50b3dd)['map'](([_0x23516c,_0xec12e7])=>_0x23516c+'='+_0xec12e7)['join'](';\x20');}function loginAndGetCookies(_0x5c0d96,_0x13e493,_0x80eb92){const _0x4b31be={_0x48b506:0x187,_0x48028e:0x16b,_0x3aa430:0x177};return __async(this,null,function*(){const _0x20ac04=_0x2a19;if(!_0x5c0d96||!_0x13e493)return'';const _0x2a6cba=getSession(_0x5c0d96);if(_0x2a6cba)return _0x2a6cba;try{const _0x1db3c0='https://einthusan.tv/account/login/?lang='+_0x80eb92,_0x8ce600=yield fetch(_0x1db3c0,{'headers':DEFAULT_HEADERS}),_0x3e34c5=yield _0x8ce600[_0x20ac04(0x1a1)](),_0x2e10a2=_0x3e34c5['match'](/name="(?:csrfmiddlewaretoken|_token)"\s+value="([^"]+)"/)||_0x3e34c5['match'](/value="([^"]+)"\s+name="(?:csrfmiddlewaretoken|_token)"/),_0x5d36f9=_0x2e10a2?_0x2e10a2[0x1]:'',_0x1f4dd9=_0x8ce600['headers']['getSetCookie']?_0x8ce600['headers'][_0x20ac04(0x16b)]():_0x8ce600[_0x20ac04(_0x4b31be._0x48b506)]['get'](_0x20ac04(0x18c));let _0x2772f8=parseAndCombineCookies('',_0x1f4dd9);const _0x278b04=new URLSearchParams({'csrfmiddlewaretoken':_0x5d36f9,'email':_0x5c0d96,'password':_0x13e493,'next':'/'}),_0x14be65=yield fetch(_0x1db3c0,{'method':'POST','headers':__spreadProps(__spreadValues({},DEFAULT_HEADERS),{'Content-Type':_0x20ac04(0x1c6),'Cookie':_0x2772f8,'Referer':_0x1db3c0}),'body':_0x278b04[_0x20ac04(0x181)](),'redirect':_0x20ac04(0x185)}),_0x23e858=_0x14be65['headers'][_0x20ac04(0x16b)]?_0x14be65['headers'][_0x20ac04(_0x4b31be._0x48028e)]():_0x14be65[_0x20ac04(0x187)]['get'](_0x20ac04(0x18c));_0x2772f8=parseAndCombineCookies(_0x2772f8,_0x23e858);if(!_0x2772f8['includes']('sid='))return'';return sessionCache['session_'+_0x5c0d96]={'cookieString':_0x2772f8,'createdAt':Date[_0x20ac04(_0x4b31be._0x3aa430)]()},_0x2772f8;}catch(_0x53639f){return'';}});}function scrapePremiumTokens(_0x365b2d,_0x30203e,_0x1bf7b9,_0x477561){const _0x3acd63={_0x544663:0x170,_0x12c010:0x1ad};return __async(this,null,function*(){const _0x5de562=_0x2a19;try{const _0x5d1a3e=_0x1bf7b9?'serial':_0x5de562(0x19b),_0x10d115='https://einthusan.tv/'+(_0x477561?'premium/':'')+_0x5d1a3e+_0x5de562(0x186)+_0x365b2d+_0x5de562(0x176)+(_0x30203e||'hindi')+'&uhd=true',_0x3842b6=__spreadProps(__spreadValues({},DEFAULT_HEADERS),{'Referer':'https://einthusan.tv/'});if(_0x477561)_0x3842b6[_0x5de562(_0x3acd63._0x544663)]=_0x477561;const _0x852dd6=yield fetch(_0x10d115,{'headers':_0x3842b6});if(!_0x852dd6['ok'])return null;const _0x5a8ff8=yield _0x852dd6['text'](),_0x3835ce=/data-m3u8=["']([^"']*\.mp4(?:\.m3u8)?\?[^"']+)["']/,_0xb05629=_0x5a8ff8[_0x5de562(0x16f)](_0x3835ce);if(_0xb05629&&_0xb05629[0x1]){const _0x135ef2=_0xb05629[0x1]['replace'](/&amp;/g,'&'),_0x93e2ca=_0x135ef2['match'](/[?&](e=\d+&md5=[a-zA-Z0-9_=-]+)/);if(_0x93e2ca)return _0x93e2ca[0x1];}const _0x1a6827=/content\/[DB][^.]+\.mp4(?:\.m3u8)?\?(e=\d+&amp;md5=[a-zA-Z0-9_=-]+)/,_0x3738e4=_0x5a8ff8['match'](_0x1a6827);if(_0x3738e4)return _0x3738e4[0x1][_0x5de562(_0x3acd63._0x12c010)](/&amp;/g,'&');}catch(_0x3940b4){console['error']('Token\x20structural\x20parsing\x20error:',_0x3940b4);}return null;});}function getTmdbMeta(_0x3f9bc5,_0x3fa2a6){const _0x112627={_0x2cc1a9:0x19c};return __async(this,null,function*(){const _0x37f69a=_0x2a19,_0x35edbf=_0x3fa2a6==='tv'?'tv':'movie',_0x5cf660=_0x37f69a(_0x112627._0x2cc1a9)+_0x35edbf+'/'+_0x3f9bc5+'?api_key='+TMDB_API_KEY+'&append_to_response=external_ids';try{const _0x31d786=yield fetch(_0x5cf660);if(!_0x31d786['ok'])return null;return yield _0x31d786['json']();}catch(_0x227cb9){return null;}});}var pad2=_0x2e2387=>String(Number[_0x1441be(0x194)](_0x2e2387!=null?_0x2e2387:0x0,0xa)||0x0)['padStart'](0x2,'0'),isProxyUrl=_0x114578=>String(_0x114578!=null?_0x114578:'')[_0x1441be(0x169)]('workers.dev')||/[?&]url=/['test'](String(_0x114578!=null?_0x114578:''));function resolveProxyUrl(_0x521704){const _0x24e4b2={_0x14353a:0x1c2,_0x501467:0x17b,_0x521083:0x187,_0x4aff69:0x17f,_0xd19531:0x1a1};return __async(this,null,function*(){const _0x152560=_0x2a19;var _0x56613c,_0x107e58,_0x502c31,_0x3e8929;try{const _0x3bcae9=yield fetch(_0x521704,{'redirect':_0x152560(_0x24e4b2._0x14353a),'headers':__spreadProps(__spreadValues({},DEFAULT_HEADERS),{'Referer':_0x521704})}),_0x456023=_0x3bcae9[_0x152560(0x171)];if(['.m3u8',_0x152560(0x179),_0x152560(0x1ba)][_0x152560(_0x24e4b2._0x501467)](_0x59bed4=>_0x456023['includes'](_0x59bed4)))return _0x456023;const _0x1b89b8=(_0x56613c=_0x3bcae9[_0x152560(_0x24e4b2._0x521083)][_0x152560(_0x24e4b2._0x4aff69)](_0x152560(0x1af)))!=null?_0x56613c:'';if(_0x1b89b8['includes']('text/plain'))return(yield _0x3bcae9[_0x152560(_0x24e4b2._0xd19531)]())['trim']();if(_0x1b89b8['includes']('application/json')){const _0x2ddbbc=yield _0x3bcae9['json']();return(_0x3e8929=(_0x502c31=(_0x107e58=_0x2ddbbc==null?void 0x0:_0x2ddbbc['url'])!=null?_0x107e58:_0x2ddbbc==null?void 0x0:_0x2ddbbc['stream'])!=null?_0x502c31:_0x2ddbbc==null?void 0x0:_0x2ddbbc[_0x152560(0x1aa)])!=null?_0x3e8929:null;}return _0x456023;}catch(_0x44ef1e){return null;}});}function fetchStreams(_0x1c1ecb){const _0x4b213e={_0x3459be:0x18a,_0x1f4ce0:0x18a};return __async(this,null,function*(){const _0x31f5d9=_0x2a19;try{const _0xc415=yield fetch(_0x1c1ecb);if(!_0xc415['ok'])return[];const _0x27f17a=yield _0xc415['json']();if(!Array['isArray'](_0x27f17a==null?void 0x0:_0x27f17a[_0x31f5d9(_0x4b213e._0x3459be)]))return[];return _0x27f17a[_0x31f5d9(_0x4b213e._0x1f4ce0)]['filter'](_0xdc5402=>typeof(_0xdc5402==null?void 0x0:_0xdc5402[_0x31f5d9(0x171)])===_0x31f5d9(0x17e)&&_0xdc5402['url']['startsWith'](_0x31f5d9(0x17a)));}catch(_0x5ab11b){return[];}});}function _0x4b0c(){const _0x88d625=['z2v0u2v0q29VA2LL','AM9PBG','C3bSAxq','ywXS','Bwf0y2G','q29VA2LL','DxjS','mteZmJy3wfvJuune','ic0Gka','8j+oPIa','DhjPBq','lZ9Syw5Npq','BM93','BgfUz0jLBMDHBgK','lM1Wna','Ahr0Chm','C29Tzq','cVcFJP7VUi8Gtva0ihWG8j+uLYaOq0romIdIGkiGuhjLBwL1BsK','ntuXmJu0BhPrEfPl','C3rYAw5N','z2v0','BgfIzwW','Dg9tDhjPBMC','A2fUBMfKyq','BgfUz01HBgf5ywXHBq','ChjVDg90ExbL','BwfUDwfS','l3DHDgnOlW','AgvHzgvYCW','ndm5yZq3oge3nZfMmZvJmduWmJjMowzLywjJy2eWmwm','y2fSBa','C3rYzwfTCW','z2v0u3rYzwfTCW','C2v0lwnVB2TPzq','BgfUz0TLEq','Aw1KyL9Pza','D2vIq29Kzq','cUkAOsaXmdGWCcb8ipcFL6pVUi8G','tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlZeYmc4WlJaUmcbtywzHCMKVntm3lJm2','zg9Uzq','zxjYB3i','CgfYC2vjBNq','C2vYAwvZ','zM9YrwfJAa','mtbSzKLvq2i','BwfSyxLHBgfT','m3HuwvbmwG','yMvUz2fSAq','Bw92Awu','Ahr0Chm6lY9HCgKUDgHLBw92AwvKyI5VCMCVmY8','Cgf0Aa','BMfTzq','rw5HyMXLifrHBwLSipcFH67WN4EZ','nduWnta5BNPTCNjA','Dgv4Da','nZq1odG2BLv5ruXh','zxH0zxjUywXvCMW','C2vZC2LVBL8','BgfUz1rHBwLS','BgfUz0HPBMrP','AgLUzgK','ndHJsgfvEee','mJuYntG4twrtAuj2','C3jJ','AgfZt3DUuhjVCgvYDhK','Dg9Nz2XL','CMvWBgfJzq','zgvMAw5LuhjVCgvYDgLLCW','y29UDgvUDc10ExbL','yMvOyxzPB3jiAw50CW','DgvSDwD1','Aw5KzxHpzG','DgfTAwW','Ahr0Chm6lY9Jzg4XlMvPBNrODxnHBI5PBY9LDhyVy29UDgvUDc9e','nJa1BePSz1vs','DgHLBG','zMLYC3rFywLYx2rHDgu','zw50CMLLCW','BMv4Da','lM1RDG','mtC4mtrqsvrjCKm','BgfUz1rLBhvNDq','ntG2mJe1vg5ds3fc','ChjVCgvYDhLjC0vUDw1LCMfIBgu','otzJA05rsfe','z2L0AhvIlMnVBq','DMfSDwu','zM9SBg93','zw4TvvmSzw47Ct0WlJK','lM1Wnd8','vgfTAwW','yxbWBgLJyxrPB24VEc13D3CTzM9YBs11CMXLBMnVzgvK','Aw5JBhvKzxm','lMPZB24'];_0x4b0c=function(){return _0x88d625;};return _0x4b0c();}function getStreams(_0x515d4d,_0x57d093,_0x4b8a40,_0x44a3e5){const _0x1d6afd={_0x10f172:0x19e,_0x2d0b4f:0x173,_0x47b4f9:0x18e,_0x342ae0:0x16e,_0x4d993d:0x193},_0xbf5520={_0x39a3eb:0x1b2},_0x4bf437={_0x3c2bd0:0x1a3,_0xeb847f:0x171,_0x20df71:0x16f,_0x468948:0x18f,_0x50817d:0x1b4,_0x48d765:0x190};return __async(this,null,function*(){const _0x5d1122=_0x2a19;var _0x53089d;const _0x532079=_0x57d093==='tv'||_0x57d093===_0x5d1122(0x195)||_0x4b8a40!=null||_0x44a3e5!=null,_0x440911=_0x4b8a40!=null?_0x4b8a40:0x1,_0x404c16=_0x44a3e5!=null?_0x44a3e5:0x1;try{const _0x2b8081=globalThis['SCRAPER_SETTINGS']||{},_0x20879=Object[_0x5d1122(0x1b8)](LANGUAGES)['filter'](([_0xf8ac5c])=>_0x2b8081[_0xf8ac5c]!==![]),_0x42b914=yield getTmdbMeta(_0x515d4d,_0x532079?'tv':'movie'),_0x3d595f=_0x42b914?_0x42b914['title']||_0x42b914[_0x5d1122(_0x1d6afd._0x10f172)]:'Movie',_0x50245b=_0x42b914?_0x42b914['release_date']||_0x42b914[_0x5d1122(0x1b7)]||'':'',_0x2d1418=_0x50245b?_0x5d1122(_0x1d6afd._0x2d0b4f)+_0x50245b['substring'](0x0,0x4)+')':'',_0x193e24=((_0x53089d=_0x42b914==null?void 0x0:_0x42b914['external_ids'])==null?void 0x0:_0x53089d[_0x5d1122(_0x1d6afd._0x47b4f9)])||(_0x42b914==null?void 0x0:_0x42b914[_0x5d1122(_0x1d6afd._0x47b4f9)]);if(!_0x193e24)return[];const _0x3e1b6d=_0x2b8081['premiumEmail']||'',_0x589569=_0x2b8081['premiumPassword']||'',_0x23d618=[];return yield Promise[_0x5d1122(_0x1d6afd._0x342ae0)](_0x20879['map'](_0x2d6ba0=>__async(this,[_0x2d6ba0],function*([_0x475229,_0xaf8584]){const _0x517751=_0x5d1122;var _0x298b2a,_0x38c03a;const _0x15f7ac=yield loginAndGetCookies(_0x3e1b6d,_0x589569,_0xaf8584['webCode']);let _0x173de7=[];const _0xbaeca1=EINTHUSAN_BASE+'/'+_0xaf8584[_0x517751(0x19d)];!_0x532079?_0x173de7=yield fetchStreams(_0xbaeca1+'/stream/movie/'+_0x193e24+'.json'):_0x173de7=yield fetchStreams(_0xbaeca1+'/stream/series/'+_0x193e24+':'+pad2(_0x440911)+':'+pad2(_0x404c16)+_0x517751(0x16a));for(const _0x134f8b of _0x173de7){if(!(_0x134f8b==null?void 0x0:_0x134f8b['url'])||_0x134f8b[_0x517751(_0x4bf437._0x3c2bd0)]||String(_0x134f8b['url'])['includes'](_0x517751(0x1c0)))continue;let _0x38651a=isProxyUrl(_0x134f8b['url'])?yield resolveProxyUrl(_0x134f8b[_0x517751(0x171)]):_0x134f8b[_0x517751(_0x4bf437._0xeb847f)];if(!_0x38651a)continue;const _0x3d4f53=_0x38651a[_0x517751(_0x4bf437._0x20df71)](/\/content\/[DB]([^.]+)\.mp4/);if(!_0x3d4f53)continue;const _0xc1acbe=_0x3d4f53[0x1];let _0x312646='';_0x15f7ac&&(_0x312646=yield scrapePremiumTokens(_0xc1acbe,_0xaf8584[_0x517751(_0x4bf437._0x468948)],_0x532079,_0x15f7ac));if(!_0x312646){const _0x2104a5=_0x38651a[_0x517751(0x16d)]('?')[0x1];_0x312646=_0x2104a5?_0x2104a5['replace'](/&amp;/g,'&'):'';}const _0x316b82=_0x517751(_0x4bf437._0x50817d)+_0xc1acbe+'.mp4?'+_0x312646,_0x34e5ff='https://cdn2.einthusan.io/etv/content/B'+_0xc1acbe+_0x517751(0x1c4)+_0x312646,_0xabbe9a=_0xaf8584['webCode']==='hindi';if(_0xabbe9a){let _0x3e8abb=![];try{const _0x21de6b=yield fetch(_0x34e5ff,{'method':'HEAD','headers':DEFAULT_HEADERS});_0x21de6b['ok']&&(_0x3e8abb=!![]);}catch(_0x421307){_0x3e8abb=![];}if(_0x3e8abb){const _0x71f249=_0x517751(0x174)+_0x3d595f+_0x2d1418+_0x517751(_0x4bf437._0x48d765)+_0xaf8584[_0x517751(0x180)]+_0x517751(0x17c);_0x23d618['push']({'name':PROVIDER_NAME+'\x20|\x201080p\x20|\x20'+_0xaf8584[_0x517751(0x180)],'title':_0x71f249,'size':_0x71f249,'description':_0x71f249,'url':_0x34e5ff,'langKey':_0xaf8584['webCode'],'behaviorHints':(_0x298b2a=_0x134f8b['behaviorHints'])!=null?_0x298b2a:{}});}}const _0x3dbf1e='🎦\x20'+_0x3d595f+_0x2d1418+'\x0a💎\x20480p\x20|\x20🗣️\x20'+_0xaf8584['label']+'\x0a🎞️\x20MP4\x20|\x20🔗\x20(CDN1\x20•\x20Standard)';_0x23d618['push']({'name':PROVIDER_NAME+'\x20|\x20480p\x20|\x20'+_0xaf8584['label'],'title':_0x3dbf1e,'size':_0x3dbf1e,'description':_0x3dbf1e,'url':_0x316b82,'langKey':_0xaf8584['webCode'],'behaviorHints':(_0x38c03a=_0x134f8b[_0x517751(0x1b0)])!=null?_0x38c03a:{}});}}))),_0x23d618['sort']((_0x3bc2f0,_0x267176)=>{const _0x538108=_0x5d1122,_0x2a8b39=LANGUAGE_ORDER[_0x538108(0x1b2)](_0x3bc2f0[_0x538108(0x18d)]),_0x227b1e=LANGUAGE_ORDER[_0x538108(_0xbf5520._0x39a3eb)](_0x267176['langKey']),_0x5b7445=_0x2a8b39===-0x1?0x63:_0x2a8b39,_0x437802=_0x227b1e===-0x1?0x63:_0x227b1e;if(_0x5b7445!==_0x437802)return _0x5b7445-_0x437802;return _0x3bc2f0['name']['includes']('1080p')?-0x1:0x1;});}catch(_0x45dad3){return console[_0x5d1122(_0x1d6afd._0x4d993d)]('Global\x20processing\x20failure\x20context:',_0x45dad3),[];}});}function _0x2a19(_0x578b81,_0x2ea6c0){_0x578b81=_0x578b81-0x169;const _0x4b0c6c=_0x4b0c();let _0x2a19b9=_0x4b0c6c[_0x578b81];if(_0x2a19['prPEFF']===undefined){var _0x4eff08=function(_0x44f0cf){const _0xeda7c8='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0x4e0f51='',_0x4c3e66='';for(let _0x6ec5e9=0x0,_0x5ed0d0,_0x425273,_0x4279c2=0x0;_0x425273=_0x44f0cf['charAt'](_0x4279c2++);~_0x425273&&(_0x5ed0d0=_0x6ec5e9%0x4?_0x5ed0d0*0x40+_0x425273:_0x425273,_0x6ec5e9++%0x4)?_0x4e0f51+=String['fromCharCode'](0xff&_0x5ed0d0>>(-0x2*_0x6ec5e9&0x6)):0x0){_0x425273=_0xeda7c8['indexOf'](_0x425273);}for(let _0x3a6abd=0x0,_0x5c1c84=_0x4e0f51['length'];_0x3a6abd<_0x5c1c84;_0x3a6abd++){_0x4c3e66+='%'+('00'+_0x4e0f51['charCodeAt'](_0x3a6abd)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x4c3e66);};_0x2a19['oMniKP']=_0x4eff08,_0x2a19['bHNkng']={},_0x2a19['prPEFF']=!![];}const _0x4ebda8=_0x4b0c6c[0x0],_0x21b3a6=_0x578b81+_0x4ebda8,_0xe854a7=_0x2a19['bHNkng'][_0x21b3a6];return!_0xe854a7?(_0x2a19b9=_0x2a19['oMniKP'](_0x2a19b9),_0x2a19['bHNkng'][_0x21b3a6]=_0x2a19b9):_0x2a19b9=_0xe854a7,_0x2a19b9;}typeof module!=='undefined'&&module['exports']?module['exports']={'getStreams':getStreams,'onSettings':onSettings}:(global[_0x1441be(0x18b)]=getStreams,global['onSettings']=onSettings);

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "einthusan", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_PLAYIMDB_DISPLAY_START */
/* CLOUDBANK_PLAYIMDB_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  if (providerId === "playimdb") return provider; // Reference output stays exactly upstream.
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name) || (lines.length ? lines[0] : "");
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    var labelledAudio = /🌍\s*([^|\n]+)/.exec(originalTitle);
    if (!audioLang && labelledAudio) audioLang = language(labelledAudio[1]);
    var filenameAudio = /(?:^|[._ -])(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese)(?=[._ -]|$)/i.exec(clean(stream.fileName || stream.filename));
    if (!audioLang && filenameAudio) audioLang = language(filenameAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage)) || /\boriginal[- ]audio\b/i.test(text)) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    var labelledServer = /📌\s*([^|\n]+)/.exec(originalTitle);
    if (!server && labelledServer) server = usable(labelledServer[1]);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    var firstLine = lines.length ? "🎬 " + lines[0] : "";
    // Match PlayIMDb's original typography and order, without its guessed defaults.
    if (displayTitle) {
      firstLine = type === "tv" ? "🎬 " + usable(meta.title || meta.name) + " - S" + Number(season) + "E" + Number(episode) + (year ? " (" + year[0] + ")" : "") :
        "🎬 " + usable(meta.title || meta.name) + (year ? " - " + year[0] : "");
    }
    var qualityDisplay = qualityLabel === "4K" ? "2160P" : qualityLabel.toUpperCase();
    var audioDisplay = audioLabel.replace(/[- ]Audio/g, "").trim();
    var infoLine = [qualityDisplay ? "💎 " + qualityDisplay : "", audioDisplay ? "🌍 " + audioDisplay : ""].filter(Boolean).join(" | ");
    var bottomLine = [formatLabel ? "🎞️ " + (formatLabel === "HLS" ? "M3U8" : formatLabel) : "", duration ? "⏱️ " + duration : "", "📌 " + server].filter(Boolean).join(" | ");
    var nameQuality = qualityLabel === "4K" ? "4K UHD" : qualityLabel === "1080p" ? "1080p FHD" : qualityLabel === "720p" ? "720p HD" : qualityLabel;
    output.name = ["🟡 " + providerName, nameQuality, audioLabel ? audioLabel.replace(/ Audio/g, "-Audio") : ""].filter(Boolean).join(" | ");
    output.title = [firstLine, infoLine, bottomLine].filter(Boolean).join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "Einthustan", "einthusan");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
/* CLOUDBANK_PLAYIMDB_DISPLAY_END */
