// Imported provider: animezey; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
var _0x281d9e=_0xc337;(function(_0x409329,_0x2141cb){var _0xab6af5={_0x3db0f7:0x17d,_0x4746bb:0x1d3,_0x495b10:0x1cf,_0x1091c6:0x1ba,_0x4cc3af:0x202},_0x6aeff0=_0xc337,_0x25e406=_0x409329();while(!![]){try{var _0x45485f=-parseInt(_0x6aeff0(_0xab6af5._0x3db0f7))/0x1*(parseInt(_0x6aeff0(_0xab6af5._0x4746bb))/0x2)+parseInt(_0x6aeff0(0x1e8))/0x3+parseInt(_0x6aeff0(0x1b1))/0x4*(parseInt(_0x6aeff0(_0xab6af5._0x495b10))/0x5)+-parseInt(_0x6aeff0(_0xab6af5._0x1091c6))/0x6+parseInt(_0x6aeff0(0x192))/0x7+-parseInt(_0x6aeff0(0x1bf))/0x8+parseInt(_0x6aeff0(_0xab6af5._0x4cc3af))/0x9;if(_0x45485f===_0x2141cb)break;else _0x25e406['push'](_0x25e406['shift']());}catch(_0x1d6af7){_0x25e406['push'](_0x25e406['shift']());}}}(_0x50b3,0xbff13));var __async=(_0x46023d,_0x3e28e4,_0x2fb2cf)=>{return new Promise((_0x4fa95a,_0x422774)=>{var _0x25c329=_0xc337,_0x4848d7=_0xcfeeea=>{var _0x3e3172=_0xc337;try{_0x5a2533(_0x2fb2cf[_0x3e3172(0x189)](_0xcfeeea));}catch(_0x4a4f65){_0x422774(_0x4a4f65);}},_0x7029e6=_0x3564e4=>{try{_0x5a2533(_0x2fb2cf['throw'](_0x3564e4));}catch(_0x32bacf){_0x422774(_0x32bacf);}},_0x5a2533=_0x473cf4=>_0x473cf4[_0x25c329(0x19a)]?_0x4fa95a(_0x473cf4[_0x25c329(0x17b)]):Promise[_0x25c329(0x1cd)](_0x473cf4['value'])[_0x25c329(0x18d)](_0x4848d7,_0x7029e6);_0x5a2533((_0x2fb2cf=_0x2fb2cf['apply'](_0x46023d,_0x3e28e4))[_0x25c329(0x189)]());});},PROVIDER_NAME=_0x281d9e(0x1d1),TMDB_API_KEY=_0x281d9e(0x1c8),TMDB_BASE=_0x281d9e(0x1c3),MAX_RESULTS_MOVIE=0x5,MAX_RESULTS_EPISODE=0x2,WORKER_DOMAINS=[_0x281d9e(0x1f7),_0x281d9e(0x19d)],MOBILE_UAS=['Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/120.0.0.0\x20Safari/537.36','Mozilla/5.0\x20(Linux;\x20Android\x2014;\x20Pixel\x208\x20Pro)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/124.0.0.0\x20Mobile\x20Safari/537.36','Mozilla/5.0\x20(iPhone;\x20CPU\x20iPhone\x20OS\x2017_0\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20Version/17.0\x20Mobile/15E148\x20Safari/604.1'];function getInvertedSortTag(_0x2b0846,_0x58e8dd){var _0x574189={_0x4f7471:0x18b,_0x4a60f5:0x191},_0x4229d1=_0x281d9e;_0x58e8dd===void 0x0&&(_0x58e8dd=0xf423f);var _0x3d274b=Math['max'](0x0,parseInt(_0x2b0846,0xa)||0x0),_0x4d656f=Math[_0x4229d1(_0x574189._0x4f7471)](0x0,_0x58e8dd-_0x3d274b),_0x103bbe=_0x4d656f[_0x4229d1(_0x574189._0x4a60f5)](0x2)['padStart'](0x14,'0');return _0x103bbe[_0x4229d1(0x1bd)]('')[_0x4229d1(0x1bc)](function(_0x1fa5a8){return _0x1fa5a8==='1'?'\ufeff':'​';})['join']('');}function resolveSettings(_0x2c8d8b){var _0x372398={_0x371298:0x164,_0x3924c9:0x1f5,_0xce8c50:0x1b7,_0x413f7d:0x1be,_0x197142:0x203},_0x51264a=_0x281d9e,_0x26d0f7={'sortBy':'quality'};try{var _0x52197f=_0x2c8d8b;!_0x52197f&&typeof globalThis!==_0x51264a(0x1a9)&&(_0x52197f=globalThis[_0x51264a(_0x372398._0x371298)]||globalThis['SETTINGS']||globalThis[_0x51264a(_0x372398._0x3924c9)]);!_0x52197f&&typeof global!=='undefined'&&(_0x52197f=global['SCRAPER_SETTINGS']||global[_0x51264a(_0x372398._0xce8c50)]||global['settings']);!_0x52197f&&typeof window!=='undefined'&&(_0x52197f=window[_0x51264a(0x164)]||window[_0x51264a(0x1b7)]||window['settings']);if(_0x52197f){var _0x4cf5d8=_0x52197f[_0x51264a(0x203)]||_0x52197f['sort_by']||_0x52197f['sort']||'';typeof _0x4cf5d8===_0x51264a(0x18c)&&_0x4cf5d8!==null&&(_0x4cf5d8=_0x4cf5d8['value']||_0x4cf5d8['label']||'');var _0x411951=String(_0x4cf5d8)['toLowerCase']();_0x411951[_0x51264a(_0x372398._0x413f7d)](_0x51264a(0x19e))||_0x411951[_0x51264a(0x1be)]('largest')?_0x26d0f7['sortBy']='size':_0x26d0f7[_0x51264a(_0x372398._0x197142)]='quality';}}catch(_0xf8b270){console[_0x51264a(0x1a1)]('['+PROVIDER_NAME+_0x51264a(0x1de),_0xf8b270);}return _0x26d0f7;}function onSettings(){var _0x497ea4={_0x2e7ef0:0x1c0},_0x4730ce=_0x281d9e;return[{'type':'select','key':_0x4730ce(0x203),'name':_0x4730ce(_0x497ea4._0x2e7ef0),'label':'Sort\x20By','options':[{'label':'Quality\x20Score','value':'quality'},{'label':'Largest\x20Size','value':_0x4730ce(0x19e)}],'default':'quality'}];}function _0xc337(_0x466efc,_0x1b595f){_0x466efc=_0x466efc-0x15d;var _0x50b310=_0x50b3();var _0xc337b5=_0x50b310[_0x466efc];if(_0xc337['yVwkBV']===undefined){var _0x354406=function(_0x1df3f1){var _0x19866a='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';var _0x46023d='',_0x3e28e4='';for(var _0x2fb2cf=0x0,_0x4fa95a,_0x422774,_0x4848d7=0x0;_0x422774=_0x1df3f1['charAt'](_0x4848d7++);~_0x422774&&(_0x4fa95a=_0x2fb2cf%0x4?_0x4fa95a*0x40+_0x422774:_0x422774,_0x2fb2cf++%0x4)?_0x46023d+=String['fromCharCode'](0xff&_0x4fa95a>>(-0x2*_0x2fb2cf&0x6)):0x0){_0x422774=_0x19866a['indexOf'](_0x422774);}for(var _0x7029e6=0x0,_0x5a2533=_0x46023d['length'];_0x7029e6<_0x5a2533;_0x7029e6++){_0x3e28e4+='%'+('00'+_0x46023d['charCodeAt'](_0x7029e6)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x3e28e4);};_0xc337['GCQSPT']=_0x354406,_0xc337['jXUBiu']={},_0xc337['yVwkBV']=!![];}var _0x2afd8f=_0x50b310[0x0],_0x41cbaf=_0x466efc+_0x2afd8f,_0x408615=_0xc337['jXUBiu'][_0x41cbaf];return!_0x408615?(_0xc337b5=_0xc337['GCQSPT'](_0xc337b5),_0xc337['jXUBiu'][_0x41cbaf]=_0xc337b5):_0xc337b5=_0x408615,_0xc337b5;}function getQualityRank(_0x3fb0db){var _0x2d48b7={_0x48a582:0x1ca,_0x252c07:0x1a5,_0x4fac3c:0x1be},_0x2a48f2=_0x281d9e,_0x8d3bb5=String(_0x3fb0db)[_0x2a48f2(0x1f8)]();if(_0x8d3bb5['includes'](_0x2a48f2(_0x2d48b7._0x48a582))||_0x8d3bb5[_0x2a48f2(0x1be)]('4k')||_0x8d3bb5['includes'](_0x2a48f2(_0x2d48b7._0x252c07)))return 0x4;if(_0x8d3bb5[_0x2a48f2(0x1be)]('1080')||_0x8d3bb5['includes']('fullhd')||_0x8d3bb5[_0x2a48f2(_0x2d48b7._0x4fac3c)](_0x2a48f2(0x176)))return 0x3;if(_0x8d3bb5[_0x2a48f2(0x1be)]('720')||_0x8d3bb5['includes']('hd'))return 0x2;if(_0x8d3bb5['includes']('480')||_0x8d3bb5['includes']('sd')||_0x8d3bb5['includes']('dvdrip'))return 0x1;return 0x0;}function removeAccents(_0x5c4945){return(_0x5c4945||'')['normalize']('NFKD')['replace'](/[\u0300-\u036f]/g,'');}function normalizeForCompare(_0x4cea8f){if(!_0x4cea8f)return'';var _0x200dc7=removeAccents(String(_0x4cea8f))['toLowerCase']();return _0x200dc7['replace'](/[^a-z0-9]/g,'');}function parseQuality(_0x462b4e){var _0xb9686b={_0x23dd37:0x1a5,_0x4d755e:0x1be,_0xe96ff9:0x174,_0x465c41:0x16b,_0x3e5794:0x1be,_0x16d83d:0x1ed,_0x55fc28:0x174},_0x5113b6=_0x281d9e,_0x54aa36=String(_0x462b4e||'')['toLowerCase']();if(_0x54aa36[_0x5113b6(0x1be)]('2160p')||_0x54aa36['includes']('4k')||_0x54aa36[_0x5113b6(0x1be)](_0x5113b6(_0xb9686b._0x23dd37)))return'2160p';if(_0x54aa36[_0x5113b6(_0xb9686b._0x4d755e)](_0x5113b6(_0xb9686b._0xe96ff9))||_0x54aa36[_0x5113b6(0x1be)](_0x5113b6(_0xb9686b._0x465c41))||_0x54aa36['includes']('full\x20hd'))return _0x5113b6(_0xb9686b._0xe96ff9);if(_0x54aa36[_0x5113b6(_0xb9686b._0x3e5794)]('720p'))return _0x5113b6(0x1c2);if([_0x5113b6(0x179),'sd',_0x5113b6(0x1ce),_0x5113b6(_0xb9686b._0x16d83d)][_0x5113b6(0x1d2)](function(_0xc628ee){var _0x5cc1f7=_0x5113b6;return _0x54aa36[_0x5cc1f7(0x1be)](_0xc628ee);}))return'480p';return _0x5113b6(_0xb9686b._0x55fc28);}function formatSize(_0x40579d){var _0x42a6df={_0x117d32:0x167,_0xecbbc7:0x167},_0x35119f=_0x281d9e;try{var _0x37152e=Number(_0x40579d);if(!_0x37152e||isNaN(_0x37152e))return'N/A';if(_0x37152e<0x400)return _0x37152e+'\x20B';if(_0x37152e<0x400*0x400)return(_0x37152e/0x400)[_0x35119f(_0x42a6df._0x117d32)](0x2)+'\x20KB';if(_0x37152e<0x400*0x400*0x400)return(_0x37152e/(0x400*0x400))[_0x35119f(_0x42a6df._0xecbbc7)](0x2)+_0x35119f(0x177);return(_0x37152e/(0x400*0x400*0x400))[_0x35119f(0x167)](0x2)+_0x35119f(0x16d);}catch(_0x1467a1){return'N/A';}}function escapeRegExp(_0x18ffff){return _0x18ffff['replace'](/[.*+?^${}()|[\]\\]/g,'\x5c$&');}function pad(_0x39dc6e,_0x3edaba){var _0x52da62={_0x432259:0x1e2},_0xb0b93a=_0x281d9e;return String(_0x39dc6e)[_0xb0b93a(_0x52da62._0x432259)](_0x3edaba,'0');}function decodeEntities(_0x19694f){var _0x1fb6f8={_0xa26ddd:0x1eb},_0x21d89a=_0x281d9e;if(!_0x19694f)return'';var _0x44a31e=/&(nbsp|amp|quot|lt|gt|#038);/g,_0x3ac9e7={'nbsp':'\x20','amp':'&','quot':'\x22','lt':'<','gt':'>','#038':'&'};return _0x19694f[_0x21d89a(_0x1fb6f8._0xa26ddd)](_0x44a31e,function(_0x45376b,_0xd48192){return _0x3ac9e7[_0xd48192];})['replace'](/&#(\d+);/g,function(_0x5f03e2,_0x4ca1a2){var _0x6e5d2b=_0x21d89a;return String[_0x6e5d2b(0x19b)](_0x4ca1a2);});}function getAnimeSearchPatterns(_0x202ab6,_0x2f9652){var _0x2684a3={_0x4242d6:0x1fa},_0xb912c2={},_0x3a7e1b=[];function _0x2196cd(_0x587026,_0x1c4029){var _0xa1c57e=_0xc337,_0x470414=_0x587026+':'+_0x1c4029;!_0xb912c2[_0x470414]&&(_0xb912c2[_0x470414]=!![],_0x3a7e1b[_0xa1c57e(_0x2684a3._0x4242d6)]([_0x587026,_0x1c4029]));}return _0x2196cd(_0x202ab6,_0x2f9652),_0x202ab6===0x1&&_0x2f9652>0xb&&[0xc,0xd]['forEach'](function(_0x3116ed){if(_0x2f9652>_0x3116ed)_0x2196cd(0x2,_0x2f9652-_0x3116ed);}),_0x3a7e1b;}function getAnimeSearchCodes(_0x2effbb,_0x4ae7b9){var _0x29454d={_0xaa009d:0x1fa},_0x5a4201=getAnimeSearchPatterns(_0x2effbb,_0x4ae7b9),_0x1a1099={},_0x4555c0=[];function _0x28d6f2(_0x3935fd){var _0xb3026d=_0xc337;!_0x1a1099[_0x3935fd]&&(_0x1a1099[_0x3935fd]=!![],_0x4555c0[_0xb3026d(_0x29454d._0xaa009d)](_0x3935fd));}return _0x5a4201['forEach'](function(_0x1708f4){var _0x1e51e2=_0x1708f4[0x0],_0x441442=_0x1708f4[0x1];_0x28d6f2('S'+pad(_0x1e51e2,0x2)+'E'+pad(_0x441442,0x2)),_0x28d6f2(pad(_0x1e51e2,0x2)+'x'+pad(_0x441442,0x2)),_0x28d6f2(_0x1e51e2+'.'+pad(_0x441442,0x2)),_0x1e51e2===0x1&&_0x441442!==0x1&&(_0x28d6f2(pad(_0x441442,0x2)),_0x28d6f2(pad(_0x441442,0x3)),_0x28d6f2('ep'+pad(_0x441442,0x2)),_0x28d6f2('e'+pad(_0x441442,0x2)));}),_0x4555c0;}var TITLE_END_RE=new RegExp('^(?:s\x5cd{1,2}e\x5cd{1,2}|\x5c[?\x5cd{3,4}p\x5c]?|(?:19|20)\x5cd{2}|ep?\x5cs*\x5cd+|episode\x5cs*\x5cd+|\x5c[(?:dual|dub|leg|sub|pt[\x5c-.]br|bluray|bdrip|webrip|web[\x5c-.]dl|hdtv|x264|x265|hevc|aac|mkv|mp4|avi|wmv|mov)\x5c]|(?:dual|dub|leg|sub|pt[\x5c-.]br|bluray|bdrip|webrip|web[\x5c-.]dl|hdtv|x264|x265|hevc|aac|mkv|mp4|avi|wmv|mov)|\x5c[\x5cd+|\x5cs-\x5cs\x5cd+)','i'),IGNORABLE_PREFIX_WORDS={'the':0x1,'a':0x1,'an':0x1,'o':0x1,'os':0x1,'as':0x1,'de':0x1,'do':0x1,'da':0x1,'dos':0x1,'das':0x1,'em':0x1,'no':0x1,'na':0x1,'nos':0x1,'nas':0x1,'um':0x1,'uma':0x1},NOISE_WORD_RE=new RegExp('^(?:\x5cd{4}|[a-z0-9]+(?:p|k)|bluray|bdrip|webrip|web|hdtv|x264|x265|hevc|aac|mkv|mp4|avi|wmv|mov|hdr|sdr|remux|dual|dub|dublado|leg|legendado|sub|pt[\x5c-.]?br|nf|netflix|hbo|max|hbomax|disney|disneyplus|amazon|prime|paramount|peacock|hulu|apple|appletv|star|globoplay|telecine|crunchyroll|funimation|youtube|vix|pluto|copia|copy|sample|extras?)$','i');function fetchPlain(_0x2c1e72,_0x3855f1){return __async(this,null,function*(){return fetch(_0x2c1e72,_0x3855f1||{});});}function fetchJson(_0x410bae,_0x33db9f){return __async(this,null,function*(){try{var _0x200b0a=yield fetchPlain(_0x410bae,{'headers':{'User-Agent':_0x33db9f}});if(!_0x200b0a['ok'])return null;return yield _0x200b0a['json']();}catch(_0x5619a4){return null;}});}function fetchTmdbDetails(_0x3ac9cd,_0x16df31,_0x594499){return __async(this,null,function*(){var _0x40f5e8=_0xc337,_0x4e670b=_0x16df31==='movie'?'/movie/'+_0x3ac9cd:_0x40f5e8(0x1a7)+_0x3ac9cd,_0x247b74=TMDB_BASE+_0x4e670b+'?api_key='+TMDB_API_KEY+'&language=en-US';return yield fetchJson(_0x247b74,_0x594499);});}function computeAbsoluteEpisode(_0x1526dd,_0x13a981,_0x2af2d6){var _0x34ad96={_0x34b65f:0x1df},_0x411bfe=_0x281d9e;if(!Array['isArray'](_0x1526dd))return null;var _0xd085ba=_0x2af2d6;for(var _0x1558f3=0x0;_0x1558f3<_0x1526dd[_0x411bfe(_0x34ad96._0x34b65f)];_0x1558f3++){var _0x339892=_0x1526dd[_0x1558f3];_0x339892['season_number']>0x0&&_0x339892['season_number']<_0x13a981&&(_0xd085ba+=_0x339892['episode_count']||0x0);}return _0xd085ba;}function _0x50b3(){var _0x18b3b8=['C2XPy2u','req1lJe','CM9TywPPx3rPDgXL','zNvSBgHK','z2v0','ieDc','z2v0u3rYzwfTCW','y2XLyw4','DgvZDa','BgLUAW','Aw5KzxHpzG','zgf0yq','mta4mha','ksbVBIa','zMHK','ie1c','Bw92Awu','zhzKCMLW','AxngAw5PDgu','DMfSDwu','C2L6zuLUtui','nZGYn05JCePcDa','v0vcuMLW','zMLSDgvY','rerqns4X','ug9YDhvNDwvZzsdWN4EN8j+hTW','C2vZC2LVBLvb','lZe6C2vHCMnO','C3rYAw5NAwz5','8j+nVYa','x2LZqw5PBwu','Agv2yW','C2v0','BMv4Da','x3bYB2nLC3nszxn1BhrZ','Bwf4','B2jQzwn0','DgHLBG','yw5PBwv6zxKXnJa4mJaYmY5HBMLTzxPLEte2mdGYmdiZlNDVCMTLCNmUzgv2','Dgv4Da','kI8Q','Dg9tDhjPBMC','nZKWnJu3mhPxsgXTvq','tI9b','x21HDgnOzxntzxjPzxnjBKzPBgvUyw1L','zMLSzq','ChjVDg90ExbL','DgHLia','kd8HxgqP','x2j1AwXKrg93BMXVywrmAw5R','zg9Uzq','zNjVBunOyxjdB2rL','x2DLBMvYyxrLtw92AwvrDwvYAwvZ','ms5HBMLTzxPLEwrSlNDVCMTLCNmUzgv2','C2L6zq','B3jPz2LUywXuAxrSzq','B3jPz2LUywXFDgL0Bgu','zxjYB3i','DhjPBq','sc4YnJq','mtbcAxq','DwHK','mJaYnG','l3r2lW','EwvHCG','Dw5KzwzPBMvK','CxvHBgL0Eq','BwvKAwfuExbL','rhvHBc1bDwrPBW','x3rPDgXLtwf0y2G','sersmta','y3vYCMvUDerVBwfPBKLUzgv4','zxzLCNK','mtKYt3DVuuPP','sc4YnJu','C3rHDhvZ','zMLSzxm','u2LUz2XLief1zgLV','8j+mJsa','u0vuveLor1m','sersmtaR','tva0','nJKXmZCYmMfisgH5EG','Edi2nq','BwfW','C3bSAxq','Aw5JBhvKzxm','mtaYmtK2ntz3qLjiAhK','C29YDf9IEq','Ahr0Chm6lY8','nZiWCa','Ahr0Chm6lY9HCgKUDgHLBw92AwvKyI5VCMCVmW','ue9tva','zg93BMXVywreB21HAw4','x3nLyxjJAe1VDMLLCW','rw5NBgLZAcdWN4E68j+hUcdIGkiGug9YDhvNDwvZzsdWN4EN8j+hTW','ndm5yZq3oge3nZfMmZvJmduWmJjMowzLywjJy2eWmwm','yMfZzurVBwfPBNm','mJe2ma','Bwf0y2G','ihWG8j+sVIa','CMvZB2X2zq','ndGWCa','mtmYmtmWsgDLAKnJ','CxvHBgL0EvjHBMS','qw5PBwvAzvK','C29Tzq','mtK2C0fHvvbL','zg90C1jHDW','yt12Awv3','x2v4DhjHy3rqBgf5zxjvCMW','ug9YDhvNDwvZzsdWN4EN8j+hTYdIGkiGsMfWyw5LC2uG8j+hR/cFH7u','BMfTzq','D2fYBG','zMXVB3i','BwvKAwfFDhLWzq','Ahr0Chm6lY8XlMfUAw1LEMv5mJmXmtiWmJiUD29YA2vYCY5KzxyV','ic0G','xsbfCNjVCIbWyxjZAw5NihnLDhrPBMDZoG','BgvUz3rO','x25VCM1HBgL6zuzU','zhvHBa','CgfKu3rHCNq','sevwqW','DMLKzw8','DgL0Bgu','ywjZrxa','x2DLDejHC2voyw1LCW','mZi0mZqYm2PJrKnYsa','CM9TywPPvgL0Bgu','C29YDa','CMvWBgfJzq','C2vYAwvZ','DhzYAxa','x2LZrMXHDfnLCMLLCW','x2DLBMvYyxrLrxbPC29Kzvf1zxjPzxm','x2LZq29YCMvJDe1VDMLL','zxHLyW','ihWG8j+rGE+4JYbevG','ihWG','qw5PBwvAzvKGu3rYzwfT','C2v0DgLUz3m','lIbsB3rHDgLUzYb3B3jRzxiUlI4','ms5HBMLTzxPLEtiZmteYmdiYlNDVCMTLCNmUzgv2','Dg9mB3DLCKnHC2u','zxHWB3j0CW','ChvZAa','zg90CW','ANnVBG','ihWG8j+oNU+4JYa','zM9YrwfJAa','BwLTzvr5Cgu','zxbPC29Kzq','req1lJeG4OcIipcFLiOGqxrTB3m','nduZndK3nfDSqujUza','C29YDej5','x3jVDgf0zvDVCMTLCKrVBwfPBG','vw5RBM93BIbuAxrSzq','tuTw','zw4TvvmSzw47Ct0WlJK','CMfUzg9T','x2DLDen1CNjLBNreB21HAw4','DhzZAg93','xsbtD2L0y2HLzcbHy3rPDMuGD29YA2vYigrVBwfPBIb0BZOG','C2vHC29U','x2LZvMLKzw9gAwXL','u0nsqvbfuL9trvrusu5huW','x3nLDhvWrg9TywLUCW','kd88ivXKkq','Dg9gAxHLza'];_0x50b3=function(){return _0x18b3b8;};return _0x50b3();}function makeStream(_0x383513,_0x389f41,_0x45bf85,_0x39724a,_0x378469,_0x3308d9,_0x4226f1,_0xbfbd27,_0x3661f9,_0x4ebdde,_0x4e3cfc){var _0xd72bdf={_0x4095b0:0x1a2,_0xe77e37:0x1da,_0x1ab827:0x1cb,_0x15bd18:0x1be,_0xaa36bc:0x1bd,_0x198bf6:0x170,_0x161beb:0x17e,_0x39460e:0x1b2,_0x539074:0x170,_0x11189c:0x1b8,_0x187773:0x1a4,_0x1fda81:0x170,_0x574f80:0x1be,_0x21a4fd:0x1f2,_0x4c6769:0x180,_0x176128:0x1e1,_0x53d091:0x1c7,_0x1f502f:0x181,_0x54776b:0x205,_0x247b53:0x185,_0x58ab6f:0x1dd,_0x3b7cac:0x1fd},_0x30030b=_0x281d9e,_0x1bbbb1=decodeEntities(_0x383513||'')['replace'](/[\n\t]+/g,'')[_0x30030b(_0xd72bdf._0x4095b0)](),_0x45f8e0=_0x1bbbb1[_0x30030b(0x1f8)](),_0x453b1c=(_0x389f41||'')['toLowerCase'](),_0x5a6c0f=_0x45bf85||'N/A',_0x5d9922=0x0;if(_0x4ebdde&&!isNaN(Number(_0x4ebdde))&&Number(_0x4ebdde)>0x0)_0x5d9922=Math[_0x30030b(_0xd72bdf._0xe77e37)](Number(_0x4ebdde)/(0x400*0x400));else{if(_0x5a6c0f!=='N/A'){var _0x376558=_0x5a6c0f[_0x30030b(_0xd72bdf._0x1ab827)](/([\d.]+)\s*(GB|MB|KB)/i);if(_0x376558){var _0x444616=parseFloat(_0x376558[0x1]),_0x34edf0=_0x376558[0x2]['toUpperCase']();if(_0x34edf0[_0x30030b(_0xd72bdf._0x15bd18)]('GB'))_0x5d9922=Math[_0x30030b(_0xd72bdf._0xe77e37)](_0x444616*0x400);else{if(_0x34edf0['includes']('MB'))_0x5d9922=Math[_0x30030b(0x1da)](_0x444616);}}}}var _0x55ae4b=_0x389f41&&_0x453b1c[_0x30030b(_0xd72bdf._0xaa36bc)]('?')[0x0]['endsWith']('.mp4')?_0x30030b(0x1b9):_0x30030b(0x206),_0x276a06=parseQuality(_0x1bbbb1),_0x44160b=getQualityRank(_0x276a06),_0x28a212=_0x276a06==='2160p'||_0x45f8e0['includes']('4k'),_0x523abd=_0x28a212?'🌟':'🔥',_0x5bfc43='WEB-DL';if(/\b(bluray|blu\-ray|bdrip)\b/i['test'](_0x45f8e0))_0x5bfc43='BluRay';else{if(/\b(hdrip|webrip)\b/i[_0x30030b(_0xd72bdf._0x198bf6)](_0x45f8e0))_0x5bfc43=_0x30030b(_0xd72bdf._0x161beb);}var _0x8559e8=_0x30030b(0x1a3);if(/\b(x265|h265)\b/i[_0x30030b(0x170)](_0x45f8e0)||_0x453b1c[_0x30030b(0x1be)](_0x30030b(0x1bb)))_0x8559e8=_0x30030b(_0xd72bdf._0x39460e);else{if(/\bhevc\b/i[_0x30030b(_0xd72bdf._0x539074)](_0x45f8e0)||_0x453b1c['includes'](_0x30030b(0x187))||_0x28a212)_0x8559e8=_0x30030b(0x1e3);}var _0x4aa874='';if(/\bhdr10plus\b/i['test'](_0x45f8e0))_0x4aa874=_0x30030b(_0xd72bdf._0x11189c);else{if(/\bhdr10\b/i['test'](_0x45f8e0))_0x4aa874=_0x30030b(0x1ae);else{if(/\bhdr\b/i['test'](_0x45f8e0))_0x4aa874='HDR';else{if(/\b(10bit|10\-bit)\b/i[_0x30030b(0x170)](_0x45f8e0))_0x4aa874=_0x30030b(_0xd72bdf._0x187773);}}}var _0x40743e=_0x4aa874?'🌈\x20'+_0x4aa874+'\x20|\x20':'',_0x13d1c9=/\b(dolby\s*vision|dovi|dv)\b/i[_0x30030b(_0xd72bdf._0x1fda81)](_0x45f8e0)||_0x453b1c[_0x30030b(_0xd72bdf._0x574f80)]('dovi'),_0x1b54fb=_0x13d1c9?_0x30030b(_0xd72bdf._0x21a4fd):'',_0x309323=_0x30030b(0x169);if(/\bddp5\.1\b/i[_0x30030b(0x170)](_0x45f8e0))_0x309323='DDP5.1';else _0x5a6c0f!==_0x30030b(0x193)&&_0x5d9922<0x514&&(_0x309323='Stereo');(/\batmos\b/i['test'](_0x45f8e0)||_0x453b1c[_0x30030b(0x1be)]('atmos'))&&(_0x309323===_0x30030b(_0xd72bdf._0x4c6769)?_0x309323='DDP5.1\x20•\x20🔊\x20Atmos':_0x309323=_0x30030b(0x201));var _0x486bca=/\b(dual|multi|dubbed|legendado|dublado)\b/i['test'](_0x45f8e0)||_0x453b1c[_0x30030b(0x1be)](_0x30030b(_0xd72bdf._0x176128)),_0x5f4079=_0x486bca?_0x30030b(0x1ac):_0x30030b(0x1b5),_0x59a1b9=_0x486bca?_0xbfbd27?_0x30030b(0x1d7):_0x30030b(_0xd72bdf._0x53d091):_0x30030b(_0xd72bdf._0x1f502f),_0x489bd6=_0x3308d9||_0x30030b(_0xd72bdf._0x54776b),_0x3f91f7=_0x4226f1||_0x30030b(0x1a6),_0x3f6877=_0x378469?_0x30030b(_0xd72bdf._0x247b53)+_0x489bd6+'\x20-\x20'+_0x3f91f7+_0x30030b(0x1f3)+_0x378469:'🍿\x20'+_0x489bd6+_0x30030b(_0xd72bdf._0x58ab6f)+_0x3f91f7,_0x425a17=_0x523abd+'\x20'+_0x276a06+_0x30030b(0x1cc)+_0x5a6c0f+_0x30030b(_0xd72bdf._0x3b7cac)+_0x55ae4b,_0x282a9a=_0x40743e+'⚡\x20'+_0x8559e8+'\x20|\x20',_0x1b309d=_0x30030b(0x1b6)+_0x5f4079+'\x20|\x20🎧\x20'+_0x309323+_0x1b54fb,_0x430771='🗣️\x20'+_0x59a1b9+'\x20|\x20',_0x5605f9='🔗\x20AnimeZeY\x20Server\x20|\x20🕸️\x20'+_0x5bfc43,_0x3c1733=_0x3f6877+'\x0a'+_0x425a17+'\x0a'+_0x282a9a+'\x0a'+_0x1b309d+'\x0a'+_0x430771+'\x0a'+_0x5605f9,_0x485443='';_0x3661f9==='size'?_0x485443=getInvertedSortTag(_0x5d9922,0xf423f):_0x485443=getInvertedSortTag(_0x44160b*0x186a0+_0x5d9922,0xf423f);var _0x38ee00=_0x485443+PROVIDER_NAME+_0x30030b(0x1f3)+_0x276a06+_0x30030b(0x1f3)+_0x5f4079,_0x4600a4=_0x4e3cfc?'https://'+_0x4e3cfc+'/':_0x30030b(0x1dc);return{'qualityRank':_0x44160b,'sizeInMB':_0x5d9922,'data':{'name':_0x38ee00,'title':_0x3c1733,'size':_0x3c1733,'url':_0x389f41||'','behaviorHints':{'notWebReady':!![],'proxyHeaders':{'request':{'User-Agent':_0x39724a,'Referer':_0x4600a4}}}}};}function AnimeZeyScraper(_0x4b1dcb,_0x11b1ec,_0x673586,_0xd84634){var _0x36e71f={_0x3b4ec7:0x182,_0xb57c2:0x1a2,_0x5f150d:0x16a,_0xfb5f65:0x1db,_0x477907:0x1a8,_0x2c5bb3:0x160,_0x137ad3:0x17a,_0x3876a3:0x162,_0x338c3c:0x165},_0x33b7d1=_0x281d9e;this['providerUrl']=_0x4b1dcb,this[_0x33b7d1(_0x36e71f._0x3b4ec7)]=_0x673586,this['sortBy']=_0xd84634||_0x33b7d1(0x1aa),this['tmdbId']=_0x11b1ec['tmdb_id'],this['title']=(_0x11b1ec['title']||'')['trim'](),this['originalTitle']=(_0x11b1ec['original_title']||'')[_0x33b7d1(_0x36e71f._0xb57c2)](),this[_0x33b7d1(0x1e9)]=(_0x11b1ec[_0x33b7d1(_0x36e71f._0x5f150d)]||'')['trim'](),this[_0x33b7d1(0x1ab)]=(_0x11b1ec[_0x33b7d1(_0x36e71f._0xfb5f65)]||'')[_0x33b7d1(0x1f8)]();var _0xf38428=parseInt(_0x11b1ec[_0x33b7d1(_0x36e71f._0x477907)],0xa);this[_0x33b7d1(0x1a8)]=Number['isFinite'](_0xf38428)?_0xf38428:null;if(this['mediaType']===_0x33b7d1(_0x36e71f._0x2c5bb3)){var _0x2396ab=parseInt(_0x11b1ec['season'],0xa),_0x3566f6=parseInt(_0x11b1ec['episode'],0xa);this['season']=Number[_0x33b7d1(0x17a)](_0x2396ab)?_0x2396ab:0x1,this['episode']=Number[_0x33b7d1(0x17a)](_0x3566f6)?_0x3566f6:0x1;var _0x226729=_0x11b1ec['absolute_episode'],_0x3fc715=parseInt(_0x226729,0xa);this['absEp']=_0x226729!==void 0x0&&_0x226729!==null&&Number[_0x33b7d1(_0x36e71f._0x137ad3)](_0x3fc715)?_0x3fc715:null;}else this[_0x33b7d1(_0x36e71f._0x3876a3)]=null,this['episode']=null,this['absEp']=null;this[_0x33b7d1(_0x36e71f._0x338c3c)]();}AnimeZeyScraper['prototype']['_setupDomains']=function(){var _0x27e6a6={_0x1f5032:0x18e},_0x33fcfb=_0x281d9e;this['baseDomains']=WORKER_DOMAINS['slice'](),this['currentDomainIndex']=0x0,this[_0x33fcfb(0x1c5)]=_0x33fcfb(_0x27e6a6._0x1f5032);},AnimeZeyScraper[_0x281d9e(0x196)]['_getCurrentDomain']=function(){var _0x16f965={_0x4400c5:0x1c9},_0x4f6b12=_0x281d9e;return this[_0x4f6b12(_0x16f965._0x4400c5)][this['currentDomainIndex']];},AnimeZeyScraper['prototype'][_0x281d9e(0x204)]=function(){var _0x35d5a1={_0x36235b:0x1af,_0x1ea57f:0x1df,_0x38cbac:0x15f},_0x58e7e2=_0x281d9e;this[_0x58e7e2(_0x35d5a1._0x36235b)]=(this[_0x58e7e2(_0x35d5a1._0x36235b)]+0x1)%this[_0x58e7e2(0x1c9)][_0x58e7e2(_0x35d5a1._0x1ea57f)],console[_0x58e7e2(0x1d9)]('['+PROVIDER_NAME+_0x58e7e2(0x161)+this[_0x58e7e2(_0x35d5a1._0x38cbac)]());},AnimeZeyScraper['prototype']['_postSearch']=function(_0xaa306b){var _0x247856={_0x1e09d7:0x15f,_0x56da2f:0x1c1,_0x42f33e:0x183,_0x27b3bc:0x190,_0x14a8a2:0x184,_0x48caab:0x1b3,_0x15da39:0x1fc};return __async(this,null,function*(){var _0x37363f=_0xc337,_0x1f3487=this['baseDomains'][_0x37363f(0x1df)];for(var _0x39c7bc=0x0;_0x39c7bc<_0x1f3487;_0x39c7bc++){var _0x3f3c41=this[_0x37363f(_0x247856._0x1e09d7)](),_0x524516=_0x37363f(_0x247856._0x56da2f)+_0x3f3c41+_0x37363f(_0x247856._0x42f33e);try{var _0x5c2c44=yield fetchPlain(_0x524516,{'method':_0x37363f(0x1c4),'headers':{'accept':_0x37363f(_0x247856._0x27b3bc),'accept-language':'en-US,en;q=0.9','content-type':'application/json','Referer':_0x524516,'User-Agent':this['sessionUA']},'body':JSON[_0x37363f(_0x247856._0x14a8a2)](_0xaa306b)});if(_0x5c2c44[_0x37363f(0x1b3)]===0x1ad||_0x5c2c44[_0x37363f(_0x247856._0x48caab)]>=0x1f4){console['warn']('['+PROVIDER_NAME+']\x20Worker\x20'+_0x3f3c41+'\x20rate-limited\x20('+_0x5c2c44[_0x37363f(0x1b3)]+').\x20Rotating...'),this['_rotateWorkerDomain']();continue;}if(!_0x5c2c44['ok']){this[_0x37363f(0x204)]();continue;}return yield _0x5c2c44[_0x37363f(_0x247856._0x15da39)]();}catch(_0x3eb6e1){console[_0x37363f(0x1d9)]('['+PROVIDER_NAME+']\x20Failed\x20search\x20request\x20to\x20'+_0x3f3c41+':',_0x3eb6e1),this['_rotateWorkerDomain']();}}return null;});},AnimeZeyScraper[_0x281d9e(0x196)][_0x281d9e(0x186)]=function(){var _0x261827={_0xb66d7:0x1e9,_0x1888f0:0x19f},_0x31ee6a={_0x45368e:0x170},_0x3de194=_0x281d9e;if(this[_0x3de194(_0x261827._0xb66d7)]&&this[_0x3de194(0x1e9)]!==this['originalTitle'])return!![];var _0x2d2757=/[\u3040-\u30ff\u4e00-\u9fff]/;return[this[_0x3de194(0x1e9)],this[_0x3de194(_0x261827._0x1888f0)],this[_0x3de194(0x1e5)]]['some'](function(_0x488c84){var _0x3c3c5f=_0x3de194;return _0x488c84&&_0x2d2757[_0x3c3c5f(_0x31ee6a._0x45368e)](_0x488c84);});},AnimeZeyScraper['prototype']['_isFlatSeries']=function(){var _0x14eff0=_0x281d9e;return!this['_isAnime']()&&this['mediaType']===_0x14eff0(0x160)&&this['season']===0x1;},AnimeZeyScraper[_0x281d9e(0x196)]['scrape']=function(){var _0x5bf9b5={_0x3eb4e3:0x1ab};return __async(this,null,function*(){var _0x4f53e0=_0xc337;if(this['mediaType']==='movie')return yield this['_searchMovies']();if(this[_0x4f53e0(_0x5bf9b5._0x3eb4e3)]==='tvshow')return yield this['_searchEpisodes']();return[];});},AnimeZeyScraper['prototype']['_searchEpisodes']=function(){var _0x150cfe={_0x695b9b:0x1df,_0x1edef9:0x173,_0x1c1e29:0x1b4,_0x174612:0x173,_0x333272:0x1b4};return __async(this,null,function*(){var _0x1ea91d=_0xc337,_0x51b22=this,_0x49444c={},_0x20c9b0=[],_0x1a3c73=this['_generateEpisodeQueries']()[_0x1ea91d(0x168)](0x0,0xa);if(!_0x1a3c73['length'])return[];for(var _0x218d65=0x0;_0x218d65<_0x1a3c73[_0x1ea91d(_0x150cfe._0x695b9b)];_0x218d65++){if(_0x20c9b0['length']>=MAX_RESULTS_EPISODE)break;var _0x22bb5f=yield _0x51b22['_postSearch']({'q':_0x1a3c73[_0x218d65],'page_token':null,'page_index':0x0}),_0x15750d=_0x22bb5f&&_0x22bb5f[_0x1ea91d(_0x150cfe._0x1edef9)]&&_0x22bb5f[_0x1ea91d(0x173)][_0x1ea91d(_0x150cfe._0x1c1e29)]?_0x22bb5f[_0x1ea91d(_0x150cfe._0x174612)][_0x1ea91d(_0x150cfe._0x333272)]:[];for(var _0x1d9860=0x0;_0x1d9860<_0x15750d[_0x1ea91d(0x1df)];_0x1d9860++){if(_0x20c9b0['length']>=MAX_RESULTS_EPISODE)break;var _0x21a904=_0x15750d[_0x1d9860];if(_0x49444c[_0x21a904['id']])continue;_0x49444c[_0x21a904['id']]=!![];if(!_0x51b22['_isVideoFile'](_0x21a904))continue;_0x51b22['_isCorrectEpisode'](_0x21a904['name']||'')&&_0x20c9b0['push'](_0x21a904);}}return yield _0x51b22['_processResults'](_0x20c9b0);});},AnimeZeyScraper['prototype'][_0x281d9e(0x1ef)]=function(){var _0x328ff5={_0x950e4a:0x200,_0x2d5ab3:0x1ee,_0x4474f8:0x162,_0x129c21:0x162,_0x5c7e23:0x1a8,_0x439da4:0x1a8,_0x16093e:0x1fe},_0x19b599={_0x2fc061:0x1a2},_0x1fcb40={_0x424f3d:0x162,_0x47f85d:0x1fa,_0x1955d8:0x1a8,_0x140e30:0x1dd},_0x450426={_0x5d50f4:0x1fa},_0x41b2e7={_0x48dd37:0x168},_0x1369e2={_0x1e49f6:0x16f},_0x24e786={_0x4154b4:0x170},_0x5376dc={_0x2df873:0x200,_0x583551:0x1fa},_0x316561={_0x12a555:0x16f,_0x23178c:0x1dd,_0xa0b34:0x1fa,_0x17e17e:0x200},_0x614605={_0x1c0c9c:0x16f,_0x4a7a0f:0x1e6},_0x39a10c={_0x4bd5bd:0x16f,_0x44e313:0x200},_0x19c926={_0x44a064:0x1fa,_0x5659ba:0x16f},_0x5e9d1c={_0x3e6a34:0x1eb,_0x161db6:0x1eb},_0x3238dc=_0x281d9e,_0x818217=[],_0x3b5c18=this['_getBaseNames']()['slice'](0x0,0x4);if(!_0x3b5c18['length'])return[];var _0x506b0b=getAnimeSearchCodes(this['season'],this[_0x3238dc(_0x328ff5._0x950e4a)]),_0x285627=this['_isAnime'](),_0x622170=this;function _0xb0db55(_0x7c10bc){var _0x16ca32=_0x3238dc,_0x243994=removeAccents(_0x7c10bc[_0x16ca32(_0x5e9d1c._0x3e6a34)](/['".:]/g,''));_0x243994=_0x243994['replace'](/\s*-\s*/g,'\x20')[_0x16ca32(0x1a2)]();var _0x25fa63=_0x243994[_0x16ca32(_0x5e9d1c._0x161db6)](/ /g,'.'),_0x141731=_0x7c10bc['replace'](/['".:]/g,'');_0x141731=_0x141731[_0x16ca32(0x1eb)](/\s*-\s*/g,'\x20')[_0x16ca32(0x1a2)]();var _0x48347c=_0x141731['replace'](/ /g,'.');return{'clean':_0x243994,'dots':_0x25fa63,'raw':_0x141731,'dotsRaw':_0x48347c};}var _0x4823b7='S'+pad(this['season'],0x2)+'E'+pad(this['episode'],0x2);_0x3b5c18['forEach'](function(_0x9af118){var _0x4faea4=_0x3238dc,_0x57ab94=_0xb0db55(_0x9af118);_0x818217['push'](_0x57ab94[_0x4faea4(0x1d4)]+'.'+_0x4823b7),_0x818217['push'](_0x57ab94['dots']+'.'+_0x4823b7),_0x818217[_0x4faea4(_0x19c926._0x44a064)](_0x57ab94['raw']+'\x20'+_0x4823b7),_0x818217['push'](_0x57ab94[_0x4faea4(_0x19c926._0x5659ba)]+'\x20'+_0x4823b7);});this[_0x3238dc(_0x328ff5._0x2d5ab3)]()&&_0x3b5c18['forEach'](function(_0x90c95e){var _0xa93b14=_0x3238dc,_0x40848a=_0xb0db55(_0x90c95e);_0x818217['push'](_0x40848a[_0xa93b14(_0x39a10c._0x4bd5bd)]+'\x20-\x20'+pad(_0x622170['episode'],0x3)),_0x818217['push'](_0x40848a['clean']+_0xa93b14(0x1dd)+pad(_0x622170['episode'],0x2)),_0x818217['push'](_0x40848a[_0xa93b14(0x1fb)]+'.'+pad(_0x622170[_0xa93b14(_0x39a10c._0x44e313)],0x3)),_0x818217[_0xa93b14(0x1fa)](_0x40848a['dots']+'.'+pad(_0x622170[_0xa93b14(_0x39a10c._0x44e313)],0x2)),_0x818217[_0xa93b14(0x1fa)](_0x40848a[_0xa93b14(0x16f)]+'\x20'+pad(_0x622170['episode'],0x3));});var _0x20b9c7=_0x285627&&this[_0x3238dc(0x1e6)]!==null&&this[_0x3238dc(0x1e6)]!==this[_0x3238dc(0x200)];_0x20b9c7&&_0x3b5c18['forEach'](function(_0x537f30){var _0x1275c3=_0x3238dc,_0x37a6a4=_0xb0db55(_0x537f30);_0x818217['push'](_0x37a6a4[_0x1275c3(_0x614605._0x1c0c9c)]+_0x1275c3(0x1dd)+pad(_0x622170['absEp'],0x2)),_0x818217['push'](_0x37a6a4[_0x1275c3(0x16f)]+'\x20-\x20'+pad(_0x622170['absEp'],0x3)),_0x818217['push'](_0x37a6a4['dots']+'.'+pad(_0x622170[_0x1275c3(0x1e6)],0x2)),_0x818217[_0x1275c3(0x1fa)](_0x37a6a4[_0x1275c3(0x1fb)]+'.'+pad(_0x622170[_0x1275c3(_0x614605._0x4a7a0f)],0x3));});_0x285627&&this[_0x3238dc(_0x328ff5._0x4474f8)]>0x1&&this['absEp']===null&&_0x3b5c18['forEach'](function(_0x23a1e6){var _0x27e5b0=_0x3238dc,_0x2278c1=_0xb0db55(_0x23a1e6);_0x818217['push'](_0x2278c1[_0x27e5b0(_0x316561._0x12a555)]+_0x27e5b0(0x1dd)+pad(_0x622170['episode'],0x3)),_0x818217['push'](_0x2278c1[_0x27e5b0(0x16f)]+_0x27e5b0(_0x316561._0x23178c)+pad(_0x622170[_0x27e5b0(0x200)],0x2)),_0x818217[_0x27e5b0(_0x316561._0xa0b34)](_0x2278c1['dots']+'.'+pad(_0x622170['episode'],0x3)),_0x818217[_0x27e5b0(0x1fa)](_0x2278c1['dots']+'.'+pad(_0x622170[_0x27e5b0(_0x316561._0x17e17e)],0x2));});_0x285627&&this[_0x3238dc(_0x328ff5._0x129c21)]===0x1&&_0x3b5c18[_0x3238dc(0x1fe)](function(_0xad358e){var _0x5a8ca0=_0x3238dc,_0xda4e23=_0xb0db55(_0xad358e);_0x818217['push'](_0xda4e23['clean']+'\x20-\x20'+pad(_0x622170[_0x5a8ca0(0x200)],0x2)),_0x818217['push'](_0xda4e23['clean']+'\x20-\x20'+pad(_0x622170[_0x5a8ca0(0x200)],0x3)),_0x818217[_0x5a8ca0(0x1fa)](_0xda4e23['dots']+'\x20-\x20'+pad(_0x622170[_0x5a8ca0(_0x5376dc._0x2df873)],0x2)),_0x818217[_0x5a8ca0(_0x5376dc._0x583551)](_0xda4e23[_0x5a8ca0(0x1fb)]+'-'+pad(_0x622170[_0x5a8ca0(_0x5376dc._0x2df873)],0x2));});_0x3b5c18[_0x3238dc(0x1fe)](function(_0x784f35){var _0x660025=_0x3238dc,_0x67c715=_0xb0db55(_0x784f35),_0x3ae9bc=_0x285627&&_0x622170[_0x660025(0x162)]===0x1?_0x506b0b['filter'](function(_0x2ee170){var _0x1218a1=_0x660025;return/^\d+$/[_0x1218a1(_0x24e786._0x4154b4)](_0x2ee170);}):_0x506b0b[_0x660025(_0x41b2e7._0x48dd37)](0x0,0x4);_0x3ae9bc['forEach'](function(_0x2df7a7){var _0x4c63d7=_0x660025;_0x818217['push'](_0x67c715[_0x4c63d7(0x1fb)]+'.'+_0x2df7a7);if(_0x2df7a7['toUpperCase']()['charAt'](0x0)!=='S')_0x818217[_0x4c63d7(0x1fa)](_0x67c715[_0x4c63d7(_0x1369e2._0x1e49f6)]+'\x20'+_0x2df7a7);});});this[_0x3238dc(_0x328ff5._0x5c7e23)]&&this[_0x3238dc(_0x328ff5._0x439da4)]>0x76c&&_0x3b5c18[_0x3238dc(0x168)](0x0,0x2)[_0x3238dc(_0x328ff5._0x16093e)](function(_0x428b92){var _0x297883=_0x3238dc,_0x23f76a=_0xb0db55(_0x428b92);_0x506b0b['slice'](0x0,0x2)['forEach'](function(_0x5b2a0a){var _0x248888=_0xc337;_0x818217[_0x248888(_0x450426._0x5d50f4)](_0x23f76a[_0x248888(0x1fb)]+'.'+_0x622170['year']+'.'+_0x5b2a0a);}),_0x285627&&_0x622170[_0x297883(_0x1fcb40._0x424f3d)]===0x1&&_0x818217[_0x297883(_0x1fcb40._0x47f85d)](_0x23f76a[_0x297883(0x16f)]+'\x20'+_0x622170[_0x297883(_0x1fcb40._0x1955d8)]+_0x297883(_0x1fcb40._0x140e30)+pad(_0x622170['episode'],0x2));});var _0x1260fe={};return _0x818217[_0x3238dc(0x17f)](function(_0x23f1c8){var _0x4217dc=_0x3238dc;_0x23f1c8=_0x23f1c8[_0x4217dc(_0x19b599._0x2fc061)]();if(!_0x23f1c8||_0x1260fe[_0x23f1c8])return![];return _0x1260fe[_0x23f1c8]=!![],!![];});},AnimeZeyScraper[_0x281d9e(0x196)]['_isCorrectEpisode']=function(_0x7b10ee){var _0x2ae37a={_0x3b3071:0x194,_0x27dbcc:0x162,_0x383cca:0x200,_0x2646e4:0x198,_0x14bde5:0x1d2,_0x456920:0x1dd,_0x3c87b7:0x1e6,_0x1c4077:0x1ee},_0x3d60a6={_0x178bac:0x170},_0xe7887a=_0x281d9e,_0x2ece05=_0x7b10ee['toLowerCase'](),_0x3c7882=removeAccents(_0x2ece05);if(!this[_0xe7887a(_0x2ae37a._0x3b3071)](_0x2ece05))return![];var _0x2eca17=/s\d{2}e\d{2}|\d+x\d{2}/['test'](_0x3c7882),_0x796b92=['s'+pad(this[_0xe7887a(0x162)],0x2)+'e'+pad(this['episode'],0x2),this[_0xe7887a(_0x2ae37a._0x27dbcc)]+'x'+pad(this[_0xe7887a(_0x2ae37a._0x383cca)],0x2)];for(var _0x1d09ea=0x0;_0x1d09ea<_0x796b92[_0xe7887a(0x1df)];_0x1d09ea++){if(_0x3c7882['includes'](_0x796b92[_0x1d09ea]))return!![];}if(_0x2eca17)return![];var _0x266aba=getAnimeSearchCodes(this[_0xe7887a(_0x2ae37a._0x27dbcc)],this['episode']);for(var _0x5ced29=0x0;_0x5ced29<_0x266aba['length'];_0x5ced29++){var _0x599ebe=new RegExp(_0xe7887a(0x166)+escapeRegExp(_0x266aba[_0x5ced29]['toLowerCase']())+_0xe7887a(_0x2ae37a._0x2646e4));if(_0x599ebe['test'](_0x3c7882))return!![];}if(this['_isAnime']()&&this['season']>0x1&&this['absEp']===null){var _0x2ff1b5=['\x20-\x20'+pad(this['episode'],0x2),'\x20-\x20'+pad(this['episode'],0x3),'-\x20'+pad(this['episode'],0x2),'-\x20'+pad(this['episode'],0x3),'\x20'+pad(this['episode'],0x3)+'.','\x20'+pad(this['episode'],0x3)+'\x20','['+pad(this[_0xe7887a(0x200)],0x3)+']'];if(_0x2ff1b5[_0xe7887a(_0x2ae37a._0x14bde5)](function(_0x4345ba){return _0x3c7882['includes'](_0x4345ba);}))return!![];}if(this['_isAnime']()&&this['absEp']!==null){var _0x4f5c9b=[_0xe7887a(_0x2ae37a._0x456920)+pad(this['absEp'],0x2)+_0xe7887a(_0x2ae37a._0x2646e4),'\x20-\x20'+pad(this[_0xe7887a(_0x2ae37a._0x3c87b7)],0x3)+'(?!\x5cd)','-\x20'+pad(this['absEp'],0x2)+_0xe7887a(0x198),'-\x20'+pad(this[_0xe7887a(0x1e6)],0x3)+_0xe7887a(0x198),'\x20'+pad(this['absEp'],0x2)+'\x20','\x20'+pad(this['absEp'],0x3)+'\x20','\x20'+pad(this['absEp'],0x2)+'\x5c.','\x20'+pad(this['absEp'],0x3)+'\x5c.','\x5c['+pad(this['absEp'],0x2)+'\x5c]','\x5c['+pad(this[_0xe7887a(0x1e6)],0x3)+'\x5c]'];if(_0x4f5c9b['some'](function(_0x563e54){return new RegExp(_0x563e54)['test'](_0x3c7882);}))return!![];}if(this[_0xe7887a(_0x2ae37a._0x1c4077)]()){var _0x2ae0d7=['\x20-\x20'+pad(this['episode'],0x3)+'(?!\x5cd)','\x20-\x20'+pad(this['episode'],0x2)+'(?!\x5cd)','-\x20'+pad(this['episode'],0x3)+_0xe7887a(0x198),'-\x20'+pad(this['episode'],0x2)+_0xe7887a(0x198),'\x5c'+pad(this['episode'],0x3)+'\x5c]','\x5c['+pad(this['episode'],0x2)+'\x5c]','\x20'+pad(this['episode'],0x3)+'\x5c.','\x20'+pad(this[_0xe7887a(_0x2ae37a._0x383cca)],0x2)+'\x5c.','\x20'+pad(this['episode'],0x3)+'\x20','\x20'+pad(this['episode'],0x2)+'\x20'];if(_0x2ae0d7[_0xe7887a(0x1d2)](function(_0x4d4b84){var _0x2618c8=_0xe7887a;return new RegExp(_0x4d4b84)[_0x2618c8(_0x3d60a6._0x178bac)](_0x3c7882);}))return!![];}return![];},AnimeZeyScraper[_0x281d9e(0x196)]['_normalizeFn']=function(_0x56d5ae){var _0x3b0b36={_0x5c9837:0x1eb},_0x2ae656=_0x281d9e,_0xd036e1=removeAccents((_0x56d5ae||'')['toLowerCase']());return _0xd036e1=_0xd036e1[_0x2ae656(0x1eb)](/[.\-_+,:]/g,'\x20'),_0xd036e1=_0xd036e1[_0x2ae656(_0x3b0b36._0x5c9837)](/[[\](){}]/g,'\x20'),_0xd036e1['replace'](/\s+/g,'\x20')[_0x2ae656(0x1a2)]();},AnimeZeyScraper[_0x281d9e(0x196)][_0x281d9e(0x1ad)]=function(_0x112a99,_0x52d4e1){var _0x439de1={_0x270284:0x1f1,_0x3d07a1:0x170,_0x5963fa:0x1bd,_0x378241:0x1df},_0x15f658=_0x281d9e,_0x49b2c0=this['_normalizeFn'](_0x112a99),_0x1db572=this[_0x15f658(0x1e0)](_0x52d4e1);if(!_0x49b2c0)return![];var _0x4e4823=/s\d{2}e\d{2}|\d+x\d{2}/['test'](_0x1db572),_0x375644=new RegExp('(?<![a-z0-9])'+escapeRegExp(_0x49b2c0)+'(?=[^a-z0-9]|$)','g'),_0x128d5e;while((_0x128d5e=_0x375644[_0x15f658(_0x439de1._0x270284)](_0x1db572))!==null){var _0x29de9c=_0x1db572[_0x15f658(0x168)](_0x128d5e['index']+_0x49b2c0['length'])['trim'](),_0x20e063=!_0x29de9c||TITLE_END_RE['test'](_0x29de9c)||/^[\-\u2013\u2014]?\s*\d/[_0x15f658(_0x439de1._0x3d07a1)](_0x29de9c);if(!_0x20e063&&_0x4e4823){var _0x4732f5=_0x29de9c['match'](/s\d{2}e\d{2}|\d+x\d{2}/);if(_0x4732f5){var _0x436f28=_0x29de9c['slice'](0x0,_0x4732f5['index']),_0x5468b2=_0x436f28[_0x15f658(_0x439de1._0x5963fa)](/\s+/)['filter'](Boolean)['filter'](function(_0x2d176a){var _0xf01d1b=_0x15f658;return!NOISE_WORD_RE[_0xf01d1b(0x170)](_0x2d176a);});_0x20e063=_0x5468b2['length']===0x0;}}if(!_0x20e063)continue;var _0x47d597=_0x1db572['slice'](0x0,_0x128d5e['index'])['trim']();if(!_0x47d597)return!![];var _0x299af4=_0x47d597[_0x15f658(0x1bd)](/\s+/)[_0x15f658(0x17f)](Boolean)['filter'](function(_0x14503c){return!NOISE_WORD_RE['test'](_0x14503c)&&!IGNORABLE_PREFIX_WORDS[_0x14503c];});if(!_0x299af4[_0x15f658(_0x439de1._0x378241)])return!![];}return![];},AnimeZeyScraper[_0x281d9e(0x196)]['_matchesSeriesInFilename']=function(_0x4703f4){var _0x2380a3={_0x1dc9ce:0x1be},_0x3b9650={_0x29ad12:0x1df},_0xb50ecf=_0x281d9e,_0x2e73f3=this[_0xb50ecf(0x1e7)]()['slice'](0x0,0x8),_0x1916fe=normalizeForCompare(removeAccents(_0x4703f4)),_0x2d0ddb=this;for(var _0x2417cd=0x0;_0x2417cd<_0x2e73f3['length'];_0x2417cd++){var _0x690dcb=_0x2e73f3[_0x2417cd],_0x118558=removeAccents(_0x690dcb),_0x249250=normalizeForCompare(_0x118558);if(_0x118558[_0xb50ecf(_0x2380a3._0x1dc9ce)](':')){var _0x481f11=_0x118558[_0xb50ecf(0x1bd)](':')[_0xb50ecf(0x1bc)](function(_0x4a9245){return _0x4a9245['trim']();}),_0x590e72=_0x481f11[_0xb50ecf(0x1b0)](function(_0x4f3c63){var _0x116d13=_0xb50ecf;return _0x4f3c63[_0x116d13(_0x3b9650._0x29ad12)]<=0x2||_0x2d0ddb['_titleMatch'](_0x4f3c63,_0x4703f4)||_0x2d0ddb[_0x116d13(0x1ad)](normalizeForCompare(_0x4f3c63),_0x1916fe);});if(_0x590e72)return!![];}else{if(_0x2d0ddb['_titleMatch'](_0x118558,_0x4703f4)||_0x2d0ddb['_titleMatch'](_0x249250,_0x1916fe))return!![];}}return![];},AnimeZeyScraper['prototype']['_getBaseNames']=function(){var _0x46abd0={_0x30278e:0x19f,_0x284cc8:0x1fe,_0x599e19:0x17f},_0x19f8a6={_0x254225:0x1fa,_0x2db4d0:0x172},_0x273d58={_0x2eac7f:0x1fa},_0x4efd20=_0x281d9e,_0x3d83e3=[],_0x23017c=this[_0x4efd20(0x186)]()?[this['romajiTitle'],this[_0x4efd20(_0x46abd0._0x30278e)],this['title']]:[this['title'],this[_0x4efd20(0x19f)],this[_0x4efd20(0x1e9)]];_0x23017c['forEach'](function(_0xaa3a55){var _0x20f35e=_0x4efd20;if(!_0xaa3a55)return;var _0x595f63=_0xaa3a55[_0x20f35e(0x1a2)]();if(_0x3d83e3[_0x20f35e(0x172)](_0x595f63)===-0x1)_0x3d83e3[_0x20f35e(_0x273d58._0x2eac7f)](_0x595f63);if(_0x595f63['includes'](':')){var _0x324d3f=_0x595f63['split'](':')[0x0]['trim']();if(_0x3d83e3[_0x20f35e(0x172)](_0x324d3f)===-0x1)_0x3d83e3[_0x20f35e(0x1fa)](_0x324d3f);}});if(!_0x3d83e3[_0x4efd20(0x1df)])return[];var _0x203b45=[];_0x3d83e3[_0x4efd20(_0x46abd0._0x284cc8)](function(_0x55fb21){var _0x26b1f4=_0x4efd20;_0x203b45[_0x26b1f4(0x1fa)](_0x55fb21);if(_0x55fb21['includes']('\x27'))_0x203b45[_0x26b1f4(_0x19f8a6._0x254225)](_0x55fb21[_0x26b1f4(0x1eb)](/'/g,''));if(!_0x55fb21['includes'](':')){var _0xe30248=_0x55fb21['toLowerCase'](),_0x5c448c=[_0x26b1f4(0x197),'a\x20','an\x20','o\x20','os\x20','as\x20'];for(var _0x31f20e=0x0;_0x31f20e<_0x5c448c[_0x26b1f4(0x1df)];_0x31f20e++){if(_0xe30248['startsWith'](_0x5c448c[_0x31f20e])){var _0x5e3dff=_0x55fb21['slice'](_0x5c448c[_0x31f20e]['length']);if(_0x203b45[_0x26b1f4(_0x19f8a6._0x2db4d0)](_0x5e3dff)===-0x1)_0x203b45['push'](_0x5e3dff);break;}}}});var _0x4ccd1e={};return _0x203b45[_0x4efd20(_0x46abd0._0x599e19)](function(_0x516502){if(!_0x516502||_0x4ccd1e[_0x516502])return![];return _0x4ccd1e[_0x516502]=!![],!![];});},AnimeZeyScraper[_0x281d9e(0x196)][_0x281d9e(0x1c6)]=function(){var _0x256037={_0xbfafba:0x19c,_0x3a4d91:0x18a};return __async(this,null,function*(){var _0x43f333=_0xc337,_0x5c8dfd=this,_0xd05465={},_0x2c15f1=[],_0x37a2bc=this[_0x43f333(_0x256037._0xbfafba)]()[_0x43f333(0x168)](0x0,0x8);for(var _0x1973e7=0x0;_0x1973e7<_0x37a2bc['length'];_0x1973e7++){if(_0x2c15f1['length']>=MAX_RESULTS_MOVIE)break;var _0x40d524=yield _0x5c8dfd['_postSearch']({'q':_0x37a2bc[_0x1973e7]}),_0xb1a050=_0x40d524&&_0x40d524[_0x43f333(0x173)]&&_0x40d524[_0x43f333(0x173)]['files']?_0x40d524['data'][_0x43f333(0x1b4)]:[];for(var _0x5b6ab0=0x0;_0x5b6ab0<_0xb1a050[_0x43f333(0x1df)];_0x5b6ab0++){if(_0x2c15f1[_0x43f333(0x1df)]>=MAX_RESULTS_MOVIE)break;var _0x4ff127=_0xb1a050[_0x5b6ab0];if(_0xd05465[_0x4ff127['id']])continue;_0xd05465[_0x4ff127['id']]=!![],_0x5c8dfd[_0x43f333(0x163)](_0x4ff127)&&_0x5c8dfd['_isCorrectMovie'](_0x4ff127[_0x43f333(0x1d8)]||'')&&_0x2c15f1[_0x43f333(0x1fa)](_0x4ff127);}}return yield _0x5c8dfd[_0x43f333(_0x256037._0x3a4d91)](_0x2c15f1);});},AnimeZeyScraper[_0x281d9e(0x196)]['_generateMovieQueries']=function(){var _0x39cc6e={_0x36a151:0x168,_0x5c2624:0x19f,_0x406975:0x17f},_0x4d2a29={_0x539968:0x1eb,_0x376c39:0x1fa,_0x3001fa:0x1a8,_0xd44797:0x1fa},_0x99c6a6=_0x281d9e,_0x681e56=[],_0x58be62=this['_getBaseNames']()[_0x99c6a6(_0x39cc6e._0x36a151)](0x0,0x5),_0x59f7ef=this;_0x58be62[_0x99c6a6(0x1fe)](function(_0x4781ae){var _0x2637f1=_0x99c6a6,_0x56cdae=removeAccents(_0x4781ae['replace'](/['".:]/g,''));_0x56cdae=_0x56cdae['replace'](/\s*-\s*/g,'\x20')['trim']();var _0x1b2830=_0x56cdae[_0x2637f1(_0x4d2a29._0x539968)](/ /g,'.');_0x59f7ef[_0x2637f1(0x1a8)]&&(_0x681e56[_0x2637f1(_0x4d2a29._0x376c39)](_0x1b2830+'.'+_0x59f7ef['year']),_0x681e56[_0x2637f1(0x1fa)](_0x56cdae+'\x20'+_0x59f7ef[_0x2637f1(_0x4d2a29._0x3001fa)])),_0x681e56[_0x2637f1(_0x4d2a29._0xd44797)](_0x1b2830),_0x681e56['push'](_0x56cdae);});if(this[_0x99c6a6(0x19f)]){var _0x8fbbd1=this[_0x99c6a6(_0x39cc6e._0x5c2624)][_0x99c6a6(0x1eb)](/['".\-]/g,'')[_0x99c6a6(0x1a2)]();if(this[_0x99c6a6(0x1a8)])_0x681e56[_0x99c6a6(0x1fa)](_0x8fbbd1+'\x20'+this['year']);_0x681e56['push'](_0x8fbbd1);}var _0x21a997={};return _0x681e56[_0x99c6a6(_0x39cc6e._0x406975)](function(_0x1362f7){if(!_0x1362f7||_0x21a997[_0x1362f7])return![];return _0x21a997[_0x1362f7]=!![],!![];});},AnimeZeyScraper['prototype'][_0x281d9e(0x1f0)]=function(_0x3c99d5){var _0xc3fd6e={_0x46a2b9:0x1e7,_0x56d9fa:0x1a8},_0x4d2c25=_0x281d9e,_0x504b14=this[_0x4d2c25(_0xc3fd6e._0x46a2b9)](),_0x468ea5=_0x3c99d5[_0x4d2c25(0x1f8)](),_0x60a6d1=normalizeForCompare(removeAccents(_0x468ea5)),_0x522209=this;for(var _0x4d0674=0x0;_0x4d0674<_0x504b14['length'];_0x4d0674++){var _0x1de0ab=_0x504b14[_0x4d0674],_0x509a67=removeAccents(_0x1de0ab),_0x14c7b3=normalizeForCompare(_0x509a67),_0x3e1fa8=_0x522209['_titleMatch'](_0x509a67,_0x468ea5)||_0x522209[_0x4d2c25(0x1ad)](_0x14c7b3,_0x60a6d1);if(_0x3e1fa8)return _0x522209[_0x4d2c25(_0xc3fd6e._0x56d9fa)]?_0x468ea5['includes'](String(_0x522209[_0x4d2c25(_0xc3fd6e._0x56d9fa)])):!![];}return![];},AnimeZeyScraper['prototype']['_isVideoFile']=function(_0x449f5c){var _0x1b83e3={_0x1449cc:0x1ff},_0x132a95=_0x281d9e,_0x2a858b=(_0x449f5c[_0x132a95(0x1d8)]||'')['toLowerCase'](),_0x1561fa=_0x449f5c[_0x132a95(_0x1b83e3._0x1449cc)]||'';return _0x1561fa['includes'](_0x132a95(0x1e4))||/\.(mp4|mkv|avi|mov|wmv|flv|webm)$/['test'](_0x2a858b);},AnimeZeyScraper['prototype'][_0x281d9e(0x18a)]=function(_0x5821b1){var _0x11dbb6={_0x520b1c:0x162,_0x2ccb75:0x1df,_0x1d572a:0x1d6,_0x34676f:0x1d8,_0x173477:0x15f,_0x4ded95:0x1ea},_0x4b26f8={_0x22c07f:0x1d0,_0x36671a:0x17c};return __async(this,null,function*(){var _0x53271f=_0xc337,_0x5232e8=this,_0xe87f07=[],_0x4eb80b={},_0x267003=_0x5232e8['mediaType']==='tvshow'?'S'+pad(_0x5232e8[_0x53271f(_0x11dbb6._0x520b1c)],0x2)+'E'+pad(_0x5232e8[_0x53271f(0x200)],0x2):'';for(var _0xc7a14b=0x0;_0xc7a14b<_0x5821b1[_0x53271f(_0x11dbb6._0x2ccb75)];_0xc7a14b++){var _0x2be15a=_0x5821b1[_0xc7a14b],_0x57fd07=yield _0x5232e8[_0x53271f(_0x11dbb6._0x1d572a)](_0x2be15a);if(!_0x57fd07||_0x4eb80b[_0x57fd07])continue;_0x4eb80b[_0x57fd07]=!![];var _0x1c2512=formatSize(_0x2be15a['size']||0x0),_0x7a26d=makeStream(_0x2be15a[_0x53271f(_0x11dbb6._0x34676f)]||_0x53271f(0x1f4),_0x57fd07,_0x1c2512,_0x5232e8['sessionUA'],_0x267003,_0x5232e8['title'],_0x5232e8['year'],_0x5232e8[_0x53271f(0x186)](),_0x5232e8['sortBy'],_0x2be15a['size'],_0x5232e8[_0x53271f(_0x11dbb6._0x173477)]());_0xe87f07[_0x53271f(0x1fa)](_0x7a26d);}return _0xe87f07[_0x53271f(_0x11dbb6._0x4ded95)](function(_0x4c3f7d,_0x547c71){var _0x4aaa28=_0x53271f;if(_0x5232e8[_0x4aaa28(0x203)]==='size')return _0x547c71[_0x4aaa28(0x17c)]-_0x4c3f7d['sizeInMB'];else{if(_0x547c71[_0x4aaa28(_0x4b26f8._0x22c07f)]!==_0x4c3f7d[_0x4aaa28(0x1d0)])return _0x547c71[_0x4aaa28(0x1d0)]-_0x4c3f7d['qualityRank'];return _0x547c71[_0x4aaa28(0x17c)]-_0x4c3f7d[_0x4aaa28(_0x4b26f8._0x36671a)];}}),_0xe87f07[_0x53271f(0x1bc)](function(_0x24ae6d){var _0x3d9a5f=_0x53271f;return _0x24ae6d[_0x3d9a5f(0x173)];});});},AnimeZeyScraper[_0x281d9e(0x196)]['_extractPlayerUrl']=function(_0x558f77){var _0x4b6055={_0x3b6db6:0x1c9,_0x5c4cc4:0x1df,_0x58f497:0x15f,_0x4964f9:0x1d5,_0xe7c9a9:0x1be,_0x47fd23:0x15d,_0x37c9e5:0x1b3,_0x44771a:0x1b3,_0x1c05b0:0x1f6,_0x2d241a:0x1cb,_0x1e0711:0x204,_0x1ffdf8:0x199};return __async(this,null,function*(){var _0x317733=_0xc337,_0x829d94=_0x558f77[_0x317733(0x171)]||'';if(!_0x829d94)return null;if(_0x829d94[_0x317733(0x1be)]('/download.aspx'))return this['_buildDownloadLink'](_0x829d94);var _0x50026=this[_0x317733(_0x4b6055._0x3b6db6)][_0x317733(_0x4b6055._0x5c4cc4)];for(var _0x2ee8ee=0x0;_0x2ee8ee<_0x50026;_0x2ee8ee++){var _0xb1164d=this[_0x317733(_0x4b6055._0x58f497)](),_0x3e1a3c='https://'+_0xb1164d+_0x829d94;!_0x3e1a3c['includes'](_0x317733(_0x4b6055._0x4964f9))&&(_0x3e1a3c+=_0x3e1a3c[_0x317733(_0x4b6055._0xe7c9a9)]('?')?'&a=view':'?a=view');try{var _0x876768=yield fetchPlain(_0x3e1a3c,{'headers':{'User-Agent':this['sessionUA'],'Accept':'text/html,application/xhtml+xml','Accept-Language':_0x317733(_0x4b6055._0x47fd23),'Referer':_0x317733(0x1c1)+_0xb1164d+'/'}});if(_0x876768[_0x317733(_0x4b6055._0x37c9e5)]===0x1ad||_0x876768['status']>=0x1f4){console[_0x317733(0x1d9)]('['+PROVIDER_NAME+']\x20Extract\x20Player\x20URL\x20rate-limited\x20('+_0x876768[_0x317733(_0x4b6055._0x44771a)]+_0x317733(0x175)+_0xb1164d+_0x317733(_0x4b6055._0x1c05b0)),this[_0x317733(0x204)]();continue;}if(!_0x876768['ok']){this['_rotateWorkerDomain']();continue;}var _0x3d54c8=yield _0x876768[_0x317733(0x18f)](),_0x5bd54e=_0x3d54c8[_0x317733(_0x4b6055._0x2d241a)](/<source[^>]+src=["']([^"']+)["']/i);if(_0x5bd54e)return _0x5bd54e[0x1];break;}catch(_0x1755d4){this[_0x317733(_0x4b6055._0x1e0711)]();}}return this[_0x317733(_0x4b6055._0x1ffdf8)](_0x829d94);});},AnimeZeyScraper[_0x281d9e(0x196)]['_buildDownloadLink']=function(_0x49e4b8){var _0x1005f9={_0x3b6fb4:0x172,_0x27ccdd:0x168,_0x185632:0x16c,_0x4d202f:0x195},_0x3608e3={_0x475ccd:0x188},_0x17c5d2=_0x281d9e;if(!_0x49e4b8||_0x49e4b8['charAt'](0x0)!=='/')return null;try{var _0x24b068=_0x49e4b8[_0x17c5d2(_0x1005f9._0x3b6fb4)]('?'),_0xd3afb2=_0x24b068===-0x1?_0x49e4b8:_0x49e4b8[_0x17c5d2(0x168)](0x0,_0x24b068),_0x3b352a=_0x24b068===-0x1?'':_0x49e4b8[_0x17c5d2(_0x1005f9._0x27ccdd)](_0x24b068+0x1),_0x44c4f5=new URLSearchParams(_0x3b352a),_0x384c77=_0x44c4f5[_0x17c5d2(_0x1005f9._0x185632)](_0x17c5d2(_0x1005f9._0x4d202f));if(!_0x384c77)return null;var _0x2443f5=new URLSearchParams({'file':_0x384c77});return['expiry','mac']['forEach'](function(_0x527f09){var _0x4904b3=_0x17c5d2,_0xa8357a=_0x44c4f5['get'](_0x527f09);if(_0xa8357a)_0x2443f5[_0x4904b3(_0x3608e3._0x475ccd)](_0x527f09,_0xa8357a);}),'https://'+this['downloadDomain']+_0xd3afb2+'?'+_0x2443f5['toString']();}catch(_0x606579){return null;}};function getStreams(_0x4e19d1,_0x32bb49,_0x44faa2,_0x2ffa36,_0x9217bc){var _0x4222a5={_0x123223:0x1da,_0x57bb3e:0x15e,_0x4a0da7:0x1df,_0x3745e9:0x178,_0x1c09bc:0x1d8,_0x58c1ab:0x168,_0x58feca:0x160};return __async(this,null,function*(){var _0x5b5cbe=_0xc337;try{var _0x16595b=resolveSettings(_0x9217bc),_0x8e9e6e=MOBILE_UAS[Math[_0x5b5cbe(_0x4222a5._0x123223)](Math[_0x5b5cbe(_0x4222a5._0x57bb3e)]()*MOBILE_UAS[_0x5b5cbe(_0x4222a5._0x4a0da7)])],_0x365860=_0x32bb49===_0x5b5cbe(_0x4222a5._0x3745e9),_0x25918f=_0x32bb49==='tv'||_0x32bb49===_0x5b5cbe(0x1ec)||_0x32bb49==='tvshow';if(!_0x365860&&!_0x25918f)return[];var _0x10f61e=yield fetchTmdbDetails(_0x4e19d1,_0x365860?'movie':'tv',_0x8e9e6e);if(!_0x10f61e)return[];var _0x3d43e6=_0x365860?_0x10f61e[_0x5b5cbe(0x1e5)]:_0x10f61e[_0x5b5cbe(_0x4222a5._0x1c09bc)],_0x2d53a3=_0x365860?_0x10f61e[_0x5b5cbe(0x1a0)]:_0x10f61e['original_name'],_0x2d2ad9=_0x10f61e['release_date']||_0x10f61e['first_air_date']||'',_0x551052=_0x2d2ad9?parseInt(_0x2d2ad9[_0x5b5cbe(_0x4222a5._0x58c1ab)](0x0,0x4),0xa):null,_0x5e84d3={'tmdb_id':_0x4e19d1,'title':_0x3d43e6,'original_title':_0x2d53a3,'romaji_title':'','media_type':_0x365860?'movie':_0x5b5cbe(_0x4222a5._0x58feca),'year':_0x551052,'season':_0x44faa2,'episode':_0x2ffa36,'absolute_episode':!_0x365860&&_0x10f61e['seasons']?computeAbsoluteEpisode(_0x10f61e['seasons'],_0x44faa2,_0x2ffa36):null},_0x518c2b=new AnimeZeyScraper(WORKER_DOMAINS,_0x5e84d3,_0x8e9e6e,_0x16595b['sortBy']);return yield _0x518c2b['scrape']();}catch(_0x3a7444){return[];}});}typeof module!==_0x281d9e(0x1a9)&&module[_0x281d9e(0x1f9)]?module['exports']={'getStreams':getStreams,'onSettings':onSettings}:(global[_0x281d9e(0x16e)]=getStreams,global['onSettings']=onSettings);

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "animezey", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_PLAYIMDB_DISPLAY_START */
/* CLOUDBANK_PLAYIMDB_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  if (providerId === "playimdb") return provider; // Reference output stays exactly upstream.
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name) || (lines.length ? lines[0] : "");
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    var labelledAudio = /🌍\s*([^|\n]+)/.exec(originalTitle);
    if (!audioLang && labelledAudio) audioLang = language(labelledAudio[1]);
    var filenameAudio = /(?:^|[._ -])(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese)(?=[._ -]|$)/i.exec(clean(stream.fileName || stream.filename));
    if (!audioLang && filenameAudio) audioLang = language(filenameAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage)) || /\boriginal[- ]audio\b/i.test(text)) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    var labelledServer = /📌\s*([^|\n]+)/.exec(originalTitle);
    if (!server && labelledServer) server = usable(labelledServer[1]);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    var firstLine = lines.length ? "🎬 " + lines[0] : "";
    // Match PlayIMDb's original typography and order, without its guessed defaults.
    if (displayTitle) {
      firstLine = type === "tv" ? "🎬 " + usable(meta.title || meta.name) + " - S" + Number(season) + "E" + Number(episode) + (year ? " (" + year[0] + ")" : "") :
        "🎬 " + usable(meta.title || meta.name) + (year ? " - " + year[0] : "");
    }
    var qualityDisplay = qualityLabel === "4K" ? "2160P" : qualityLabel.toUpperCase();
    var audioDisplay = audioLabel.replace(/[- ]Audio/g, "").trim();
    var infoLine = [qualityDisplay ? "💎 " + qualityDisplay : "", audioDisplay ? "🌍 " + audioDisplay : ""].filter(Boolean).join(" | ");
    var bottomLine = [formatLabel ? "🎞️ " + (formatLabel === "HLS" ? "M3U8" : formatLabel) : "", duration ? "⏱️ " + duration : "", "📌 " + server].filter(Boolean).join(" | ");
    var nameQuality = qualityLabel === "4K" ? "4K UHD" : qualityLabel === "1080p" ? "1080p FHD" : qualityLabel === "720p" ? "720p HD" : qualityLabel;
    output.name = ["🟡 " + providerName, nameQuality, audioLabel ? audioLabel.replace(/ Audio/g, "-Audio") : ""].filter(Boolean).join(" | ");
    output.title = [firstLine, infoLine, bottomLine].filter(Boolean).join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "AnimeZeY", "animezey");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
/* CLOUDBANK_PLAYIMDB_DISPLAY_END */
