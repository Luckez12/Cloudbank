// Imported provider: allwish; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
const _0x2c2e6d=_0xf68e;(function(_0x4ca543,_0xddd23){const _0x5bb1b7=_0xf68e,_0x394889=_0x4ca543();while(!![]){try{const _0x3e0132=-parseInt(_0x5bb1b7(0x11f))/0x1+parseInt(_0x5bb1b7(0xb8))/0x2*(parseInt(_0x5bb1b7(0x150))/0x3)+-parseInt(_0x5bb1b7(0x14a))/0x4+parseInt(_0x5bb1b7(0xd0))/0x5*(-parseInt(_0x5bb1b7(0xba))/0x6)+parseInt(_0x5bb1b7(0x139))/0x7*(parseInt(_0x5bb1b7(0x13a))/0x8)+-parseInt(_0x5bb1b7(0xe4))/0x9*(-parseInt(_0x5bb1b7(0x111))/0xa)+-parseInt(_0x5bb1b7(0xf2))/0xb;if(_0x3e0132===_0xddd23)break;else _0x394889['push'](_0x394889['shift']());}catch(_0x55b124){_0x394889['push'](_0x394889['shift']());}}}(_0xc8f3,0xbd25a));var __defProp=Object[_0x2c2e6d(0xf8)],__defProps=Object['defineProperties'],__getOwnPropDescs=Object[_0x2c2e6d(0x104)],__getOwnPropSymbols=Object['getOwnPropertySymbols'],__hasOwnProp=Object[_0x2c2e6d(0xc9)][_0x2c2e6d(0xf5)],__propIsEnum=Object[_0x2c2e6d(0xc9)]['propertyIsEnumerable'],__defNormalProp=(_0xf040fc,_0x508bfd,_0xb4428b)=>_0x508bfd in _0xf040fc?__defProp(_0xf040fc,_0x508bfd,{'enumerable':!![],'configurable':!![],'writable':!![],'value':_0xb4428b}):_0xf040fc[_0x508bfd]=_0xb4428b,__spreadValues=(_0x195fe3,_0x36422a)=>{const _0x603060=_0x2c2e6d;for(var _0x2afa6d in _0x36422a||(_0x36422a={}))if(__hasOwnProp[_0x603060(0x120)](_0x36422a,_0x2afa6d))__defNormalProp(_0x195fe3,_0x2afa6d,_0x36422a[_0x2afa6d]);if(__getOwnPropSymbols)for(var _0x2afa6d of __getOwnPropSymbols(_0x36422a)){if(__propIsEnum[_0x603060(0x120)](_0x36422a,_0x2afa6d))__defNormalProp(_0x195fe3,_0x2afa6d,_0x36422a[_0x2afa6d]);}return _0x195fe3;},__spreadProps=(_0x340b78,_0xf3dbff)=>__defProps(_0x340b78,__getOwnPropDescs(_0xf3dbff)),__async=(_0x219ac4,_0x41e316,_0xe46133)=>{return new Promise((_0x466e92,_0x208718)=>{const _0x10d627=_0xf68e;var _0xafb8ed=_0x109bb2=>{const _0x57f0fe=_0xf68e;try{_0x2885fb(_0xe46133[_0x57f0fe(0x14c)](_0x109bb2));}catch(_0x251dae){_0x208718(_0x251dae);}},_0x40e3d4=_0x2e2e95=>{try{_0x2885fb(_0xe46133['throw'](_0x2e2e95));}catch(_0xd7854f){_0x208718(_0xd7854f);}},_0x2885fb=_0x39bb5e=>_0x39bb5e[_0x10d627(0xc0)]?_0x466e92(_0x39bb5e[_0x10d627(0xce)]):Promise[_0x10d627(0xf7)](_0x39bb5e[_0x10d627(0xce)])[_0x10d627(0xf0)](_0xafb8ed,_0x40e3d4);_0x2885fb((_0xe46133=_0xe46133[_0x10d627(0xe1)](_0x219ac4,_0x41e316))[_0x10d627(0x14c)]());});},cheerio=require(_0x2c2e6d(0xd8)),CryptoJS=require(_0x2c2e6d(0xcd)),PROVIDER_NAME=_0x2c2e6d(0xb6),MAIN_URL=_0x2c2e6d(0xe0),TMDB_API_KEY=_0x2c2e6d(0xca),REQUEST_TIMEOUT=0x2ee0,EPISODE_LIST_TIMEOUT=0x7530,VRF_SECRET='ysJhV6U27FVIjjuk',HEADERS={'User-Agent':_0x2c2e6d(0xd6),'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8','Accept-Language':_0x2c2e6d(0x14e),'Connection':'keep-alive'},AJAX_HEADERS={'X-Requested-With':_0x2c2e6d(0x122),'User-Agent':HEADERS[_0x2c2e6d(0xc4)],'Referer':MAIN_URL+'/'};function fetchSafe(_0x15767a){return __async(this,arguments,function*(_0x4eff9c,_0x133c67={},_0x1f22fb=REQUEST_TIMEOUT){const _0x2d55b7=_0xf68e;try{const _0x25091a=typeof AbortSignal!==_0x2d55b7(0x105)&&AbortSignal[_0x2d55b7(0x125)]?AbortSignal[_0x2d55b7(0x125)](_0x1f22fb):null,_0xb2382a=__spreadProps(__spreadValues({},_0x133c67),{'headers':__spreadValues(__spreadValues({},HEADERS),_0x133c67['headers']||{})});if(_0x25091a)_0xb2382a[_0x2d55b7(0xb4)]=_0x25091a;const _0x398ba0=yield fetch(_0x4eff9c,_0xb2382a);return _0x398ba0;}catch(_0x311219){return console[_0x2d55b7(0x141)]('['+PROVIDER_NAME+_0x2d55b7(0x15d)+(_0x4eff9c||'')['substring'](0x0,0x64)+_0x2d55b7(0x148)+_0x311219[_0x2d55b7(0x118)]),null;}});}function fetchJson(_0x2f2610){return __async(this,arguments,function*(_0x23b0a9,_0x2891d4={},_0xe7baa3){const _0x3af8e8=_0xf68e;try{const _0xbfebbd=yield fetchSafe(_0x23b0a9,_0x2891d4,_0xe7baa3);if(!_0xbfebbd||!_0xbfebbd['ok'])return null;return JSON['parse'](yield _0xbfebbd[_0x3af8e8(0x16b)]());}catch(_0xc6bce2){return console[_0x3af8e8(0x141)]('['+PROVIDER_NAME+_0x3af8e8(0xff)+(_0x23b0a9||'')['substring'](0x0,0x64)+_0x3af8e8(0x148)+_0xc6bce2['message']),null;}});}function fetchHtml(_0x4ba983){return __async(this,arguments,function*(_0x1c1995,_0x39dff0={}){const _0x5acee7=_0xf68e;try{const _0x220ea2=yield fetchSafe(_0x1c1995,_0x39dff0);if(!_0x220ea2||!_0x220ea2['ok'])return null;return cheerio[_0x5acee7(0x12c)](yield _0x220ea2[_0x5acee7(0x16b)]());}catch(_0x4f4772){return console[_0x5acee7(0x141)]('['+PROVIDER_NAME+']\x20fetchHtml:\x20'+(_0x1c1995||'')[_0x5acee7(0xfc)](0x0,0x64)+'\x20->\x20'+_0x4f4772[_0x5acee7(0x118)]),null;}});}function makeStream(_0x246b71,_0x3bde92,_0x2bc1c1,_0x2c99fc,_0x32fc65={},_0x590048){const _0x231fb6=_0x2c2e6d,_0x2c7d70={'name':PROVIDER_NAME+_0x231fb6(0x14d)+_0x246b71,'title':_0x3bde92||'','url':_0x2bc1c1||'','quality':_0x2c99fc||'HD','headers':__spreadValues({'User-Agent':HEADERS[_0x231fb6(0xc4)]},_0x32fc65||{})};return _0x590048&&Array[_0x231fb6(0x102)](_0x590048)&&_0x590048[_0x231fb6(0xbd)]>0x0&&(_0x2c7d70[_0x231fb6(0xd1)]=_0x590048),_0x2c7d70;}function buildStreamLabels(_0x3df22d,_0x35b9ed,_0x14d38d,_0x2df68b){const _0x547b87=_0x2c2e6d,_0x12e808=_0x35b9ed||'HD',_0xf356ee=_0x12e808+(_0x14d38d?'\x20'+_0x14d38d:'');let _0x5b58b1='';return _0x2df68b&&_0x2df68b[_0x547b87(0x152)]?_0x2df68b[_0x547b87(0x10f)]==='tv'&&_0x2df68b[_0x547b87(0x132)]!=null&&_0x2df68b[_0x547b87(0xf3)]!=null?_0x5b58b1=_0x2df68b[_0x547b87(0x152)]+'\x0aS'+_0x2df68b[_0x547b87(0x132)]+'\x20E'+_0x2df68b[_0x547b87(0xf3)]+_0x547b87(0xee)+_0x12e808+_0x547b87(0xfe):_0x5b58b1=_0x2df68b[_0x547b87(0x152)]+'\x0a'+_0x12e808+'\x20·\x20HLS':_0x5b58b1=_0x3df22d+(_0x14d38d?'\x20'+_0x14d38d:'')+'\x0a'+_0x12e808+_0x547b87(0xfe),_0x5b58b1+=_0x547b87(0x163),{'name':_0xf356ee,'title':_0x5b58b1};}function dedupe(_0x31838e){const _0x593d3d=_0x2c2e6d,_0x20b6f3=new Set();return(_0x31838e||[])[_0x593d3d(0x137)](_0x5eb7a7=>{const _0x5ac165=_0x593d3d;if(!_0x5eb7a7||!_0x5eb7a7['url']||_0x20b6f3['has'](_0x5eb7a7['url']))return![];return _0x20b6f3['add'](_0x5eb7a7[_0x5ac165(0xc3)]),!![];});}function getTMDBInfo(_0x523e8a,_0x416b94){return __async(this,null,function*(){const _0x5edb60=_0xf68e,_0x41131c=String(_0x523e8a||'')[_0x5edb60(0x12a)](),_0x4473d9=_0x41131c[_0x5edb60(0x12b)]('tt'),_0x369740=_0x416b94==='tv'||_0x416b94===_0x5edb60(0x10b)?'tv':'movie';try{if(_0x4473d9){const _0x52cc96=yield fetchJson(_0x5edb60(0x161)+_0x41131c+_0x5edb60(0xd5)+TMDB_API_KEY+_0x5edb60(0xbf)),_0x502ac2=_0x52cc96?_0x369740==='tv'?_0x52cc96[_0x5edb60(0x168)]:_0x52cc96[_0x5edb60(0x164)]:null;if(_0x502ac2&&_0x502ac2[_0x5edb60(0xbd)]>0x0){const _0x876064=_0x502ac2[0x0];return{'id':_0x876064['id'],'title':_0x369740==='tv'?_0x876064['name']:_0x876064['title'],'originalTitle':_0x369740==='tv'?_0x876064[_0x5edb60(0x143)]:_0x876064[_0x5edb60(0x167)],'year':(_0x876064[_0x5edb60(0x15f)]||_0x876064[_0x5edb60(0xe2)]||'')[_0x5edb60(0xc7)]('-')[0x0],'genres':_0x876064[_0x5edb60(0x117)]||[],'imdbId':_0x41131c};}return{'id':_0x41131c,'title':_0x41131c,'originalTitle':_0x41131c,'year':null,'genres':[],'imdbId':_0x41131c};}else{const _0x1854ed=yield fetchJson('https://api.themoviedb.org/3/'+_0x369740+'/'+_0x41131c+_0x5edb60(0xd5)+TMDB_API_KEY+_0x5edb60(0xcb));if(_0x1854ed)return{'id':_0x1854ed['id'],'title':_0x369740==='tv'?_0x1854ed[_0x5edb60(0xc6)]:_0x1854ed[_0x5edb60(0x152)],'originalTitle':_0x369740==='tv'?_0x1854ed[_0x5edb60(0x143)]:_0x1854ed[_0x5edb60(0x167)],'year':(_0x1854ed[_0x5edb60(0x15f)]||_0x1854ed[_0x5edb60(0xe2)]||'')['split']('-')[0x0],'genres':(_0x1854ed[_0x5edb60(0xf4)]||[])['map'](_0x2e3aec=>_0x2e3aec['id']),'imdbId':_0x1854ed[_0x5edb60(0x145)]||_0x1854ed[_0x5edb60(0x162)]&&_0x1854ed[_0x5edb60(0x162)]['imdb_id']||null};}}catch(_0x2316be){console[_0x5edb60(0x141)]('['+PROVIDER_NAME+_0x5edb60(0x155)+_0x2316be['message']);}return{'id':_0x41131c,'title':_0x41131c,'originalTitle':_0x41131c,'year':null,'genres':[],'imdbId':null};});}function cleanTitle(_0x545905){const _0x5c1a86=_0x2c2e6d;return String(_0x545905||'')[_0x5c1a86(0x15a)]()[_0x5c1a86(0xb1)](/[^a-z0-9\s]/g,'\x20')[_0x5c1a86(0xb1)](/\s+/g,'\x20')[_0x5c1a86(0x12a)]();}function tokenize(_0x5aaef7){const _0x3af422=_0x2c2e6d;return cleanTitle(_0x5aaef7)[_0x3af422(0xc7)]('\x20')[_0x3af422(0x137)](Boolean);}function scoreTitle(_0x5ac27f,_0x2031c5,_0x51e3fb,_0x19557d){const _0x1816d0=_0x2c2e6d,_0x164ee7=tokenize(_0x2031c5);if(!_0x164ee7[_0x1816d0(0xbd)])return 0x0;const _0x577656=new Set(tokenize(_0x5ac27f)),_0x1cc5bd=cleanTitle(_0x5ac27f),_0x540e1e=cleanTitle(_0x2031c5),_0x221b24=tokenize(_0x5ac27f);if(_0x1cc5bd===_0x540e1e)return 1.5;const _0x38251a=_0x1cc5bd[_0x1816d0(0xb1)](/\s+tv$/,'')[_0x1816d0(0xb1)](/\s+movie$/,'')['replace'](/\s+anime$/,'')[_0x1816d0(0xb1)](/\s+specials?$/,'')[_0x1816d0(0x12a)]();if(_0x38251a===_0x540e1e)return 1.4;let _0x5d2e9d=0x0;for(const _0x233736 of _0x164ee7){if(_0x577656[_0x1816d0(0x106)](_0x233736))_0x5d2e9d++;}let _0x27db1c=_0x5d2e9d/Math[_0x1816d0(0xed)](_0x164ee7['length'],0x1);if(_0x1cc5bd['startsWith'](_0x540e1e)){_0x27db1c+=0.3;const _0x179f6f=_0x221b24[_0x1816d0(0xbd)]-_0x164ee7[_0x1816d0(0xbd)];_0x179f6f>0x2&&(_0x27db1c-=Math['min'](_0x179f6f*0.1,0.4));const _0x12bcb0=['part',_0x1816d0(0x129),_0x1816d0(0x132),_0x1816d0(0x112),_0x1816d0(0x12d),'special',_0x1816d0(0x12f),_0x1816d0(0x159),_0x1816d0(0x123),'films',_0x1816d0(0xe7)],_0x929984=_0x221b24[_0x1816d0(0xb9)](_0x164ee7[_0x1816d0(0xbd)])['filter'](_0x4c4c16=>_0x12bcb0[_0x1816d0(0xe9)](_0x4c4c16))[_0x1816d0(0xbd)];if(_0x929984>0x0)_0x27db1c-=0.2;}else _0x164ee7[_0x1816d0(0xbd)]<=0x4&&_0x5d2e9d===_0x164ee7[_0x1816d0(0xbd)]&&(_0x27db1c-=0.4);if(_0x51e3fb){const _0x22c22f=/\b(19|20)\d{2}\b/,_0x5ac534=_0x1cc5bd[_0x1816d0(0x13b)](_0x22c22f);if(_0x5ac534&&Math[_0x1816d0(0x100)](parseInt(_0x5ac534[0x0])-parseInt(_0x51e3fb))<=0x1)_0x27db1c+=0.5;else{if(_0x5ac534){const _0x2edd5f=Math[_0x1816d0(0x100)](parseInt(_0x5ac534[0x0])-parseInt(_0x51e3fb));_0x27db1c-=Math[_0x1816d0(0x110)](_0x2edd5f*0.1,0.8);}}}if(_0x19557d&&Number(_0x19557d)>0x1){const _0x4de336=Number(_0x19557d),_0x45ebf1=_0x1cc5bd[_0x1816d0(0x13b)](new RegExp('\x5cb'+_0x4de336+_0x1816d0(0x10a)+_0x4de336+'|\x5cbpart\x5cs*'+_0x4de336,'i'));if(_0x45ebf1)_0x27db1c+=0.4;else{const _0x5b2feb=_0x1cc5bd[_0x1816d0(0x13b)](/\b(?:season|part)\s*\d+/i);!_0x5b2feb&&(_0x27db1c-=0.3);}}return Math['min'](_0x27db1c,0x2);}function searchAllWish(_0xcfe9eb,_0x4466f7,_0x5abccc,_0x37043e){return __async(this,null,function*(){const _0xfe3060=_0xf68e;try{const _0x12bc75=[];if(_0xcfe9eb)_0x12bc75[_0xfe3060(0x154)](_0xcfe9eb);if(_0x4466f7&&_0x4466f7!==_0xcfe9eb)_0x12bc75[_0xfe3060(0x154)](_0x4466f7);if(_0x37043e&&Number(_0x37043e)>0x1){const _0x450227=Number(_0x37043e);_0xcfe9eb&&(_0x12bc75[_0xfe3060(0x154)](_0xcfe9eb+'\x20'+_0x450227),_0x12bc75[_0xfe3060(0x154)](_0xcfe9eb+_0xfe3060(0x108)+_0x450227));}const _0x48b11c=[];for(const _0x298c4f of _0x12bc75){const _0x4f1184=yield fetchHtml(MAIN_URL+'/filter?keyword='+encodeURIComponent(_0x298c4f)+_0xfe3060(0x121));if(!_0x4f1184)continue;_0x4f1184(_0xfe3060(0xea))[_0xfe3060(0xeb)]((_0x488885,_0x3d3f72)=>{const _0x47ae3c=_0xfe3060,_0x615fd8=_0x4f1184(_0x3d3f72)['find'](_0x47ae3c(0xdd))[_0x47ae3c(0x16b)]()[_0x47ae3c(0x12a)](),_0x3ec04a=_0x4f1184(_0x3d3f72)['find'](_0x47ae3c(0xdd))['attr'](_0x47ae3c(0x127));if(_0x615fd8&&_0x3ec04a){const _0x2c56c2=_0x3ec04a['replace'](/\/ep-\d+\/?$/i,'');_0x48b11c['push']({'title':_0x615fd8,'watchUrl':_0x2c56c2,'query':_0x298c4f});}});if(_0x48b11c[_0xfe3060(0xbd)]>0x0)break;}if(_0x48b11c[_0xfe3060(0xbd)]===0x0)return null;let _0x285339=null,_0x4f2bf7=-0x1;for(const _0x128c8a of _0x48b11c){const _0xdf55be=scoreTitle(_0x128c8a['title'],_0xcfe9eb||'',_0x5abccc||null,_0x37043e),_0x4f1667=_0x4466f7?scoreTitle(_0x128c8a['title'],_0x4466f7,_0x5abccc||null,_0x37043e):0x0,_0x444d38=Math[_0xfe3060(0xed)](_0xdf55be,_0x4f1667);_0x444d38>_0x4f2bf7&&(_0x4f2bf7=_0x444d38,_0x285339=_0x128c8a);}if(_0x4f2bf7<0.3)return console[_0xfe3060(0xaf)]('['+PROVIDER_NAME+']\x20Title\x20match\x20score\x20too\x20low:\x20'+_0x4f2bf7),null;return console[_0xfe3060(0xaf)]('['+PROVIDER_NAME+']\x20Best\x20match:\x20\x22'+_0x285339[_0xfe3060(0x152)]+'\x22\x20score='+_0x4f2bf7['toFixed'](0x2)),_0x285339;}catch(_0x15088a){return console['error']('['+PROVIDER_NAME+']\x20Search\x20error:\x20'+_0x15088a['message']),null;}});}function _0xf68e(_0x4a0a32,_0x16cf48){_0x4a0a32=_0x4a0a32-0xaf;const _0xc8f35=_0xc8f3();let _0xf68ece=_0xc8f35[_0x4a0a32];if(_0xf68e['ajTpux']===undefined){var _0x37bb49=function(_0x2aae78){const _0x146320='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0xf040fc='',_0x508bfd='';for(let _0xb4428b=0x0,_0x195fe3,_0x36422a,_0x2afa6d=0x0;_0x36422a=_0x2aae78['charAt'](_0x2afa6d++);~_0x36422a&&(_0x195fe3=_0xb4428b%0x4?_0x195fe3*0x40+_0x36422a:_0x36422a,_0xb4428b++%0x4)?_0xf040fc+=String['fromCharCode'](0xff&_0x195fe3>>(-0x2*_0xb4428b&0x6)):0x0){_0x36422a=_0x146320['indexOf'](_0x36422a);}for(let _0x340b78=0x0,_0xf3dbff=_0xf040fc['length'];_0x340b78<_0xf3dbff;_0x340b78++){_0x508bfd+='%'+('00'+_0xf040fc['charCodeAt'](_0x340b78)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x508bfd);};_0xf68e['bHDnhD']=_0x37bb49,_0xf68e['uTitBd']={},_0xf68e['ajTpux']=!![];}const _0x36a987=_0xc8f35[0x0],_0x38cdcf=_0x4a0a32+_0x36a987,_0x43618b=_0xf68e['uTitBd'][_0x38cdcf];return!_0x43618b?(_0xf68ece=_0xf68e['bHDnhD'](_0xf68ece),_0xf68e['uTitBd'][_0x38cdcf]=_0xf68ece):_0xf68ece=_0x43618b,_0xf68ece;}function _0xc8f3(){const _0x496e78=['AxnbCNjHEq','zgL2lNnLCNzLCI10ExbL','z2v0t3DUuhjVCgvYDhLezxnJCMLWDg9YCW','Dw5KzwzPBMvK','AgfZ','i21Lz2fWBgf5lxbSyxLLCG','ihnLyxnVBIa','zMLSzq','kd86C3r8BMr8CMr8DgGPxhmRC2vHC29UFhnLyxnVBLXZkG','C2vYAwvZ','CgfYC2u','zgf0ys1Pzhm','q0jd','BwvKAwfuExbL','BwLU','mJi5mfnwvvLjuq','Bw92Awu','xsbfCgLZB2rLigXPC3qGzMfPBgvK','l2fQyxGVC2vYDMvYp2DLDd0','xsbszxr1CM5PBMCG','Dg9tDhjPBMC','z2vUCMvFAwrZ','BwvZC2fNzq','z2v0','zgf0ys10ExbL','Ahr0Chm6lY9TzwDHCgXHEs5IDxP6','Bw9Kzq','D2f0y2HvCMW','sc1tDwi','mJa2nty5y2Tqs2nr','y2fSBa','jNbHz2u9mq','we1mshr0CfjLCxvLC3q','zMLSBq','B3jPz2LUywXuAxrSzq','DgLTzw91Da','zMXHDa','AhjLzG','w0r1yL0','CgfYDhm','DhjPBq','C3rHCNrZv2L0Aa','Bg9Hza','Bw92AwvZ','jtiW','C3bLy2LHBhm','p3zYzJ0','zgf0ys1KDwi','C2vHC29U','zgL2lNnLCNzLCI1SAxn0id4GzgL2lNnLCNzLCG','CMvZDwX0','Ahr0Chm6lY9TzwDHCgXHEs5IDxP6lW','iIaO','zMLSDgvY','ifm9','n2vJt0jRDa','mtG5ntG5nLPvDMXKta','Bwf0y2G','zMLUza','zxHWB3j0CW','CxvHBgL0Eq','xsbszxnVBhzLzdOGiG','zhvI','zxjYB3i','xsbAzw4GzxjYB3i6ia','B3jPz2LUywXFBMfTzq','mta4mha','Aw1KyL9Pza','C2vJDgLVBLr5Cgu','xsbtzwXLy3rLzcbLCgLZB2rLihnSDwC9','ic0+ia','AgfZu3vI','ntu1mZeYz2vjuM1i','C29YDa','BMv4Da','ihWG','zw4TvvmSzw47Ct0WlJu','AgfZrhvI','mtG2ndC0DuDfvg94','tI9b','DgL0Bgu','vw5RBM93BG','ChvZAa','xsbuturcigvYCM9YoIa','C3vI','zgf0ys1Pza','l2fQyxGVC2vYDMvYl2XPC3q/C2vYDMvYCZ0','B3zH','Dg9mB3DLCKnHC2u','zgf0ys1SAw5RlwLK','EwvHCG','xsbMzxrJAfnHzMu6ia','quvt','zMLYC3rFywLYx2rHDgu','jMLKpq','Ahr0Chm6lY9HCgKUDgHLBw92AwvKyI5VCMCVmY9MAw5KlW','zxH0zxjUywXFAwrZ','cMj5ihbPCMf0zxPVCM85','Bw92AwvFCMvZDwX0CW','xsboBYbZAg93ieLeigzVDw5K','BgfIzwW','B3jPz2LUywXFDgL0Bgu','DhzFCMvZDwX0CW','ieu9','BgfUz3vHz2u','Dgv4Da','Bg9N','igLKCZ0','CMvWBgfJzq','xsboBYbuturcigrHDge','xsbgyxrHBdOG','C2LNBMfS','ksWGCMvQzwn0Aw5N','qwXSv2LZAa','l2fQyxGVzxbPC29Kzs9SAxn0lW','mZrVyKTTBgy','C2XPy2u','nNfLEgzwAW','zNjVBq','ihn0CMvHBxm','BgvUz3rO','Ahr0Chm6lY9TzwDHCgXHEs5IDxP6l3n0CMvHBs9NzxrtB3vYy2vZp2LKpq','jMv4DgvYBMfSx3nVDxjJzt1PBwrIx2LK','zg9Uzq','zNjVBunOyxjdB2rL','C291CMnLCW','DxjS','vxnLCI1bz2vUDa','zgvJCNLWDa','BMfTzq','C3bSAxq','ugTJCZC','ChjVDg90ExbL','ndm5yZq3oge3nZfMmZvJmduWmJjMowzLywjJy2eWmwm','jMfWCgvUzf90B19YzxnWB25Zzt1LEhrLCM5HBf9Pzhm','zgL2lNjHBMDLid4GzgL2id4Gyq','y3j5ChrVlwPZ','DMfSDwu','xsboB3qGyw5PBwuGkgDLBNjLCZOG','mtu5mZaZnuneCeTWBW','C3vIDgL0BgvZ','zgf0ys1TywW','C2X1zW','vxrMoa','p2fWAv9RzxK9','tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlZeZms4WlJaUmcbtywzHCMKVntm3lJm2','BwfW','y2HLzxjPBY13AxrOB3v0lw5VzguTBMf0AxzL','zw5J','AM9PBG','xsbnzwDHugXHEsbLCNjVCJOG','qMfZzty0','zgL2lM5HBwuGpIbH','xsboBYbTyxrJAcbVBIbbBgXxAxnO','w0HHCMqGu3vIxq','Ahr0Chm6lY9HBgWTD2LZAc5Tzq','yxbWBhK','CMvSzwfZzv9KyxrL','Ahr0Chm6lY9WBgf5zxiUC2DZz3nNC3iUC2L0zs8','nJaZodfsDK1PueK','y2HHCKnVzgvbDa','DgvZDa','DgHL','zMLYC3q','Aw5JBhvKzxm','zgL2lML0zw0','zwfJAa','ywXS','Bwf4','imk3ia','A2LUza','DgHLBG','yxr0CG','mtuZmdqXmJr4CMrss04','zxbPC29Kzq','z2vUCMvZ','AgfZt3DUuhjVCgvYDhK','C3bHBG','CMvZB2X2zq','zgvMAw5LuhjVCgvYDhK','z2v0u3rYzwfTCW','w1n1yL0','CgfK','C3vIC3rYAw5N','xsbtzxj2zxiGCMvZB2X2zsbLCNjVCJOG','imk3ieHmuW','xsbMzxrJAePZB246ia','ywjZ','zgf0ys1ZDwi'];_0xc8f3=function(){return _0x496e78;};return _0xc8f3();}function generateEpisodeVrf(_0x500214){const _0xbed82f=_0x2c2e6d,_0x3cf55b=encodeURIComponent(_0x500214)[_0xbed82f(0xb1)](/%21/g,'!')[_0xbed82f(0xb1)](/%27/g,'\x27')['replace'](/%28/g,'(')[_0xbed82f(0xb1)](/%29/g,')')[_0xbed82f(0xb1)](/%7E/g,'~')[_0xbed82f(0xb1)](/%2A/g,'*')[_0xbed82f(0xb1)](/%20/g,_0xbed82f(0x12e)),_0x5087b8=Array['from'](VRF_SECRET)[_0xbed82f(0xd7)](_0x2d8d67=>_0x2d8d67[_0xbed82f(0xe5)](0x0)),_0x5c0b22=Array[_0xbed82f(0xbb)](_0x3cf55b)[_0xbed82f(0xd7)](_0x2f55e2=>_0x2f55e2[_0xbed82f(0xe5)](0x0)),_0x7caec5=Array[_0xbed82f(0xbb)]({'length':0x100},(_0x59ecf9,_0x2d9a50)=>_0x2d9a50);let _0x2ea21d=0x0;for(let _0x4e714d=0x0;_0x4e714d<=0xff;_0x4e714d++){_0x2ea21d=(_0x2ea21d+_0x7caec5[_0x4e714d]+_0x5087b8[_0x4e714d%_0x5087b8[_0xbed82f(0xbd)]])%0x100,[_0x7caec5[_0x4e714d],_0x7caec5[_0x2ea21d]]=[_0x7caec5[_0x2ea21d],_0x7caec5[_0x4e714d]];}const _0x4527aa=[];let _0xd982fb=0x0;_0x2ea21d=0x0;for(let _0x2ad2d8=0x0;_0x2ad2d8<_0x5c0b22['length'];_0x2ad2d8++){_0xd982fb=(_0xd982fb+0x1)%0x100,_0x2ea21d=(_0x2ea21d+_0x7caec5[_0xd982fb])%0x100,[_0x7caec5[_0xd982fb],_0x7caec5[_0x2ea21d]]=[_0x7caec5[_0x2ea21d],_0x7caec5[_0xd982fb]];const _0x11dff5=_0x7caec5[(_0x7caec5[_0xd982fb]+_0x7caec5[_0x2ea21d])%0x100];_0x4527aa[_0xbed82f(0x154)]((_0x5c0b22[_0x2ad2d8]^_0x11dff5)&0xff);}function _0x2eb1b3(_0x3e39b4){const _0x166389=_0xbed82f;let _0x1bc6de='';for(const _0x44dc53 of _0x3e39b4)_0x1bc6de+=String[_0x166389(0xc1)](_0x44dc53);return btoa(_0x1bc6de)[_0x166389(0xb1)](/\+/g,'-')['replace'](/\//g,'_')[_0x166389(0xb1)](/=+$/,'');}const _0xf4ec51=_0x2eb1b3(_0x4527aa),_0x2e33b5={0x0:-0x3,0x1:0x3,0x2:-0x4,0x3:0x2,0x4:-0x2,0x5:0x5,0x6:0x4,0x7:0x5},_0x7602ab=Array[_0xbed82f(0xbb)](_0xf4ec51)[_0xbed82f(0xd7)]((_0x11995f,_0x14904d)=>{const _0x33acd6=_0xbed82f;let _0x33bdb9=_0x11995f[_0x33acd6(0xe5)](0x0);return _0x33bdb9+=_0x2e33b5[_0x14904d%0x8]||0x0,_0x33bdb9&0xff;}),_0x3beaf3=_0x2eb1b3(_0x7602ab),_0x48d4ed=_0x11f4f3=>{const _0x4d4a03=_0xbed82f;if(_0x11f4f3>='A'&&_0x11f4f3<='Z')return String[_0x4d4a03(0xc1)]((_0x11f4f3['charCodeAt'](0x0)-0x41+0xd)%0x1a+0x41);if(_0x11f4f3>='a'&&_0x11f4f3<='z')return String['fromCharCode']((_0x11f4f3[_0x4d4a03(0xe5)](0x0)-0x61+0xd)%0x1a+0x61);return _0x11f4f3;};return Array[_0xbed82f(0xbb)](_0x3beaf3)[_0xbed82f(0xd7)](_0x48d4ed)[_0xbed82f(0xda)]('');}function chooseEpisode(_0x4a666d,_0x86455f,_0x4cb2f9,_0x20af93){const _0x509d1a=_0x2c2e6d,_0x21189a=_0x4a666d(_0x509d1a(0xcc))[_0x509d1a(0xd7)]((_0x400f86,_0x361b54)=>({'slug':parseInt(_0x4a666d(_0x361b54)['attr']('data-slug')||'0',0xa),'ids':_0x4a666d(_0x361b54)[_0x509d1a(0xf1)](_0x509d1a(0x10d))||'','hasSub':_0x4a666d(_0x361b54)[_0x509d1a(0xf1)](_0x509d1a(0x101))==='1','hasDub':_0x4a666d(_0x361b54)[_0x509d1a(0xf1)](_0x509d1a(0x131))==='1','malId':_0x4a666d(_0x361b54)[_0x509d1a(0xf1)]('data-mal')?parseInt(_0x4a666d(_0x361b54)['attr'](_0x509d1a(0xd2)),0xa):null}))[_0x509d1a(0x119)]()['filter'](_0x542e9e=>_0x542e9e['ids']);if(!_0x21189a['length'])return null;if(_0x20af93===_0x509d1a(0x112)||_0x4cb2f9==null)return _0x21189a[0x0];const _0x59e568=Number(_0x4cb2f9);return _0x21189a[_0x509d1a(0x13c)](_0x84cfa4=>_0x84cfa4[_0x509d1a(0xd3)]===_0x59e568)||null;}function extractMegaPlay(_0x122ebf,_0x4f95d5,_0x39d6a5){return __async(this,null,function*(){const _0x3adb51=_0xf68e;try{const _0x4e91f8=yield fetchSafe(_0x122ebf,{'headers':__spreadProps(__spreadValues({},HEADERS),{'X-Requested-With':'XMLHttpRequest','Referer':'https://megaplay.buzz/'})});if(!_0x4e91f8)return[];const _0x6d1a54=cheerio[_0x3adb51(0x12c)](yield _0x4e91f8[_0x3adb51(0x16b)]()),_0x5645d5=_0x6d1a54(_0x3adb51(0x107))[_0x3adb51(0xf1)](_0x3adb51(0x157));if(!_0x5645d5)return[];const _0x1a0258=yield fetchJson(_0x3adb51(0xbe)+_0x5645d5+_0x3adb51(0x160)+_0x5645d5,{'headers':__spreadProps(__spreadValues({},HEADERS),{'X-Requested-With':_0x3adb51(0x122),'Referer':_0x3adb51(0x135)})});if(!_0x1a0258||!_0x1a0258[_0x3adb51(0xc2)]||!_0x1a0258[_0x3adb51(0xc2)][_0x3adb51(0x109)])return[];const _0x3b0f5b=(_0x1a0258['tracks']||[])['filter'](_0x461d13=>_0x461d13['kind']==='captions'||_0x461d13[_0x3adb51(0xef)]===_0x3adb51(0xd1))[_0x3adb51(0xd7)](_0x284a1e=>({'label':_0x284a1e[_0x3adb51(0x166)]||_0x3adb51(0x153),'url':_0x284a1e[_0x3adb51(0x109)]}))[_0x3adb51(0x137)](_0x3369a8=>_0x3369a8[_0x3adb51(0xc3)]),_0x48a5ab=buildStreamLabels('MegaPlay',_0x3adb51(0x144),_0x4f95d5,_0x39d6a5);return[makeStream(_0x48a5ab[_0x3adb51(0xc6)],_0x48a5ab[_0x3adb51(0x152)],_0x1a0258[_0x3adb51(0xc2)][_0x3adb51(0x109)],'1080p',{'Referer':_0x3adb51(0x135),'Origin':_0x3adb51(0x11b),'User-Agent':HEADERS['User-Agent']},_0x3b0f5b[_0x3adb51(0xbd)]>0x0?_0x3b0f5b:void 0x0)];}catch(_0x2ef7ac){return console['error']('['+PROVIDER_NAME+_0x3adb51(0xdb)+_0x2ef7ac['message']),[];}});}function extractZen(_0x5d78a6,_0x33d978,_0x56adb3){return __async(this,null,function*(){const _0x11d295=_0xf68e;try{const _0x37de36=yield fetchSafe(_0x5d78a6,{'headers':HEADERS});if(!_0x37de36)return[];const _0x2cde77=yield _0x37de36[_0x11d295(0x16b)](),_0x267dd3=_0x2cde77[_0x11d295(0x13b)](/video_b64:\s*"([^"]+)"/),_0x4990a6=_0x2cde77[_0x11d295(0x13b)](/enc_key_b64:\s*"([^"]+)"/),_0x1ad258=_0x2cde77[_0x11d295(0x13b)](/iv_b64:\s*"([^"]+)"/),_0x5f3fd8=_0x2cde77[_0x11d295(0x13b)](/subtitles:\s*"([^"]*)"/);if(!_0x267dd3||!_0x4990a6||!_0x1ad258)return[];const _0x4087e8=_0x267dd3[0x1],_0x5a3e9b=_0x4990a6[0x1],_0x12dba7=_0x1ad258[0x1],_0x2cbb74=CryptoJS[_0x11d295(0xd9)]['Base64'][_0x11d295(0x10c)](_0x5a3e9b),_0x514354=CryptoJS[_0x11d295(0xd9)][_0x11d295(0xdc)]['parse'](_0x12dba7),_0x1d3aa9=CryptoJS[_0x11d295(0xd9)][_0x11d295(0xdc)]['parse'](_0x4087e8),_0x13bc80=CryptoJS[_0x11d295(0x15e)][_0x11d295(0xc5)]({'ciphertext':_0x1d3aa9},_0x2cbb74,{'iv':_0x514354,'mode':CryptoJS[_0x11d295(0x11c)][_0x11d295(0x10e)],'padding':CryptoJS[_0x11d295(0xfb)][_0x11d295(0xc8)]}),_0x3e33ec=_0x13bc80[_0x11d295(0x116)](CryptoJS['enc'][_0x11d295(0xd4)]);if(!_0x3e33ec)return[];let _0x40c735=[];if(_0x5f3fd8&&_0x5f3fd8[0x1])try{const _0xada49a=_0x5f3fd8[0x1][_0x11d295(0xb1)](/\\"/g,'\x22')[_0x11d295(0xb1)](/\\\\\//g,'/')[_0x11d295(0xb1)](/\\u([0-9a-fA-F]{4})/g,(_0x2973d5,_0x3a2a95)=>String[_0x11d295(0xc1)](parseInt(_0x3a2a95,0x10))),_0x3930df=JSON[_0x11d295(0x10c)](_0xada49a);Array['isArray'](_0x3930df)&&(_0x40c735=_0x3930df['filter'](_0x373e47=>_0x373e47[_0x11d295(0xc3)])['map'](_0x4d1eaa=>({'label':_0x4d1eaa[_0x11d295(0x16a)]||_0x11d295(0x153),'url':_0x4d1eaa[_0x11d295(0xc3)]})));}catch(_0x58cabb){}const _0x486464=buildStreamLabels('Zen',_0x11d295(0x144),_0x33d978,_0x56adb3);return[makeStream(_0x486464[_0x11d295(0xc6)],_0x486464[_0x11d295(0x152)],_0x3e33ec[_0x11d295(0x12a)](),_0x11d295(0x144),{'Referer':_0x11d295(0xe3),'Origin':_0x11d295(0xe3)},_0x40c735['length']>0x0?_0x40c735:void 0x0)];}catch(_0x355be7){return console[_0x11d295(0x141)]('['+PROVIDER_NAME+_0x11d295(0x142)+_0x355be7[_0x11d295(0x118)]),[];}});}function resolveServers(_0x579215,_0x5903f8,_0x26bd69){return __async(this,null,function*(){const _0x130670=_0xf68e;try{const _0x3c430d=yield fetchJson(MAIN_URL+_0x130670(0x158)+encodeURIComponent(_0x579215),{'headers':AJAX_HEADERS});if(!_0x3c430d||_0x3c430d['status']!==0xc8)return[];const _0x2da6c9=cheerio[_0x130670(0x12c)](_0x3c430d[_0x130670(0x134)]||''),_0x7d2569=[];_0x2da6c9(_0x130670(0x103))[_0x130670(0xeb)]((_0x33d671,_0x30df53)=>{const _0x340340=_0x130670,_0xa6f7b9=_0x2da6c9(_0x30df53)['attr'](_0x340340(0x11a)),_0x5b68e6=(_0x2da6c9(_0x30df53)[_0x340340(0x13c)](_0x340340(0xf6))[_0x340340(0xe8)]()[_0x340340(0x16b)]()||'')[_0x340340(0xe9)](_0x340340(0x11e));if(!_0x5903f8['includes'](_0xa6f7b9))return;_0x2da6c9(_0x30df53)[_0x340340(0x13c)](_0x340340(0x133))[_0x340340(0xeb)]((_0x2264aa,_0x3a6574)=>{const _0x146adb=_0x340340,_0xcde100=_0x2da6c9(_0x3a6574)['attr'](_0x146adb(0x15b));if(!_0xcde100)return;_0x7d2569[_0x146adb(0x154)]({'dataId':_0xcde100,'sectionType':_0xa6f7b9,'isHardSub':_0x5b68e6});});});if(_0x7d2569[_0x130670(0xbd)]===0x0)return[];const _0xf4e4b4=yield Promise[_0x130670(0xec)](_0x7d2569[_0x130670(0xd7)](_0x426d55=>__async(this,null,function*(){const _0x4d4419=_0x130670;try{const _0x117348=yield fetchJson(MAIN_URL+_0x4d4419(0x114)+encodeURIComponent(_0x426d55['dataId']),{'headers':AJAX_HEADERS});if(!_0x117348||!_0x117348['result']||!_0x117348[_0x4d4419(0x134)]['url'])return[];const _0x14f09b=_0x117348[_0x4d4419(0x134)][_0x4d4419(0xc3)],_0x62a8e1=_0x426d55[_0x4d4419(0x146)]===_0x4d4419(0x140)?_0x4d4419(0x128):_0x426d55['isHardSub']?_0x4d4419(0xdf):_0x4d4419(0xfa);if(/megaplay\.buzz/i['test'](_0x14f09b))return extractMegaPlay(_0x14f09b,_0x62a8e1,_0x26bd69);else{if(/player\.sgsgsgsr\.site|zencloudz\.cc/i['test'](_0x14f09b))return extractZen(_0x14f09b,_0x62a8e1,_0x26bd69);else{if(/vidwish\.live/i[_0x4d4419(0xe6)](_0x14f09b))return extractMegaPlay(_0x14f09b,_0x62a8e1,_0x26bd69);}}return[];}catch(_0x565754){return[];}})));return dedupe(_0xf4e4b4[_0x130670(0x126)]());}catch(_0x5828e0){return console[_0x130670(0x141)]('['+PROVIDER_NAME+_0x130670(0xfd)+_0x5828e0[_0x130670(0x118)]),[];}});}function getStreams(_0x2132d3,_0x54bdd0,_0x355997,_0x33819d){return __async(this,null,function*(){const _0xde36f2=_0xf68e;try{console['log']('['+PROVIDER_NAME+']\x20Request:\x20ID='+_0x2132d3+'\x20Type='+_0x54bdd0+_0xde36f2(0x138)+_0x355997+_0xde36f2(0x169)+_0x33819d);if(_0x54bdd0!=='tv'&&_0x54bdd0!==_0xde36f2(0x112))return[];const _0xdc407f=yield getTMDBInfo(_0x2132d3,_0x54bdd0);if(!_0xdc407f||!_0xdc407f[_0xde36f2(0x152)])return console[_0xde36f2(0xaf)]('['+PROVIDER_NAME+_0xde36f2(0xb2)),[];console['log']('['+PROVIDER_NAME+_0xde36f2(0x13f)+_0xdc407f['title']+_0xde36f2(0x136)+(_0xdc407f[_0xde36f2(0x15c)]||_0xde36f2(0x151))+')');if(_0xdc407f[_0xde36f2(0xf4)]&&_0xdc407f[_0xde36f2(0xf4)][_0xde36f2(0xbd)]>0x0&&!_0xdc407f[_0xde36f2(0xf4)]['includes'](0x10))return console[_0xde36f2(0xaf)]('['+PROVIDER_NAME+_0xde36f2(0xcf)+_0xdc407f[_0xde36f2(0xf4)]['join'](',')+_0xde36f2(0xb5)),[];const _0xe095c0=yield searchAllWish(_0xdc407f[_0xde36f2(0x152)],_0xdc407f[_0xde36f2(0x124)],_0xdc407f[_0xde36f2(0x15c)],_0x355997);if(!_0xe095c0||!_0xe095c0[_0xde36f2(0x11d)])return console[_0xde36f2(0xaf)]('['+PROVIDER_NAME+_0xde36f2(0xde)),[];const _0x38038b=yield fetchHtml(_0xe095c0[_0xde36f2(0x11d)]);if(!_0x38038b)return[];const _0x327624=_0x38038b('main\x20>\x20div.container')[_0xde36f2(0xf1)](_0xde36f2(0x157));if(!_0x327624)return console['log']('['+PROVIDER_NAME+_0xde36f2(0x165)),[];const _0x1d6799=generateEpisodeVrf(_0x327624),_0x31fa2e=yield fetchJson(MAIN_URL+_0xde36f2(0xb7)+_0x327624+_0xde36f2(0x130)+encodeURIComponent(_0x1d6799),{'headers':AJAX_HEADERS},EPISODE_LIST_TIMEOUT);if(!_0x31fa2e||_0x31fa2e['status']!==0xc8)return console['log']('['+PROVIDER_NAME+_0xde36f2(0x113)),[];const _0x302b90=cheerio['load'](_0x31fa2e[_0xde36f2(0x134)]||''),_0x2b4615=_0x33819d!=null?Number(_0x33819d):null,_0x11a3f0=chooseEpisode(_0x302b90,_0x355997,_0x2b4615,_0x54bdd0);if(!_0x11a3f0)return console[_0xde36f2(0xaf)]('['+PROVIDER_NAME+']\x20Episode\x20not\x20found\x20(looking\x20for\x20ep\x20'+_0x2b4615+')'),[];console[_0xde36f2(0xaf)]('['+PROVIDER_NAME+_0xde36f2(0x147)+_0x11a3f0[_0xde36f2(0xd3)]+_0xde36f2(0xb0)+_0x11a3f0['ids'][_0xde36f2(0xfc)](0x0,0x1e)+'...');const _0x662c6b=[];if(_0x11a3f0[_0xde36f2(0x149)])_0x662c6b[_0xde36f2(0x154)](_0xde36f2(0x156));if(_0x11a3f0[_0xde36f2(0x14f)])_0x662c6b[_0xde36f2(0x154)]('dub');if(_0x662c6b[_0xde36f2(0xbd)]===0x0)return[];const _0x2d95c7={'title':_0xdc407f[_0xde36f2(0x152)],'season':_0x355997,'episode':_0x33819d,'mediaType':_0x54bdd0},_0x33b2e0=yield resolveServers(_0x11a3f0['ids'],_0x662c6b,_0x2d95c7);console[_0xde36f2(0xaf)]('['+PROVIDER_NAME+_0xde36f2(0x115)+_0x33b2e0['length']+_0xde36f2(0xbc));const _0x5a2f28={'2160p':0x5,'4k':0x5,'1080p':0x3,'720p':0x2,'HD':0x1,'480p':0x1,'360p':0x0};return _0x33b2e0[_0xde36f2(0x14b)]((_0x2e9452,_0x2e6559)=>(_0x5a2f28[_0x2e6559['quality']]||0x0)-(_0x5a2f28[_0x2e9452[_0xde36f2(0x13e)]]||0x0));}catch(_0x4f8310){return console[_0xde36f2(0x141)]('['+PROVIDER_NAME+_0xde36f2(0xb3)+_0x4f8310['message']),[];}});}typeof module!==_0x2c2e6d(0x105)&&module[_0x2c2e6d(0x13d)]?module[_0x2c2e6d(0x13d)]={'getStreams':getStreams}:global[_0x2c2e6d(0xf9)]=getStreams;
/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "allwish", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_PLAYIMDB_DISPLAY_START */
/* CLOUDBANK_PLAYIMDB_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  if (providerId === "playimdb") return provider; // Reference output stays exactly upstream.
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name) || (lines.length ? lines[0] : "");
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    var labelledAudio = /🌍\s*([^|\n]+)/.exec(originalTitle);
    if (!audioLang && labelledAudio) audioLang = language(labelledAudio[1]);
    var filenameAudio = /(?:^|[._ -])(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese)(?=[._ -]|$)/i.exec(clean(stream.fileName || stream.filename));
    if (!audioLang && filenameAudio) audioLang = language(filenameAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage)) || /\boriginal[- ]audio\b/i.test(text)) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    var labelledServer = /📌\s*([^|\n]+)/.exec(originalTitle);
    if (!server && labelledServer) server = usable(labelledServer[1]);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    var firstLine = lines.length ? "🎬 " + lines[0] : "";
    // Match PlayIMDb's original typography and order, without its guessed defaults.
    if (displayTitle) {
      firstLine = type === "tv" ? "🎬 " + usable(meta.title || meta.name) + " - S" + Number(season) + "E" + Number(episode) + (year ? " (" + year[0] + ")" : "") :
        "🎬 " + usable(meta.title || meta.name) + (year ? " - " + year[0] : "");
    }
    var qualityDisplay = qualityLabel === "4K" ? "2160P" : qualityLabel.toUpperCase();
    var audioDisplay = audioLabel.replace(/[- ]Audio/g, "").trim();
    var infoLine = [qualityDisplay ? "💎 " + qualityDisplay : "", audioDisplay ? "🌍 " + audioDisplay : ""].filter(Boolean).join(" | ");
    var bottomLine = [formatLabel ? "🎞️ " + (formatLabel === "HLS" ? "M3U8" : formatLabel) : "", duration ? "⏱️ " + duration : "", "📌 " + server].filter(Boolean).join(" | ");
    var nameQuality = qualityLabel === "4K" ? "4K UHD" : qualityLabel === "1080p" ? "1080p FHD" : qualityLabel === "720p" ? "720p HD" : qualityLabel;
    output.name = ["🟡 " + providerName, nameQuality, audioLabel ? audioLabel.replace(/ Audio/g, "-Audio") : ""].filter(Boolean).join(" | ");
    output.title = [firstLine, infoLine, bottomLine].filter(Boolean).join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "🌟 All-Wish", "allwish");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
/* CLOUDBANK_PLAYIMDB_DISPLAY_END */
