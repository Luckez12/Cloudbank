// Imported provider: cinefreak; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
var _0x2a015c=_0x38d9;(function(_0xa45f35,_0x220580){var _0x2a2a36={_0x520c86:0xcf,_0x17d51c:0xbe,_0x3217fc:0xe6,_0x42c985:0xb9,_0x577734:0xc6,_0x5aed24:0xb4,_0x56166c:0xb6},_0x5cb333=_0x38d9,_0x23e3a2=_0xa45f35();while(!![]){try{var _0x276a3a=-parseInt(_0x5cb333(_0x2a2a36._0x520c86))/0x1*(parseInt(_0x5cb333(_0x2a2a36._0x17d51c))/0x2)+parseInt(_0x5cb333(_0x2a2a36._0x3217fc))/0x3+-parseInt(_0x5cb333(_0x2a2a36._0x42c985))/0x4+-parseInt(_0x5cb333(_0x2a2a36._0x577734))/0x5*(parseInt(_0x5cb333(0xf9))/0x6)+-parseInt(_0x5cb333(0xe9))/0x7*(parseInt(_0x5cb333(_0x2a2a36._0x5aed24))/0x8)+-parseInt(_0x5cb333(0xf1))/0x9+parseInt(_0x5cb333(_0x2a2a36._0x56166c))/0xa*(parseInt(_0x5cb333(0xbc))/0xb);if(_0x276a3a===_0x220580)break;else _0x23e3a2['push'](_0x23e3a2['shift']());}catch(_0x1908b0){_0x23e3a2['push'](_0x23e3a2['shift']());}}}(_0x5153,0x49266));var __async=(_0x3be549,_0x467335,_0x19a99c)=>{var _0xac46c5={_0x48de3a:0xa7};return new Promise((_0x243f70,_0x1dbd51)=>{var _0x2f2c9a={_0x36bc72:0x9b},_0x284017=_0x38d9,_0xb7e89b=_0x4349f5=>{var _0x292293=_0x38d9;try{_0x28e579(_0x19a99c[_0x292293(_0xac46c5._0x48de3a)](_0x4349f5));}catch(_0x3f34e9){_0x1dbd51(_0x3f34e9);}},_0x2ad1d7=_0x1cada2=>{var _0x48f6df=_0x38d9;try{_0x28e579(_0x19a99c[_0x48f6df(_0x2f2c9a._0x36bc72)](_0x1cada2));}catch(_0x114164){_0x1dbd51(_0x114164);}},_0x28e579=_0xaa676e=>_0xaa676e['done']?_0x243f70(_0xaa676e[_0x284017(0xe3)]):Promise[_0x284017(0xc9)](_0xaa676e[_0x284017(0xe3)])[_0x284017(0xa9)](_0xb7e89b,_0x2ad1d7);_0x28e579((_0x19a99c=_0x19a99c[_0x284017(0xd9)](_0x3be549,_0x467335))[_0x284017(0xa7)]());});},PROVIDER_NAME='CineFreak',BASE_URL=_0x2a015c(0xad),CINECLOUD_BASE=_0x2a015c(0xfe),TMDB_API_KEY=_0x2a015c(0xd0),MOBILE_UAS=['Mozilla/5.0\x20(Linux;\x20Android\x2014;\x20Pixel\x208\x20Pro)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/124.0.0.0\x20Mobile\x20Safari/537.36','Mozilla/5.0\x20(Linux;\x20Android\x2013;\x20SM-S918B)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/116.0.0.0\x20Mobile\x20Safari/537.36',_0x2a015c(0xe7),_0x2a015c(0xfc)];function getHeaders(_0x2dd0c7){return{'User-Agent':_0x2dd0c7,'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Accept-Language':'en-US,en;q=0.5'};}function _0x38d9(_0x4bf9d7,_0x5ddc99){_0x4bf9d7=_0x4bf9d7-0x9b;var _0x515335=_0x5153();var _0x38d9ca=_0x515335[_0x4bf9d7];if(_0x38d9['WLHCGk']===undefined){var _0x23ed6d=function(_0x15e83c){var _0x2768e3='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';var _0x3be549='',_0x467335='';for(var _0x19a99c=0x0,_0x243f70,_0x1dbd51,_0xb7e89b=0x0;_0x1dbd51=_0x15e83c['charAt'](_0xb7e89b++);~_0x1dbd51&&(_0x243f70=_0x19a99c%0x4?_0x243f70*0x40+_0x1dbd51:_0x1dbd51,_0x19a99c++%0x4)?_0x3be549+=String['fromCharCode'](0xff&_0x243f70>>(-0x2*_0x19a99c&0x6)):0x0){_0x1dbd51=_0x2768e3['indexOf'](_0x1dbd51);}for(var _0x2ad1d7=0x0,_0x28e579=_0x3be549['length'];_0x2ad1d7<_0x28e579;_0x2ad1d7++){_0x467335+='%'+('00'+_0x3be549['charCodeAt'](_0x2ad1d7)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x467335);};_0x38d9['ZHDbHI']=_0x23ed6d,_0x38d9['mVqMmw']={},_0x38d9['WLHCGk']=!![];}var _0x72344f=_0x515335[0x0],_0x481d0a=_0x4bf9d7+_0x72344f,_0x289a6f=_0x38d9['mVqMmw'][_0x481d0a];return!_0x289a6f?(_0x38d9ca=_0x38d9['ZHDbHI'](_0x38d9ca),_0x38d9['mVqMmw'][_0x481d0a]=_0x38d9ca):_0x38d9ca=_0x289a6f,_0x38d9ca;}function fetchText(_0x52bf0e,_0x407ee1){return __async(this,null,function*(){try{var _0x415047={'headers':getHeaders(_0x407ee1||MOBILE_UAS[0x0])};const _0x56ea88=new Promise(function(_0x59a8a5,_0x125a17){setTimeout(function(){_0x125a17(new Error('timeout'));},0xfa0);}),_0x27b025=yield Promise['race']([fetch(_0x52bf0e,_0x415047),_0x56ea88]);if(!_0x27b025['ok'])return null;return yield _0x27b025['text']();}catch(_0x68dacb){return null;}});}function fetchJson(_0x4952dc,_0x3dc4a1){var _0x3eb1ae={_0x196f46:0xec};return __async(this,null,function*(){var _0x511286=_0x38d9;try{var _0x5ae51e=yield fetchText(_0x4952dc,_0x3dc4a1);if(!_0x5ae51e)return null;return JSON[_0x511286(_0x3eb1ae._0x196f46)](_0x5ae51e);}catch(_0x1f8085){return null;}});}function parseQuality(_0x35f962){var _0x3fb9fb={_0x16617c:0xed,_0xdd928e:0xbd},_0x52baf9=_0x2a015c,_0xda4ff3=String(_0x35f962||'')[_0x52baf9(0xa1)]();if(_0xda4ff3['indexOf']('2160')>=0x0||_0xda4ff3[_0x52baf9(_0x3fb9fb._0x16617c)]('4k')>=0x0)return _0x52baf9(0xe4);if(_0xda4ff3[_0x52baf9(_0x3fb9fb._0x16617c)](_0x52baf9(_0x3fb9fb._0xdd928e))>=0x0)return'1080p';if(_0xda4ff3['indexOf']('720')>=0x0)return'720p';if(_0xda4ff3['indexOf']('480')>=0x0)return'480p';return'HD';}function extractFslUrl(_0x7d5745){var _0x13e9e7={_0x219fca:0xbf,_0x4ea906:0xed,_0x350ac9:0x104},_0x5f1aa0=_0x2a015c,_0x25a6b5=/href="([^"]+)"[^>]*id="fsl"|href="([^"]+(?:\.workers\.dev|\.r2\.dev|\.buzz|\.cloudflarestorage\.com)\/[^"]+)"|href="(https?:\/\/[^"]+\.(?:mkv|mp4)[^"]*)"|href="(https:\/\/pub-[^"]+)"/ig,_0x3ccd36;while((_0x3ccd36=_0x25a6b5['exec'](_0x7d5745))!==null){var _0x58d607=_0x3ccd36[0x1]||_0x3ccd36[0x2]||_0x3ccd36[0x3]||_0x3ccd36[0x4];if(_0x58d607&&!_0x58d607['includes'](_0x5f1aa0(0xc2)))return _0x58d607[_0x5f1aa0(_0x13e9e7._0x219fca)](/&amp;/g,'&');}var _0x5cfdc0=_0x5f1aa0(0x105),_0xcbdca5=_0x7d5745[_0x5f1aa0(_0x13e9e7._0x4ea906)](_0x5cfdc0);if(_0xcbdca5===-0x1)return null;var _0x273996=_0xcbdca5+0x6,_0x469335=_0x7d5745['indexOf']('\x22',_0x273996);if(_0x469335===-0x1)return null;var _0x15f79c=_0x7d5745[_0x5f1aa0(_0x13e9e7._0x350ac9)](_0x273996,_0x469335);return _0x15f79c=_0x15f79c[_0x5f1aa0(_0x13e9e7._0x219fca)](/&amp;/g,'&'),_0x15f79c;}function decodeGenerateUrl(_0x488e74){try{var _0x1cd08c=atob(_0x488e74);return _0x1cd08c=_0x1cd08c['replace'](/newgo32$/,''),_0x1cd08c;}catch(_0x184465){return null;}}function encodeUri(_0x3d4840){try{return encodeURIComponent(_0x3d4840);}catch(_0x317ba6){return _0x3d4840;}}function manifest(){var _0x1afdf9={_0x5474d3:0xaa},_0x3ca56c=_0x2a015c;return{'id':_0x3ca56c(_0x1afdf9._0x5474d3),'name':'CineFreak','description':'Direct\x20MKV/MP4\x20streams\x20from\x20cinefreak.nl','version':'1.0.0','logo':'https://cinefreak.nl/wp-content/uploads/2024/08/cropped-cgk-192x192.png','background':_0x3ca56c(0x9d),'types':['movie','tv'],'resources':[_0x3ca56c(0xcb)],'idPrefixes':['tt','tmdb']};}function search(_0x1a4407,_0x348ee3){var _0x348955={_0x406562:0xc0,_0x49c6b9:0x102,_0x517d12:0xa4,_0x33b856:0xba,_0x1255d0:0x100};return __async(this,null,function*(){var _0x2214c5=_0x38d9;if(!_0x1a4407)return[];var _0x1eca08=BASE_URL+_0x2214c5(_0x348955._0x406562)+encodeUri(_0x1a4407)+_0x2214c5(_0x348955._0x49c6b9),_0x5f3b1f=yield fetchJson(_0x1eca08);if(!_0x5f3b1f||!_0x5f3b1f[_0x2214c5(_0x348955._0x517d12)])return[];var _0xe06eb8=[];for(var _0x1da82e=0x0;_0x1da82e<_0x5f3b1f['length'];_0x1da82e++){var _0xdb2a01=_0x5f3b1f[_0x1da82e];if(!_0xdb2a01||!_0xdb2a01['title']||!_0xdb2a01[_0x2214c5(_0x348955._0x33b856)])continue;var _0x4708b5=String(_0xdb2a01[_0x2214c5(0xc3)])['replace'](/Download\s*/gi,'')['trim']();if(!_0x4708b5)continue;_0xe06eb8[_0x2214c5(_0x348955._0x1255d0)]({'id':_0xdb2a01[_0x2214c5(0xba)],'title':_0x4708b5,'url':_0xdb2a01['url']});}return _0xe06eb8;});}function getTMDBInfo(_0x3d2d43,_0x514873,_0x1c0dda){var _0x269f69={_0x4de4c2:0x104,_0x4aa3b4:0xa2,_0x4d92ab:0x104};return __async(this,null,function*(){var _0x43b767=_0x38d9,_0x104c4e=_0x514873==='tv'||_0x514873===_0x43b767(0xdf),_0x532a1f=_0x104c4e?'https://api.themoviedb.org/3/tv/'+_0x3d2d43+_0x43b767(0xd1)+TMDB_API_KEY:'https://api.themoviedb.org/3/movie/'+_0x3d2d43+'?api_key='+TMDB_API_KEY,_0x514ee8=yield fetchJson(_0x532a1f,_0x1c0dda);if(!_0x514ee8)return null;return{'title':_0x104c4e?_0x514ee8[_0x43b767(0xf6)]:_0x514ee8['title'],'year':_0x104c4e?(_0x514ee8[_0x43b767(0xd4)]||'')[_0x43b767(_0x269f69._0x4de4c2)](0x0,0x4):(_0x514ee8[_0x43b767(_0x269f69._0x4aa3b4)]||'')[_0x43b767(_0x269f69._0x4d92ab)](0x0,0x4),'isTv':_0x104c4e};});}function wordMatchScore(_0xbc8050,_0x58d101){var _0x69135c={_0x26143a:0xa1,_0x2184dd:0xa4,_0x4d26ce:0xa4,_0x3702f2:0xbf},_0x22a63f=_0x2a015c,_0x37171c=String(_0xbc8050||'')[_0x22a63f(_0x69135c._0x26143a)]()[_0x22a63f(0xfa)](),_0x3040dd=String(_0x58d101||'')[_0x22a63f(0xa1)](),_0x477e9f=_0x37171c['replace'](/[^a-z0-9\s]/g,'\x20')['split'](/\s+/),_0x52d020=0x0,_0x1f8834=0x0;for(var _0x4834b7=0x0;_0x4834b7<_0x477e9f[_0x22a63f(_0x69135c._0x2184dd)];_0x4834b7++){var _0x49d6ee=_0x477e9f[_0x4834b7];if(_0x49d6ee[_0x22a63f(_0x69135c._0x4d26ce)]<0x3)continue;_0x1f8834++;var _0x1da5d2=new RegExp('\x5cb'+_0x49d6ee[_0x22a63f(_0x69135c._0x3702f2)](/[.*+?^${}()|[\]\\]/g,'\x5c$&')+'\x5cb','i');if(_0x1da5d2[_0x22a63f(0xce)](_0x58d101))_0x52d020++;}if(_0x1f8834===0x0)return 0x0;return _0x52d020/_0x1f8834;}function titleStartsWith(_0x5a12f7,_0x31e86f){var _0x107851={_0x3bb8ca:0xa1,_0x4132fe:0xed},_0x5b47a0=_0x2a015c,_0x3d9be2=String(_0x5a12f7||'')[_0x5b47a0(_0x107851._0x3bb8ca)]()['trim'](),_0x294ecd=String(_0x31e86f||'')['toLowerCase']()['trim']();return _0x3d9be2[_0x5b47a0(_0x107851._0x4132fe)](_0x294ecd)===0x0||_0x3d9be2[_0x5b47a0(0xed)](_0x294ecd+'\x20')===0x0||_0x3d9be2['indexOf']('('+_0x294ecd+')')===0x0;}function urlContains(_0x4a8b3b,_0x3000f3){var _0x59faf1={_0x323bd7:0xa1,_0x112e48:0xa4},_0x2f9a5f=_0x2a015c,_0x281a9d=String(_0x4a8b3b||'')['toLowerCase'](),_0x39f5bb=String(_0x3000f3||'')[_0x2f9a5f(_0x59faf1._0x323bd7)]()['replace'](/[^a-z0-9]/g,'-')[_0x2f9a5f(0xbf)](/-+/g,'-'),_0x2dea0f=_0x39f5bb[_0x2f9a5f(0xa8)]('-')['filter'](function(_0x1f4265){return _0x1f4265['length']>0x2;}),_0x148074=0x0;for(var _0x4c8880=0x0;_0x4c8880<_0x2dea0f[_0x2f9a5f(_0x59faf1._0x112e48)];_0x4c8880++){if(_0x281a9d[_0x2f9a5f(0xed)](_0x2dea0f[_0x4c8880])>=0x0)_0x148074++;}return _0x2dea0f[_0x2f9a5f(_0x59faf1._0x112e48)]>0x0?_0x148074/_0x2dea0f['length']:0x0;}function matchByTitleYear(_0x42693c,_0x6704ea,_0x5abe5b,_0x321236){var _0x465029={_0x27f290:0xac,_0x2ae28a:0xa4,_0x47eee8:0xa4,_0x35ea1d:0xc3},_0x5b097c=_0x2a015c;if(!_0x5abe5b||!_0x5abe5b[_0x5b097c(0xa4)])return null;var _0x400a99=String(_0x42693c||'')['toLowerCase']()[_0x5b097c(0xfa)](),_0x546209=String(_0x6704ea||'');function _0x4a66b9(_0x4992f){var _0x34ec6f=_0x5b097c;if(!_0x4992f)return 0x0;var _0x111d06=0x0;if(titleStartsWith(_0x4992f['title'],_0x42693c))_0x111d06+=0xa;_0x111d06+=urlContains(_0x4992f[_0x34ec6f(0xba)],_0x42693c)*0x5,_0x111d06+=wordMatchScore(_0x42693c,_0x4992f[_0x34ec6f(0xc3)]);if(_0x546209&&String(_0x4992f[_0x34ec6f(0xc3)])['toLowerCase']()['indexOf'](_0x546209)>=0x0)_0x111d06+=0x3;return _0x111d06;}if(_0x321236){var _0x358ce1=_0x5b097c(_0x465029._0x27f290)+_0x321236+'\x5cb',_0x5f22e8=new RegExp(_0x358ce1,'i'),_0x333857=null,_0x141d96=-0x1;for(var _0x54e15f=0x0;_0x54e15f<_0x5abe5b[_0x5b097c(_0x465029._0x2ae28a)];_0x54e15f++){var _0x120a26=_0x5abe5b[_0x54e15f];if(!_0x120a26||!_0x120a26['title'])continue;if(_0x5f22e8[_0x5b097c(0xce)](_0x120a26[_0x5b097c(0xc3)])){var _0x327716=_0x4a66b9(_0x120a26)+0xa;_0x327716>_0x141d96&&(_0x141d96=_0x327716,_0x333857=_0x120a26);}}if(_0x333857)return _0x333857;}var _0x333857=null,_0x141d96=-0x1;for(var _0x54e15f=0x0;_0x54e15f<_0x5abe5b[_0x5b097c(_0x465029._0x47eee8)];_0x54e15f++){var _0x120a26=_0x5abe5b[_0x54e15f];if(!_0x120a26||!_0x120a26[_0x5b097c(_0x465029._0x35ea1d)])continue;var _0x327716=_0x4a66b9(_0x120a26);_0x327716>_0x141d96&&(_0x141d96=_0x327716,_0x333857=_0x120a26);}if(_0x333857&&_0x141d96>=0x3)return _0x333857;return null;}function searchCinefreak(_0xd0d906,_0x49e11d,_0x1e5b83){var _0xa29beb={_0x32e392:0xa4,_0x22c051:0xba};return __async(this,null,function*(){var _0x32c375=_0x38d9;if(!_0xd0d906)return[];var _0x38c726=BASE_URL+'/wp-json/wp/v2/search?search='+encodeUri(_0xd0d906)+'&per_page=10',_0x2bdf4c=yield fetchJson(_0x38c726,_0x1e5b83);if(!_0x2bdf4c||!_0x2bdf4c[_0x32c375(_0xa29beb._0x32e392)])return[];var _0x543750=[];for(var _0x305a1d=0x0;_0x305a1d<_0x2bdf4c['length'];_0x305a1d++){var _0x222c12=_0x2bdf4c[_0x305a1d];if(!_0x222c12||!_0x222c12[_0x32c375(0xc3)]||!_0x222c12[_0x32c375(_0xa29beb._0x22c051)])continue;_0x543750['push']({'id':_0x222c12['id'],'title':String(_0x222c12['title'])['replace'](/Download\s*/gi,'')['trim'](),'url':_0x222c12[_0x32c375(_0xa29beb._0x22c051)]});}return _0x543750;});}function fetchPostPage(_0x3f8371,_0x3f8a4a){var _0x33a8ff={_0x14add6:0xed};return __async(this,null,function*(){var _0xc1cc73=_0x38d9;if(!_0x3f8371)return null;var _0x44fc7b=_0x3f8371;if(_0x3f8371['indexOf']('http')!==0x0){if(_0x3f8371[_0xc1cc73(_0x33a8ff._0x14add6)]('/')===0x0)_0x44fc7b=BASE_URL+_0x3f8371;else _0x44fc7b=BASE_URL+'/'+_0x3f8371;}return yield fetchText(_0x44fc7b,_0x3f8a4a);});}function extractAllGenerateLinks(_0x44287b){var _0x44228a={_0x2f4797:0xed,_0x5affff:0xf5,_0x1c7fa1:0xe8,_0x29300e:0x104,_0x2c5630:0x100},_0x2aaa5c=_0x2a015c;if(!_0x44287b)return[];var _0xbd97e9=[],_0x25fa84=0x0,_0x4be806='/generate.php?id=';while(!![]){var _0x437a92=_0x44287b[_0x2aaa5c(_0x44228a._0x2f4797)](_0x4be806,_0x25fa84);if(_0x437a92===-0x1)break;var _0x5314aa=_0x44287b[_0x2aaa5c(_0x44228a._0x5affff)](_0x2aaa5c(_0x44228a._0x1c7fa1),_0x437a92);if(_0x5314aa===-0x1||_0x5314aa<_0x25fa84){_0x25fa84=_0x437a92+0x1;continue;}var _0x434c53=_0x44287b[_0x2aaa5c(_0x44228a._0x2f4797)]('</a>',_0x437a92);if(_0x434c53===-0x1){_0x25fa84=_0x437a92+0x1;continue;}var _0x200dc0=_0x44287b['indexOf']('>',_0x437a92);if(_0x200dc0===-0x1||_0x200dc0>_0x434c53){_0x25fa84=_0x434c53+0x4;continue;}var _0x8f7faf=_0x44287b[_0x2aaa5c(_0x44228a._0x29300e)](_0x200dc0+0x1,_0x434c53)['trim'](),_0x3f3e36=_0x44287b['indexOf']('\x22',_0x437a92);if(_0x3f3e36===-0x1){_0x25fa84=_0x434c53+0x4;continue;}var _0x53b0fb=_0x44287b['substring'](_0x437a92,_0x3f3e36),_0x26d579=_0x53b0fb['match'](/id=([a-zA-Z0-9+/=]+)/);if(!_0x26d579){_0x25fa84=_0x434c53+0x4;continue;}var _0x50ea59=_0x26d579[0x1],_0x323aa9=decodeGenerateUrl(_0x50ea59);_0xbd97e9[_0x2aaa5c(_0x44228a._0x2c5630)]({'encodedId':_0x50ea59,'decodedUrl':_0x323aa9||'','label':_0x8f7faf,'fullTag':_0x44287b['substring'](_0x5314aa,_0x434c53+0x4)}),_0x25fa84=_0x434c53+0x4;}return _0xbd97e9;}function extractMovieQualities(_0x1cf4c1){var _0x5333b1=_0x2a015c;if(!_0x1cf4c1)return[];var _0x1f62eb=[],_0x3435f4=_0x1cf4c1['split']('dlbtn-container');for(var _0x5018ff=0x1;_0x5018ff<_0x3435f4['length'];_0x5018ff++){var _0x32d1b0=_0x3435f4[_0x5018ff],_0x426fed=_0x3435f4[_0x5018ff-0x1],_0x5d59e2=_0x32d1b0['match'](/href="(?:https?:\/\/[^"]*?)?\/generate\.php\?id=([a-zA-Z0-9+/=]+)"/);if(!_0x5d59e2)continue;var _0x468624=_0x5d59e2[0x1],_0x1cb06=decodeGenerateUrl(_0x468624);if(!_0x1cb06||_0x1cb06[_0x5333b1(0xed)]('/f/')===-0x1)continue;var _0x1e7c91='',_0x4e1d2a=_0x426fed['match'](/<\/span>\s*([^<]*?(?:2160|1080|720|480|4K)[^<]*?\[[^\]]+\])/i);!_0x4e1d2a&&(_0x4e1d2a=_0x426fed['match'](/<\/span>\s*([^<]*?(?:2160|1080|720|480|4K)[^<]*?)\s*\[/i));_0x4e1d2a&&(_0x1e7c91=_0x4e1d2a[0x1]['trim']());if(!_0x1e7c91||!_0x1e7c91[_0x5333b1(0xf3)]('[')){var _0x358f6f=_0x426fed['match'](/<h4[^>]*>([\s\S]*?)<\/h4>/i);if(_0x358f6f)_0x1e7c91=(_0x1e7c91+'\x20'+_0x358f6f[0x1][_0x5333b1(0xbf)](/<[^>]*>/g,''))[_0x5333b1(0xfa)]();}if(!_0x1e7c91){_0x4e1d2a=_0x426fed['match'](/\b(?:4K\s*2160p|UHD|2160p|1080p|720p|480p)\b/i);if(!_0x4e1d2a)_0x4e1d2a=_0x426fed['match'](/\b(?:SD|HD)\b/i);if(_0x4e1d2a)_0x1e7c91=_0x4e1d2a[0x0];}if(!_0x1e7c91)_0x1e7c91=_0x1cb06;var _0x4422ac=parseQuality(_0x1e7c91),_0x41a098=![];for(var _0x5cfb41=0x0;_0x5cfb41<_0x1f62eb['length'];_0x5cfb41++){if(_0x1f62eb[_0x5cfb41]['decodedUrl']===_0x1cb06){_0x41a098=!![];break;}}if(_0x41a098)continue;_0x1f62eb['push']({'encodedId':_0x468624,'decodedUrl':_0x1cb06,'label':_0x1e7c91||_0x4422ac,'quality':_0x4422ac});}return _0x1f62eb;}function extractEpisodeQualities(_0x3ef157,_0x3d3be4){var _0x2db26c={_0x7b54ef:0x103,_0x305d7b:0xa3,_0x24809a:0x103,_0x4380e8:0x100,_0x105b76:0xf0},_0x483476=_0x2a015c;if(!_0x3ef157)return[];var _0x2de654=_0x3ef157['split'](_0x483476(0xd5)),_0x420914=null;for(var _0x37251a=0x1;_0x37251a<_0x2de654['length'];_0x37251a++){var _0x385612=_0x2de654[_0x37251a],_0x1a2ca6=_0x385612['match'](/episode-badge[^>]*>Episode\s*(\d+)/i);if(!_0x1a2ca6)continue;var _0x2ab8ba=parseInt(_0x1a2ca6[0x1],0xa);if(_0x2ab8ba===_0x3d3be4){_0x420914=_0x385612;break;}}if(!_0x420914)return[];var _0x8721cc=extractAllGenerateLinks(_0x420914),_0x4e59d3=[];for(var _0x1a2085=0x0;_0x1a2085<_0x8721cc['length'];_0x1a2085++){var _0x5829f8=_0x8721cc[_0x1a2085];if(!_0x5829f8[_0x483476(0x103)]||_0x5829f8[_0x483476(_0x2db26c._0x7b54ef)][_0x483476(0xed)]('/f/')===-0x1)continue;var _0x57a3fd=_0x5829f8[_0x483476(_0x2db26c._0x305d7b)],_0x1b3da8=parseQuality(_0x57a3fd||_0x5829f8[_0x483476(0x103)]),_0x2738b3=![];for(var _0x4e14eb=0x0;_0x4e14eb<_0x4e59d3['length'];_0x4e14eb++){if(_0x4e59d3[_0x4e14eb]['decodedUrl']===_0x5829f8[_0x483476(_0x2db26c._0x24809a)]){_0x2738b3=!![];break;}}if(_0x2738b3)continue;_0x4e59d3[_0x483476(_0x2db26c._0x4380e8)]({'encodedId':_0x5829f8[_0x483476(_0x2db26c._0x105b76)],'decodedUrl':_0x5829f8['decodedUrl'],'label':_0x57a3fd||_0x1b3da8,'quality':_0x1b3da8});}return _0x4e59d3;}function filterQualities(_0x140c40){var _0x67342a={_0x36b724:0xa4,_0x2fdde3:0xea,_0x2727ca:0xea,_0x4c62b0:0x100},_0x46a3ed={_0x1baea7:0xea},_0x195f7a=_0x2a015c;if(!_0x140c40||!_0x140c40[_0x195f7a(_0x67342a._0x36b724)])return[];var _0xe7872=[];for(var _0x5d5f0a=0x0;_0x5d5f0a<_0x140c40['length'];_0x5d5f0a++){var _0x7f4f5=_0x140c40[_0x5d5f0a];if(_0x7f4f5[_0x195f7a(_0x67342a._0x2fdde3)]==='480p'||_0x7f4f5[_0x195f7a(_0x67342a._0x2727ca)]==='SD')continue;_0xe7872[_0x195f7a(_0x67342a._0x4c62b0)](_0x7f4f5);}var _0x3bd302={'2160p':0x0,'1080p':0x1,'720p':0x2,'HD':0x3};return _0xe7872['sort'](function(_0x3a1f3a,_0x264d6e){var _0x2dbf00=_0x195f7a,_0x3c43a7=_0x3bd302[_0x3a1f3a['quality']]!==void 0x0?_0x3bd302[_0x3a1f3a['quality']]:0x63,_0x1e6e62=_0x3bd302[_0x264d6e[_0x2dbf00(_0x46a3ed._0x1baea7)]]!==void 0x0?_0x3bd302[_0x264d6e['quality']]:0x63;return _0x3c43a7-_0x1e6e62;}),_0xe7872;}function extractHash(_0x276c4c){var _0x2162d5={_0x5e98c4:0xed,_0x4ab73b:0x104},_0x4e1596=_0x2a015c;if(!_0x276c4c)return'';var _0x20d164=_0x276c4c[_0x4e1596(_0x2162d5._0x5e98c4)]('/f/'),_0x18cfe7=_0x276c4c[_0x4e1596(_0x2162d5._0x5e98c4)](_0x4e1596(0xfb)),_0x25ced1=_0x20d164>=0x0?_0x20d164+0x3:_0x18cfe7>=0x0?_0x18cfe7+0x3:-0x1;if(_0x25ced1<0x0)return'';return _0x276c4c[_0x4e1596(_0x2162d5._0x4ab73b)](_0x25ced1);}function resolveFslUrl(_0x26b466,_0x1223d6){var _0x4f4163={_0x427409:0xbb};return __async(this,null,function*(){var _0xbb18fd=_0x38d9;if(!_0x26b466)return null;var _0x4b7b66=extractHash(_0x26b466);if(!_0x4b7b66)return null;var _0x1c9da5=CINECLOUD_BASE+_0xbb18fd(_0x4f4163._0x427409)+_0x4b7b66,_0x40338e=yield fetchText(_0x1c9da5,_0x1223d6);if(!_0x40338e)return null;return extractFslUrl(_0x40338e);});}function decodeEntities(_0x40648d){var _0x1905a3=_0x2a015c;if(!_0x40648d)return'';var _0x432079=/&(nbsp|amp|quot|lt|gt|#038);/g,_0x41c2ce={'nbsp':'\x20','amp':'&','quot':'\x22','lt':'<','gt':'>','#038':'&'};return _0x40648d['replace'](_0x432079,function(_0x3a1827,_0x2c13d0){return _0x41c2ce[_0x2c13d0];})[_0x1905a3(0xbf)](/&#(\d+);/g,function(_0xf7bc58,_0x42b312){return String['fromCharCode'](_0x42b312);});}function makeStream(_0x122e14,_0x219aa7,_0x2ef03f,_0x8666f,_0xac0aec,_0xad91d1){var _0x44beed={_0x562e64:0xfa,_0x58dd02:0xa8,_0x257801:0xbf,_0x40ffd9:0xa1,_0x1ecc1a:0xcd,_0x1ad7ce:0x9c,_0x16d606:0xf3,_0x45e5a0:0xde,_0x5237ee:0xaf,_0x36c877:0xce,_0x437950:0xf3,_0x3d5f0e:0xf2,_0x5d41f6:0xf3,_0x179077:0xc5,_0x29352b:0xb2,_0x14f543:0xb8,_0x3bf716:0xc1,_0x5a21b3:0xc4,_0x241ed9:0xf4,_0x27bde1:0xd2,_0x219b11:0xf8,_0x16956c:0xb1,_0x39c340:0xb5,_0x371f2d:0xda,_0x202931:0xca,_0x3e2396:0xbd},_0x1ee8f3=_0x2a015c,_0x51a831=decodeEntities(_0x122e14||'')['replace'](/[\n\t]+/g,'')[_0x1ee8f3(_0x44beed._0x562e64)](),_0x54eca3=decodeEntities(_0x219aa7||'')['replace'](/[\n\t]+/g,'\x20')[_0x1ee8f3(0xbf)](/\s{2,}/g,'\x20')[_0x1ee8f3(0xfa)]();_0x51a831[_0x1ee8f3(0xed)]('\x20-\x20')>0x0&&(_0x51a831=_0x51a831[_0x1ee8f3(_0x44beed._0x58dd02)](_0x1ee8f3(0xd7))[0x0][_0x1ee8f3(0xfa)]());_0x51a831=_0x51a831[_0x1ee8f3(_0x44beed._0x257801)](/\(\d{4}\).*$/gi,'')[_0x1ee8f3(_0x44beed._0x257801)](/\d{3,4}p.*$/gi,'')[_0x1ee8f3(0xfa)]();var _0x1d7ae7=_0x54eca3[_0x1ee8f3(_0x44beed._0x40ffd9)](),_0x54f002=(_0x2ef03f||'')['toLowerCase'](),_0x1ec06c=_0x1ee8f3(_0x44beed._0x1ecc1a),_0x2ee72d=_0x54eca3['match'](/\[\s*(\d+(?:\.\d+)?\s*[MG]B)\s*\]/i)||_0x54eca3[_0x1ee8f3(0xb5)](/(\d+(?:\.\d+)?\s*[MG]B)/i);if(_0x2ee72d)_0x1ec06c=_0x2ee72d[0x1][_0x1ee8f3(_0x44beed._0x1ad7ce)]()['replace'](/\s+/g,'');var _0x2bad2d=0x0,_0x588fd0=0x0;if(_0x2ee72d){var _0x67dba4=parseFloat(_0x2ee72d[0x1]),_0x225f35=_0x2ee72d[0x1]['toUpperCase']();_0x2bad2d=_0x225f35['includes']('GB')?_0x67dba4*0x400:_0x67dba4,_0x588fd0=_0x225f35[_0x1ee8f3(_0x44beed._0x16d606)]('GB')?_0x67dba4:_0x67dba4/0x400;}var _0x4a470a=_0x1ee8f3(_0x44beed._0x45e5a0);if(_0x2ef03f&&_0x54f002[_0x1ee8f3(0xa8)]('?')[0x0][_0x1ee8f3(0xdc)](_0x1ee8f3(0x9f)))_0x4a470a=_0x1ee8f3(0xc8);var _0x441e46='WEB-DL';if(/\b(bluray|blu\-ray)\b/i['test'](_0x1d7ae7))_0x441e46=_0x1ee8f3(_0x44beed._0x5237ee);else{if(/\b(hdrip|webrip)\b/i[_0x1ee8f3(_0x44beed._0x36c877)](_0x1d7ae7))_0x441e46=_0x1ee8f3(0xb7);}var _0x966acc=_0x8666f[_0x1ee8f3(_0x44beed._0x437950)](_0x1ee8f3(_0x44beed._0x3d5f0e))||_0x8666f['toLowerCase']()[_0x1ee8f3(0xf3)]('4k')||_0x1d7ae7[_0x1ee8f3(0xf3)]('2160p'),_0x47db4b='H.264';(/\b(hevc|x265|h265)\b/i['test'](_0x1d7ae7)||_0x54f002[_0x1ee8f3(_0x44beed._0x16d606)](_0x1ee8f3(0xd6))||_0x54f002[_0x1ee8f3(_0x44beed._0x5d41f6)](_0x1ee8f3(_0x44beed._0x179077))||_0x966acc)&&(_0x47db4b=_0x1ee8f3(_0x44beed._0x29352b));var _0x3a8100='',_0x1c9b3a='';if(/\b(dolby\s*vision|dovi|dv)\b/i['test'](_0x1d7ae7)||_0x54f002['includes']('dovi')||_0x54f002[_0x1ee8f3(_0x44beed._0x437950)](_0x1ee8f3(_0x44beed._0x14f543)))_0x1c9b3a=_0x1ee8f3(0x9e);else{if(/\bhdr10\b/i['test'](_0x1d7ae7)||_0x54f002[_0x1ee8f3(0xf3)]('hdr10'))_0x1c9b3a=_0x1ee8f3(0xae);else{if(/\bhdr\b/i['test'](_0x1d7ae7)||_0x54f002[_0x1ee8f3(0xf3)]('hdr'))_0x1c9b3a='HDR';else(/\b(10bit|10\-bit)\b/i['test'](_0x1d7ae7)||_0x54f002['includes']('10bit'))&&(_0x1c9b3a=_0x1ee8f3(_0x44beed._0x3bf716));}}if(_0x1c9b3a)_0x3a8100=_0x1ee8f3(_0x44beed._0x5a21b3)+_0x1c9b3a+_0x1ee8f3(_0x44beed._0x241ed9)+_0x47db4b;else _0x3a8100='\x20|\x20⚡\x20'+_0x47db4b;var _0x43cfa6='DD5.1';if(_0x966acc)_0x43cfa6=_0x1ee8f3(_0x44beed._0x27bde1);else{if(_0x2ee72d&&_0x588fd0<1.3)_0x43cfa6='Stereo';else{if(_0x54f002[_0x1ee8f3(_0x44beed._0x16d606)]('hq'))_0x43cfa6=_0x1ee8f3(0xd2);else _0x47db4b==='HEVC'&&(_0x43cfa6='DD5.1');}}var _0xbfc29f=/\b(dual|multi|dubbed|hindi)\b/i['test'](_0x1d7ae7)||decodeEntities(_0x122e14||'')[_0x1ee8f3(0xa1)]()[_0x1ee8f3(0xf3)](_0x1ee8f3(0xe2))||_0x54f002['includes']('dual'),_0x17bf2b=_0xbfc29f?_0x1ee8f3(_0x44beed._0x219b11):_0x1ee8f3(_0x44beed._0x16956c),_0x1b0fde=_0xbfc29f?'English\x20🇺🇸\x20•\x20Hindi\x20🇮🇳':'English\x20🇺🇸',_0x2f3e81=_0x8666f||'1080p',_0x4f2667=PROVIDER_NAME+'\x20|\x20'+_0x2f3e81+_0x1ee8f3(0xd3)+_0x17bf2b,_0xe8d045=decodeEntities(_0x122e14||'')[_0x1ee8f3(_0x44beed._0x39c340)](/\b(19|20)\d{2}\b/),_0x115289=_0xe8d045?_0xe8d045[0x0]:_0x1ee8f3(0xee),_0x1ad103='';_0xad91d1&&(_0xad91d1[_0x1ee8f3(_0x44beed._0x371f2d)]('S')||_0xad91d1['includes']('E'))?_0x1ad103=_0x1ee8f3(0x106)+_0x51a831+'\x20('+_0x115289+')\x20-\x20'+_0xad91d1['replace'](/E0*(\d+)/i,_0x1ee8f3(_0x44beed._0x202931))[_0x1ee8f3(_0x44beed._0x257801)](/S0*(\d+)/i,'S$1'):_0x1ad103='🎦\x20'+_0x51a831+'\x20-\x20('+_0x115289+')';var _0x4dca98='💎\x20'+_0x2f3e81+'\x20|\x20🗣️\x20'+_0x1b0fde+_0x1ee8f3(0x101)+_0x1ec06c,_0x45e7fb='🎞️\x20'+_0x4a470a+'\x20|\x20🎧\x20'+_0x43cfa6+_0x3a8100,_0x259934='🔗\x20FSL\x20Server\x20|\x20☁️\x20'+_0x441e46,_0x59af77=_0x1ad103+'\x0a'+_0x4dca98+'\x0a'+_0x45e7fb+'\x0a'+_0x259934,_0x5851a0=_0x966acc?0x895440:_0x2f3e81[_0x1ee8f3(_0x44beed._0x16d606)](_0x1ee8f3(_0x44beed._0x3e2396))?0x5b8d80:0x2dc6c0,_0x1583cc=_0x5851a0+_0x2bad2d;return{'name':_0x4f2667,'title':_0x59af77,'size':_0x59af77,'url':_0x2ef03f||'','_resWeight':_0x5851a0,'_sortWeight':_0x1583cc,'behaviorHints':{'notWebReady':!![],'proxyHeaders':{'request':_0xac0aec||{'Referer':CINECLOUD_BASE+'/'}}}};}function getStreams(_0x1c24c2,_0x598c03,_0xb3006a,_0x2ea8d7){var _0x5bcbd0={_0x24ef91:0xa4,_0x362e3c:0xdb,_0x54844a:0xcc,_0x2c66fb:0xc3,_0x48b740:0xb3,_0xb87c61:0xc3,_0x12832c:0xba,_0x1ee864:0xa5,_0x3b8f7f:0x103,_0x27bd38:0xc3,_0x41a31c:0xa3,_0x4712b3:0xea,_0x303e44:0xfa,_0xad2e7b:0xef,_0x20b00d:0xe5,_0x30db30:0xa6,_0x5517cb:0xff},_0x585855={_0x234c1e:0xea};return __async(this,null,function*(){var _0x83ed32=_0x38d9;try{var _0xc96a6c=_0x598c03==='tv'||_0x598c03==='series';console['log']('['+PROVIDER_NAME+']\x20Request:\x20tmdbId='+_0x1c24c2+'\x20type='+_0x598c03+_0x83ed32(0xd8)+_0xb3006a+_0x83ed32(0xeb)+_0x2ea8d7);var _0x1d68e4=MOBILE_UAS[Math[_0x83ed32(0xc7)](Math[_0x83ed32(0xb0)]()*MOBILE_UAS[_0x83ed32(_0x5bcbd0._0x24ef91)])],_0x1022ee=yield getTMDBInfo(_0x1c24c2,_0x598c03,_0x1d68e4);if(!_0x1022ee||!_0x1022ee['title'])return console['log']('['+PROVIDER_NAME+_0x83ed32(_0x5bcbd0._0x362e3c)+_0x1c24c2),[];console['log']('['+PROVIDER_NAME+']\x20TMDB:\x20'+_0x1022ee[_0x83ed32(0xc3)]+'\x20('+_0x1022ee['year']+')');var _0x4b3418=_0xc96a6c?parseInt(_0xb3006a,0xa)||0x1:null,_0x2bdde8=yield searchCinefreak(_0x1022ee['title'],null,_0x1d68e4);if(!_0x2bdde8||_0x2bdde8['length']<0x3){var _0x120b59=yield searchCinefreak(_0x1022ee['title']+'\x20'+_0x1022ee[_0x83ed32(0xa0)],null,_0x1d68e4);if(_0x120b59&&_0x120b59[_0x83ed32(0xa4)])_0x2bdde8=_0x120b59;}if(!_0x2bdde8||!_0x2bdde8['length'])return console['log']('['+PROVIDER_NAME+']\x20No\x20search\x20results\x20for\x20'+_0x1022ee['title']),[];var _0x315c82=matchByTitleYear(_0x1022ee['title'],_0x1022ee['year'],_0x2bdde8,_0x4b3418);if(!_0x315c82)return console['log']('['+PROVIDER_NAME+_0x83ed32(_0x5bcbd0._0x54844a)+_0x1022ee[_0x83ed32(_0x5bcbd0._0x2c66fb)]),[];console[_0x83ed32(_0x5bcbd0._0x48b740)]('['+PROVIDER_NAME+']\x20Matched:\x20'+_0x315c82[_0x83ed32(_0x5bcbd0._0xb87c61)]);var _0x9cb3ec=yield fetchPostPage(_0x315c82[_0x83ed32(_0x5bcbd0._0x12832c)],_0x1d68e4);if(!_0x9cb3ec)return console[_0x83ed32(0xb3)]('['+PROVIDER_NAME+']\x20Failed\x20to\x20fetch\x20post\x20page'),[];var _0x4475b1;if(_0xc96a6c){var _0x5883a4=parseInt(_0x2ea8d7,0xa)||0x1;_0x4475b1=extractEpisodeQualities(_0x9cb3ec,_0x5883a4);}else _0x4475b1=extractMovieQualities(_0x9cb3ec);if(!_0x4475b1||!_0x4475b1[_0x83ed32(0xa4)])return console['log']('['+PROVIDER_NAME+']\x20No\x20quality\x20links\x20found'),[];var _0x2db500=filterQualities(_0x4475b1);if(!_0x2db500[_0x83ed32(_0x5bcbd0._0x24ef91)])return console[_0x83ed32(_0x5bcbd0._0x48b740)]('['+PROVIDER_NAME+']\x20No\x20usable\x20qualities\x20after\x20filtering'),[];console[_0x83ed32(0xb3)]('['+PROVIDER_NAME+_0x83ed32(_0x5bcbd0._0x1ee864)+_0x2db500[_0x83ed32(0xdd)](function(_0x5713e9){var _0x113ddb=_0x83ed32;return _0x5713e9[_0x113ddb(_0x585855._0x234c1e)];})['join'](',\x20'));var _0x4b5dec='';if(_0xc96a6c){var _0xa85a7f=parseInt(_0xb3006a,0xa)||0x1,_0x410351=parseInt(_0x2ea8d7,0xa)||0x1;_0x4b5dec='S'+(_0xa85a7f<0xa?'0':'')+_0xa85a7f+'E'+(_0x410351<0xa?'0':'')+_0x410351+'\x20';}var _0x2c1a43=[];for(var _0x46bf4b=0x0;_0x46bf4b<_0x2db500['length'];_0x46bf4b++){var _0x16d35d=_0x2db500[_0x46bf4b],_0x5ec026=yield resolveFslUrl(_0x16d35d[_0x83ed32(_0x5bcbd0._0x3b8f7f)],_0x1d68e4);if(_0x5ec026){var _0x283ed2=makeStream(_0x315c82[_0x83ed32(_0x5bcbd0._0x27bd38)],_0x16d35d[_0x83ed32(_0x5bcbd0._0x41a31c)],_0x5ec026,_0x16d35d[_0x83ed32(_0x5bcbd0._0x4712b3)],{'Referer':CINECLOUD_BASE+'/','User-Agent':_0x1d68e4},_0x4b5dec[_0x83ed32(_0x5bcbd0._0x303e44)]());_0x2c1a43['push'](_0x283ed2);}}var _0x4cabd3=_0x2c1a43[_0x83ed32(_0x5bcbd0._0xad2e7b)](function(_0x4b2eab,_0x4a011a){var _0x38b42f=_0x83ed32;return(_0x4a011a['_sortWeight']||0x0)-(_0x4b2eab[_0x38b42f(0xe1)]||0x0);});return console['log']('['+PROVIDER_NAME+_0x83ed32(_0x5bcbd0._0x20b00d)+_0x4cabd3['length']+'\x20stream(s)'),_0x4cabd3;}catch(_0x26fcbf){return console[_0x83ed32(0xb3)]('['+PROVIDER_NAME+_0x83ed32(_0x5bcbd0._0x30db30)+(_0x26fcbf[_0x83ed32(_0x5bcbd0._0x5517cb)]||_0x26fcbf)),[];}});}function _0x5153(){var _0x29e1c4=['zMLYC3rFywLYx2rHDgu','pgrPDIbJBgfZCZ0IzxaTy2fYzci','Agv2yW','ic0G','ifm9','yxbWBhK','C3rHCNrZv2L0Aa','xsbuturcigLUzM8GBM90igzVDw5KigzVCIa','zw5KC1DPDgG','BwfW','tuTw','C2vYAwvZ','zxHWB3j0CW','x3nVCNrxzwLNAhq','zhvHBcbHDwrPBW','DMfSDwu','mJe2mha','xsbszxr1CM5PBMCG','mteWntKXn1jzu2zksW','tw96AwXSys81lJaGkeXPBNv4oYbbBMrYB2LKideYoYbqAxHLBca2ksbbChbSzvDLyKTPDc81mZCUmZyGkeTive1mlcbSAwTLieDLy2TVksbdAhjVBwuVmte1lJaUmc4Wie1VyMLSzsbtywzHCMKVntm3lJm2','pgeG','mteYANnevLPd','CxvHBgL0Eq','ieu9','CgfYC2u','Aw5KzxHpzG','mJaYnG','C29YDa','zw5JB2rLzeLK','mte4odC5mNn1tMPpCa','mJe2ma','Aw5JBhvKzxm','iokaOIdIMQeG','BgfZDeLUzgv4t2y','BMfTzq','C2vHCMnO','rhvHBc1bDwrPBW','mta0mty2wfjHt3fI','DhjPBq','l3GV','tw96AwXSys81lJaGkgLqAg9UztSGq1bvigLqAg9UzsbpuYaXn18WigXPA2uGtwfJie9tifGPiefWCgXLv2vIs2L0lZyWns4XlJe1icHlsfrntcWGBgLRzsbhzwnRBYKGvMvYC2LVBI8XnY4Wie1VyMLSzs8XnuuXndGGu2fMyxjPlZyWnc4X','BwfUAwzLC3q','Ahr0Chm6lY9UzxC1lMnPBMvJBg91zc5ZAxrL','BwvZC2fNzq','ChvZAa','ihWG8j+sVIa','jNbLCL9WywDLpteW','zgvJB2rLzfvYBa','C3vIC3rYAw5N','AhjLzJ0IAhr0Chm6lY9WDwiT','8j+oPIa','DgHYB3C','Dg9vChbLCKnHC2u','Ahr0Chm6lY9JAw5LzNjLywSUBMWVD3aTy29UDgvUDc91CgXVywrZlZiWmJqVmdGVy3jVChbLzc1Jz2STmtKYEde5mI5WBMC','rg9SyNKGvMLZAw9U','lM1Wna','EwvHCG','Dg9mB3DLCKnHC2u','CMvSzwfZzv9KyxrL','BgfIzwW','BgvUz3rO','xsbrDwfSAxrPzxm6ia','xsbgyxrHBcbLCNjVCJOG','BMv4Da','C3bSAxq','DgHLBG','y2LUzwzYzwfR','Dw5KzwzPBMvK','kd86C2vHC29UFhmPxhmQ','Ahr0Chm6lY9JAw5LzNjLywSUBMW','sersmta','qMX1uMf5','CMfUzg9T','u2LUz2XLief1zgLV','sevwqW','Bg9N','mJuYmtq0EKXbrhDj','Bwf0y2G','mti3mJu5otbLvKHOvfG','v0vcuMLW','zg9SyNKUDMLZAw9U','odu4mZyWqwLnDKLz','DxjS','l2yV','mtfmCvHUuum','mta4ma','mtK5nZG2rK9zD2zU','CMvWBgfJzq','l3DWlwPZB24VD3aVDJiVC2vHCMnOp3nLyxjJAd0','mtbcAxq','lNPPCa','DgL0Bgu','ihWG8j+uHIa','Edi2nq','ntvyqLLVsMq','zMXVB3i','tva0','CMvZB2X2zq','rsqX','C3rYzwfT','xsboBYbTyxrJAcbMB3vUzcbMB3iG','tI9b','DgvZDa','m29lqxznra','ndm5yZq3oge3nZfMmZvJmduWmJjMowzLywjJy2eWmwm','p2fWAv9RzxK9','rerqns4XiokaOIdWN5skief0Bw9Z','ihWG'];_0x5153=function(){return _0x29e1c4;};return _0x5153();}typeof module!==_0x2a015c(0xab)&&module['exports']?module[_0x2a015c(0xe0)]={'manifest':manifest,'search':search,'getStreams':getStreams}:(global[_0x2a015c(0xfd)]=manifest,global[_0x2a015c(0xf7)]=search,global['getStreams']=getStreams);

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "cinefreak", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_PLAYIMDB_DISPLAY_START */
/* CLOUDBANK_PLAYIMDB_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  if (providerId === "playimdb") return provider; // Reference output stays exactly upstream.
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name) || (lines.length ? lines[0] : "");
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    var labelledAudio = /🌍\s*([^|\n]+)/.exec(originalTitle);
    if (!audioLang && labelledAudio) audioLang = language(labelledAudio[1]);
    var filenameAudio = /(?:^|[._ -])(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese)(?=[._ -]|$)/i.exec(clean(stream.fileName || stream.filename));
    if (!audioLang && filenameAudio) audioLang = language(filenameAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage)) || /\boriginal[- ]audio\b/i.test(text)) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    var labelledServer = /📌\s*([^|\n]+)/.exec(originalTitle);
    if (!server && labelledServer) server = usable(labelledServer[1]);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    var firstLine = lines.length ? "🎬 " + lines[0] : "";
    // Match PlayIMDb's original typography and order, without its guessed defaults.
    if (displayTitle) {
      firstLine = type === "tv" ? "🎬 " + usable(meta.title || meta.name) + " - S" + Number(season) + "E" + Number(episode) + (year ? " (" + year[0] + ")" : "") :
        "🎬 " + usable(meta.title || meta.name) + (year ? " - " + year[0] : "");
    }
    var qualityDisplay = qualityLabel === "4K" ? "2160P" : qualityLabel.toUpperCase();
    var audioDisplay = audioLabel.replace(/[- ]Audio/g, "").trim();
    var infoLine = [qualityDisplay ? "💎 " + qualityDisplay : "", audioDisplay ? "🌍 " + audioDisplay : ""].filter(Boolean).join(" | ");
    var bottomLine = [formatLabel ? "🎞️ " + (formatLabel === "HLS" ? "M3U8" : formatLabel) : "", duration ? "⏱️ " + duration : "", "📌 " + server].filter(Boolean).join(" | ");
    var nameQuality = qualityLabel === "4K" ? "4K UHD" : qualityLabel === "1080p" ? "1080p FHD" : qualityLabel === "720p" ? "720p HD" : qualityLabel;
    output.name = ["🟡 " + providerName, nameQuality, audioLabel ? audioLabel.replace(/ Audio/g, "-Audio") : ""].filter(Boolean).join(" | ");
    output.title = [firstLine, infoLine, bottomLine].filter(Boolean).join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "CineFreak", "cinefreak");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
/* CLOUDBANK_PLAYIMDB_DISPLAY_END */
