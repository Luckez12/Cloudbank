// Imported provider: movieshunt; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
var _0x310f1c=_0x2f28;(function(_0x37811,_0x15a88d){var _0x56f970={_0x3d81d5:0x149,_0x31b5eb:0x184,_0x5ac781:0x133,_0x391c08:0x15b},_0x180768=_0x2f28,_0x41c7e9=_0x37811();while(!![]){try{var _0x38d53a=-parseInt(_0x180768(0x16a))/0x1*(parseInt(_0x180768(0x125))/0x2)+parseInt(_0x180768(0x17e))/0x3+-parseInt(_0x180768(_0x56f970._0x3d81d5))/0x4*(parseInt(_0x180768(_0x56f970._0x31b5eb))/0x5)+parseInt(_0x180768(0x17b))/0x6*(parseInt(_0x180768(0x13d))/0x7)+parseInt(_0x180768(0x18b))/0x8+-parseInt(_0x180768(_0x56f970._0x5ac781))/0x9+-parseInt(_0x180768(_0x56f970._0x391c08))/0xa*(-parseInt(_0x180768(0x12b))/0xb);if(_0x38d53a===_0x15a88d)break;else _0x41c7e9['push'](_0x41c7e9['shift']());}catch(_0x550585){_0x41c7e9['push'](_0x41c7e9['shift']());}}}(_0x16be,0xb1d13));var __async=(_0x1750ab,_0x374b0d,_0x425222)=>{var _0x1c7652={_0x2d9341:0x164};return new Promise((_0x25582f,_0x5b90ea)=>{var _0x21ba9b=_0x2f28,_0x55645f=_0x43b88e=>{var _0x1e680f=_0x2f28;try{_0x5dc19c(_0x425222[_0x1e680f(0x181)](_0x43b88e));}catch(_0x54a602){_0x5b90ea(_0x54a602);}},_0x17ebe3=_0x5d81cc=>{try{_0x5dc19c(_0x425222['throw'](_0x5d81cc));}catch(_0x4aa80f){_0x5b90ea(_0x4aa80f);}},_0x5dc19c=_0x12d3a0=>_0x12d3a0[_0x21ba9b(0x127)]?_0x25582f(_0x12d3a0[_0x21ba9b(0x161)]):Promise[_0x21ba9b(0x147)](_0x12d3a0[_0x21ba9b(0x161)])['then'](_0x55645f,_0x17ebe3);_0x5dc19c((_0x425222=_0x425222[_0x21ba9b(_0x1c7652._0x2d9341)](_0x1750ab,_0x374b0d))['next']());});},PROVIDER_NAME='MoviesHunt',TMDB_API_KEY='439c478a771f35c05022f9feabcca01c',movieshuntBase=_0x310f1c(0x16f),abhilinksBase='https://abhilinks.site',currentUA='Mozilla/5.0\x20(Linux;\x20Android\x2014;\x20Pixel\x208\x20Pro)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/124.0.0.0\x20Mobile\x20Safari/537.36',UAS=['Mozilla/5.0\x20(Linux;\x20Android\x2014;\x20Pixel\x208\x20Pro)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/124.0.0.0\x20Mobile\x20Safari/537.36',_0x310f1c(0x146),_0x310f1c(0x154),_0x310f1c(0x12f)];function log(_0x31693e){console['log']('['+PROVIDER_NAME+']\x20'+_0x31693e);}function hdrs(_0x17e151){var _0x12b221=_0x310f1c;return Object['assign']({},{'User-Agent':currentUA,'Accept-Language':_0x12b221(0x150),'Accept':_0x12b221(0x171)},_0x17e151||{});}var FETCH_TIMEOUT=0x4e20;function raceTimeout(_0x59861b){return new Promise(function(_0x2d2fb3,_0x8108d5){setTimeout(function(){_0x8108d5(new Error('Timeout'));},_0x59861b);});}function fetchText(_0x5a461e,_0x39ad72){return __async(this,null,function*(){try{var _0x480aa8=yield Promise['race']([fetch(_0x5a461e,_0x39ad72||{}),raceTimeout(FETCH_TIMEOUT)]);if(_0x480aa8&&_0x480aa8['ok'])return yield _0x480aa8['text']();}catch(_0x206690){}return null;});}function _0x16be(){var _0x34b08e=['8j+tPsbxruiTreW','Ahr0Ca','8j+nVYa','tw96AwXSys81lJaGkgLqAg9UztSGq1bvigLqAg9UzsbpuYaXn18WigXPA2uGtwfJie9tifGPiefWCgXLv2vIs2L0lZyWns4XlJe1icHlsfrntcWGBgLRzsbhzwnRBYKGvMvYC2LVBI8XnY4Wie1VyMLSzs8XnuuXndGGu2fMyxjPlZyWnc4X','BMfTzq','iokaOIa','rLnm','mte1nJu0odzPuK9cAxK','ihjLC3vSDhm','zw4TvvmSzw47Ct0WlJu','ns4X','CMvWBgfJzq','DMnSB3vK','AhvIy2XVDwq','C3vIC3rYAw5N','zxHLyW','zMLYC3rFywLYx2rHDgu','nZuXnZuXte5xuMfp','D2vIlxjPCa','Aw5Uzxi','vhj5Aw5NihbVC3q6ia','DxjS','jMXHBMD1ywDLpwvUlvvt','8j+mIca','mJe2ma','zMXVB3i','tw96AwXSys81lJaGkeXPBNv4oYbbBMrYB2LKideZoYbtts1tote4qIKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlZeXnI4WlJaUmcbnB2jPBguGu2fMyxjPlZuZnY4ZnG','CMvZB2X2zq','ihWGuW','nZiWodHUB0rbsuG','Dg9mB3DLCKnHC2u','CxvHBgL0Eq','8j+uIca','ywXS','DgL0Bgu','ChvZAa','zw4TvvmSzw47Ct0WlJK','Cg9W','BwfYyxrOAq','yxrTB3m','tw96AwXSys81lJaGkeXPBNv4oYbbBMrYB2LKideYoYbqAxHLBca2ksbbChbSzvDLyKTPDc81mZCUmZyGkeTive1mlcbSAwTLieDLy2TVksbdAhjVBwuVmte1lJaUmc4Wie1VyMLSzsbtywzHCMKVntm3lJm2','CMfUzg9T','yMvUz2fSAq','lZ9Zpq','AgrY','tM8GDgL0BguGzNjVBsbuturc','CMfJzq','mtb0zK5lEuu','ihWG8j+uIIbbDg1VCW','C2vYAwvZ','ndGWCa','DgvSDwD1','vhj1zuHe','DMfSDwu','8j+oPsb4mJy0','ihn0CMvHBxmGzNjVBsa','yxbWBhK','zxHWB3j0CW','Edi2nq','reqGns4X','tuTw','qwjOAwXPBMTZigzLDgnOigzHAwXLza','mteWodG1B3jjDgzl','CMf3vgv4Da','C29YDa','mta4mha','rLnmDJi','Ahr0Chm6lY9TB3zPzxnODw50lNj1BG','Awr4','Dgv4Dc9ODg1SlgfWCgXPy2f0Aw9Ul3HODg1Sk3HTBcXHChbSAwnHDgLVBI94BwW7Ct0WlJKSkI8Qo3e9mc44','ihWG8j+oPYa','DhLWzq','DgvZDa','A2v5CW','BgvUz3rO','Aw5KzxG','EgXHpxm0Da','DhjPBq','CMvSzwfZzv9KyxrL','ndjMuMTVq1u','BwLU','Bwf0y2G','mZC4odq5mffXsuzICG','Dg9vChbLCKnHC2u','tM8GAhvIy2XVDwqVDMnSB3vKihrHC2TZ','BMv4Da','zgrWns4X','u2vHCMnOigzHAwXLza','nZvxtfDQDwm','Bwf4','8j+oPsb4mJy1','txvSDgKTqxvKAw8','8j+mKcbxruiTuKLq','mtbIAxq','D2vICMLW','nduWodaWmen4s0zkyW','ihWG','C3bSAxq','twf0y2HLCZOG','zMLSDgvY','tw96AwXSys81lJaGkfGXmtSGvwj1BNr1oYbmAw51Ecb4odzFnJq7ihj2oJe1mI4WksbhzwnRBY8YmdeWmdeWmsbgAxjLzM94lZe1mI4W','v29YA2vY','BgLUA3m','8j+uLYa','vgL0Bgu6ia','qufd','zhvHBa','Dw5KzwzPBMvK','BwfSyxLHBgfT','AgrYmta','Aw5KzxHpzG','AgrYmtaR','mtHtA1LguuG','AM9PBG','zg9Uzq','icbMzxrJAcbMywLSzwq','tM8GC3rYzwfTCYbMCM9TihrOAxmGCg9ZDcWGDhj5Aw5Nig5LEhqGBwf0y2G','CgfKu3rHCNq','nZCZoty3n2PuCeHSEq'];_0x16be=function(){return _0x34b08e;};return _0x16be();}function fetchJson(_0x1cdeba,_0x3e56f2){var _0x23b4e5={_0xc8e14b:0x15a};return __async(this,null,function*(){var _0x229ae8=_0x2f28;try{var _0x142245=yield Promise[_0x229ae8(_0x23b4e5._0xc8e14b)]([fetch(_0x1cdeba,_0x3e56f2||{}),raceTimeout(FETCH_TIMEOUT)]);if(_0x142245&&_0x142245['ok'])return yield _0x142245['json']();}catch(_0x181162){}return null;});}function getTMDBInfo(_0x30733c,_0xeacd58){return __async(this,null,function*(){var _0x3caf36=_0x2f28,_0x5dda87=_0xeacd58==='tv'||_0xeacd58===_0x3caf36(0x15d)?'tv':'movie',_0x2b1e06='https://api.themoviedb.org/3/'+_0x5dda87+'/'+_0x30733c+'?api_key='+TMDB_API_KEY+_0x3caf36(0x142);return yield fetchJson(_0x2b1e06,{'headers':{'User-Agent':currentUA}});});}function parseSearchResults(_0x4c2672){var _0x89d025={_0x460e94:0x13b,_0x343e96:0x12d,_0x3189fd:0x14f},_0x1c9dc8=_0x310f1c,_0x1c3113=[],_0x48ac38=/<h\d[^>]*class="[^"]*entry-title[^"]*"[^>]*>([\s\S]*?)<\/h\d>/gi,_0x3ee030;while((_0x3ee030=_0x48ac38[_0x1c9dc8(_0x89d025._0x460e94)](_0x4c2672))!==null){var _0x34d893=_0x3ee030[0x1],_0x4f8e1f=_0x34d893[_0x1c9dc8(0x17d)](/<a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i);if(_0x4f8e1f){var _0x154561=_0x4f8e1f[0x1];if(_0x154561[_0x1c9dc8(0x123)](_0x1c9dc8(_0x89d025._0x343e96))!==0x0)_0x154561=movieshuntBase+(_0x154561['startsWith']('/')?'':'/')+_0x154561;var _0x3f983b=_0x4f8e1f[0x2][_0x1c9dc8(0x137)](/<[^>]+>/g,'')[_0x1c9dc8(0x179)]();if(_0x3f983b[_0x1c9dc8(0x176)]>0x5)_0x1c3113[_0x1c9dc8(_0x89d025._0x3189fd)]({'title':_0x3f983b,'url':_0x154561});}}return _0x1c3113;}function searchSite(_0x42cbdf){var _0x3701e2={_0x1e445e:0x137,_0x2f384a:0x137,_0x226de9:0x179,_0x37fd30:0x14f,_0x5a8390:0x18f,_0x5017a0:0x17c,_0x1f1e86:0x176,_0x3d06db:0x126,_0x968c52:0x176,_0x21ae64:0x174,_0xad123a:0x123,_0x190f3a:0x176,_0x57d8fb:0x157,_0x11c285:0x176,_0x1b3ef4:0x134};return __async(this,null,function*(){var _0x2af5f9=_0x2f28,_0x2749b3=[],_0x191469=[_0x42cbdf['replace'](/'/g,'')['trim']()],_0xc65b00=_0x42cbdf[_0x2af5f9(_0x3701e2._0x1e445e)](/[^a-zA-Z0-9 ]/g,'\x20')[_0x2af5f9(_0x3701e2._0x2f384a)](/\s+/g,'\x20')[_0x2af5f9(_0x3701e2._0x226de9)]();if(_0xc65b00!==_0x191469[0x0])_0x191469['push'](_0xc65b00);var _0x2fe763=_0xc65b00['replace'](/\s*\d{4}\s*/g,'\x20')[_0x2af5f9(0x179)]();if(_0x2fe763&&_0x191469['indexOf'](_0x2fe763)<0x0)_0x191469[_0x2af5f9(_0x3701e2._0x37fd30)](_0x2fe763);var _0x5ead67=_0xc65b00[_0x2af5f9(0x18d)]('\x20')[_0x2af5f9(_0x3701e2._0x5a8390)](function(_0x22fdce){return _0x22fdce['length']>0x2;});while(_0x5ead67[_0x2af5f9(0x176)]>0x1){_0x5ead67[_0x2af5f9(0x151)]();var _0x56463=_0x5ead67['join']('\x20');if(_0x56463[_0x2af5f9(0x176)]>0x3&&_0x191469[_0x2af5f9(0x123)](_0x56463)<0x0)_0x191469[_0x2af5f9(0x14f)](_0x56463);}if(_0xc65b00){var _0x5a1b3a=_0xc65b00['split']('\x20');if(_0x5a1b3a['length']>0x1){var _0x368ef2=_0x5a1b3a['slice'](-Math[_0x2af5f9(_0x3701e2._0x5017a0)](0x2,_0x5a1b3a[_0x2af5f9(_0x3701e2._0x1f1e86)]))[_0x2af5f9(_0x3701e2._0x3d06db)]('\x20');if(_0x368ef2[_0x2af5f9(0x176)]>0x3&&_0x191469['indexOf'](_0x368ef2)<0x0)_0x191469['push'](_0x368ef2);var _0x35e876=_0x5a1b3a[_0x5a1b3a['length']-0x1];if(_0x35e876[_0x2af5f9(_0x3701e2._0x968c52)]>0x3&&/[a-zA-Z]/[_0x2af5f9(_0x3701e2._0x21ae64)](_0x35e876)&&_0x191469[_0x2af5f9(_0x3701e2._0xad123a)](_0x35e876)<0x0)_0x191469['push'](_0x35e876);}}for(var _0x5bef5a=0x0;_0x5bef5a<_0x191469[_0x2af5f9(_0x3701e2._0x190f3a)];_0x5bef5a++){var _0x1c3578=_0x191469[_0x5bef5a];if(_0x1c3578[_0x2af5f9(_0x3701e2._0x1f1e86)]<0x3)continue;var _0x12a8f2=movieshuntBase+_0x2af5f9(_0x3701e2._0x57d8fb)+encodeURIComponent(_0x1c3578),_0x4b7b7d=yield fetchText(_0x12a8f2,{'headers':hdrs()});if(!_0x4b7b7d)continue;var _0x218ded=parseSearchResults(_0x4b7b7d);if(_0x218ded&&_0x218ded[_0x2af5f9(0x176)])return log('Search\x20\x27'+_0x1c3578+'\x27\x20found\x20'+_0x218ded[_0x2af5f9(_0x3701e2._0x11c285)]+_0x2af5f9(_0x3701e2._0x1b3ef4)),_0x218ded;}return _0x2749b3;});}function matchHits(_0xbcc84a,_0x20027d,_0x5b86f5){var _0x30d2e5={_0x20b15a:0x14e,_0x5a85f2:0x14a,_0x3a0a88:0x137,_0x1b1b39:0x18d,_0x4dba11:0x176,_0x27dbfd:0x137,_0x40a905:0x123,_0x127221:0x179,_0x3aa121:0x18f,_0x3de717:0x16c},_0x5150b6={_0x22141d:0x176},_0x41eacf=_0x310f1c,_0x8b4d86=(_0x5b86f5?_0x20027d['name']:_0x20027d[_0x41eacf(_0x30d2e5._0x20b15a)])||'',_0x574091=_0x5b86f5?(_0x20027d['first_air_date']||'')['split']('-')[0x0]:(_0x20027d['release_date']||'')['split']('-')[0x0],_0x56e944=_0x8b4d86[_0x41eacf(_0x30d2e5._0x5a85f2)]()['replace'](/[\u2018\u2019\u201A\u201B\u2032\u2035]/g,'\x27'),_0x23e902=/\b(and|&|the|a|an)\b/g,_0x104c83=_0x56e944['replace'](_0x23e902,'')[_0x41eacf(_0x30d2e5._0x3a0a88)](/\s+/g,'\x20')['trim'](),_0x1a0806=_0x56e944[_0x41eacf(_0x30d2e5._0x1b1b39)](/\s+/)['filter'](function(_0x43c4f5){var _0x1a1bf9=_0x41eacf;return _0x43c4f5[_0x1a1bf9(_0x5150b6._0x22141d)]>0x1;}),_0x2950bc=[],_0x1695f2={};for(var _0x1bbcce=0x0;_0x1bbcce<_0xbcc84a[_0x41eacf(_0x30d2e5._0x4dba11)];_0x1bbcce++){var _0x3ea9ab=_0xbcc84a[_0x1bbcce],_0xea8102=_0x3ea9ab['title']||'',_0x44595a=_0x3ea9ab['url']||'';if(_0x1695f2[_0x44595a])continue;_0x1695f2[_0x44595a]=!![];var _0x135b70=_0xea8102[_0x41eacf(0x14a)]()['replace'](/[\u2018\u2019\u201A\u201B\u2032\u2035]/g,'\x27'),_0x45d4bd=0x0;if(_0x135b70===_0x56e944)_0x45d4bd+=0x64;else{if(_0x135b70['indexOf'](_0x56e944)>=0x0||_0x56e944['indexOf'](_0x135b70)>=0x0)_0x45d4bd+=0x32;else{var _0x311c89=_0x135b70[_0x41eacf(0x137)](_0x23e902,'')[_0x41eacf(_0x30d2e5._0x27dbfd)](/\s+/g,'\x20')[_0x41eacf(0x179)]();if(_0x311c89['indexOf'](_0x104c83)>=0x0||_0x104c83[_0x41eacf(_0x30d2e5._0x40a905)](_0x311c89)>=0x0)_0x45d4bd+=0x32;else{if(_0x311c89[_0x41eacf(_0x30d2e5._0x3a0a88)](/[^a-z0-9\s]/g,'')[_0x41eacf(0x179)]()===_0x104c83['replace'](/[^a-z0-9\s]/g,'')[_0x41eacf(_0x30d2e5._0x127221)]())_0x45d4bd+=0x3c;}}}if(_0x45d4bd===0x0&&_0x1a0806['length']>0x1){var _0x1e9e79=_0x135b70['split'](/\s+/)[_0x41eacf(_0x30d2e5._0x3aa121)](function(_0x5925f1){var _0x276692=_0x41eacf;return _0x5925f1[_0x276692(0x176)]>0x1;}),_0x46d0a0=0x0;for(var _0x1d6f28=0x0;_0x1d6f28<_0x1a0806['length'];_0x1d6f28++){for(var _0x3bca6c=0x0;_0x3bca6c<_0x1e9e79['length'];_0x3bca6c++){if(_0x1a0806[_0x1d6f28]===_0x1e9e79[_0x3bca6c]||_0x1e9e79[_0x3bca6c]['indexOf'](_0x1a0806[_0x1d6f28])===0x0||_0x1a0806[_0x1d6f28]['indexOf'](_0x1e9e79[_0x3bca6c])===0x0){_0x46d0a0++;break;}}}if(_0x46d0a0>=Math['min'](_0x1a0806[_0x41eacf(_0x30d2e5._0x4dba11)],0x3))_0x45d4bd+=0x32;}if(_0x45d4bd>=0x32&&_0x574091&&_0xea8102['indexOf'](_0x574091)>=0x0)_0x45d4bd+=0xa;if(_0x45d4bd>=0x32)_0x2950bc['push']({'doc':_0x3ea9ab,'score':_0x45d4bd});}_0x2950bc[_0x41eacf(_0x30d2e5._0x3de717)](function(_0x14835f,_0x34e38f){return _0x34e38f['score']-_0x14835f['score'];});var _0x4181ad=[];for(var _0x58ee5b=0x0;_0x58ee5b<Math['min'](_0x2950bc['length'],0x5);_0x58ee5b++)_0x4181ad[_0x41eacf(0x14f)](_0x2950bc[_0x58ee5b]['doc']);return _0x4181ad;}function extractAbhilinksUrl(_0x187d86){var _0x11cf52=_0x310f1c,_0x481f78=_0x187d86['match'](/<a[^>]*href="(https:\/\/abhilinks\.(?:life|site)\/[^"]+)"[^>]*class="btn"[^>]*>/i);if(_0x481f78)return _0x481f78[0x1];var _0x971738=_0x187d86[_0x11cf52(0x17d)](/<a[^>]*href="(https:\/\/abhilinks\.(?:life|site)\/[^"]+)"[^>]*>/i);if(_0x971738)return _0x971738[0x1];return null;}function extractQualityOptions(_0x20fe67){var _0x1381f4={_0x4a6234:0x13b,_0x20362c:0x14a,_0x12769a:0x177,_0x104fab:0x185,_0x1d402d:0x138},_0x19a4b3=_0x310f1c,_0x23729e=[],_0x503fcb=/(2160|1080|720|480)[pP](?:\s+\w{1,15})?\s*\[([^\]]+)\]/g,_0x52cacc;while((_0x52cacc=_0x503fcb[_0x19a4b3(_0x1381f4._0x4a6234)](_0x20fe67))!==null){var _0x187712=_0x52cacc[0x1][_0x19a4b3(_0x1381f4._0x20362c)]()+'p',_0x1d7858=_0x52cacc[0x2];if(_0x187712==='480p')continue;var _0x8ad359=_0x52cacc[_0x19a4b3(_0x1381f4._0x12769a)],_0x149d52=_0x20fe67['substring'](Math[_0x19a4b3(_0x1381f4._0x104fab)](0x0,_0x8ad359-0xc8),_0x8ad359+0x258),_0x39b7b3=_0x149d52['match'](/href="(https:\/\/hubcloud\.cx\/(?:drive|video)\/[^"]+)"/i),_0x1ec54e=_0x149d52['match'](/href="(https:\/\/href\.li\/\?https:\/\/vcloud\.zip\/[^"]+)"/i);if(_0x39b7b3)_0x23729e['push']({'quality':_0x187712,'size':_0x1d7858,'type':'hubcloud','url':_0x39b7b3[0x1]});else{if(_0x1ec54e)_0x23729e['push']({'quality':_0x187712,'size':_0x1d7858,'type':_0x19a4b3(_0x1381f4._0x1d402d),'url':_0x1ec54e[0x1]});}}return _0x23729e;}function extractVcloudUrl(_0x4692d9){var _0x323fa6={_0x13d9bc:0x17d},_0x3ff589=_0x310f1c,_0x2d1ca4=_0x4692d9[_0x3ff589(_0x323fa6._0x13d9bc)](/href\.li\/\?https:\/\/vcloud\.zip\/([^"&?]+)/i);if(_0x2d1ca4)return'https://vcloud.zip/'+_0x2d1ca4[0x1];return null;}function processHubcloud(_0x53d57c){var _0x29dded={_0x1b8937:0x190,_0x7e4ecd:0x171,_0x1e1360:0x176};return __async(this,null,function*(){var _0x4e56c7=_0x2f28,_0x66e1d6=yield fetchText(_0x53d57c,{'headers':hdrs({'Referer':abhilinksBase+'/'})});if(!_0x66e1d6)return null;var _0x4af464=_0x66e1d6['match'](/href="(https:\/\/[^"]*hubcloud\.php[^"]*)"/i);if(!_0x4af464)return null;var _0x44815f=_0x4af464[0x1][_0x4e56c7(0x137)](/&amp;/g,'&'),_0x2fd0cb=_0x4e56c7(_0x29dded._0x1b8937),_0x1bad6c=yield fetchText(_0x44815f,{'headers':{'User-Agent':_0x2fd0cb,'Accept':_0x4e56c7(_0x29dded._0x7e4ecd),'Accept-Language':_0x4e56c7(0x135),'Referer':_0x53d57c,'DNT':'1','Cookie':'xla=s4t'}});if(!_0x1bad6c||_0x1bad6c[_0x4e56c7(_0x29dded._0x1e1360)]<0x1f4)return null;return extractFSLLinks(_0x1bad6c);});}function _0x2f28(_0x4047aa,_0x53f8be){_0x4047aa=_0x4047aa-0x123;var _0x16beae=_0x16be();var _0x2f285b=_0x16beae[_0x4047aa];if(_0x2f28['LzjmQW']===undefined){var _0xc5914c=function(_0x1b0fae){var _0xb3db34='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';var _0x1750ab='',_0x374b0d='';for(var _0x425222=0x0,_0x25582f,_0x5b90ea,_0x55645f=0x0;_0x5b90ea=_0x1b0fae['charAt'](_0x55645f++);~_0x5b90ea&&(_0x25582f=_0x425222%0x4?_0x25582f*0x40+_0x5b90ea:_0x5b90ea,_0x425222++%0x4)?_0x1750ab+=String['fromCharCode'](0xff&_0x25582f>>(-0x2*_0x425222&0x6)):0x0){_0x5b90ea=_0xb3db34['indexOf'](_0x5b90ea);}for(var _0x17ebe3=0x0,_0x5dc19c=_0x1750ab['length'];_0x17ebe3<_0x5dc19c;_0x17ebe3++){_0x374b0d+='%'+('00'+_0x1750ab['charCodeAt'](_0x17ebe3)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x374b0d);};_0x2f28['ruJRDY']=_0xc5914c,_0x2f28['EdYqyz']={},_0x2f28['LzjmQW']=!![];}var _0xd9de81=_0x16beae[0x0],_0x3cb9c4=_0x4047aa+_0xd9de81,_0x2c6f23=_0x2f28['EdYqyz'][_0x3cb9c4];return!_0x2c6f23?(_0x2f285b=_0x2f28['ruJRDY'](_0x2f285b),_0x2f28['EdYqyz'][_0x3cb9c4]=_0x2f285b):_0x2f285b=_0x2c6f23,_0x2f285b;}function processVcloud(_0x2103c8){return __async(this,null,function*(){var _0x17ac52=_0x2f28,_0xe77736=yield fetchText(_0x2103c8,{'headers':hdrs({'Referer':abhilinksBase+'/'})});if(!_0xe77736)return null;var _0x55d29d=_0xe77736['match'](/atob\s*\(\s*atob\s*\(\s*['"]([^'"]+)['"]\s*\)\s*\)/);if(!_0x55d29d)return null;var _0x43d203,_0x22cb2a;try{_0x43d203=atob(_0x55d29d[0x1]),_0x22cb2a=atob(_0x43d203);}catch(_0x395319){return null;}var _0x2597d7=yield fetchText(_0x22cb2a,{'headers':hdrs({'Referer':movieshuntBase+'/','Cookie':_0x17ac52(0x178)})});if(!_0x2597d7)return null;return extractFSLLinks(_0x2597d7);});}function extractFSLLinks(_0x325d9b){var _0x3b0ffd={_0x492a8f:0x137,_0x33b0b5:0x174,_0x315366:0x174,_0x2ba6f9:0x174,_0x55f5db:0x16e,_0xb72fea:0x174,_0x3bb4b6:0x132,_0x202d72:0x174,_0x25ea77:0x191,_0x4dedf1:0x14a,_0x48b91d:0x14f},_0x5af520=_0x310f1c,_0x208d5b=[],_0x1b3a38=_0x325d9b[_0x5af520(0x17d)](/<a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi);if(!_0x1b3a38)return _0x208d5b;for(var _0x40e07e=0x0;_0x40e07e<_0x1b3a38[_0x5af520(0x176)];_0x40e07e++){var _0x1ad292=_0x1b3a38[_0x40e07e],_0x2e9704=_0x1ad292['match'](/href="([^"]+)"/i),_0x6ea2d4=_0x1ad292['match'](/>([\s\S]*?)<\/a>/i);if(!_0x2e9704)continue;var _0x2f5eb1=_0x2e9704[0x1]['replace'](/&amp;/g,'&'),_0x4e905b=_0x6ea2d4?_0x6ea2d4[0x1][_0x5af520(_0x3b0ffd._0x492a8f)](/<[^>]+>/g,'')['trim']():'';if(!_0x2f5eb1||_0x2f5eb1[_0x5af520(0x123)]('javascript:')===0x0)continue;if(/telegram/i[_0x5af520(0x174)](_0x4e905b)||/tg\//i[_0x5af520(_0x3b0ffd._0x33b0b5)](_0x2f5eb1)||/pixeldrain/i[_0x5af520(_0x3b0ffd._0x315366)](_0x2f5eb1))continue;if(/hubcloud\.cx|gpdl2/i[_0x5af520(0x174)](_0x2f5eb1))continue;var _0x1ba466='';if(/cdn\.fsl-buckets\.life/i['test'](_0x2f5eb1)||/r2\.cloudflarestorage/i['test'](_0x2f5eb1)||/r2\.dev/i[_0x5af520(_0x3b0ffd._0x2ba6f9)](_0x2f5eb1))_0x1ba466=_0x5af520(_0x3b0ffd._0x55f5db);else{if(/hub\.(latent|whistle)/i[_0x5af520(_0x3b0ffd._0xb72fea)](_0x2f5eb1))_0x1ba466=_0x5af520(_0x3b0ffd._0x3bb4b6);else{if(/workers\.dev/i[_0x5af520(_0x3b0ffd._0x202d72)](_0x2f5eb1))_0x1ba466=_0x5af520(_0x3b0ffd._0x25ea77);else continue;}}var _0x41d550='',_0x40aab7=_0x4e905b['match'](/(2160|1080|720|480)\s*[pP]/i);if(_0x40aab7)_0x41d550=_0x40aab7[0x1][_0x5af520(_0x3b0ffd._0x4dedf1)]()+'p';_0x208d5b[_0x5af520(_0x3b0ffd._0x48b91d)]({'url':_0x2f5eb1,'type':_0x1ba466,'quality':_0x41d550,'rawText':_0x4e905b});}return _0x208d5b;}function dedupe(_0x4bf438){var _0x160ba3={_0x41daf6:0x18f},_0x592ea8={_0x2708f3:0x141,_0x2807bd:0x141},_0x1b456c=_0x310f1c,_0x461301={};return(_0x4bf438||[])[_0x1b456c(_0x160ba3._0x41daf6)](function(_0xf9c09c){var _0xbe5ab2=_0x1b456c;if(!_0xf9c09c||!_0xf9c09c[_0xbe5ab2(_0x592ea8._0x2708f3)])return![];if(_0x461301[_0xf9c09c['url']])return![];return _0x461301[_0xf9c09c[_0xbe5ab2(_0x592ea8._0x2807bd)]]=!![],!![];});}function extractEpisodes(_0x2e4c8d){var _0xa7d4ad={_0x3e26a1:0x14f,_0x6116a8:0x13b},_0x7fee0=_0x310f1c,_0x5df0a0=[],_0x399c5c=/-:\s*Episodes?\s*:\s*(\d+)\s*:-/gi,_0x1031cb=[],_0x5dc188;while((_0x5dc188=_0x399c5c[_0x7fee0(0x13b)](_0x2e4c8d))!==null)_0x1031cb[_0x7fee0(_0xa7d4ad._0x3e26a1)]({'num':parseInt(_0x5dc188[0x1]),'idx':_0x5dc188['index']});if(_0x1031cb['length']===0x0){var _0x4f1092=/>\s*Episode\s*(\d+)\s*</gi;while((_0x5dc188=_0x4f1092[_0x7fee0(_0xa7d4ad._0x6116a8)](_0x2e4c8d))!==null)_0x1031cb['push']({'num':parseInt(_0x5dc188[0x1]),'idx':_0x5dc188[_0x7fee0(0x177)]});}for(var _0x4e001d=0x0;_0x4e001d<_0x1031cb[_0x7fee0(0x176)];_0x4e001d++){var _0x152570=_0x1031cb[_0x4e001d][_0x7fee0(0x170)],_0x4df64b=_0x4e001d+0x1<_0x1031cb['length']?_0x1031cb[_0x4e001d+0x1][_0x7fee0(0x170)]:_0x2e4c8d['length'],_0xd81823=_0x2e4c8d[_0x7fee0(0x13a)](_0x152570,_0x4df64b),_0x465b63=[],_0x5051a2=/href="(https:\/\/hubcloud\.cx\/(?:drive|video)\/[^"]+)"/gi,_0x2be59c;while((_0x2be59c=_0x5051a2['exec'](_0xd81823))!==null)_0x465b63['push']({'type':_0x7fee0(0x139),'url':_0x2be59c[0x1]});var _0xfbf45f=/href="(https:\/\/href\.li\/\?https:\/\/vcloud\.zip\/[^"]+)"/gi;while((_0x2be59c=_0xfbf45f['exec'](_0xd81823))!==null){var _0x43559a=extractVcloudUrl(_0x2be59c[0x1]);if(_0x43559a)_0x465b63[_0x7fee0(0x14f)]({'type':_0x7fee0(0x138),'url':_0x43559a});}if(_0x465b63['length'])_0x5df0a0['push']({'number':_0x1031cb[_0x4e001d]['num'],'links':_0x465b63});}return _0x5df0a0;}function extractSeasonLinks(_0x1dcfe6){var _0xf0fc92={_0x4eb7d7:0x177,_0x50b10e:0x176,_0x9ea5ee:0x17d,_0x5ab49c:0x13a,_0x455ca5:0x17d},_0x42784f=_0x310f1c,_0x270685={},_0xfbb9da=/<h4[^>]*>([\s\S]*?)<\/h4>/gi,_0x24646c=[],_0xb06cca;while((_0xb06cca=_0xfbb9da['exec'](_0x1dcfe6))!==null)_0x24646c[_0x42784f(0x14f)]({'inner':_0xb06cca[0x1],'start':_0xb06cca[_0x42784f(0x177)],'end':_0xb06cca[_0x42784f(_0xf0fc92._0x4eb7d7)]+_0xb06cca[0x0][_0x42784f(0x176)]});for(var _0x502eff=0x0;_0x502eff<_0x24646c[_0x42784f(_0xf0fc92._0x50b10e)];_0x502eff++){var _0x1299b2=_0x24646c[_0x502eff],_0x452671=_0x1299b2['inner'][_0x42784f(_0xf0fc92._0x9ea5ee)](/Season\s+(\d+)/i),_0x213cb1=_0x1299b2[_0x42784f(0x13f)]['match'](/(\d+p)/i);if(!_0x452671||!_0x213cb1)continue;var _0x33c6cc=parseInt(_0x452671[0x1]),_0x318229=_0x213cb1[0x1]['toLowerCase'](),_0x515b3a=_0x24646c[_0x502eff]['end'],_0x74b9de=_0x502eff+0x1<_0x24646c[_0x42784f(0x176)]?_0x24646c[_0x502eff+0x1]['start']:_0x1dcfe6['length'],_0x3b2681=_0x1dcfe6[_0x42784f(_0xf0fc92._0x5ab49c)](_0x515b3a,_0x74b9de),_0x331be4=_0x3b2681[_0x42784f(_0xf0fc92._0x455ca5)](/href="(https:\/\/abhilinks\.(?:life|site)\/archives\/\d+)\/?"/i);if(_0x331be4){if(!_0x270685[_0x33c6cc])_0x270685[_0x33c6cc]={};if(!_0x270685[_0x33c6cc][_0x318229])_0x270685[_0x33c6cc][_0x318229]=_0x331be4[0x1];}}return _0x270685;}function parseLanguage(_0xf8242d){var _0x32745b={_0x5187dd:0x15f,_0x8de059:0x156,_0x4e8fa6:0x152,_0x1ab9c7:0x123,_0x50c3a8:0x187},_0x46c742=_0x310f1c,_0x3212f6=String(_0xf8242d||'')['toLowerCase'](),_0x3170a9=['tamil',_0x46c742(_0x32745b._0x5187dd),_0x46c742(_0x32745b._0x8de059),_0x46c742(0x198),'kannada',_0x46c742(_0x32745b._0x4e8fa6),'punjabi'],_0x39de57=0x0;for(var _0x2df865=0x0;_0x2df865<_0x3170a9['length'];_0x2df865++){if(_0x3212f6[_0x46c742(_0x32745b._0x1ab9c7)](_0x3170a9[_0x2df865])!==-0x1)_0x39de57++;}if(_0x39de57>=0x1||_0x3212f6[_0x46c742(0x123)]('multi')!==-0x1)return _0x46c742(_0x32745b._0x50c3a8);if(_0x3212f6[_0x46c742(0x123)](_0x46c742(0x196))!==-0x1||_0x3212f6['indexOf']('hindi')!==-0x1&&_0x3212f6['indexOf']('english')!==-0x1)return'Dual-Audio';return'Dual-Audio';}function buildDropdownMetadata(_0x2540b4,_0x3938c2,_0x3eebc5,_0x39a9a8,_0x492dd4,_0x17f4f6,_0x25a629,_0x58dbe6,_0xef4265){var _0x233868={_0x5bc085:0x130,_0x59a387:0x14e,_0x2d54ca:0x17a,_0x5e5daa:0x12e,_0x14c2fc:0x123,_0x12c8a0:0x144,_0x971a9b:0x17f,_0x2bdfd1:0x123,_0x65d70a:0x124,_0x4f7b77:0x199,_0x8adf0e:0x158,_0x1286a5:0x123,_0x4978b0:0x123,_0x3c94ee:0x168,_0xfa1a19:0x182,_0x52fc18:0x14f,_0x55a12a:0x160,_0xfafe3a:0x167,_0x3d9489:0x131,_0x3041f9:0x123,_0x1315e4:0x153,_0x359870:0x14c,_0x3066e4:0x172,_0x5e21ba:0x12c,_0x565ab5:0x188,_0xe83cc1:0x193},_0x2fe5f2=_0x310f1c,_0x30c874=(_0x492dd4?_0x2540b4[_0x2fe5f2(_0x233868._0x5bc085)]:_0x2540b4[_0x2fe5f2(_0x233868._0x59a387)])||'Unknown\x20Title',_0x141c2a=_0x492dd4?(_0x2540b4[_0x2fe5f2(0x13c)]||'')['split']('-')[0x0]:(_0x2540b4[_0x2fe5f2(_0x233868._0x2d54ca)]||'')['split']('-')[0x0],_0x15e228=_0x141c2a?'\x20('+_0x141c2a+')':'',_0xb426f5=(String(_0x58dbe6)+'\x20'+String(_0xef4265))[_0x2fe5f2(0x14a)](),_0x3c2e97=_0x492dd4?'🎬\x20':_0x2fe5f2(_0x233868._0x5e5daa),_0x36a88b=_0x3c2e97+_0x30c874+_0x15e228;_0x492dd4&&_0x17f4f6!=null&&_0x25a629!=null&&(_0x36a88b+=_0x2fe5f2(0x148)+String(_0x17f4f6)[_0x2fe5f2(0x12a)](0x2,'0')+'\x20E'+String(_0x25a629)[_0x2fe5f2(0x12a)](0x2,'0'));var _0x2db396='💎';if(_0x3938c2[_0x2fe5f2(_0x233868._0x14c2fc)](_0x2fe5f2(_0x233868._0x12c8a0))!==-0x1||_0x3938c2['indexOf']('4k')!==-0x1)_0x2db396='🌟';else{if(_0x3938c2[_0x2fe5f2(_0x233868._0x14c2fc)]('1080')!==-0x1)_0x2db396='🔥';}var _0xe81952=_0xb426f5[_0x2fe5f2(0x17d)](/(\d+(?:\.\d+)?\s*(?:gb|mb))/i),_0x7fbdb=_0xe81952?_0xe81952[0x1][_0x2fe5f2(_0x233868._0x971a9b)]():_0x3eebc5||'Variable\x20Size',_0xbaf3b1=_0x2db396+'\x20'+_0x3938c2+'\x20|\x20💾\x20'+_0x7fbdb,_0x2ab57f='SDR';if(_0xb426f5[_0x2fe5f2(_0x233868._0x2bdfd1)](_0x2fe5f2(_0x233868._0x65d70a))!==-0x1)_0x2ab57f='HDR10+';else{if(_0xb426f5['indexOf'](_0x2fe5f2(_0x233868._0x4f7b77))!==-0x1)_0x2ab57f='HDR10';else{if(_0xb426f5[_0x2fe5f2(_0x233868._0x2bdfd1)](_0x2fe5f2(_0x233868._0x8adf0e))!==-0x1)_0x2ab57f='HDR';}}var _0x2a4c49='';if(_0xb426f5[_0x2fe5f2(0x123)](_0x2fe5f2(0x189))!==-0x1||_0xb426f5[_0x2fe5f2(_0x233868._0x1286a5)]('10-bit')!==-0x1)_0x2a4c49='\x20•\x2010Bit';var _0xf4553e=_0x2fe5f2(0x162);if(_0xb426f5[_0x2fe5f2(0x123)]('hevc')!==-0x1)_0xf4553e='⚡\x20HEVC';else{if(_0xb426f5[_0x2fe5f2(_0x233868._0x4978b0)](_0x2fe5f2(0x166))!==-0x1||_0xb426f5['indexOf']('h265')!==-0x1)_0xf4553e=_0x2fe5f2(0x186);}var _0x5b5a90=_0xef4265[_0x2fe5f2(0x123)]('.mp4')!==-0x1?'MP4':_0x2fe5f2(_0x233868._0x3c94ee),_0x17a161=_0x2fe5f2(0x143)+_0x2ab57f+_0x2a4c49+'\x20|\x20'+_0xf4553e+'\x20|\x20📦\x20'+_0x5b5a90,_0x4798cc=parseLanguage(_0xb426f5),_0x5819bf=[];if(_0xb426f5['indexOf'](_0x2fe5f2(_0x233868._0xfa1a19))!==-0x1||_0xb426f5[_0x2fe5f2(0x123)]('ddp\x205.1')!==-0x1)_0x5819bf[_0x2fe5f2(_0x233868._0x52fc18)]('DDP5.1');if(_0xb426f5['indexOf']('truehd')!==-0x1)_0x5819bf['push'](_0x2fe5f2(_0x233868._0x55a12a));if(_0xb426f5[_0x2fe5f2(0x123)]('dd5.1')!==-0x1||_0xb426f5['indexOf'](_0x2fe5f2(0x136))!==-0x1){if(_0x5819bf['indexOf']('DDP5.1')===-0x1)_0x5819bf['push'](_0x2fe5f2(_0x233868._0xfafe3a));}_0x5819bf[_0x2fe5f2(0x176)]===0x0&&_0x5819bf[_0x2fe5f2(0x14f)](_0x2fe5f2(0x195));var _0x4f648b=_0x5819bf[_0x2fe5f2(0x126)](_0x2fe5f2(_0x233868._0x3d9489)),_0x19840c=_0xb426f5[_0x2fe5f2(_0x233868._0x3041f9)](_0x2fe5f2(_0x233868._0x1315e4))!==-0x1?_0x2fe5f2(0x15c):'',_0x34f959=_0x2fe5f2(_0x233868._0x359870)+_0x4798cc+_0x2fe5f2(_0x233868._0x3066e4)+_0x4f648b+_0x19840c,_0x4a18c5=_0x2fe5f2(_0x233868._0x5e21ba);if(_0xb426f5[_0x2fe5f2(0x123)](_0x2fe5f2(0x13e))!==-0x1||_0xb426f5[_0x2fe5f2(0x123)](_0x2fe5f2(0x18a))!==-0x1)_0x4a18c5=_0x2fe5f2(_0x233868._0x565ab5);else{if(_0xb426f5[_0x2fe5f2(0x123)]('bluray')!==-0x1)_0x4a18c5='💿\x20Blu-Ray';}var _0x491e25=_0x2fe5f2(_0x233868._0xe83cc1)+(_0x39a9a8||'FSL')+_0x2fe5f2(0x18c)+_0x4a18c5;return _0x36a88b+'\x0a'+_0xbaf3b1+'\x0a'+_0x17a161+'\x0a'+_0x34f959+'\x0a'+_0x491e25;}function getStreams(_0x4eaad3,_0x54ad2f,_0x47391e,_0x3af7cd){var _0x4c0c61={_0x4b2692:0x159,_0x4b6244:0x194,_0x1d633e:0x183,_0x2de632:0x176,_0x4c91a:0x18e,_0xede543:0x197,_0x5d8f1d:0x175,_0x1f52c5:0x16c,_0x8c230b:0x176,_0x2534e4:0x192,_0x128ddf:0x176,_0x3f9876:0x180,_0x9d4b59:0x141,_0x2f6303:0x173,_0x2cd511:0x18c,_0x5f3bca:0x14d,_0x3d8cac:0x14b,_0xbdc23a:0x141,_0xc36a42:0x14f,_0x1268d2:0x16c,_0x16c8b0:0x163,_0x4a0f0c:0x129};return __async(this,null,function*(){var _0x55280c={_0x543986:0x14a,_0x4d6e91:0x16d},_0x4a0b41=_0x2f28;currentUA=UAS[Math[_0x4a0b41(0x145)](Math[_0x4a0b41(0x155)]()*UAS['length'])],log('getStreams('+_0x4eaad3+',\x20'+_0x54ad2f+',\x20'+_0x47391e+',\x20'+_0x3af7cd+')');var _0x1d261e=_0x54ad2f==='tv'||_0x54ad2f==='series',_0x559f11=yield getTMDBInfo(_0x4eaad3,_0x54ad2f);if(!_0x559f11)return log('TMDB\x20fetch\x20failed'),[];var _0x48efd9=_0x1d261e?_0x559f11['name']:_0x559f11[_0x4a0b41(0x14e)];if(!_0x48efd9)return log(_0x4a0b41(_0x4c0c61._0x4b2692)),[];log(_0x4a0b41(_0x4c0c61._0x4b6244)+_0x48efd9);var _0x28eb64=yield searchSite(_0x48efd9);if(!_0x28eb64||!_0x28eb64['length'])return log(_0x4a0b41(_0x4c0c61._0x1d633e)),[];log('Search\x20results:\x20'+_0x28eb64['length']);var _0x38c2d1=matchHits(_0x28eb64,_0x559f11,_0x1d261e);if(!_0x38c2d1[_0x4a0b41(_0x4c0c61._0x2de632)])return log('No\x20match\x20found'),[];log(_0x4a0b41(_0x4c0c61._0x4c91a)+_0x38c2d1[_0x4a0b41(_0x4c0c61._0x2de632)]);for(var _0x5a23b5=0x0;_0x5a23b5<_0x38c2d1['length'];_0x5a23b5++){let _0x15d98d=function(_0x11a14c){var _0x2ff857=_0x4a0b41,_0x8fb4e7=_0x11a14c[_0x2ff857(_0x55280c._0x543986)]();if(_0x8fb4e7['indexOf']('2160p')!==-0x1||_0x8fb4e7[_0x2ff857(0x123)]('4k')!==-0x1)return 0x870;if(_0x8fb4e7[_0x2ff857(0x123)](_0x2ff857(_0x55280c._0x4d6e91))!==-0x1)return 0x438;if(_0x8fb4e7['indexOf']('720p')!==-0x1)return 0x2d0;if(_0x8fb4e7['indexOf']('480p')!==-0x1)return 0x1e0;return 0x0;};var _0xf73bc6=_0x15d98d,_0x577933=_0x38c2d1[_0x5a23b5],_0x22a0ab=_0x577933['url'];log(_0x4a0b41(0x140)+_0x22a0ab);var _0x1a6162=yield fetchText(_0x22a0ab,{'headers':hdrs()});if(!_0x1a6162)continue;var _0x18a46d=[];if(_0x1d261e){var _0xc7baca=_0x47391e!==void 0x0&&_0x47391e!==null&&_0x47391e!==_0x4a0b41(_0x4c0c61._0xede543)?parseInt(_0x47391e):null,_0x17d273=_0x3af7cd!==void 0x0&&_0x3af7cd!==null&&_0x3af7cd!=='undefined'?parseInt(_0x3af7cd):null,_0x2240f8=[];if(_0xc7baca){var _0x2a618e=extractSeasonLinks(_0x1a6162);if(_0x2a618e[_0xc7baca]){var _0x29427b=Object[_0x4a0b41(_0x4c0c61._0x5d8f1d)](_0x2a618e[_0xc7baca])[_0x4a0b41(_0x4c0c61._0x1f52c5)](function(_0xaa4366,_0x109acb){return parseInt(_0x109acb)-parseInt(_0xaa4366);});_0x29427b['forEach'](function(_0x1b2eae){var _0x40fcec=_0x4a0b41;_0x2240f8[_0x40fcec(0x14f)]({'quality':_0x1b2eae,'url':_0x2a618e[_0xc7baca][_0x1b2eae]});}),log('S'+_0xc7baca+'\x20qualities:\x20'+_0x29427b[_0x4a0b41(0x126)](',\x20'));}}if(!_0x2240f8[_0x4a0b41(0x176)]){var _0x397b2c=extractAbhilinksUrl(_0x1a6162);if(_0x397b2c)_0x2240f8[_0x4a0b41(0x14f)]({'quality':'','url':_0x397b2c});}if(!_0x2240f8['length']){log('No\x20abhilinks\x20URLs,\x20trying\x20next\x20match');continue;}var _0x2f8b07=[];for(var _0xe8c940=0x0;_0xe8c940<_0x2240f8['length'];_0xe8c940++){var _0x508206=_0x2240f8[_0xe8c940];log('Fetching\x20'+(_0x508206['quality']||'default')+':\x20'+_0x508206[_0x4a0b41(0x141)]);var _0x119a5f=yield fetchText(_0x508206[_0x4a0b41(0x141)],{'headers':hdrs()});if(!_0x119a5f){log(_0x4a0b41(0x128));continue;}var _0x3c8677=extractEpisodes(_0x119a5f);if(!_0x3c8677[_0x4a0b41(_0x4c0c61._0x8c230b)]){log('\x20\x20no\x20episodes');continue;}var _0x1aecaf=_0x3c8677;if(_0x17d273){_0x1aecaf=_0x3c8677[_0x4a0b41(0x18f)](function(_0x70348b){return _0x70348b['number']===_0x17d273;});if(!_0x1aecaf[_0x4a0b41(0x176)]){log('\x20\x20episode\x20'+_0x17d273+'\x20not\x20found');continue;}}for(var _0x468cdf=0x0;_0x468cdf<_0x1aecaf['length'];_0x468cdf++){var _0xbf76d9=_0x1aecaf[_0x468cdf];for(var _0x493863=0x0;_0x493863<_0xbf76d9[_0x4a0b41(0x192)]['length'];_0x493863++){var _0x51e685=_0xbf76d9[_0x4a0b41(_0x4c0c61._0x2534e4)][_0x493863];_0x2f8b07['push'](function(_0x109088,_0x4274d7,_0x2636b4){var _0x517c5b={_0x177b73:0x173};return function(){var _0x4f6a8c={_0x4f48ef:0x14b};return __async(this,null,function*(){var _0x5d22fb=_0x2f28,_0x3e6ce7=null;if(_0x4274d7['type']==='hubcloud')_0x3e6ce7=yield processHubcloud(_0x4274d7[_0x5d22fb(0x141)]);else{if(_0x4274d7[_0x5d22fb(_0x517c5b._0x177b73)]===_0x5d22fb(0x138))_0x3e6ce7=yield processVcloud(_0x4274d7['url']);}return _0x3e6ce7&&_0x3e6ce7['forEach'](function(_0x4bfed7){var _0x3b60ef=_0x5d22fb;_0x4bfed7['episode']=_0x109088,_0x4bfed7[_0x3b60ef(_0x4f6a8c._0x4f48ef)]=_0x4bfed7['quality']||_0x2636b4;}),_0x3e6ce7;});};}(_0xbf76d9['number'],_0x51e685,_0x508206[_0x4a0b41(0x14b)]));}}}if(!_0x2f8b07[_0x4a0b41(_0x4c0c61._0x128ddf)]){log(_0x4a0b41(_0x4c0c61._0x3f9876));continue;}log('Processing\x20'+_0x2f8b07['length']+'\x20hubcloud/vcloud\x20links...');var _0x2ad642=yield Promise['all'](_0x2f8b07['map'](function(_0x17c2e4){return _0x17c2e4();}));for(var _0x38c39d=0x0;_0x38c39d<_0x2ad642['length'];_0x38c39d++){if(!_0x2ad642[_0x38c39d])continue;for(var _0x2f1a14=0x0;_0x2f1a14<_0x2ad642[_0x38c39d][_0x4a0b41(0x176)];_0x2f1a14++){var _0x1be39f=_0x2ad642[_0x38c39d][_0x2f1a14],_0x47b640=(_0x1be39f[_0x4a0b41(0x14b)]||'')['toLowerCase']();if(_0x47b640==='480p'||_0x47b640==='hd')continue;var _0x59b4d2=_0x47b640||_0x4a0b41(0x16d),_0x28ea33=(_0x1be39f['rawText']||'')+'\x20'+_0x1be39f[_0x4a0b41(_0x4c0c61._0x9d4b59)],_0x4c389f=parseLanguage(_0x28ea33),_0x8ec37b=buildDropdownMetadata(_0x559f11,_0x59b4d2,'',_0x1be39f[_0x4a0b41(_0x4c0c61._0x2f6303)],!![],_0xc7baca,_0x1be39f['episode'],_0x28ea33,_0x1be39f[_0x4a0b41(_0x4c0c61._0x9d4b59)]);_0x18a46d[_0x4a0b41(0x14f)]({'name':PROVIDER_NAME+_0x4a0b41(_0x4c0c61._0x2cd511)+_0x59b4d2+_0x4a0b41(_0x4c0c61._0x2cd511)+_0x4c389f,'title':_0x8ec37b,'size':_0x8ec37b,'description':_0x8ec37b,'url':_0x1be39f[_0x4a0b41(0x141)],'quality':'','language':'','headers':{'Referer':movieshuntBase+'/','User-Agent':currentUA}});}}}else{var _0xdafffd=extractAbhilinksUrl(_0x1a6162);if(!_0xdafffd){log('No\x20abhilinks\x20URL,\x20trying\x20next\x20match');continue;}log('Abhilinks:\x20'+_0xdafffd);var _0x119a5f=yield fetchText(_0xdafffd,{'headers':hdrs()});if(!_0x119a5f){log(_0x4a0b41(0x169));continue;}var _0x1ef9b7=extractQualityOptions(_0x119a5f);if(!_0x1ef9b7[_0x4a0b41(_0x4c0c61._0x128ddf)]){log('No\x20quality\x20options\x20found');continue;}log('Quality\x20options:\x20'+_0x1ef9b7['length']);var _0x509d32=[];for(var _0x253041=0x0;_0x253041<_0x1ef9b7['length'];_0x253041++){var _0x52c1cf=_0x1ef9b7[_0x253041];_0x509d32['push'](function(_0x4ee6a2){var _0x1e2843={_0x3d0a87:0x141};return function(){return __async(this,null,function*(){var _0x4acf5b=_0x2f28;if(_0x4ee6a2[_0x4acf5b(0x173)]==='hubcloud')return yield processHubcloud(_0x4ee6a2['url']);else{if(_0x4ee6a2['type']==='vcloud'){var _0x1dda2b=extractVcloudUrl(_0x4ee6a2[_0x4acf5b(_0x1e2843._0x3d0a87)]);if(!_0x1dda2b)return null;return yield processVcloud(_0x1dda2b);}}return null;});};}(_0x52c1cf));}var _0x49b302=yield Promise[_0x4a0b41(_0x4c0c61._0x5f3bca)](_0x509d32['map'](function(_0x5369f0){return _0x5369f0();}));for(var _0x1af6e8=0x0;_0x1af6e8<_0x49b302['length'];_0x1af6e8++){if(!_0x49b302[_0x1af6e8])continue;var _0x3d2802=_0x1ef9b7[_0x1af6e8];for(var _0x1a2da9=0x0;_0x1a2da9<_0x49b302[_0x1af6e8][_0x4a0b41(0x176)];_0x1a2da9++){var _0x1d7dd6=_0x49b302[_0x1af6e8][_0x1a2da9],_0x50492a=(_0x1d7dd6[_0x4a0b41(_0x4c0c61._0x3d8cac)]||_0x3d2802[_0x4a0b41(0x14b)]||'')['toLowerCase']();if(_0x50492a===_0x4a0b41(0x15e)||_0x50492a==='hd')continue;var _0x59b4d2=_0x50492a||'1080p',_0x4eed6b=_0x3d2802['size']||'',_0x28ea33=(_0x1d7dd6[_0x4a0b41(0x16b)]||'')+'\x20'+_0x1d7dd6[_0x4a0b41(_0x4c0c61._0xbdc23a)]+'\x20'+_0x4eed6b,_0x4c389f=parseLanguage(_0x28ea33),_0x8ec37b=buildDropdownMetadata(_0x559f11,_0x59b4d2,_0x4eed6b,_0x1d7dd6['type'],![],null,null,_0x28ea33,_0x1d7dd6[_0x4a0b41(0x141)]);_0x18a46d[_0x4a0b41(_0x4c0c61._0xc36a42)]({'name':'🏹\x20'+PROVIDER_NAME+_0x4a0b41(_0x4c0c61._0x2cd511)+_0x59b4d2+'\x20|\x20'+_0x4c389f,'title':_0x8ec37b,'size':_0x8ec37b,'description':_0x8ec37b,'url':_0x1d7dd6['url'],'quality':'','language':'','headers':{'Referer':movieshuntBase+'/','User-Agent':currentUA}});}}}_0x18a46d=dedupe(_0x18a46d),_0x18a46d[_0x4a0b41(_0x4c0c61._0x1268d2)](function(_0x4c9389,_0x8a7a04){var _0xc86f46=_0x4a0b41;return _0x15d98d(_0x8a7a04['name'])-_0x15d98d(_0x4c9389[_0xc86f46(0x130)]);});if(_0x18a46d['length']>0x0)return log('Returning\x20'+_0x18a46d[_0x4a0b41(_0x4c0c61._0x8c230b)]+_0x4a0b41(_0x4c0c61._0x16c8b0)+_0x22a0ab),_0x18a46d;log(_0x4a0b41(_0x4c0c61._0x4a0f0c));}return log('No\x20streams\x20from\x20any\x20match'),[];});}typeof module!=='undefined'&&module[_0x310f1c(0x165)]?module['exports']={'getStreams':getStreams}:global['getStreams']=getStreams;

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "movieshunt", ["movie"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_PLAYIMDB_DISPLAY_START */
/* CLOUDBANK_PLAYIMDB_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  if (providerId === "playimdb") return provider; // Reference output stays exactly upstream.
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name) || (lines.length ? lines[0] : "");
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    var labelledAudio = /🌍\s*([^|\n]+)/.exec(originalTitle);
    if (!audioLang && labelledAudio) audioLang = language(labelledAudio[1]);
    var filenameAudio = /(?:^|[._ -])(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese)(?=[._ -]|$)/i.exec(clean(stream.fileName || stream.filename));
    if (!audioLang && filenameAudio) audioLang = language(filenameAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage)) || /\boriginal[- ]audio\b/i.test(text)) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    var labelledServer = /📌\s*([^|\n]+)/.exec(originalTitle);
    if (!server && labelledServer) server = usable(labelledServer[1]);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    var firstLine = lines.length ? "🎬 " + lines[0] : "";
    // Match PlayIMDb's original typography and order, without its guessed defaults.
    if (displayTitle) {
      firstLine = type === "tv" ? "🎬 " + usable(meta.title || meta.name) + " - S" + Number(season) + "E" + Number(episode) + (year ? " (" + year[0] + ")" : "") :
        "🎬 " + usable(meta.title || meta.name) + (year ? " - " + year[0] : "");
    }
    var qualityDisplay = qualityLabel === "4K" ? "2160P" : qualityLabel.toUpperCase();
    var audioDisplay = audioLabel.replace(/[- ]Audio/g, "").trim();
    var infoLine = [qualityDisplay ? "💎 " + qualityDisplay : "", audioDisplay ? "🌍 " + audioDisplay : ""].filter(Boolean).join(" | ");
    var bottomLine = [formatLabel ? "🎞️ " + (formatLabel === "HLS" ? "M3U8" : formatLabel) : "", duration ? "⏱️ " + duration : "", "📌 " + server].filter(Boolean).join(" | ");
    var nameQuality = qualityLabel === "4K" ? "4K UHD" : qualityLabel === "1080p" ? "1080p FHD" : qualityLabel === "720p" ? "720p HD" : qualityLabel;
    output.name = ["🟡 " + providerName, nameQuality, audioLabel ? audioLabel.replace(/ Audio/g, "-Audio") : ""].filter(Boolean).join(" | ");
    output.title = [firstLine, infoLine, bottomLine].filter(Boolean).join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "🎬 MoviesHunt", "movieshunt");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
/* CLOUDBANK_PLAYIMDB_DISPLAY_END */
