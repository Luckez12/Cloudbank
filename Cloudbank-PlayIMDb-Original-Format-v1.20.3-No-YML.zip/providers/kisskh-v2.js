// Imported provider: kisskh-v2; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
const _0x41778f=_0x33a8;(function(_0x104ed8,_0x594abf){const _0x19fed8={_0x472805:0x1d9,_0xb7e4e9:0x1e0,_0x427a29:0x1d4},_0x476bef=_0x33a8,_0x125229=_0x104ed8();while(!![]){try{const _0x437ef3=parseInt(_0x476bef(0x1c6))/0x1*(-parseInt(_0x476bef(_0x19fed8._0x472805))/0x2)+-parseInt(_0x476bef(0x1f7))/0x3*(parseInt(_0x476bef(0x1e2))/0x4)+-parseInt(_0x476bef(_0x19fed8._0xb7e4e9))/0x5+parseInt(_0x476bef(0x1ec))/0x6+parseInt(_0x476bef(0x1c4))/0x7*(-parseInt(_0x476bef(0x1c7))/0x8)+-parseInt(_0x476bef(_0x19fed8._0x427a29))/0x9*(-parseInt(_0x476bef(0x1f4))/0xa)+parseInt(_0x476bef(0x1bf))/0xb*(parseInt(_0x476bef(0x1fc))/0xc);if(_0x437ef3===_0x594abf)break;else _0x125229['push'](_0x125229['shift']());}catch(_0x1ad90c){_0x125229['push'](_0x125229['shift']());}}}(_0x211a,0x6f12c));var __defProp=Object['defineProperty'],__getOwnPropSymbols=Object['getOwnPropertySymbols'],__hasOwnProp=Object[_0x41778f(0x1f1)]['hasOwnProperty'],__propIsEnum=Object['prototype'][_0x41778f(0x20b)],__defNormalProp=(_0x59a0ce,_0x203ab7,_0x453c8b)=>_0x203ab7 in _0x59a0ce?__defProp(_0x59a0ce,_0x203ab7,{'enumerable':!![],'configurable':!![],'writable':!![],'value':_0x453c8b}):_0x59a0ce[_0x203ab7]=_0x453c8b,__spreadValues=(_0x2f2a38,_0x20f060)=>{const _0x2edd7a=_0x41778f;for(var _0x9cae8c in _0x20f060||(_0x20f060={}))if(__hasOwnProp[_0x2edd7a(0x1c5)](_0x20f060,_0x9cae8c))__defNormalProp(_0x2f2a38,_0x9cae8c,_0x20f060[_0x9cae8c]);if(__getOwnPropSymbols)for(var _0x9cae8c of __getOwnPropSymbols(_0x20f060)){if(__propIsEnum['call'](_0x20f060,_0x9cae8c))__defNormalProp(_0x2f2a38,_0x9cae8c,_0x20f060[_0x9cae8c]);}return _0x2f2a38;},__async=(_0x56f872,_0x34012e,_0x2aad33)=>{return new Promise((_0x4d738d,_0x2d73c7)=>{const _0x3604de=_0x33a8;var _0x1d9a9b=_0x3bcbc0=>{try{_0x3c5ff5(_0x2aad33['next'](_0x3bcbc0));}catch(_0x569dcc){_0x2d73c7(_0x569dcc);}},_0x47dbf5=_0x1ade28=>{try{_0x3c5ff5(_0x2aad33['throw'](_0x1ade28));}catch(_0x7be24c){_0x2d73c7(_0x7be24c);}},_0x3c5ff5=_0x43e578=>_0x43e578[_0x3604de(0x1e8)]?_0x4d738d(_0x43e578['value']):Promise['resolve'](_0x43e578['value'])[_0x3604de(0x1e9)](_0x1d9a9b,_0x47dbf5);_0x3c5ff5((_0x2aad33=_0x2aad33['apply'](_0x56f872,_0x34012e))['next']());});},KISSKH_BASE=_0x41778f(0x1d5),HEADERS={'User-Agent':'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/147.0.0.0\x20Safari/537.36','Referer':KISSKH_BASE+'/','Accept':_0x41778f(0x1bd)};function fetchSafe(_0x2081d0){const _0x23b93a={_0x5c3088:0x1bc,_0x2d4f83:0x1d2,_0x49033b:0x1b6,_0x1628c0:0x1cb,_0x3e154f:0x1c1,_0x3a6968:0x1df};return __async(this,arguments,function*(_0xb777,_0x450596={}){const _0x19876f=_0x33a8;try{const _0x733212=0x3a98,_0x57125a=typeof AbortSignal!==_0x19876f(0x1b6)&&AbortSignal[_0x19876f(_0x23b93a._0x5c3088)]?AbortSignal['timeout'](_0x733212):null;let _0x1c4f36={'headers':__spreadValues(__spreadValues({},HEADERS),_0x450596[_0x19876f(_0x23b93a._0x2d4f83)]||{})};if(_0x57125a)_0x1c4f36['signal']=_0x57125a;if(typeof fetchText!==_0x19876f(_0x23b93a._0x49033b)){const _0x3782fc=yield fetchText(_0xb777,_0x1c4f36);return _0x3782fc;}else{const _0x51f075=yield fetch(_0xb777,_0x1c4f36);if(!_0x51f075||!_0x51f075['ok'])return null;return yield _0x51f075[_0x19876f(0x1c3)]();}}catch(_0xe05c4){return console[_0x19876f(_0x23b93a._0x1628c0)](_0x19876f(_0x23b93a._0x3e154f)+_0xe05c4[_0x19876f(_0x23b93a._0x3a6968)]),null;}});}function fetchJsonSafe(_0x2f8a5d){const _0xca9ee0={_0x5d048e:0x1cb};return __async(this,arguments,function*(_0x33a5ba,_0x5cd4e2={}){const _0x3a7fca=_0x33a8,_0x16c93b=yield fetchSafe(_0x33a5ba,_0x5cd4e2);if(!_0x16c93b)return null;try{return JSON[_0x3a7fca(0x1d8)](_0x16c93b);}catch(_0x2d1a6d){return console[_0x3a7fca(_0xca9ee0._0x5d048e)](_0x3a7fca(0x1ea)+_0x2d1a6d['message']),null;}});}function calculateHash(_0x22b07a){const _0x15b925=_0x41778f;let _0x147792=0x0;for(let _0x1b34e8=0x0;_0x1b34e8<_0x22b07a['length'];_0x1b34e8++){_0x147792=(_0x147792<<0x5)-_0x147792+_0x22b07a[_0x15b925(0x206)](_0x1b34e8);}return _0x147792;}function wordsToHex(_0x426b29){let _0x59e3bf='';for(let _0x3f7416=0x0;_0x3f7416<_0x426b29['length'];_0x3f7416++){let _0x2896a2=(_0x426b29[_0x3f7416]>>>0x0)['toString'](0x10);while(_0x2896a2['length']<0x8)_0x2896a2='0'+_0x2896a2;_0x59e3bf+=_0x2896a2;}return _0x59e3bf['toUpperCase']();}function encryptKkeyCustom(_0x59d24b){const _0x2d0ff4={_0xa22b42:0x206,_0x362620:0x1e3},_0x3dbe0f=_0x41778f;let _0x4bfa5d=_0x59d24b,_0x854f35=0x10-_0x59d24b['length']%0x10;for(let _0x2b146c=0x0;_0x2b146c<_0x854f35;_0x2b146c++){_0x4bfa5d+=String['fromCharCode'](_0x854f35);}let _0x294224=[];for(let _0x48a206=0x0;_0x48a206<_0x4bfa5d['length'];_0x48a206+=0x4){_0x294224['push'](_0x4bfa5d[_0x3dbe0f(0x206)](_0x48a206)<<0x18|_0x4bfa5d[_0x3dbe0f(_0x2d0ff4._0xa22b42)](_0x48a206+0x1)<<0x10|_0x4bfa5d['charCodeAt'](_0x48a206+0x2)<<0x8|_0x4bfa5d['charCodeAt'](_0x48a206+0x3));}const _0x48f2d5=[[0x4f6bdaa3,-0x61d07350,0x7f5e722d,-0x61210cec,0x536620a8,-0x32b653e8,-0x4de821cb,0x2cc92d21,-0x73412227,0x41f771c1,-0xc1f500c,-0x20d67d2b,0x2dadde47,0x6c5aaf86,-0x6045ff8e,0x409382a7,-0x6417db2,-0x6a1bd238,0xa5e2dba,0x4acdaf1d,0x54c72698,-0x3edcf4b0,-0x3482d916,-0x7e4f7609,-0x6c9fb16c,0x524345c4,-0x66c19cd2,0x188eead9,-0x351884c7,-0x675bc103,0x19a5dd3,0x1914b70a,-0x4fb1e313,0x28ea2210,0x29707fc3,0x3064c8c9,-0x17593e17,-0x3fb31c07,-0x16c363c6,-0x26a7ab0d,-0x4b793324,0x74ca2f25,-0x62094ce1,0x44aee7ec]];var _0x42c3de=[],_0x545c9f=[],_0x310bd9=[],_0xc76051=[],_0x43db5a=[],_0x1d204f=[];for(let _0x384500=0x0;_0x384500<0x100;_0x384500++)_0x1d204f[_0x384500]=_0x384500<0x80?_0x384500<<0x1:_0x384500<<0x1^0x11b;var _0x1543d8=0x0,_0x123d3b=0x0;for(let _0x4869ad=0x0;_0x4869ad<0x100;_0x4869ad++){var _0x2e903d=_0x123d3b^_0x123d3b<<0x1^_0x123d3b<<0x2^_0x123d3b<<0x3^_0x123d3b<<0x4;_0x2e903d=_0x2e903d>>>0x8^0xff&_0x2e903d^0x63,_0x42c3de[_0x1543d8]=_0x2e903d;var _0x25c18a=_0x1d204f[_0x1543d8],_0x2c1a96=_0x1d204f[_0x1d204f[_0x25c18a]],_0x5bccaa=0x101*_0x1d204f[_0x2e903d]^0x1010100*_0x2e903d;_0x545c9f[_0x1543d8]=_0x5bccaa<<0x18|_0x5bccaa>>>0x8,_0x310bd9[_0x1543d8]=_0x5bccaa<<0x10|_0x5bccaa>>>0x10,_0xc76051[_0x1543d8]=_0x5bccaa<<0x8|_0x5bccaa>>>0x18,_0x43db5a[_0x1543d8]=_0x5bccaa,_0x1543d8?(_0x1543d8=_0x25c18a^_0x1d204f[_0x1d204f[_0x1d204f[_0x2c1a96^_0x25c18a]]],_0x123d3b^=_0x1d204f[_0x1d204f[_0x123d3b]]):_0x1543d8=_0x123d3b=0x1;}_0x48f2d5[_0x3dbe0f(_0x2d0ff4._0x362620)](_0x545c9f),_0x48f2d5[_0x3dbe0f(0x1e3)](_0x310bd9),_0x48f2d5['push'](_0xc76051),_0x48f2d5['push'](_0x43db5a),_0x48f2d5[_0x3dbe0f(0x1e3)](_0x42c3de);const [_0x40bdfc,_0x457201,_0x35bf7e,_0x9a9dc,_0x2de4bf,_0x45ae79]=_0x48f2d5,_0x1a2ddc=[0x1504af3,0x56e619cf,0x2e42bba6,-0x73c08f07];for(let _0x37f332=0x0;_0x37f332<_0x294224['length'];_0x37f332+=0x4){let _0x26e77a=_0x37f332===0x0?_0x1a2ddc:_0x294224[_0x3dbe0f(0x1d0)](_0x37f332-0x4,_0x37f332);for(let _0x7f6614=0x0;_0x7f6614<0x4;_0x7f6614++){_0x294224[_0x37f332+_0x7f6614]^=_0x26e77a[_0x7f6614];}let _0x2ccf00=_0x294224[_0x37f332]^_0x40bdfc[0x0],_0x574a2e=_0x294224[_0x37f332+0x1]^_0x40bdfc[0x1],_0x417cc2=_0x294224[_0x37f332+0x2]^_0x40bdfc[0x2],_0x295407=_0x294224[_0x37f332+0x3]^_0x40bdfc[0x3],_0x4ae57d=0x4;for(let _0xc525f2=0x1;_0xc525f2<0xa;_0xc525f2++){let _0x46a364=_0x457201[_0x2ccf00>>>0x18]^_0x35bf7e[_0x574a2e>>>0x10&0xff]^_0x9a9dc[_0x417cc2>>>0x8&0xff]^_0x2de4bf[0xff&_0x295407]^_0x40bdfc[_0x4ae57d++],_0xc7e5c0=_0x457201[_0x574a2e>>>0x18]^_0x35bf7e[_0x417cc2>>>0x10&0xff]^_0x9a9dc[_0x295407>>>0x8&0xff]^_0x2de4bf[0xff&_0x2ccf00]^_0x40bdfc[_0x4ae57d++],_0x396cca=_0x457201[_0x417cc2>>>0x18]^_0x35bf7e[_0x295407>>>0x10&0xff]^_0x9a9dc[_0x2ccf00>>>0x8&0xff]^_0x2de4bf[0xff&_0x574a2e]^_0x40bdfc[_0x4ae57d++];_0x295407=_0x457201[_0x295407>>>0x18]^_0x35bf7e[_0x2ccf00>>>0x10&0xff]^_0x9a9dc[_0x574a2e>>>0x8&0xff]^_0x2de4bf[0xff&_0x417cc2]^_0x40bdfc[_0x4ae57d++],_0x2ccf00=_0x46a364,_0x574a2e=_0xc7e5c0,_0x417cc2=_0x396cca;}let _0x21d8b1=(_0x45ae79[_0x2ccf00>>>0x18]<<0x18|_0x45ae79[_0x574a2e>>>0x10&0xff]<<0x10|_0x45ae79[_0x417cc2>>>0x8&0xff]<<0x8|_0x45ae79[0xff&_0x295407])^_0x40bdfc[_0x4ae57d++],_0x40ed53=(_0x45ae79[_0x574a2e>>>0x18]<<0x18|_0x45ae79[_0x417cc2>>>0x10&0xff]<<0x10|_0x45ae79[_0x295407>>>0x8&0xff]<<0x8|_0x45ae79[0xff&_0x2ccf00])^_0x40bdfc[_0x4ae57d++],_0x16c28a=(_0x45ae79[_0x417cc2>>>0x18]<<0x18|_0x45ae79[_0x295407>>>0x10&0xff]<<0x10|_0x45ae79[_0x2ccf00>>>0x8&0xff]<<0x8|_0x45ae79[0xff&_0x574a2e])^_0x40bdfc[_0x4ae57d++],_0x5bbf43=(_0x45ae79[_0x295407>>>0x18]<<0x18|_0x45ae79[_0x2ccf00>>>0x10&0xff]<<0x10|_0x45ae79[_0x574a2e>>>0x8&0xff]<<0x8|_0x45ae79[0xff&_0x417cc2])^_0x40bdfc[_0x4ae57d++];_0x294224[_0x37f332]=_0x21d8b1,_0x294224[_0x37f332+0x1]=_0x40ed53,_0x294224[_0x37f332+0x2]=_0x16c28a,_0x294224[_0x37f332+0x3]=_0x5bbf43;}return wordsToHex(_0x294224);}function generateKkey(_0x35d192,_0x3279a3=![]){const _0x569af7={_0x3d8b07:0x1d7,_0xa67c6e:0x1d6,_0x4ee198:0x20e,_0x5a4b36:0x208},_0x19c5ac=_0x41778f,_0x1dedd1='2.8.10',_0x39ad75=_0x19c5ac(_0x569af7._0x3d8b07),_0x1b6079=_0x19c5ac(_0x569af7._0xa67c6e),_0x1a52de='62f176f3bb1b5b8e70e39932ad34a0c7',_0x5d9822='VgV52sWhwvBSf8BsM3BRY9weWiiCbtGp';let _0x2ee56a=['',_0x35d192[_0x19c5ac(0x20e)](),'',_0x19c5ac(0x1f8),_0x1dedd1,_0x3279a3?_0x5d9822:_0x1a52de,_0x39ad75,_0x1b6079,_0x1b6079,_0x1b6079,_0x1b6079,_0x1b6079,_0x1b6079,'00',''];const _0x535119=_0x2ee56a['join']('|'),_0x506ffe=calculateHash(_0x535119);_0x2ee56a['splice'](0x1,0x0,_0x506ffe[_0x19c5ac(_0x569af7._0x4ee198)]());const _0x3e8915=_0x2ee56a[_0x19c5ac(_0x569af7._0x5a4b36)]('|');return encryptKkeyCustom(_0x3e8915);}function _0x33a8(_0x35bb70,_0x4b8d5f){_0x35bb70=_0x35bb70-0x1b6;const _0x211a07=_0x211a();let _0x33a80f=_0x211a07[_0x35bb70];if(_0x33a8['VqWtoQ']===undefined){var _0x2c23c3=function(_0x208386){const _0x151968='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0x59a0ce='',_0x203ab7='';for(let _0x453c8b=0x0,_0x2f2a38,_0x20f060,_0x9cae8c=0x0;_0x20f060=_0x208386['charAt'](_0x9cae8c++);~_0x20f060&&(_0x2f2a38=_0x453c8b%0x4?_0x2f2a38*0x40+_0x20f060:_0x20f060,_0x453c8b++%0x4)?_0x59a0ce+=String['fromCharCode'](0xff&_0x2f2a38>>(-0x2*_0x453c8b&0x6)):0x0){_0x20f060=_0x151968['indexOf'](_0x20f060);}for(let _0x56f872=0x0,_0x34012e=_0x59a0ce['length'];_0x56f872<_0x34012e;_0x56f872++){_0x203ab7+='%'+('00'+_0x59a0ce['charCodeAt'](_0x56f872)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x203ab7);};_0x33a8['YGbxbP']=_0x2c23c3,_0x33a8['SSMytj']={},_0x33a8['VqWtoQ']=!![];}const _0x335803=_0x211a07[0x0],_0x1cfabf=_0x35bb70+_0x335803,_0xcd96fa=_0x33a8['SSMytj'][_0x1cfabf];return!_0xcd96fa?(_0x33a80f=_0x33a8['YGbxbP'](_0x33a80f),_0x33a8['SSMytj'][_0x1cfabf]=_0x33a80f):_0x33a80f=_0xcd96fa,_0x33a80f;}var TVDB_API_KEY=_0x41778f(0x1de),_tvdbToken=null;function getTvdbToken(){const _0x30ddf1={_0x55feac:0x1c2,_0x1de595:0x1ef,_0x4b528b:0x202,_0x6366e8:0x1eb};return __async(this,null,function*(){const _0x23e951=_0x33a8;if(_tvdbToken)return _tvdbToken;try{var _0x188f48=yield fetch(_0x23e951(_0x30ddf1._0x55feac),{'method':_0x23e951(_0x30ddf1._0x1de595),'headers':{'Content-Type':_0x23e951(_0x30ddf1._0x4b528b)},'body':JSON[_0x23e951(0x1f3)]({'apikey':TVDB_API_KEY})});if(_0x188f48['ok']){var _0x5c03da=yield _0x188f48['json']();if(_0x5c03da&&_0x5c03da['data']&&_0x5c03da['data'][_0x23e951(_0x30ddf1._0x6366e8)])_tvdbToken=_0x5c03da['data']['token'];}}catch(_0x471c75){}return _tvdbToken;});}function getAbsoluteEpisode(_0x376a58,_0x27fbee,_0x360155,_0x345b65,_0x56116e){const _0x402d65={_0x286f2f:0x1f2,_0x545e08:0x1f5,_0x10ae95:0x1d3,_0x4c9dd3:0x1c8,_0x37fa0e:0x1fa,_0x53a830:0x201,_0x3d09f4:0x1c3,_0x291a26:0x1dc,_0x9cff:0x1f2,_0x46f6d6:0x1fd,_0x3e0662:0x205,_0x45d048:0x1cb,_0x2a4d43:0x203};return __async(this,null,function*(){const _0x1f58cd=_0x33a8;if(_0x27fbee==='movie')return 0x1;let _0x206360=_0x345b65,_0x39d892=null,_0x15c5bc=null;try{const _0x148db5=yield fetchJsonSafe(_0x1f58cd(_0x402d65._0x286f2f)+_0x376a58+_0x1f58cd(0x1e4));_0x148db5&&(_0x39d892=_0x148db5['imdb_id'],_0x15c5bc=_0x148db5[_0x1f58cd(_0x402d65._0x545e08)]);}catch(_0x5547f8){}if(!_0x15c5bc&&_0x56116e)try{console['log']('[KissKH]\x20Searching\x20TVDB\x20for\x20series:\x20'+_0x56116e);const _0x3bf16b=yield getTvdbToken();if(_0x3bf16b){const _0x1769ed=yield fetchJsonSafe('https://api4.thetvdb.com/v4/search?query='+encodeURIComponent(_0x56116e),{'headers':{'Authorization':'Bearer\x20'+_0x3bf16b}});if(_0x1769ed&&_0x1769ed[_0x1f58cd(0x1c8)]){const _0xbabbde=_0x1769ed['data']['find'](_0x40f3f5=>_0x40f3f5[_0x1f58cd(0x1bb)]==='series');if(_0xbabbde){const _0x52834d=_0xbabbde['id']||_0xbabbde[_0x1f58cd(_0x402d65._0x545e08)];_0x52834d&&(_0x15c5bc=parseInt(String(_0x52834d)[_0x1f58cd(0x1ff)](/^series-/,''),0xa),console[_0x1f58cd(0x1cb)]('[KissKH]\x20Resolved\x20TVDB\x20ID\x20'+_0x15c5bc+_0x1f58cd(_0x402d65._0x10ae95)));}}}}catch(_0x3853eb){}if(_0x15c5bc)try{console['log']('[KissKH]\x20Attempting\x20TVDB\x20Math\x20for\x20TVDB:\x20'+_0x15c5bc);const _0x190272=yield getTvdbToken();if(_0x190272){const _0xb78462=yield fetchJsonSafe('https://api4.thetvdb.com/v4/series/'+_0x15c5bc+'/episodes/default?season='+_0x360155,{'headers':{'Authorization':'Bearer\x20'+_0x190272}});if(_0xb78462&&_0xb78462[_0x1f58cd(_0x402d65._0x4c9dd3)]&&_0xb78462[_0x1f58cd(0x1c8)][_0x1f58cd(_0x402d65._0x37fa0e)]){const _0x5bcb12=_0xb78462[_0x1f58cd(_0x402d65._0x4c9dd3)][_0x1f58cd(0x1fa)][_0x1f58cd(0x204)](_0x2ff451=>_0x2ff451['seasonNumber']==_0x360155&&_0x2ff451[_0x1f58cd(0x20f)]==_0x345b65);if(_0x5bcb12&&_0x5bcb12[_0x1f58cd(_0x402d65._0x53a830)])return console['log']('[KissKH]\x20TVDB\x20Math\x20calculated\x20absolute\x20episode:\x20'+_0x5bcb12[_0x1f58cd(0x201)]),_0x5bcb12[_0x1f58cd(_0x402d65._0x53a830)];}}}catch(_0x6c50dd){}if(_0x39d892)try{console['log']('[KissKH]\x20Attempting\x20Regex\x20Math\x20for\x20IMDB:\x20'+_0x39d892);const _0x37013b='https://aiometadata.elfhosted.com/stremio/80d082c4-6e99-4c97-a67d-3d9e242685ce/meta/series/'+_0x39d892+'.json',_0x3615bf=yield fetch(_0x37013b);if(_0x3615bf['ok']){const _0xcdf8ab=yield _0x3615bf[_0x1f58cd(_0x402d65._0x3d09f4)]();let _0x35090b=0x0,_0x3d3a0e=![];const _0x541759=/"season"\s*:\s*(\d+)/g;let _0x358dca;while((_0x358dca=_0x541759[_0x1f58cd(_0x402d65._0x291a26)](_0xcdf8ab))!==null){_0x3d3a0e=!![];const _0x95c870=parseInt(_0x358dca[0x1]);_0x95c870>0x0&&_0x95c870<_0x360155&&_0x35090b++;}if(_0x3d3a0e){let _0x512949=_0x35090b+_0x345b65;return console[_0x1f58cd(0x1cb)]('[KissKH]\x20Regex\x20Math\x20calculated\x20absolute\x20episode:\x20'+_0x512949),_0x512949;}}}catch(_0x3dec97){}try{console['log']('[KissKH]\x20Cinemeta/TVDB\x20failed.\x20Falling\x20back\x20to\x20TMDB\x20math...');const _0x3a11b9=_0x1f58cd(_0x402d65._0x9cff)+_0x376a58+'?api_key=1865f43a0549ca50d341dd9ab8b29f49',_0x1da017=yield fetchJsonSafe(_0x3a11b9,{});if(_0x1da017&&_0x1da017[_0x1f58cd(_0x402d65._0x46f6d6)]){let _0x22faea=0x0;const _0x102c12=_0x1da017['seasons']['filter'](_0x2b0773=>_0x2b0773[_0x1f58cd(0x1ee)]>0x0&&_0x2b0773['season_number']<_0x360155);for(let _0x28b8eb of _0x102c12){_0x22faea+=_0x28b8eb[_0x1f58cd(_0x402d65._0x3e0662)];}return _0x22faea+=_0x345b65,console[_0x1f58cd(_0x402d65._0x45d048)](_0x1f58cd(_0x402d65._0x2a4d43)+_0x22faea),_0x22faea;}}catch(_0x234b8b){}return _0x206360;});}function _0x211a(){const _0x30ee7f=['DhLWzq','DgLTzw91Da','yxbWBgLJyxrPB24VANnVBIWGDgv4Dc9WBgfPBIWGkI8Q','CgfYDca','mti2otrAt3fYBMO','l2fWAs9eCMfTyuXPC3qVrxbPC29Kzs8','zMv0y2HtywzLievYCM9YoIa','Ahr0Chm6lY9HCgK0lNrOzxr2zgiUy29Tl3y0l2XVz2LU','Dgv4Da','mJeXntm3ovz2tvzZuW','y2fSBa','mJu1ndy5qMDZEuT5','ohnkuezzBa','zgf0yq','ic0G','ywjZ','Bg9N','Aw5JBhvKzxm','CMvSzwfZzv9KyxrL','l2fWAs9tDwiV','s2LZC0TiigDLDfn0CMvHBxmGy2fSBgvKoIa','C2XPy2u','l2fWAs9eCMfTyuXPC3qVu2vHCMnOp3e9','AgvHzgvYCW','igzYB20GC2vHCMnO','mZC3nZnZshjYvhm','Ahr0Chm6lY9RAxnZA2GUBMW','A2LZC2TO','ndGZmdiWmq','CgfYC2u','nMPvtLLYDG','zMLYC3rFywLYx2rHDgu','BgvUz3rO','zxHLyW','l2fWAs9eCMfTyuXPC3qVrhjHBweV','nZC3mtqWzMiTzgu5mI00ndbHlwfLyZiTotvLyJuXztjKn2fI','BwvZC2fNzq','mZC2otK1meDlr1jVAG','zxHWB3j0CW','nhbRufzvza','ChvZAa','l2v4DgvYBMfSx2LKCZ9HCgLFA2v5pte4nJvMndnHmdu0ownHntbKmZqXzgq5ywi4yJi5zJq5','B3jPz2LUywXFDgL0Bgu','vxnLCI1bz2vUDa','BgfUza','zg9Uzq','DgHLBG','zMv0y2HkC29Uu2fMzsbqyxjZzsbfCNjVCJOG','Dg9Rzw4','mJK0mteYmNbLu3z4Cq','yMvOyxzPB3jiAw50CW','C2vHC29Ux251BwjLCG','ue9tva','BMfTzq','ChjVDg90ExbL','Ahr0Chm6lY9HCgKUDgHLBw92AwvKyI5VCMCVmY90DI8','C3rYAw5NAwz5','ntaWzLnTD3HZ','DhzKyL9Pza','C3bSAxq','mJy4nJuYn0Lkwxj6qW','BwCZyZnImdrIyq','vgHPCMrqyxj0Eq','zxbPC29Kzxm','w0TPC3nlsf0GrxH0CMfJDgvKievWrgf0ysbMB3iGsuqG','mJu3mtz6rw9fveO','C2vHC29UCW','DgL0Bgu','CMvWBgfJzq','AxnbCNjHEq','ywjZB2X1DgvoDw1Izxi','yxbWBgLJyxrPB24VANnVBG','w0TPC3nlsf0Gve1eqIbdywXJDwXHDgvKigfIC29SDxrLigvWAxnVzgu6ia','zMLUza','zxbPC29Kzv9JB3vUDa','y2HHCKnVzgvbDa','CM91BMq','AM9PBG','vMLKzw8','B3jPz2LUywXFBMfTzq','ChjVCgvYDhLjC0vUDw1LCMfIBgu','w0TPC3nlsf0Gz2v0qwjZB2X1DgvfCgLZB2rLigzHAwXLza','C2vYAwvZ','Dg9tDhjPBMC','BNvTyMvY','Dw5KzwzPBMvK','rMv0y2HPBMCGve1eqJOG','z2v0u3rYzwfTCW','DhjPBq','p2LZCt1MywXZzq'];_0x211a=function(){return _0x30ee7f;};return _0x211a();}function getStreams(_0x3411f4,_0x52e66b,_0x436708,_0x45c632){const _0x403cbe={_0x388941:0x1cb,_0x512637:0x1b7,_0x151138:0x1fe,_0x239a35:0x1f6,_0x43dfcf:0x1cd,_0x36b911:0x1f6,_0xc4d2b7:0x1d1,_0x3d265b:0x1db,_0x1f380f:0x1ca,_0x5c953d:0x1c9,_0x2ce025:0x1cc,_0x1c1682:0x1dd,_0x1559e3:0x20c,_0x38c3ef:0x1fa,_0x3e5173:0x204,_0x58a936:0x1c0,_0x512e3f:0x209,_0x485191:0x1f9,_0x7ed64a:0x1e6,_0x25b9d5:0x1ed,_0xb1c863:0x1e7,_0x406afe:0x1e3};return __async(this,null,function*(){const _0x560832=_0x33a8;let _0x5ec7ea=[];console[_0x560832(_0x403cbe._0x388941)](_0x560832(0x1cf)+_0x3411f4+'\x20'+_0x52e66b);const _0x84538d='https://api.themoviedb.org/3/'+_0x52e66b+'/'+_0x3411f4+'?api_key=1865f43a0549ca50d341dd9ab8b29f49';console['log'](_0x560832(_0x403cbe._0x512637)+_0x84538d);const _0x25cc21=yield fetchJsonSafe(_0x84538d);if(!_0x25cc21)return console['log']('TMDB\x20fetch\x20failed\x20or\x20returned\x20null!'),[];const _0x2f429c=_0x25cc21[_0x560832(_0x403cbe._0x151138)]||_0x25cc21[_0x560832(0x1f0)]||_0x25cc21[_0x560832(0x1e5)]||_0x25cc21[_0x560832(0x20a)],_0x51e879=_0x2f429c[_0x560832(_0x403cbe._0x239a35)](':')[0x0][_0x560832(0x1f6)]('-')[0x0][_0x560832(0x1b9)]();console[_0x560832(0x1cb)]('TMDB\x20Base\x20Title:\x20'+_0x51e879);let _0x49e7a6='';if(_0x25cc21[_0x560832(0x1cd)])_0x49e7a6=_0x25cc21[_0x560832(_0x403cbe._0x43dfcf)][_0x560832(0x1f6)]('-')[0x0];else{if(_0x25cc21['first_air_date'])_0x49e7a6=_0x25cc21[_0x560832(0x1da)][_0x560832(_0x403cbe._0x36b911)]('-')[0x0];}let _0x130d21=KISSKH_BASE+'/api/DramaList/Search?q='+encodeURIComponent(_0x2f429c)+'&type=0',_0x10b507=yield fetchJsonSafe(_0x130d21);(!_0x10b507||!Array['isArray'](_0x10b507)||_0x10b507['length']===0x0)&&(_0x130d21=KISSKH_BASE+_0x560832(_0x403cbe._0xc4d2b7)+encodeURIComponent(_0x51e879)+'&type=0',_0x10b507=yield fetchJsonSafe(_0x130d21));if(!_0x10b507||!Array['isArray'](_0x10b507)||_0x10b507[_0x560832(_0x403cbe._0x3d265b)]===0x0)return[];let _0x434356=null,_0x3a948e=null,_0x1ab80b=null,_0x3b0abe=null;const _0x1a6516=_0x52e66b==='tv'||_0x52e66b===_0x560832(0x20d);for(let _0x2dcdc3=0x0;_0x2dcdc3<_0x10b507['length'];_0x2dcdc3++){let _0xad4610=_0x10b507[_0x2dcdc3],_0x157f10=(_0xad4610[_0x560832(0x1fe)]||'')['toLowerCase'](),_0x2c0fd2=_0x2f429c['toLowerCase'](),_0x19c755=_0x51e879['toLowerCase'](),_0x46a5e1=!![];if(_0x49e7a6){let _0x5a8e1f=_0x157f10['match'](/\((20\d\d|19\d\d)\)/);_0x5a8e1f&&(Math[_0x560832(_0x403cbe._0x1f380f)](parseInt(_0x5a8e1f[0x1])-parseInt(_0x49e7a6))>0x1&&(_0x46a5e1=![]));}if(!_0x46a5e1)continue;if(_0x1a6516&&_0x436708){let _0x4657f3='season\x20'+_0x436708,_0x29bd11=_0x560832(0x1be)+_0x436708,_0x20b753=_0x2c0fd2+'\x20'+_0x436708,_0x25e8c0=_0x2c0fd2+'\x20'+_0x4657f3,_0x575036=_0x2c0fd2+_0x560832(_0x403cbe._0x5c953d)+_0x4657f3,_0x29aff7=_0x2c0fd2+':\x20'+_0x4657f3;if(_0x157f10===_0x20b753||_0x157f10===_0x25e8c0||_0x157f10===_0x575036||_0x157f10===_0x29aff7){_0x434356=_0xad4610;break;}if((_0x157f10['includes'](_0x4657f3)||_0x157f10['includes'](_0x29bd11))&&(_0x157f10['includes'](_0x2c0fd2)||_0x157f10['includes'](_0x19c755))){if(!_0x1ab80b)_0x1ab80b=_0xad4610;}}if(_0x157f10===_0x2c0fd2||_0x157f10===_0x19c755||_0x157f10===_0x2c0fd2+'\x20('+_0x49e7a6+')')_0x3a948e=_0xad4610;else{if(_0x157f10['includes'](_0x2c0fd2)||_0x157f10[_0x560832(_0x403cbe._0x2ce025)](_0x19c755)){if(!_0x3b0abe)_0x3b0abe=_0xad4610;}}}let _0x5d6ae9=_0x434356||_0x3a948e||_0x1ab80b||_0x3b0abe;if(!_0x5d6ae9||!_0x5d6ae9['id'])return[];const _0x4a3f73=_0x5d6ae9['id'],_0x3c4cbb=KISSKH_BASE+_0x560832(_0x403cbe._0x1c1682)+_0x4a3f73+_0x560832(0x1ba),_0x3c374d=yield fetchJsonSafe(_0x3c4cbb);if(!_0x3c374d||!_0x3c374d['episodes']||_0x3c374d[_0x560832(0x1fa)]['length']===0x0)return[];let _0x1e8ba7=null,_0x5f5971=parseInt(_0x45c632);if(_0x1a6516&&_0x436708&&parseInt(_0x436708)>0x1&&_0x5d6ae9===_0x3a948e)try{_0x5f5971=yield getAbsoluteEpisode(_0x3411f4,_0x52e66b,parseInt(_0x436708),parseInt(_0x45c632),_0x2f429c);}catch(_0x1a2423){console[_0x560832(_0x403cbe._0x388941)](_0x560832(_0x403cbe._0x1559e3),_0x1a2423);}_0x1a6516&&_0x45c632?_0x1e8ba7=_0x3c374d[_0x560832(_0x403cbe._0x38c3ef)][_0x560832(_0x403cbe._0x3e5173)](_0x3f137a=>Math[_0x560832(0x207)](_0x3f137a['number']||0x0)===_0x5f5971):_0x1e8ba7=_0x3c374d['episodes'][0x0];if(!_0x1e8ba7||!_0x1e8ba7['id'])return[];const _0x1910e9=_0x1e8ba7['id']['toString'](),_0x5d0fff=generateKkey(_0x1910e9,![]),_0x4e626a=generateKkey(_0x1910e9,!![]),_0x3d5ad2=KISSKH_BASE+_0x560832(_0x403cbe._0x58a936)+_0x1910e9+'.png?err=false&ts=&time=&kkey='+_0x5d0fff,_0xb7076a=yield fetchJsonSafe(_0x3d5ad2);if(_0xb7076a){console['log'](_0x560832(0x1fb)+_0x1910e9+':\x20'+JSON[_0x560832(0x1f3)](_0xb7076a));const _0x33ce47=_0xb7076a[_0x560832(_0x403cbe._0x512e3f)]||_0xb7076a[_0x560832(_0x403cbe._0x485191)];console[_0x560832(0x1cb)]('[KissKH]\x20Selected\x20Video\x20URL:\x20'+_0x33ce47);if(_0x33ce47){const _0x45143c=_0x33ce47['indexOf']('.m3u8')!==-0x1;let _0x1e65ab={'name':'KissKH\x20-\x20Ep\x20'+Math['round'](_0x1e8ba7['number']||0x0),'title':'Auto','size':_0x5d6ae9['title'],'url':_0x33ce47,'quality':'HD'};const _0x42432c={'User-Agent':HEADERS[_0x560832(_0x403cbe._0x7ed64a)],'Referer':KISSKH_BASE+'/','Origin':KISSKH_BASE};_0x45143c?_0x1e65ab[_0x560832(0x1d2)]=_0x42432c:_0x1e65ab[_0x560832(_0x403cbe._0x25b9d5)]={'proxyHeaders':{'request':_0x42432c}},_0x5ec7ea['push'](_0x1e65ab);}}let _0x1ab0ea=[];const _0x1dd961=KISSKH_BASE+_0x560832(0x1ce)+_0x1910e9+'?kkey='+_0x4e626a,_0x50ba98=yield fetchJsonSafe(_0x1dd961);if(_0x50ba98&&Array[_0x560832(0x200)](_0x50ba98))for(const _0x3c5da3 of _0x50ba98){_0x3c5da3['src']&&_0x3c5da3[_0x560832(_0x403cbe._0xb1c863)]&&_0x1ab0ea[_0x560832(_0x403cbe._0x406afe)]({'url':_0x3c5da3['src'],'language':_0x3c5da3[_0x560832(0x1e7)]});}return _0x5ec7ea['length']>0x0&&_0x1ab0ea['length']>0x0&&(_0x5ec7ea[0x0]['subtitles']=_0x1ab0ea),_0x5ec7ea;});}typeof module!==_0x41778f(0x1b6)&&module['exports']?module[_0x41778f(0x1e1)]={'getStreams':getStreams}:global[_0x41778f(0x1b8)]=getStreams;

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "kisskh-v2", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_PLAYIMDB_DISPLAY_START */
/* CLOUDBANK_PLAYIMDB_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  if (providerId === "playimdb") return provider; // Reference output stays exactly upstream.
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name) || (lines.length ? lines[0] : "");
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    var labelledAudio = /🌍\s*([^|\n]+)/.exec(originalTitle);
    if (!audioLang && labelledAudio) audioLang = language(labelledAudio[1]);
    var filenameAudio = /(?:^|[._ -])(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese)(?=[._ -]|$)/i.exec(clean(stream.fileName || stream.filename));
    if (!audioLang && filenameAudio) audioLang = language(filenameAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage)) || /\boriginal[- ]audio\b/i.test(text)) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    var labelledServer = /📌\s*([^|\n]+)/.exec(originalTitle);
    if (!server && labelledServer) server = usable(labelledServer[1]);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    var firstLine = lines.length ? "🎬 " + lines[0] : "";
    // Match PlayIMDb's original typography and order, without its guessed defaults.
    if (displayTitle) {
      firstLine = type === "tv" ? "🎬 " + usable(meta.title || meta.name) + " - S" + Number(season) + "E" + Number(episode) + (year ? " (" + year[0] + ")" : "") :
        "🎬 " + usable(meta.title || meta.name) + (year ? " - " + year[0] : "");
    }
    var qualityDisplay = qualityLabel === "4K" ? "2160P" : qualityLabel.toUpperCase();
    var audioDisplay = audioLabel.replace(/[- ]Audio/g, "").trim();
    var infoLine = [qualityDisplay ? "💎 " + qualityDisplay : "", audioDisplay ? "🌍 " + audioDisplay : ""].filter(Boolean).join(" | ");
    var bottomLine = [formatLabel ? "🎞️ " + (formatLabel === "HLS" ? "M3U8" : formatLabel) : "", duration ? "⏱️ " + duration : "", "📌 " + server].filter(Boolean).join(" | ");
    var nameQuality = qualityLabel === "4K" ? "4K UHD" : qualityLabel === "1080p" ? "1080p FHD" : qualityLabel === "720p" ? "720p HD" : qualityLabel;
    output.name = ["🟡 " + providerName, nameQuality, audioLabel ? audioLabel.replace(/ Audio/g, "-Audio") : ""].filter(Boolean).join(" | ");
    output.title = [firstLine, infoLine, bottomLine].filter(Boolean).join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "Kisskh V2", "kisskh-v2");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
/* CLOUDBANK_PLAYIMDB_DISPLAY_END */
