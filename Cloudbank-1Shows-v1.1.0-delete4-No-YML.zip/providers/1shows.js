// Imported provider: 1shows; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
function _0x557d(){const _0x462fb5=['y2HHCKnVzgvbDa','yxbWBgLJyxrPB24VEc1TCgvNvvjm','DMLKzw8VEc1TyxrYB3nRyq','C2vYAwvZ','zM9SBg93','qufd','r0qGsw5KzxG','tI9b','Bw92Awu','jtiW','p2fWAv9RzxK9','B3rOzxi','zM9YrwfJAa','Ag9ZDg5HBwu','DgL0Bgu','C29YDa','DgfN','qMvUz2fSAq','nZq4mdC0CuvHuhrv','8j+oPYa','CuXPBMu','sw52ywXPzcbKzwnYExb0B3iGBwfUAwzLC3q','Cg9W','y29Uy2f0','C2v0','Dw5KzwzPBMvK','C3rHDhvZ','DgvZDa','l2rVD25SB2fKl21VDMLLlW','mtaZmJCWogzjrLvIrG','CMvZzxq','8j+tSsa0odbW','AxnbCNjHEq','yxbWBgLJyxrPB24VANnVBG','8j+tNsbfu3vI','y29KzwnmAw5L','8j+nVYa','mJuZoejNAejnDa','Dgv4Dc9ODg1SlgfWCgXPy2f0Aw9Ul3HODg1Sk3HTBcXHChbSAwnHDgLVBI94BwW7Ct0WlJKSAw1Hz2uVyxzPzIXPBwfNzs93zwjWlcOVkJTXptaUoa','otGWAKvewNbt','8j+mNYaYmtyWCa','y29UDgvUDc1Yyw5Nzq','DMLKzw8VBxa0','y3j5ChrV','AhjLzG','EwvHCG','mJe2ma','mta4mha','mvnOB3DZihjLDhvYBMvKig5VigrVD25SB2fKihrVA2vU','8j+xO++4JYa','lNiYlMnSB3vKzMXHCMvZDg9YywDLlMnVBq','xhmQpvXZkIHBiIDDksHBxhnCu10QpYLCmq','AhvIy2XVDwq','rerqidiUma','CgL4zwWUAhvIy2XVDwqUy3G','CM91Dgu','Ahr0Chm6lY9Nzc5RBwHKlMv1l2zPBguV','ihWGuW','yxvKAw9myw5N','Ahr0Chm6lY9WAxHLBgrYywLUlMnVBs9HCgKVzMLSzs8','ChjLBwL1Bs1OBq','Dgv4Da','BMv4Da','8j+xO++4JYbnDwX0As1bDwrPBW','BwLU','BMfTzq','zgvJB2rL','AgvHzgvYCW','8j+mIca','DgHLBG','DhjPBq','mteXndC3lNH5EG','zNvJA2LUz2zHC3qUBMv0','Dg9tDhjPBMC','ndGWCa','AM9PBG','tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2ienOCM9Tzs8XmZeUmc4WlJaGu2fMyxjPlZuZnY4ZnG','sw52ywXPzcbLBMnYExb0zwqGCgf5Bg9Hza','BwfW','A2f0Bw92AwvZ','mta4ma','BM93','CxvHBgL0EvjHBMS','C29SDMu','l3DMAwXLlW','zMXVB3i','CMf3','mJe3n2TjAfPVqG','q2XVDwrMBgfYzq','zMzMyxn0lMzPBgvZzgWUAw4','ndm5yZq3oge3nZfMmZvJmduWmJjMowzLywjJy2eWmwm','AhrTBa','zw5Oyw5Jzw1LBNrZtgLUzq','B3jPz2LU','yxnZAwDU','Aw5ZDgfUy2u','Aw5JBhvKzxm','mtbcAxq','CgfKu3rHCNq','8j+sVIa','yNvMzMvY','DhLWzq','rgLYzwn0','Bwf4','BgfIzwW','nZiW','8j+tUIa','lNrHA2vMAwXLlMXPBMS','C3rHCNrZv2L0Aa','Bw9VBMrSlMnVBq','zgLYzwn0','sers','mti2ntGXmhjkwKPSDq','uhjLBwL1Bsbitq','ue9tva','nJeZntKYtuvivLjN','zw5KC1DPDgG','Ahr0Chm6lY9HCgKUDMLKDwTPlM5LDa','BwvKAwfuExbL','zMLUza','rMfZDcbdBg91za','Dg9mB3DLCKnHC2u','8j+oNU+4JYa','C3vIDgXL','zMLYC3rFywLYx2rHDgu','yNL0zxm9mc0X','Dg9vChbLCKnHC2u','Dg9Rzw4','8j+sJIa3mJbW','ywXSB2m','nZq4men2EfL2uq','C2XPy2u','u3rYzwfTDgfWzq','zgvJCNLWDa','DxjS','ChvZAa','C2L6zuXPBMu','DgHYB3C','CMvWBgfJzq','r0vu','C291CMnLCW','zxHWB3j0CW','CMvZCg9UC2uTy29UDgvUDc1KAxnWB3nPDgLVBG','Ahr0Chm6','shvIq2XVDwq','z2v0','DMfSDwu','C3rYzwfTDgfWzq','x2zPBgu','vw5RBM93BG','C2L6zuLUtui','yxbWBhK','zMLSBxLMBhK','DMLKzw8Tzg93BMXVywrZlMDVB2DSzxvZzxjJB250zw50lMnVBq','zMLSDgvY','BgvUz3rO','C3vIC3rYAw5N','sfruuca','DwHK','C2vHCMnOugfYyw1Z','zgLYzwn0u2L6zq','mvnOB3DZigrLy3j5ChrVCIbHBgXVy2f0Aw9UigzHAwXLza','BwvTB3j5','mtuZmtK4D2PMs1nb','l2XVy2TLzd9YzwrPCMvJDd0','Bwf0y2G','ywXS','D3jPDgvcExrL','8j+uPsaXmdGWCa','rgvJCNLWDg9YieHuvfaG','muPXyLvmqW','Cgf0Ag5HBwu','x3bYB2jLtxm','B3jPz2LUywXFBMfTzq','zg9Uzq','yxbWBgLJyxrPB24VEc13D3CTzM9YBs11CMXLBMnVzgvK','qvyX','ihWG','zxbPC29Kzq','AxnjBNrLz2vY'];_0x557d=function(){return _0x462fb5;};return _0x557d();}const _0x45f04d=_0x5656;(function(_0x4ac402,_0xd0fb4c){const _0x49974e={_0x5d44cd:0x234,_0x4be883:0x279,_0x25cdf9:0x211},_0x156c7f=_0x5656,_0xfebd34=_0x4ac402();while(!![]){try{const _0x353f1d=parseInt(_0x156c7f(0x218))/0x1*(parseInt(_0x156c7f(0x23f))/0x2)+-parseInt(_0x156c7f(_0x49974e._0x5d44cd))/0x3+-parseInt(_0x156c7f(0x249))/0x4*(-parseInt(_0x156c7f(0x1f0))/0x5)+-parseInt(_0x156c7f(0x247))/0x6*(parseInt(_0x156c7f(_0x49974e._0x4be883))/0x7)+-parseInt(_0x156c7f(0x1e1))/0x8+-parseInt(_0x156c7f(_0x49974e._0x25cdf9))/0x9+-parseInt(_0x156c7f(0x1de))/0xa;if(_0x353f1d===_0xd0fb4c)break;else _0xfebd34['push'](_0xfebd34['shift']());}catch(_0x559770){_0xfebd34['push'](_0xfebd34['shift']());}}}(_0x557d,0x44c3d));var __async=(_0x34fde8,_0x37f316,_0x2d6356)=>{return new Promise((_0x22646d,_0x5a57a0)=>{const _0x3925c0={_0x384c78:0x1f7},_0x621e58=_0x5656;var _0x49a807=_0x3c646b=>{const _0x5b3cc7=_0x5656;try{_0x3624a9(_0x2d6356[_0x5b3cc7(0x260)](_0x3c646b));}catch(_0x3dad5e){_0x5a57a0(_0x3dad5e);}},_0x57feba=_0x2666e8=>{const _0x3a7060=_0x5656;try{_0x3624a9(_0x2d6356[_0x3a7060(_0x3925c0._0x384c78)](_0x2666e8));}catch(_0x2bc47c){_0x5a57a0(_0x2bc47c);}},_0x3624a9=_0x56ea5b=>_0x56ea5b[_0x621e58(0x21c)]?_0x22646d(_0x56ea5b['value']):Promise['resolve'](_0x56ea5b[_0x621e58(0x200)])[_0x621e58(0x267)](_0x49a807,_0x57feba);_0x3624a9((_0x2d6356=_0x2d6356['apply'](_0x34fde8,_0x37f316))['next']());});};function safeUtf8Decode(_0x170515){const _0x50b156={_0x18208b:0x264,_0x481ada:0x209},_0x19c8c9=_0x5656;if(typeof TextDecoder!=='undefined')try{return new TextDecoder()[_0x19c8c9(_0x50b156._0x18208b)](_0x170515);}catch(_0x3d5bba){}let _0x511b05='';for(let _0x2b3b51=0x0;_0x2b3b51<_0x170515[_0x19c8c9(_0x50b156._0x481ada)];_0x2b3b51++){_0x511b05+=String['fromCharCode'](_0x170515[_0x2b3b51]);}try{return decodeURIComponent(escape(_0x511b05));}catch(_0x5c6a9a){return _0x511b05;}}var SITE_URL='https://www.1shows.org',API_URL=_0x45f04d(0x1e3),TMDB_URL='https://api.themoviedb.org/3',TMDB_API_KEY=_0x45f04d(0x27c),USER_AGENT=_0x45f04d(0x26e),API_HEADERS={'Accept':'application/json','Origin':SITE_URL,'Referer':SITE_URL+'/','User-Agent':USER_AGENT},PAGE_HEADERS={'Accept':_0x45f04d(0x248),'Referer':SITE_URL+'/','User-Agent':USER_AGENT},DOWNLOAD_KEY_HEX='8a4df84251d6e25688e68342d1b28fa281f9bd04a3e437a2cf496e9a896f515b';function getInvertedSortTag(_0x145d04,_0x2bd69a=0xf423f){const _0x4e9fd5={_0x25810b:0x1d5},_0x42aa1e=_0x45f04d,_0x4528db=Math[_0x42aa1e(0x1d5)](0x0,parseInt(_0x145d04,0xa)||0x0),_0x41be27=Math[_0x42aa1e(_0x4e9fd5._0x25810b)](0x0,_0x2bd69a-_0x4528db),_0x34c06a=_0x41be27['toString'](0x2)[_0x42aa1e(0x1d0)](0x14,'0');return _0x34c06a['split']('')['map'](_0x305553=>_0x305553==='1'?'\ufeff':'​')['join']('');}function parseSizeToMB(_0x48ebc2){const _0x178ac1={_0x590b57:0x229,_0x435762:0x213,_0x1dc521:0x277},_0x5c0470=_0x45f04d;if(!_0x48ebc2||_0x48ebc2===_0x5c0470(_0x178ac1._0x590b57)||_0x48ebc2==='Unknown'||_0x48ebc2==='Unknown\x20Size')return 0x0;const _0x430b50=String(_0x48ebc2)[_0x5c0470(_0x178ac1._0x435762)](/([\d.]+)\s*(GB|MB)/i);if(!_0x430b50)return 0x0;const _0x1127af=parseFloat(_0x430b50[0x1]),_0x129c53=_0x430b50[0x2]['toUpperCase']();if(_0x129c53==='GB')return Math[_0x5c0470(_0x178ac1._0x1dc521)](_0x1127af*0x400);if(_0x129c53==='MB')return Math[_0x5c0470(_0x178ac1._0x1dc521)](_0x1127af);return 0x0;}function getResolutionEmoji(_0x258402){const _0x4caaed={_0x59c46b:0x250,_0x41f77e:0x20c,_0x4603f6:0x1d7,_0x13f074:0x1ce,_0x453813:0x1ce,_0x6a74fa:0x1ce,_0x1aa7fd:0x241,_0x1dbdb8:0x251},_0x923dd4=_0x45f04d,_0x6b83fd=String(_0x258402||'')['toLowerCase']();if(_0x6b83fd['includes'](_0x923dd4(_0x4caaed._0x59c46b))||_0x6b83fd[_0x923dd4(0x1ce)]('4k')||_0x6b83fd['includes'](_0x923dd4(_0x4caaed._0x41f77e)))return _0x923dd4(0x24a);if(_0x6b83fd[_0x923dd4(0x1ce)](_0x923dd4(0x272))||_0x6b83fd['includes']('fhd'))return _0x923dd4(0x216);if(_0x6b83fd[_0x923dd4(0x1ce)](_0x923dd4(_0x4caaed._0x4603f6))||_0x6b83fd[_0x923dd4(_0x4caaed._0x13f074)]('hd'))return _0x923dd4(0x1ee);if(_0x6b83fd[_0x923dd4(_0x4caaed._0x453813)]('480')||_0x6b83fd[_0x923dd4(_0x4caaed._0x6a74fa)]('sd'))return _0x923dd4(_0x4caaed._0x1aa7fd);return _0x923dd4(0x1d8)+(_0x258402||_0x923dd4(_0x4caaed._0x1dbdb8));}function fetchJson(_0x4dc456,_0x26c163){const _0x5a0a7e={_0x3ba477:0x20b,_0x53aaed:0x23c};return __async(this,null,function*(){const _0x4d386f=_0x5656,_0x5b2801=yield fetch(_0x4dc456,_0x26c163);if(!_0x5b2801['ok'])throw new Error(_0x4d386f(_0x5a0a7e._0x3ba477)+_0x5b2801[_0x4d386f(_0x5a0a7e._0x53aaed)]+':\x20'+_0x4dc456);return _0x5b2801['json']();});}function fetchText(_0x106def,_0x1b3c2f){const _0x4e3cfa={_0x6f9fe1:0x23b,_0x373c9b:0x27a,_0x4ff794:0x1cc,_0x5c84c4:0x25f};return __async(this,null,function*(){const _0x48a629=_0x5656,_0x3d0b6c=Object[_0x48a629(0x1cc)]({},_0x1b3c2f||{},{'skipSizeCheck':!![],'cfKiller':!![]});let _0x2e79a3=yield fetch(_0x106def,_0x3d0b6c);if((_0x2e79a3[_0x48a629(0x23c)]===0x193||_0x2e79a3[_0x48a629(0x23c)]===0x1f7)&&typeof globalThis['Cloudflare']!==_0x48a629(_0x4e3cfa._0x6f9fe1)&&globalThis[_0x48a629(_0x4e3cfa._0x373c9b)][_0x48a629(0x275)]){const _0x2bb634=yield globalThis[_0x48a629(0x27a)][_0x48a629(0x275)](_0x106def);_0x2e79a3=yield fetch(_0x106def,Object['assign']({},_0x3d0b6c,{'headers':Object[_0x48a629(_0x4e3cfa._0x4ff794)]({},_0x3d0b6c[_0x48a629(0x265)]||{},_0x2bb634||{})}));}if(!_0x2e79a3['ok'])throw new Error(_0x48a629(0x20b)+_0x2e79a3['status']+':\x20'+_0x106def);return{'html':yield _0x2e79a3[_0x48a629(_0x4e3cfa._0x5c84c4)](),'url':_0x2e79a3[_0x48a629(0x1f4)]||_0x106def};});}function absoluteUrl(_0x565727,_0x2c73ea){const _0x59a404=_0x45f04d;if(!_0x565727)return'';try{return new URL(_0x565727,_0x2c73ea)[_0x59a404(0x26b)]();}catch(_0x2a8846){return'';}}function decodeHtml(_0x217dca){const _0x1f69af=_0x45f04d;return String(_0x217dca||'')['replace'](/&amp;/gi,'&')[_0x1f69af(0x1f8)](/&#0*39;|&apos;/gi,'\x27')['replace'](/&quot;/gi,'\x22')['replace'](/&lt;/gi,'<')['replace'](/&gt;/gi,'>');}function stripTags(_0x359196){const _0x42688d={_0x1a98e2:0x1f8},_0x218247=_0x45f04d;return decodeHtml(String(_0x359196||'')[_0x218247(_0x42688d._0x1a98e2)](/<[^>]*>/g,'\x20'))['replace'](/\s+/g,'\x20')['trim']();}function attribute(_0x22cb7f,_0x57566f){const _0x19dee5=_0x45f04d,_0x2b008f=String(_0x22cb7f||'')['match'](new RegExp('\x5cb'+_0x57566f+_0x19dee5(0x255),'i'));return _0x2b008f?decodeHtml(_0x2b008f[0x2]):'';}function anchors(_0x3666ea,_0x1a5ece){const _0x3e366e=_0x45f04d,_0x6b72e4=[],_0x2c7b83=/<a\b[^>]*>[\s\S]*?<\/a>/gi;let _0x3f3300;while(_0x3f3300=_0x2c7b83['exec'](String(_0x3666ea||''))){const _0x1773e1=absoluteUrl(attribute(_0x3f3300[0x0],_0x3e366e(0x24e)),_0x1a5ece);if(_0x1773e1)_0x6b72e4[_0x3e366e(0x1f5)]({'href':_0x1773e1,'text':stripTags(_0x3f3300[0x0])});}return _0x6b72e4;}function hexToBytes(_0x3e2c10){const _0x18495c={_0x28b10d:0x209,_0x2abd7d:0x209},_0x279b88=_0x45f04d,_0xa2de8f=String(_0x3e2c10||'')[_0x279b88(0x268)]();if(!_0xa2de8f||_0xa2de8f[_0x279b88(_0x18495c._0x28b10d)]%0x2)throw new Error(_0x279b88(0x26f));const _0x478be8=new Uint8Array(_0xa2de8f[_0x279b88(0x209)]/0x2);for(let _0x4b7c6b=0x0;_0x4b7c6b<_0x478be8[_0x279b88(_0x18495c._0x2abd7d)];_0x4b7c6b+=0x1){const _0x3d6733=parseInt(_0xa2de8f[_0x279b88(0x1f1)](_0x4b7c6b*0x2,_0x4b7c6b*0x2+0x2),0x10);if(Number['isNaN'](_0x3d6733))throw new Error('Invalid\x20encrypted\x20payload');_0x478be8[_0x4b7c6b]=_0x3d6733;}return _0x478be8;}function writeBytes(_0x53ef3b,_0x1b9c58,_0x2dffcc,_0x11fd5a){const _0x267a51={_0xe49d95:0x1d2,_0x55ce0c:0x209},_0x80835b=_0x45f04d,_0x2069c1=_0x53ef3b[_0x1b9c58](_0x11fd5a['length']);if(!_0x2069c1)throw new Error(_0x80835b(0x20f));if(_0x53ef3b['memory'])new Uint8Array(_0x53ef3b['memory'][_0x80835b(_0x267a51._0xe49d95)],_0x2069c1,_0x11fd5a[_0x80835b(_0x267a51._0x55ce0c)])[_0x80835b(0x23a)](_0x11fd5a);else for(let _0x272b9b=0x0;_0x272b9b<_0x11fd5a[_0x80835b(_0x267a51._0x55ce0c)];_0x272b9b+=0x1){_0x53ef3b[_0x2dffcc](_0x2069c1+_0x272b9b,_0x11fd5a[_0x272b9b]);}return _0x2069c1;}function readBytes(_0x2e3e83,_0x5bbe22,_0x33fa8c,_0x134c13){const _0x23ef43={_0x359810:0x210},_0x7197=_0x45f04d;if(_0x2e3e83['memory'])return new Uint8Array(_0x2e3e83[_0x7197(_0x23ef43._0x359810)][_0x7197(0x1d2)][_0x7197(0x1f1)](_0x33fa8c,_0x33fa8c+_0x134c13));const _0x4e2350=new Uint8Array(_0x134c13);for(let _0x4bf35f=0x0;_0x4bf35f<_0x134c13;_0x4bf35f+=0x1){_0x4e2350[_0x4bf35f]=_0x2e3e83[_0x5bbe22](_0x33fa8c+_0x4bf35f);}return _0x4e2350;}function joinBytes(_0x583cf9,_0x27fcd3){const _0x160861={_0x2b4599:0x209},_0xd8b9ba=_0x45f04d,_0x442d0d=new Uint8Array(_0x583cf9[_0xd8b9ba(_0x160861._0x2b4599)]+_0x27fcd3[_0xd8b9ba(0x209)]);return _0x442d0d[_0xd8b9ba(0x23a)](_0x583cf9,0x0),_0x442d0d[_0xd8b9ba(0x23a)](_0x27fcd3,_0x583cf9[_0xd8b9ba(0x209)]),_0x442d0d;}var AES_SBOX=new Uint8Array([0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x1,0x67,0x2b,0xfe,0xd7,0xab,0x76,0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,0x4,0xc7,0x23,0xc3,0x18,0x96,0x5,0x9a,0x7,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,0x9,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,0x53,0xd1,0x0,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x2,0x7f,0x50,0x3c,0x9f,0xa8,0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,0xcd,0xc,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0xb,0xdb,0xe0,0x32,0x3a,0xa,0x49,0x6,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x8,0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,0x70,0x3e,0xb5,0x66,0x48,0x3,0xf6,0xe,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,0x8c,0xa1,0x89,0xd,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0xf,0xb0,0x54,0xbb,0x16]),AES_RCON=new Uint8Array([0x0,0x1,0x2,0x4,0x8,0x10,0x20,0x40,0x80,0x1b,0x36]);function expandAes256Key(_0x126463){const _0x243a84={_0xa72040:0x209},_0x35b102=_0x45f04d;if(_0x126463[_0x35b102(0x209)]!==0x20)throw new Error('Invalid\x20AES-256\x20key');const _0x5b2c8a=new Uint8Array(0xf0);_0x5b2c8a[_0x35b102(0x23a)](_0x126463);let _0x1b0fe2=0x20,_0xd2ae9c=0x1;const _0x299e5e=new Uint8Array(0x4);while(_0x1b0fe2<_0x5b2c8a[_0x35b102(0x209)]){for(let _0x274075=0x0;_0x274075<0x4;_0x274075+=0x1)_0x299e5e[_0x274075]=_0x5b2c8a[_0x1b0fe2-0x4+_0x274075];if(_0x1b0fe2%0x20===0x0){const _0x46071b=_0x299e5e[0x0];_0x299e5e[0x0]=AES_SBOX[_0x299e5e[0x1]]^AES_RCON[_0xd2ae9c++],_0x299e5e[0x1]=AES_SBOX[_0x299e5e[0x2]],_0x299e5e[0x2]=AES_SBOX[_0x299e5e[0x3]],_0x299e5e[0x3]=AES_SBOX[_0x46071b];}else{if(_0x1b0fe2%0x20===0x10){for(let _0x37f8f7=0x0;_0x37f8f7<0x4;_0x37f8f7+=0x1)_0x299e5e[_0x37f8f7]=AES_SBOX[_0x299e5e[_0x37f8f7]];}}for(let _0x58bb63=0x0;_0x58bb63<0x4&&_0x1b0fe2<_0x5b2c8a[_0x35b102(_0x243a84._0xa72040)];_0x58bb63+=0x1){_0x5b2c8a[_0x1b0fe2]=_0x5b2c8a[_0x1b0fe2-0x20]^_0x299e5e[_0x58bb63],_0x1b0fe2+=0x1;}}return _0x5b2c8a;}function aesXtime(_0x39f3c2){return(_0x39f3c2<<0x1^(_0x39f3c2&0x80?0x1b:0x0))&0xff;}function aesEncryptBlock(_0x29aa2b,_0x34ef61){const _0x2e9ea8=new Uint8Array(_0x29aa2b);for(let _0x220691=0x0;_0x220691<0x10;_0x220691+=0x1)_0x2e9ea8[_0x220691]^=_0x34ef61[_0x220691];for(let _0x3dcdea=0x1;_0x3dcdea<=0xe;_0x3dcdea+=0x1){for(let _0x1a36de=0x0;_0x1a36de<0x10;_0x1a36de+=0x1)_0x2e9ea8[_0x1a36de]=AES_SBOX[_0x2e9ea8[_0x1a36de]];const _0x3f3a3b=new Uint8Array(0x10);for(let _0x3ab444=0x0;_0x3ab444<0x4;_0x3ab444+=0x1){for(let _0x157d43=0x0;_0x157d43<0x4;_0x157d43+=0x1){_0x3f3a3b[_0x3ab444+0x4*_0x157d43]=_0x2e9ea8[_0x3ab444+0x4*(_0x157d43+_0x3ab444&0x3)];}}_0x2e9ea8['set'](_0x3f3a3b);if(_0x3dcdea<0xe)for(let _0x3ebb4c=0x0;_0x3ebb4c<0x4;_0x3ebb4c+=0x1){const _0x159349=_0x3ebb4c*0x4,_0x120d00=_0x2e9ea8[_0x159349],_0x13da77=_0x2e9ea8[_0x159349+0x1],_0x3928cf=_0x2e9ea8[_0x159349+0x2],_0x1dab8e=_0x2e9ea8[_0x159349+0x3],_0x461579=_0x120d00^_0x13da77^_0x3928cf^_0x1dab8e;_0x2e9ea8[_0x159349]^=_0x461579^aesXtime(_0x120d00^_0x13da77),_0x2e9ea8[_0x159349+0x1]^=_0x461579^aesXtime(_0x13da77^_0x3928cf),_0x2e9ea8[_0x159349+0x2]^=_0x461579^aesXtime(_0x3928cf^_0x1dab8e),_0x2e9ea8[_0x159349+0x3]^=_0x461579^aesXtime(_0x1dab8e^_0x120d00);}const _0x1b5e94=_0x3dcdea*0x10;for(let _0x29bf8b=0x0;_0x29bf8b<0x10;_0x29bf8b+=0x1)_0x2e9ea8[_0x29bf8b]^=_0x34ef61[_0x1b5e94+_0x29bf8b];}return _0x2e9ea8;}function xorBlock(_0xf9961e,_0x856e87){for(let _0x2d6552=0x0;_0x2d6552<0x10;_0x2d6552+=0x1)_0xf9961e[_0x2d6552]^=_0x856e87[_0x2d6552];}function ghashMultiply(_0xb02111,_0x5c9d5c){const _0x2ca6cd=new Uint8Array(0x10),_0x1d96f4=new Uint8Array(_0x5c9d5c);for(let _0x2c427e=0x0;_0x2c427e<0x80;_0x2c427e+=0x1){if(_0xb02111[_0x2c427e>>0x3]>>0x7-(_0x2c427e&0x7)&0x1)xorBlock(_0x2ca6cd,_0x1d96f4);const _0x4f85b8=_0x1d96f4[0xf]&0x1;for(let _0x1e2be0=0xf;_0x1e2be0>0x0;_0x1e2be0-=0x1){_0x1d96f4[_0x1e2be0]=_0x1d96f4[_0x1e2be0]>>>0x1|(_0x1d96f4[_0x1e2be0-0x1]&0x1)<<0x7;}_0x1d96f4[0x0]>>>=0x1;if(_0x4f85b8)_0x1d96f4[0x0]^=0xe1;}return _0x2ca6cd;}function ghashUpdate(_0x199ad7,_0x41ff8d,_0x512563){const _0xea01cd={_0x404638:0x23a,_0x5fe057:0x262},_0xc4669a=_0x45f04d;for(let _0x3912ee=0x0;_0x3912ee<_0x512563[_0xc4669a(0x209)];_0x3912ee+=0x10){const _0x4705f2=new Uint8Array(0x10);_0x4705f2[_0xc4669a(_0xea01cd._0x404638)](_0x512563['subarray'](_0x3912ee,Math[_0xc4669a(_0xea01cd._0x5fe057)](_0x3912ee+0x10,_0x512563['length']))),xorBlock(_0x199ad7,_0x4705f2),_0x199ad7['set'](ghashMultiply(_0x199ad7,_0x41ff8d));}}function writeBitLength(_0x13b268,_0x408229,_0x39320e){const _0xd75ab3=_0x45f04d;let _0x2fc4ca=_0x39320e*0x8;for(let _0x212386=0x7;_0x212386>=0x0;_0x212386-=0x1){_0x13b268[_0x408229+_0x212386]=_0x2fc4ca&0xff,_0x2fc4ca=Math[_0xd75ab3(0x277)](_0x2fc4ca/0x100);}}function incrementCounter(_0x20bf72){for(let _0x350c41=0xf;_0x350c41>=0xc;_0x350c41-=0x1){_0x20bf72[_0x350c41]=_0x20bf72[_0x350c41]+0x1&0xff;if(_0x20bf72[_0x350c41])break;}}function constantTimeEqual(_0x53b2f2,_0x36e7fd){const _0x25d817={_0x52f587:0x209},_0x12f95c=_0x45f04d;if(_0x53b2f2[_0x12f95c(0x209)]!==_0x36e7fd[_0x12f95c(_0x25d817._0x52f587)])return![];let _0x1270fa=0x0;for(let _0x4b9fc5=0x0;_0x4b9fc5<_0x53b2f2['length'];_0x4b9fc5+=0x1)_0x1270fa|=_0x53b2f2[_0x4b9fc5]^_0x36e7fd[_0x4b9fc5];return _0x1270fa===0x0;}function decryptDownloadPureJs(_0x3b69e7,_0x361859){const _0x37a403={_0xaa9ad3:0x209},_0x279f6e=_0x45f04d,_0x284c0b=hexToBytes(DOWNLOAD_KEY_HEX),_0x2e8379=hexToBytes(_0x3b69e7['iv']),_0x153373=hexToBytes(_0x3b69e7['ct']),_0x310302=hexToBytes(_0x3b69e7['tag']),_0x5c8c6e=hexToBytes(_0x361859);if(_0x2e8379[_0x279f6e(_0x37a403._0xaa9ad3)]!==0xc||_0x310302['length']!==0x10)throw new Error('Unsupported\x201Shows\x20AES-GCM\x20payload');const _0x3f0c20=expandAes256Key(_0x284c0b),_0x57e55c=aesEncryptBlock(new Uint8Array(0x10),_0x3f0c20),_0x110973=new Uint8Array(0x10);ghashUpdate(_0x110973,_0x57e55c,_0x5c8c6e),ghashUpdate(_0x110973,_0x57e55c,_0x153373);const _0x691c33=new Uint8Array(0x10);writeBitLength(_0x691c33,0x0,_0x5c8c6e['length']),writeBitLength(_0x691c33,0x8,_0x153373[_0x279f6e(0x209)]),xorBlock(_0x110973,_0x691c33),_0x110973['set'](ghashMultiply(_0x110973,_0x57e55c));const _0x4720fc=new Uint8Array(0x10);_0x4720fc['set'](_0x2e8379),_0x4720fc[0xf]=0x1;const _0x3b0ba9=aesEncryptBlock(_0x4720fc,_0x3f0c20);xorBlock(_0x3b0ba9,_0x110973);if(!constantTimeEqual(_0x3b0ba9,_0x310302))throw new Error('1Shows\x20authentication\x20failed');const _0x3ffbc2=new Uint8Array(_0x4720fc),_0x3b20e5=new Uint8Array(_0x153373['length']);for(let _0x12de7e=0x0;_0x12de7e<_0x153373['length'];_0x12de7e+=0x10){incrementCounter(_0x3ffbc2);const _0x528ef2=aesEncryptBlock(_0x3ffbc2,_0x3f0c20),_0x4405c5=Math['min'](0x10,_0x153373['length']-_0x12de7e);for(let _0x87d95e=0x0;_0x87d95e<_0x4405c5;_0x87d95e+=0x1){_0x3b20e5[_0x12de7e+_0x87d95e]=_0x153373[_0x12de7e+_0x87d95e]^_0x528ef2[_0x87d95e];}}return JSON['parse'](safeUtf8Decode(_0x3b20e5));}function decryptDownloadWithWebCrypto(_0x24a427,_0x12775e){const _0x40e3fa={_0x5b1bc5:0x278,_0x206709:0x1f3};return __async(this,null,function*(){const _0x218509=_0x5656,_0x43bb1a=globalThis[_0x218509(0x24d)];if(!_0x43bb1a||!_0x43bb1a[_0x218509(0x1e9)])throw new Error('Web\x20Crypto\x20is\x20unavailable');const _0x31e118=hexToBytes(DOWNLOAD_KEY_HEX),_0x124850=hexToBytes(_0x12775e),_0x249076=hexToBytes(_0x24a427['iv']),_0x4f0e58=joinBytes(hexToBytes(_0x24a427['ct']),hexToBytes(_0x24a427[_0x218509(0x232)])),_0x47112d=yield _0x43bb1a['subtle']['importKey'](_0x218509(_0x40e3fa._0x5b1bc5),_0x31e118,{'name':'AES-GCM'},![],[_0x218509(0x1f3)]),_0x39e81b=yield _0x43bb1a[_0x218509(0x1e9)][_0x218509(_0x40e3fa._0x206709)]({'name':'AES-GCM','iv':_0x249076,'additionalData':_0x124850,'tagLength':0x80},_0x47112d,_0x4f0e58);return JSON['parse'](safeUtf8Decode(new Uint8Array(_0x39e81b)));});}function decryptDownloadWithWasm(_0x1ca10e,_0x14ef21){const _0x5d0d27={_0xf4ab22:0x1f4,_0x3c4ca0:0x1fb,_0x54f639:0x237,_0x2ebc1c:0x1cd,_0x2af2b8:0x1ef,_0x2796f8:0x215,_0x503842:0x1ef,_0x1e67b3:0x209};return __async(this,null,function*(){const _0x114350=_0x5656;if(typeof WebAssembly==='undefined'||!WebAssembly['instantiate'])throw new Error('WebAssembly\x20is\x20unavailable');const _0x1f848a=yield fetchJson(SITE_URL+'/makimaDL-manifest.json',{'headers':API_HEADERS}),_0xd3c3a6=absoluteUrl(_0x1f848a[_0x114350(_0x5d0d27._0xf4ab22)],SITE_URL);if(!_0xd3c3a6||!_0x1f848a[_0x114350(_0x5d0d27._0x3c4ca0)])throw new Error(_0x114350(_0x5d0d27._0x54f639));const _0x453164=yield fetch(_0xd3c3a6,{'headers':PAGE_HEADERS});if(!_0x453164['ok'])throw new Error(_0x114350(0x217)+_0x453164['status']);const _0x81c386=yield WebAssembly['instantiate'](yield _0x453164['arrayBuffer'](),{'env':{'abort'(){throw new Error('1Shows\x20decryptor\x20aborted');}}}),_0x40f66c=(_0x81c386[_0x114350(_0x5d0d27._0x2ebc1c)]||_0x81c386)['exports'],_0xde8ef2=_0x1f848a['exports'],_0x27ae4a=hexToBytes(_0x14ef21),_0x585e86=hexToBytes(_0x1ca10e['iv']),_0x152ea6=hexToBytes(_0x1ca10e['ct']),_0x43e015=hexToBytes(_0x1ca10e['tag']);try{const _0x29dbc7=writeBytes(_0x40f66c,_0xde8ef2[_0x114350(_0x5d0d27._0x2af2b8)],_0xde8ef2[_0x114350(0x215)],_0x27ae4a),_0x4ccc95=writeBytes(_0x40f66c,_0xde8ef2[_0x114350(_0x5d0d27._0x2af2b8)],_0xde8ef2['writeByte'],_0x585e86),_0xff2057=writeBytes(_0x40f66c,_0xde8ef2[_0x114350(0x1ef)],_0xde8ef2['writeByte'],_0x152ea6),_0x1e8e6e=writeBytes(_0x40f66c,_0xde8ef2['alloc'],_0xde8ef2[_0x114350(_0x5d0d27._0x2796f8)],_0x43e015),_0x28b9e6=_0x40f66c[_0xde8ef2[_0x114350(_0x5d0d27._0x503842)]](_0x152ea6['length']),_0x506a6c=_0x40f66c[_0xde8ef2['decryptDownload']](_0x29dbc7,_0x27ae4a['length'],_0x4ccc95,_0x585e86['length'],_0xff2057,_0x152ea6[_0x114350(_0x5d0d27._0x1e67b3)],_0x1e8e6e,_0x43e015['length'],_0x28b9e6);if(_0x506a6c<=0x0||_0x506a6c>_0x152ea6['length'])throw new Error('1Shows\x20download\x20decryption\x20failed');const _0x58327d=readBytes(_0x40f66c,_0xde8ef2['readByte'],_0x28b9e6,_0x506a6c);return JSON['parse'](safeUtf8Decode(_0x58327d));}finally{if(_0x40f66c[_0xde8ef2[_0x114350(0x240)]])_0x40f66c[_0xde8ef2['reset']]();}});}function decryptDownload(_0x19a3ab,_0x5755aa){return __async(this,null,function*(){try{return decryptDownloadPureJs(_0x19a3ab,_0x5755aa);}catch(_0x4f3499){try{return yield decryptDownloadWithWebCrypto(_0x19a3ab,_0x5755aa);}catch(_0x43b7e7){return decryptDownloadWithWasm(_0x19a3ab,_0x5755aa);}}});}function fetchDownloadSources(_0x3f330f,_0x251906,_0x2e7f25,_0x223604){const _0x5592b9={_0x33f17f:0x242,_0x33fdc5:0x1fa};return __async(this,null,function*(){const _0x28270c=_0x5656,_0x17d6bf=yield fetchJson(API_URL+'/download-token',{'headers':API_HEADERS});if(!_0x17d6bf['token'])throw new Error(_0x28270c(0x252));const _0x2d9246=_0x251906==='tv'?'/download/tv/'+encodeURIComponent(_0x3f330f)+'/'+encodeURIComponent(_0x2e7f25)+'/'+encodeURIComponent(_0x223604):_0x28270c(0x23e)+encodeURIComponent(_0x3f330f),_0x579f62=yield fetchJson(''+API_URL+_0x2d9246,{'headers':Object['assign']({},API_HEADERS,{'x-download-token':_0x17d6bf['token']})}),_0x292d06=yield decryptDownload(_0x579f62,_0x17d6bf[_0x28270c(0x1ed)]);return Array[_0x28270c(_0x5592b9._0x33f17f)](_0x292d06[_0x28270c(_0x5592b9._0x33fdc5)])?_0x292d06['sources']:[];});}function fetchMediaDetails(_0x1ef065,_0x3ac9dc){const _0x3d5309={_0x260e79:0x22c,_0x10c102:0x243,_0x1df753:0x263,_0x270fb7:0x21b,_0x3cab98:0x1ea};return __async(this,null,function*(){const _0x5d0b9e=_0x5656;try{const _0xc66049=_0x3ac9dc==='tv'?'tv':_0x5d0b9e(0x22a),_0x51b456=yield fetchJson(TMDB_URL+'/'+_0xc66049+'/'+encodeURIComponent(_0x1ef065)+_0x5d0b9e(_0x3d5309._0x260e79)+TMDB_API_KEY,{'headers':{'Accept':_0x5d0b9e(_0x3d5309._0x10c102),'User-Agent':USER_AGENT}}),_0x3d3262=_0x51b456[_0x5d0b9e(0x230)]||_0x51b456[_0x5d0b9e(_0x3d5309._0x1df753)]||_0x51b456['original_title']||_0x51b456[_0x5d0b9e(_0x3d5309._0x270fb7)]||_0x5d0b9e(0x203),_0x4b1be5=_0x51b456['release_date']||_0x51b456[_0x5d0b9e(_0x3d5309._0x3cab98)]||'',_0x1d2541=Number(_0x4b1be5['slice'](0x0,0x4))||null;return{'title':_0x3d3262,'year':_0x1d2541};}catch(_0x2fbed9){return{'title':'Unknown','year':null};}});}function hasWrongYear(_0x1215ed,_0x5cbf91){const _0x478b92=_0x45f04d;if(!_0x5cbf91)return![];const _0x504e59=String(_0x1215ed||'')[_0x478b92(0x213)](/\b(?:19|20)\d{2}\b/g)||[];return _0x504e59['some'](_0x3bb1a2=>Math['abs'](Number(_0x3bb1a2)-_0x5cbf91)>0x1);}function isDirectMedia(_0xe49a7f){const _0xdb67e3={_0x3b8dd7:0x1e2,_0x3b5428:0x254},_0x4d88cd=_0x45f04d;if(/\.(?:m3u8|mpd|mp4|mkv|webm)(?:$|[?#])/i['test'](_0xe49a7f))return!![];try{const _0x282d1f=new URL(_0xe49a7f),_0x5206b1=_0x282d1f['hostname']['toLowerCase']();return _0x5206b1===_0x4d88cd(0x27b)||_0x5206b1===_0x4d88cd(0x207)||_0x5206b1[_0x4d88cd(0x1e2)]('.workers.dev')||_0x5206b1[_0x4d88cd(_0xdb67e3._0x3b8dd7)](_0x4d88cd(_0xdb67e3._0x3b5428))||_0x5206b1['includes']('pixeldrain')||_0x5206b1['includes']('iwebp.store')||_0x5206b1===_0x4d88cd(0x26a);}catch(_0x53ae48){return![];}}function isKnownUnplayableHost(_0x56c8ef){const _0x183a52={_0x4b4a92:0x1db,_0x464d37:0x1e2,_0xc8b29d:0x258},_0x4e2119=_0x45f04d;try{const _0x1b67af=new URL(_0x56c8ef)['hostname'][_0x4e2119(0x1e7)]();return _0x1b67af===_0x4e2119(_0x183a52._0x4b4a92)||_0x1b67af[_0x4e2119(_0x183a52._0x464d37)]('.moondl.com')||_0x1b67af==='takefile.link'||_0x1b67af['endsWith'](_0x4e2119(0x1d9))||_0x1b67af===_0x4e2119(_0x183a52._0xc8b29d);}catch(_0x8a925){return![];}}function normalizeDirectUrl(_0x97f16b){const _0x577598={_0x3be07c:0x22b,_0x5e4f99:0x1e7},_0x187cf8=_0x45f04d,_0x4fb06d=String(_0x97f16b||'')['replace'](/ /g,_0x187cf8(_0x577598._0x3be07c));try{const _0x504750=new URL(_0x4fb06d),_0x33016e=_0x504750['hostname'][_0x187cf8(_0x577598._0x5e4f99)]();if(_0x33016e==='pixeldrain.com'||_0x33016e==='www.pixeldrain.com'||_0x33016e==='pixeldrain.dev'||_0x33016e==='www.pixeldrain.dev'||_0x33016e['endsWith']('.iwebp.store')){const _0x209901=_0x504750['pathname']['match'](/^\/(?:u|l)\/([^/?#]+)/i);if(_0x209901)return _0x187cf8(0x25d)+_0x209901[0x1];}}catch(_0x4a8cf4){}return _0x4fb06d;}function preferredDownloadLink(_0x15c712){const _0x12090f=_0x45f04d,_0x215d7c=_0x15c712[_0x12090f(0x208)](_0x2f3f6e=>_0x2f3f6e&&_0x2f3f6e['href']&&!isKnownUnplayableHost(_0x2f3f6e[_0x12090f(0x24e)])),_0x43ffe4=[/(?:direct download|instant dl)/i,/(?:pixeldrain|buzzheavier)/i,/(?:fast cloud|zipdisk)/i];for(const _0xda7d42 of _0x43ffe4){const _0x2a9f02=_0x215d7c[_0x12090f(0x1e5)](_0x4869fc=>_0xda7d42[_0x12090f(0x23d)](_0x4869fc[_0x12090f(0x25f)]));if(_0x2a9f02)return _0x2a9f02;}const _0x124bd5=_0x215d7c[_0x12090f(0x1e5)](_0x1b8968=>isDirectMedia(_0x1b8968['href']));return _0x124bd5||null;}function routeName(_0x357a9d,_0x1b88eb){const _0x4583a1={_0x497ead:0x23d,_0x40a546:0x228,_0x57c7c1:0x1d4,_0x4cacc9:0x1e2,_0x2dbdb9:0x254,_0x8b3611:0x1e6},_0x559339=_0x45f04d,_0x5d6cec=String(_0x357a9d||'');if(/fast cloud|zipdisk/i[_0x559339(_0x4583a1._0x497ead)](_0x5d6cec))return'Fast\x20Cloud';if(/cloud direct/i['test'](_0x5d6cec))return'Cloud\x20Direct';if(/pixeldrain/i[_0x559339(0x23d)](_0x5d6cec))return'Pixeldrain';if(/hubcloud/i['test'](_0x5d6cec))return'HubCloud';if(/gd\s*index|gdflix/i['test'](_0x5d6cec))return _0x559339(_0x4583a1._0x40a546);if(/streamtape/i['test'](_0x5d6cec))return'Streamtape';if(/instant dl/i['test'](_0x5d6cec))return'Instant\x20DL';if(/direct download/i[_0x559339(_0x4583a1._0x497ead)](_0x5d6cec))return _0x559339(_0x4583a1._0x57c7c1);try{const _0xb3ccec=new URL(_0x1b88eb||_0x357a9d)[_0x559339(0x22f)]['toLowerCase']();if(_0xb3ccec['includes']('pixeldrain'))return'Pixeldrain';if(_0xb3ccec['includes'](_0x559339(0x201)))return _0x559339(0x1f2);if(_0xb3ccec['includes']('hubcloud'))return'HubCloud';if(_0xb3ccec[_0x559339(_0x4583a1._0x4cacc9)](_0x559339(_0x4583a1._0x2dbdb9)))return _0x559339(_0x4583a1._0x8b3611);}catch(_0x225eb3){}return'Direct';}function resolveStreamTape(_0x19fb3f,_0x2de7db){const _0x23e5bb={_0x1a7f30:0x20a,_0x461080:0x1fd};return __async(this,null,function*(){const _0x2f4029=_0x5656,_0x4cd131=yield fetchText(_0x19fb3f,{'headers':Object['assign']({},PAGE_HEADERS,{'Referer':_0x2de7db})});if(/video not found/i['test'](_0x4cd131['html']))return'';const _0xf4662f=_0x4cd131[_0x2f4029(0x27d)]['match'](/innerHTML\s*=\s*["']([^"']+)["']\s*\+\s*\(\s*["']([^"']+)["']\s*\)\.substring\((\d+)\)(?:\.substring\((\d+)\))?/i);if(_0xf4662f){let _0x2e0ec2=_0xf4662f[0x2][_0x2f4029(_0x23e5bb._0x1a7f30)](Number(_0xf4662f[0x3]));_0xf4662f[0x4]!==void 0x0&&(_0x2e0ec2=_0x2e0ec2['substring'](Number(_0xf4662f[0x4])));const _0x1e1ee6=(''+_0xf4662f[0x1]+_0x2e0ec2)[_0x2f4029(0x1f8)](/&amp;/gi,'&');return normalizeDirectUrl(_0x1e1ee6[_0x2f4029(0x1da)]('//')?_0x2f4029(_0x23e5bb._0x461080)+_0x1e1ee6:_0x1e1ee6);}return'';});}function resolveKmhdPlayer(_0x3e7641){const _0x5a2a86={_0x2d0f43:0x1cc,_0x5d8261:0x213,_0x305d5d:0x1f4};return __async(this,null,function*(){const _0x4f16c5=_0x5656;var _0x2e262f;const _0x542e33=yield fetchText(_0x3e7641,{'headers':Object[_0x4f16c5(_0x5a2a86._0x2d0f43)]({},PAGE_HEADERS,{'Referer':SITE_URL+'/'})}),_0x4fe9eb=(_0x2e262f=_0x542e33[_0x4f16c5(0x27d)][_0x4f16c5(_0x5a2a86._0x5d8261)](/streamtape_res\s*:\s*["']([^"']+)["']/i))==null?void 0x0:_0x2e262f[0x1];if(!_0x4fe9eb)return'';return resolveStreamTape('https://streamtape.com/e/'+encodeURIComponent(_0x4fe9eb),_0x542e33[_0x4f16c5(_0x5a2a86._0x305d5d)]);});}function fetchKmhdFilePage(_0x47170e){const _0x3f921d={_0x3c3b04:0x209,_0x5c18f4:0x219,_0x4225ea:0x209,_0x3b6b4d:0x209,_0x14d321:0x222,_0x3c4d57:0x1cc,_0x353a5a:0x212};return __async(this,null,function*(){const _0x166bf6=_0x5656,_0x1a8618=new URL(_0x47170e),_0x406e2c='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';let _0x4b9922='';for(let _0xffa0c0=0x0;_0xffa0c0<_0x1a8618['pathname'][_0x166bf6(_0x3f921d._0x3c3b04)];_0xffa0c0+=0x3){const _0x4060d7=_0x1a8618[_0x166bf6(_0x3f921d._0x5c18f4)]['charCodeAt'](_0xffa0c0),_0x3179fd=_0xffa0c0+0x1<_0x1a8618[_0x166bf6(0x219)][_0x166bf6(_0x3f921d._0x4225ea)],_0x1624ad=_0xffa0c0+0x2<_0x1a8618[_0x166bf6(_0x3f921d._0x5c18f4)][_0x166bf6(_0x3f921d._0x3b6b4d)],_0x3a2580=_0x3179fd?_0x1a8618['pathname'][_0x166bf6(_0x3f921d._0x14d321)](_0xffa0c0+0x1):0x0,_0x59629c=_0x1624ad?_0x1a8618['pathname']['charCodeAt'](_0xffa0c0+0x2):0x0;_0x4b9922+=_0x406e2c[_0x4060d7>>0x2],_0x4b9922+=_0x406e2c[(_0x4060d7&0x3)<<0x4|_0x3a2580>>0x4],_0x4b9922+=_0x3179fd?_0x406e2c[(_0x3a2580&0xf)<<0x2|_0x59629c>>0x6]:'=',_0x4b9922+=_0x1624ad?_0x406e2c[_0x59629c&0x3f]:'=';}try{yield fetch(_0x1a8618[_0x166bf6(0x1cb)]+'/locked?/unlock&redirect='+encodeURIComponent(_0x4b9922),{'method':_0x166bf6(0x1e0),'headers':Object[_0x166bf6(_0x3f921d._0x3c4d57)]({},PAGE_HEADERS,{'Content-Type':_0x166bf6(0x21d),'Origin':_0x1a8618['origin'],'Referer':_0x1a8618['origin']+_0x166bf6(_0x3f921d._0x353a5a)+encodeURIComponent(_0x4b9922)}),'skipSizeCheck':!![]});}catch(_0x42f371){}return fetchText(_0x47170e,{'headers':Object['assign']({},PAGE_HEADERS,{'Cookie':'unlocked=true','Referer':SITE_URL+'/'})});});}function resolveGdIndexUrls(_0x2cb4d0,_0xca89c6){const _0xc5e9be={_0x4b0d03:0x1cc,_0x3cb5b5:0x276,_0xbaf69a:0x27d,_0x1a4bc9:0x1f4,_0x24c6cc:0x270};return __async(this,null,function*(){const _0x1523e3=_0x5656;var _0x191302;try{const _0x1dc7b3=yield fetchText(_0x2cb4d0,{'headers':Object[_0x1523e3(_0xc5e9be._0x4b0d03)]({},PAGE_HEADERS,{'Referer':_0xca89c6})}),_0x5a1907=new URL(_0x1dc7b3['url']),_0x24736b=(_0x191302=_0x5a1907[_0x1523e3(0x219)]['match'](/\/file\/([^/?#]+)/i))==null?void 0x0:_0x191302[0x1];if(!_0x24736b)return[];const _0x51b352=_0x5a1907['origin']+_0x1523e3(_0xc5e9be._0x3cb5b5)+_0x24736b,_0x18ff72=yield fetchText(_0x51b352,{'headers':Object['assign']({},PAGE_HEADERS,{'Referer':_0x1dc7b3['url']})});return anchors(_0x18ff72[_0x1523e3(_0xc5e9be._0xbaf69a)],_0x18ff72[_0x1523e3(_0xc5e9be._0x1a4bc9)])['filter'](_0x50b3e6=>/download/i[_0x1523e3(0x23d)](_0x50b3e6[_0x1523e3(0x25f)])&&isDirectMedia(_0x50b3e6[_0x1523e3(0x24e)]))[_0x1523e3(_0xc5e9be._0x24c6cc)](_0x2d9868=>normalizeDirectUrl(_0x2d9868[_0x1523e3(0x24e)]));}catch(_0x589cef){return[];}});}function _0x5656(_0x4764c9,_0x37261d){_0x4764c9=_0x4764c9-0x1cb;const _0x557d31=_0x557d();let _0x565630=_0x557d31[_0x4764c9];if(_0x5656['wGNyZs']===undefined){var _0x5d9cd2=function(_0x8a9a3b){const _0x400342='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0x34fde8='',_0x37f316='';for(let _0x2d6356=0x0,_0x22646d,_0x5a57a0,_0x49a807=0x0;_0x5a57a0=_0x8a9a3b['charAt'](_0x49a807++);~_0x5a57a0&&(_0x22646d=_0x2d6356%0x4?_0x22646d*0x40+_0x5a57a0:_0x5a57a0,_0x2d6356++%0x4)?_0x34fde8+=String['fromCharCode'](0xff&_0x22646d>>(-0x2*_0x2d6356&0x6)):0x0){_0x5a57a0=_0x400342['indexOf'](_0x5a57a0);}for(let _0x57feba=0x0,_0x3624a9=_0x34fde8['length'];_0x57feba<_0x3624a9;_0x57feba++){_0x37f316+='%'+('00'+_0x34fde8['charCodeAt'](_0x57feba)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x37f316);};_0x5656['kKGcga']=_0x5d9cd2,_0x5656['rJJvCQ']={},_0x5656['wGNyZs']=!![];}const _0x5c5dbd=_0x557d31[0x0],_0x413086=_0x4764c9+_0x5c5dbd,_0x5e9e53=_0x5656['rJJvCQ'][_0x413086];return!_0x5e9e53?(_0x565630=_0x5656['kKGcga'](_0x565630),_0x5656['rJJvCQ'][_0x413086]=_0x565630):_0x565630=_0x5e9e53,_0x565630;}function resolveKatMoviesUrls(_0x26fe85){const _0x247cf5={_0x4016e8:0x1f4};return __async(this,null,function*(){const _0xee1b1d=_0x5656;var _0x24baf5;const _0x2193f8=absoluteUrl(_0x26fe85[_0xee1b1d(_0x247cf5._0x4016e8)],SITE_URL);if(!_0x2193f8||/\/play(?:\?|$)/i['test'](_0x2193f8))return[];let _0x50ccca=_0x2193f8;if(/^https?:\/\/links\.kmhd\.eu\/file\//i['test'](_0x2193f8))try{const _0x37acc5=yield fetchKmhdFilePage(_0x2193f8),_0x489cac=(_0x24baf5=_0x37acc5['html']['match'](/gdflix_res:\s*["']([^"']+)["']/i))==null?void 0x0:_0x24baf5[0x1];if(!_0x489cac||/^none$/i['test'](_0x489cac))return[];_0x50ccca=_0xee1b1d(0x25a)+encodeURIComponent(_0x489cac);}catch(_0x30b60e){return[];}if(!/(?:gdflix|gd\.kmhd)\./i['test'](_0x50ccca))return[];return resolveGdIndexUrls(_0x50ccca,_0x2193f8);});}function resolveFilmyFlyUrls(_0x27b8f9){const _0x6812d7={_0x1231de:0x1f4};return __async(this,null,function*(){const _0x37f91a={_0x34f7ed:0x24e,_0x45a830:0x1d6,_0x28c91f:0x1f4,_0x41ba4a:0x1fe,_0x5b217d:0x25f,_0x35a7f5:0x24e},_0x3573ac=_0x5656;try{const _0x352048=yield fetchText(_0x27b8f9[_0x3573ac(_0x6812d7._0x1231de)],{'headers':Object['assign']({},PAGE_HEADERS,{'Referer':SITE_URL+'/'})}),_0x20bfb1=anchors(_0x352048['html'],_0x352048['url'])['filter'](_0x2080d9=>/cloud direct|pixeldrain|hubcloud/i[_0x3573ac(0x23d)](_0x2080d9['text'])),_0x36b461=yield Promise['all'](_0x20bfb1['map'](_0x4683b5=>__async(this,null,function*(){const _0x5c266e=_0x3573ac;if(/hubcloud/i['test'](_0x4683b5['text'])){const _0x117b58=yield resolveSourceUrl({'url':_0x4683b5[_0x5c266e(_0x37f91a._0x34f7ed)],'label':_0x27b8f9[_0x5c266e(_0x37f91a._0x45a830)]},0x0,_0x352048[_0x5c266e(_0x37f91a._0x28c91f)],_0x5c266e(_0x37f91a._0x41ba4a));return _0x117b58?[_0x117b58]:[];}return[{'url':normalizeDirectUrl(_0x4683b5['href']),'route':routeName(_0x4683b5[_0x5c266e(_0x37f91a._0x5b217d)],_0x4683b5[_0x5c266e(_0x37f91a._0x35a7f5)])}];}))),_0x4de222=[]['concat'][_0x3573ac(0x205)]([],_0x36b461);return _0x4de222;}catch(_0x45384d){return[];}});}function resolveDirectUrls(_0x5bcede){return __async(this,null,function*(){const _0x320ee2=_0x5656,_0x26a5e9=normalizeDirectUrl(_0x5bcede[_0x320ee2(0x1f4)]);return _0x26a5e9&&!isKnownUnplayableHost(_0x26a5e9)?[_0x26a5e9]:[];});}function resolveSourceUrl(_0x1c2070){const _0x2ba284={_0x23c2ed:0x23d,_0x35cab6:0x1f4,_0x14ff9a:0x24e};return __async(this,arguments,function*(_0x47585c,_0x4a37df=0x0,_0x6c318e=SITE_URL+'/',_0x51d987=''){const _0x25905f={_0x181d85:0x24e,_0x4ffa34:0x1e2},_0x237f83=_0x5656;if(_0x4a37df>0x5)return null;const _0x26cec8=absoluteUrl(_0x47585c['url'],SITE_URL);if(!_0x26cec8||isKnownUnplayableHost(_0x26cec8))return null;if(isDirectMedia(_0x26cec8))return{'url':normalizeDirectUrl(_0x26cec8),'route':_0x51d987||routeName('',_0x26cec8)};if(/^https?:\/\/links\.kmhd\.eu\/play(?:\?|$)/i[_0x237f83(_0x2ba284._0x23c2ed)](_0x26cec8))try{const _0x51c13d=yield resolveKmhdPlayer(_0x26cec8);return _0x51c13d?{'url':_0x51c13d,'route':_0x51d987||'Streamtape'}:null;}catch(_0x1f9c21){return null;}try{const _0x11324b=yield fetchText(_0x26cec8,{'headers':Object['assign']({},PAGE_HEADERS,{'Referer':_0x6c318e})}),_0x2f83c0=_0x11324b['html']['match'](/window\.location(?:\.href)?\s*=\s*["']([^"']+)["']/i),_0x596f72=anchors(_0x11324b[_0x237f83(0x27d)],_0x11324b['url']),_0x41f1b7=/(?:^|\.)sportverse\.cc$/i['test'](new URL(_0x11324b['url'])['hostname'])?_0x596f72[_0x237f83(0x1e5)](_0x5a2fdc=>{const _0x32bd35=_0x237f83;try{return new URL(_0x5a2fdc[_0x32bd35(_0x25905f._0x181d85)])['hostname']['toLowerCase']()[_0x32bd35(_0x25905f._0x4ffa34)]('.r2.cloudflarestorage.com');}catch(_0x449d09){return![];}}):null,_0x679a25=preferredDownloadLink(_0x596f72),_0x3f0dee=_0x41f1b7?_0x41f1b7:_0x2f83c0?{'href':absoluteUrl(_0x2f83c0[0x1],_0x11324b[_0x237f83(_0x2ba284._0x35cab6)]),'text':''}:_0x679a25,_0x42df5a=_0x3f0dee&&_0x3f0dee[_0x237f83(_0x2ba284._0x14ff9a)];if(!_0x42df5a||_0x42df5a===_0x26cec8)return null;return resolveSourceUrl({'url':_0x42df5a,'label':_0x47585c['label']},_0x4a37df+0x1,_0x11324b[_0x237f83(_0x2ba284._0x35cab6)],_0x51d987||routeName(_0x3f0dee['text'],_0x42df5a));}catch(_0x3c14a6){return null;}});}function sourceName(_0x2fbe1d){const _0x4a30b5={_0x3af7a6:0x23d,_0x209348:0x1df},_0x5e4774=_0x45f04d;if(/4khdhub|hubcloud/i[_0x5e4774(_0x4a30b5._0x3af7a6)](_0x2fbe1d))return'HubCloud';if(/katmovies/i['test'](_0x2fbe1d))return'KatMovies';if(/filmyfly/i['test'](_0x2fbe1d))return'FilmyFly';if(/premium\s*hm/i[_0x5e4774(_0x4a30b5._0x3af7a6)](_0x2fbe1d))return _0x5e4774(_0x4a30b5._0x209348);return'KatMovies';}function sourceFamily(_0x1e9c62,_0x2ff69b){const _0x47a16f={_0x407541:0x256,_0x23071c:0x206,_0x1908f7:0x25e,_0x356b58:0x1e7,_0xc4df75:0x269,_0x4f1eab:0x1dc},_0x49d7e1=_0x45f04d;if(/4khdhub|hubcloud/i['test'](_0x1e9c62))return _0x49d7e1(_0x47a16f._0x407541);if(/katmovies/i[_0x49d7e1(0x23d)](_0x1e9c62))return'katmovies';if(/filmyfly/i['test'](_0x1e9c62))return _0x49d7e1(_0x47a16f._0x23071c);if(/premium\s*hm/i['test'](_0x1e9c62))return _0x49d7e1(_0x47a16f._0x1908f7);try{const _0x1f075c=new URL(_0x2ff69b)['hostname'][_0x49d7e1(_0x47a16f._0x356b58)]();if(_0x1f075c===_0x49d7e1(_0x47a16f._0xc4df75)||_0x1f075c['endsWith']('.111477.xyz'))return _0x49d7e1(_0x47a16f._0x4f1eab);}catch(_0x4b109d){}return _0x49d7e1(0x22d);}function qualityFromLabel(_0x39fb22){const _0x577fdb=_0x45f04d,_0x53503c=String(_0x39fb22||'')['replace'](/р/gi,'p');if(/\b(?:2160p|4k)\b/i['test'](_0x53503c))return'2160p';const _0x482c1a=_0x53503c[_0x577fdb(0x213)](/\b(1080|720|480)p\b/i);return _0x482c1a?_0x482c1a[0x1]+'p':_0x577fdb(0x26c);}function qualityRank(_0x66286f){const _0x2e545c={_0x20606c:0x23d,_0x166d55:0x23d},_0x47b690=_0x45f04d;if(/2160p|4k/i['test'](_0x66286f))return 0x4;if(/1080p/i[_0x47b690(_0x2e545c._0x20606c)](_0x66286f))return 0x3;if(/720p/i[_0x47b690(_0x2e545c._0x166d55)](_0x66286f))return 0x2;if(/480p/i[_0x47b690(_0x2e545c._0x166d55)](_0x66286f))return 0x1;return 0x0;}function sizeFromLabel(_0x480a53){const _0x43c489={_0x232b9e:0x213,_0x345eb9:0x1ec},_0x1440fb=_0x45f04d,_0x259ab0=String(_0x480a53||'')[_0x1440fb(_0x43c489._0x232b9e)](/([\d.]+)\s*(GB|MB|KB)/i);return _0x259ab0?_0x259ab0[0x1]+'\x20'+_0x259ab0[0x2][_0x1440fb(_0x43c489._0x345eb9)]():'';}function filenameFromUrl(_0x1f3a29){const _0x5823cb={_0x1f2f4d:0x1ff,_0x3f044b:0x1fc,_0x2f536f:0x219,_0x125a97:0x238,_0x5d924c:0x1f8,_0x5648bf:0x268},_0x3dd37d=_0x45f04d;var _0x47da49;try{const _0x53e498=new URL(_0x1f3a29),_0x2613d6=_0x53e498[_0x3dd37d(0x20d)][_0x3dd37d(_0x5823cb._0x1f2f4d)](_0x3dd37d(_0x5823cb._0x3f044b))||'',_0x37cdc8=(_0x47da49=_0x2613d6[_0x3dd37d(0x213)](/filename\*?=(?:UTF-8''|["']?)([^"';]+(?:\.[a-z0-9]{2,5}))/i))==null?void 0x0:_0x47da49[0x1],_0x2812b1=_0x53e498[_0x3dd37d(_0x5823cb._0x2f536f)]['split']('/')['filter'](Boolean)[_0x3dd37d(_0x5823cb._0x125a97)]()||'',_0x3cd7b7=_0x37cdc8||_0x2812b1;if(!/\.(?:mkv|mp4|avi|mov|webm)$/i['test'](_0x3cd7b7))return'';return decodeURIComponent(_0x3cd7b7['replace'](/\+/g,'\x20'))[_0x3dd37d(_0x5823cb._0x5d924c)](/\.(?:mkv|mp4|avi|mov|webm)$/i,'')[_0x3dd37d(_0x5823cb._0x5d924c)](/_+/g,'\x20')[_0x3dd37d(_0x5823cb._0x5d924c)](/\s+/g,'\x20')[_0x3dd37d(_0x5823cb._0x5648bf)]();}catch(_0x492004){return'';}}function typeFromUrl(_0x4e8073){const _0x43023d={_0x180c8b:0x23d,_0x41c5b8:0x24c,_0xbf1991:0x224},_0x54b43d=_0x45f04d;if(/\.m3u8(?:$|[?#])/i['test'](_0x4e8073))return _0x54b43d(0x223);if(/\.mpd(?:$|[?#])/i['test'](_0x4e8073))return'application/dash+xml';if(/\.mp4(?:$|[?#])/i[_0x54b43d(_0x43023d._0x180c8b)](_0x4e8073)||/\/get_video\?(?:[^#]*&)?id=/i[_0x54b43d(0x23d)](_0x4e8073))return _0x54b43d(_0x43023d._0x41c5b8);return _0x54b43d(_0x43023d._0xbf1991);}function playbackReferer(_0xb49e15,_0x1f1692){const _0x2e9710={_0x5c379f:0x1ce,_0x5bb9ee:0x201},_0x180daa=_0x45f04d;try{const _0x2c07ea=new URL(_0xb49e15);if(_0x2c07ea[_0x180daa(0x22f)]['toLowerCase']()[_0x180daa(_0x2e9710._0x5c379f)](_0x180daa(_0x2e9710._0x5bb9ee)))return _0x2c07ea['protocol']+'//'+_0x2c07ea['hostname']+'/';}catch(_0x164cc6){}return _0x1f1692||SITE_URL+'/';}function parseStreamInfo(_0x15758a,_0x57d28f,_0x440b07,_0x18c630,_0x1dfa97){const _0x48e4af={_0x3f4c53:0x208,_0x227800:0x26d,_0x5c52fe:0x23d,_0x39ac6d:0x1e8,_0x3a5dc7:0x23d,_0x41ab4e:0x23d,_0x2fffa1:0x227,_0x3de83a:0x257,_0xb4a4c5:0x23d,_0x454b77:0x235,_0x5db485:0x1dd,_0x5ade4d:0x1f5,_0x2152cd:0x266},_0x1eda2e=_0x45f04d,_0x1ca769=((_0x57d28f||'')+'\x20'+(_0x15758a||'')+'\x20'+(_0x440b07||''))['replace'](/р/gi,'p');let _0x261a8e=qualityFromLabel(_0x1ca769),_0xd45d1c=getResolutionEmoji(_0x261a8e);const _0x2d1be5=''+_0xd45d1c;let _0x23995c=_0x1eda2e(0x261);if(/dual[- .]?audio/i['test'](_0x1ca769))_0x23995c='🗣️\x20Dual-Audio';else{if(/multi[- .]?audio/i['test'](_0x1ca769))_0x23995c=_0x1eda2e(0x261);else{const _0x35f4a6=['Hindi','English','Tamil','Telugu','Malayalam',_0x1eda2e(0x233)][_0x1eda2e(_0x48e4af._0x3f4c53)](_0x14fc63=>new RegExp('\x5cb'+_0x14fc63+'\x5cb','i')['test'](_0x1ca769));if(_0x35f4a6['length']>0x1)_0x23995c=_0x1eda2e(0x253)+_0x35f4a6[_0x1eda2e(_0x48e4af._0x227800)]('-');else _0x35f4a6['length']===0x1&&(_0x23995c='🗣️\x20'+_0x35f4a6[0x0]);}}const _0x21cd15=_0x18c630||_0x1dfa97||sizeFromLabel(_0x1ca769)||'',_0x32e8ea=_0x21cd15?_0x1eda2e(0x1d1)+_0x21cd15:'';let _0x52353a='MKV';if(/\.mp4/i[_0x1eda2e(_0x48e4af._0x5c52fe)](_0x15758a)||/\.mp4/i['test'](_0x440b07))_0x52353a='MP4';else{if(/\.mkv/i[_0x1eda2e(_0x48e4af._0x5c52fe)](_0x15758a)||/\.mkv/i['test'](_0x440b07))_0x52353a='MKV';else{if(/\.webm/i['test'](_0x15758a)||/\.webm/i['test'](_0x440b07))_0x52353a='WEBM';}}const _0x2db237=_0x1eda2e(_0x48e4af._0x39ac6d)+_0x52353a;let _0x37d5a4='x265';if(/\bHEVC\b/i[_0x1eda2e(_0x48e4af._0x3a5dc7)](_0x1ca769))_0x37d5a4='HEVC';else{if(/\bx265\b|H[.]?265/i['test'](_0x1ca769))_0x37d5a4='x265';else{if(/\bx264\b|AVC|H[.]?264/i['test'](_0x1ca769))_0x37d5a4='x264';else{if(/\bAV1\b/i[_0x1eda2e(_0x48e4af._0x41ab4e)](_0x1ca769))_0x37d5a4=_0x1eda2e(0x21e);}}}const _0x2e685b='⚡\x20'+_0x37d5a4;let _0x28c5cc=_0x1eda2e(_0x48e4af._0x2fffa1);if(/\b(?:DDP?\s?5\.1|DD\+\s?5\.1|EAC3)\b/i[_0x1eda2e(_0x48e4af._0x5c52fe)](_0x1ca769))_0x28c5cc='DDP\x205.1';else{if(/\bDDP?\s?2\.0\b/i['test'](_0x1ca769))_0x28c5cc=_0x1eda2e(_0x48e4af._0x3de83a);else{if(/\bDTS(?:-HD)?\b/i[_0x1eda2e(_0x48e4af._0xb4a4c5)](_0x1ca769))_0x28c5cc='DTS';else{if(/\bTrueHD\b/i['test'](_0x1ca769))_0x28c5cc='TrueHD';else{if(/\bAAC\b/i['test'](_0x1ca769))_0x28c5cc='AAC';}}}}let _0x5df576='🎧\x20'+_0x28c5cc;/\bAtmos\b/i['test'](_0x1ca769)&&(_0x5df576=_0x1eda2e(_0x48e4af._0x454b77)+_0x28c5cc+'\x20•\x20🔊\x20Atmos');const _0x759afb=[];if(/\bHDR10\+\b/i['test'](_0x1ca769))_0x759afb['push']('HDR10+');else{if(/\bHDR\b/i[_0x1eda2e(0x23d)](_0x1ca769))_0x759afb[_0x1eda2e(0x1f5)](_0x1eda2e(_0x48e4af._0x5db485));}if(/\b10[- ]?bit\b/i[_0x1eda2e(0x23d)](_0x1ca769))_0x759afb[_0x1eda2e(_0x48e4af._0x5ade4d)](_0x1eda2e(0x1cf));const _0x12d796=_0x759afb['length']>0x0?_0x1eda2e(_0x48e4af._0x2152cd)+_0x759afb['join']('\x20•\x20'):'',_0x3c6f0e=/\bDV\b|\bDolby[- ]?Vision\b|\bDoVi\b/i['test'](_0x1ca769)?'✨\x20DV':'',_0x385d16=/\bESub\b|\bEnglish\s*Sub\b/i['test'](_0x1ca769)?_0x1eda2e(0x244):'',_0x4cff42=[_0x12d796,_0x3c6f0e,_0x385d16]['filter'](Boolean)[_0x1eda2e(0x26d)](_0x1eda2e(0x21f));return{'q':_0x261a8e,'qLine':_0x2d1be5,'audioLang':_0x23995c,'sizeLine':_0x32e8ea,'formatLine':_0x2db237,'codecLine':_0x2e685b,'audioLine':_0x5df576,'enhancementsLine':_0x4cff42,'sz':_0x21cd15};}function makeStream(_0x344476,_0x25d14f,_0xf2fbcc,_0x46f552,_0xc80083){const _0x253879={_0x3509c4:0x1f4,_0x5ba110:0x1d6,_0x4b31df:0x259,_0x24d1f5:0x1d6,_0x4d48c3:0x246,_0x51bebc:0x230,_0x218671:0x24f,_0x5d37dd:0x25b,_0x45312d:0x220,_0x559553:0x24f,_0x546a26:0x236,_0x4fb4e1:0x25c,_0x421f87:0x1f6,_0x310820:0x26d,_0x280b6e:0x208,_0x14df30:0x27e},_0x173bd4=_0x45f04d,_0x28a9dc=_0x25d14f[_0x173bd4(_0x253879._0x3509c4)],_0x48d205=sourceName(_0x344476[_0x173bd4(_0x253879._0x5ba110)]||''),_0x553c46=_0x25d14f[_0x173bd4(_0x253879._0x4b31df)]||routeName('',_0x28a9dc),_0x82d56a=filenameFromUrl(_0x28a9dc)||_0x48d205+_0x173bd4(0x202),_0x4b244a=parseStreamInfo(_0x82d56a,_0x344476[_0x173bd4(_0x253879._0x24d1f5)],_0x28a9dc,_0x344476['size'],_0x344476[_0x173bd4(0x20e)]),_0x3b4ce0=qualityRank(_0x4b244a['q']),_0xedefd3=parseSizeToMB(_0x4b244a['sz']),_0x39df63=getInvertedSortTag(_0x3b4ce0*0x186a0+_0xedefd3,0xf423f),_0x48f9ca=_0x39df63+'1Shows\x20•\x20'+_0x4b244a['q']+'\x20•\x20'+_0x553c46+(_0x46f552>0x1?'\x20'+(_0xf2fbcc+0x1):''),_0x6fd43e=_0xc80083[_0x173bd4(0x1e4)]==='tv'?_0x173bd4(_0x253879._0x4d48c3)+_0xc80083[_0x173bd4(_0x253879._0x51bebc)]+(_0xc80083['year']?'\x20('+_0xc80083[_0x173bd4(_0x253879._0x218671)]+')':'')+_0x173bd4(_0x253879._0x5d37dd)+_0xc80083['season']+'E'+_0xc80083[_0x173bd4(_0x253879._0x45312d)]:_0x173bd4(_0x253879._0x4d48c3)+_0xc80083['title']+(_0xc80083['year']?'\x20('+_0xc80083[_0x173bd4(_0x253879._0x559553)]+')':''),_0x1b6409=[_0x4b244a[_0x173bd4(_0x253879._0x546a26)],_0x4b244a[_0x173bd4(_0x253879._0x4fb4e1)],_0x4b244a[_0x173bd4(_0x253879._0x421f87)]]['filter'](Boolean)[_0x173bd4(_0x253879._0x310820)]('\x20|\x20'),_0x951dd=[_0x4b244a[_0x173bd4(0x245)],_0x4b244a['audioLine']][_0x173bd4(_0x253879._0x280b6e)](Boolean)[_0x173bd4(_0x253879._0x310820)]('\x20'),_0xdd6a3a=[_0x4b244a['formatLine'],_0x951dd]['filter'](Boolean)['join']('\x20|\x20'),_0x44c4c2=_0x4b244a[_0x173bd4(_0x253879._0x14df30)],_0x44932d='🔗\x20'+_0x48d205+'\x20|\x20🌐\x20'+_0x553c46,_0x3c1a5a=[_0x6fd43e,_0x1b6409,_0xdd6a3a,_0x44c4c2,_0x44932d]['filter'](_0x13ce37=>_0x13ce37!==''),_0x3d3ff1=_0x3c1a5a[_0x173bd4(_0x253879._0x310820)]('\x0a'),_0x1e73f7={'User-Agent':USER_AGENT,'Referer':playbackReferer(_0x28a9dc,_0x344476[_0x173bd4(0x1f4)])};return{'name':_0x48f9ca,'title':_0x3d3ff1,'size':_0x3d3ff1,'description':_0x3d3ff1,'url':_0x28a9dc,'type':typeFromUrl(_0x28a9dc),'qualityRank':_0x3b4ce0,'sizeInMB':_0xedefd3,'behaviorHints':{'notWebReady':!![],'proxyHeaders':{'request':_0x1e73f7}}};}function resolveSource(_0x3bc755,_0x241a3b){const _0x5ba7a3={_0x2139f4:0x1d6,_0x22dad9:0x271,_0x41a134:0x270};return __async(this,null,function*(){const _0x2fa203=_0x5656,_0x38e4c4=sourceFamily(_0x3bc755[_0x2fa203(_0x5ba7a3._0x2139f4)]||'',_0x3bc755['url']),_0x3c8b4a=_0x38e4c4===_0x2fa203(_0x5ba7a3._0x22dad9)?(yield resolveKatMoviesUrls(_0x3bc755))['map'](_0x201257=>({'url':_0x201257,'route':_0x2fa203(0x228)})):_0x38e4c4==='filmyfly'?yield resolveFilmyFlyUrls(_0x3bc755):_0x38e4c4==='direct'?(yield resolveDirectUrls(_0x3bc755))[_0x2fa203(_0x5ba7a3._0x41a134)](_0x854ade=>({'url':_0x854ade,'route':'Direct'})):[yield resolveSourceUrl(_0x3bc755)],_0x35df36=_0x3c8b4a['filter']((_0x12def0,_0x25bd41)=>_0x12def0&&_0x12def0[_0x2fa203(0x1f4)]&&_0x3c8b4a['findIndex'](_0x1735f3=>_0x1735f3&&_0x1735f3[_0x2fa203(0x1f4)]===_0x12def0['url'])===_0x25bd41);return _0x35df36[_0x2fa203(0x270)]((_0x348241,_0x17df3f)=>makeStream(_0x3bc755,_0x348241,_0x17df3f,_0x35df36['length'],_0x241a3b));});}function isStreamAlive(_0x155ebe){const _0x211c62={_0x386895:0x273,_0x1e7c3e:0x1f9,_0x593d37:0x1eb,_0x409971:0x226,_0x31776c:0x265,_0x135de6:0x1ff,_0x2572bc:0x204,_0x2f33f2:0x1d3,_0x38261b:0x1d3,_0xfdb106:0x21a};return __async(this,null,function*(){const _0x208ee5=_0x5656;var _0x7ca39b;const _0x2b5b4d=Date[_0x208ee5(_0x211c62._0x386895)]();try{const _0x18591c=yield fetch(_0x155ebe[_0x208ee5(0x1f4)],{'method':_0x208ee5(_0x211c62._0x1e7c3e),'headers':Object[_0x208ee5(0x1cc)]({},_0x155ebe[_0x208ee5(0x265)]||{},{'Range':_0x208ee5(_0x211c62._0x593d37)}),'redirect':_0x208ee5(_0x211c62._0x409971),'skipSizeCheck':!![]}),_0x1b96d7=String(_0x18591c['headers']&&_0x18591c['headers']['get']?_0x18591c[_0x208ee5(_0x211c62._0x31776c)][_0x208ee5(_0x211c62._0x135de6)](_0x208ee5(0x24b))||'':''),_0x2bfe74=String(_0x18591c[_0x208ee5(_0x211c62._0x31776c)]&&_0x18591c[_0x208ee5(0x265)]['get']?_0x18591c[_0x208ee5(_0x211c62._0x31776c)][_0x208ee5(0x1ff)]('content-type')||'':'')['toLowerCase'](),_0x2f44e5=Number(((_0x7ca39b=_0x1b96d7[_0x208ee5(0x213)](/\/(\d+)$/))==null?void 0x0:_0x7ca39b[0x1])||0x0),_0x1d4148=_0x18591c[_0x208ee5(0x23c)]===0xce&&/^bytes\s+0-1\//i[_0x208ee5(0x23d)](_0x1b96d7)&&_0x2f44e5>=0x400*0x400,_0x4c73dd=_0x18591c['ok']&&(/mpegurl|application\/vnd\.apple\.mpegurl/i['test'](_0x2bfe74)||/\.m3u8(?:$|[?#])/i[_0x208ee5(0x23d)](_0x155ebe['url']));_0x1d4148&&(_0x155ebe[_0x208ee5(_0x211c62._0x2572bc)]=Math['floor'](_0x2f44e5/(0x400*0x400)));if(/video\/mp4/i['test'](_0x2bfe74))_0x155ebe[_0x208ee5(_0x211c62._0x2f33f2)]='video/mp4';else{if(/video\/webm/i['test'](_0x2bfe74))_0x155ebe[_0x208ee5(_0x211c62._0x38261b)]='video/webm';else{if(/matroska/i['test'](_0x2bfe74))_0x155ebe[_0x208ee5(0x1d3)]=_0x208ee5(0x224);else{if(/mpegurl/i[_0x208ee5(0x23d)](_0x2bfe74))_0x155ebe[_0x208ee5(0x1d3)]='application/x-mpegURL';}}}return _0x155ebe[_0x208ee5(_0x211c62._0xfdb106)]=Date['now']()-_0x2b5b4d,_0x18591c['ok']||_0x18591c['status']===0xce||_0x1d4148||_0x4c73dd;}catch(_0x29e070){return!![];}});}function mediaFingerprint(_0x1469bc){const _0x39f119={_0x4e2772:0x23d},_0x57e3d4=_0x45f04d;if(!/1Shows/i[_0x57e3d4(_0x39f119._0x4e2772)](_0x1469bc[_0x57e3d4(0x263)]||''))return'';try{const _0x1ae9b3=decodeURIComponent(new URL(_0x1469bc['url'])['pathname']['split']('/')['filter'](Boolean)[_0x57e3d4(0x238)]()||'');return/\.(?:mkv|mp4|webm)$/i['test'](_0x1ae9b3)?_0x1ae9b3['toLowerCase']():'';}catch(_0x3f0473){return'';}}function getStreams(_0x15afc7,_0x4f0503,_0x5c0f1e,_0x58fa21,_0x4ed345){const _0x260d7c={_0xb167a7:0x225,_0x5255e8:0x214,_0x12c9d1:0x24f,_0x35d1b7:0x239,_0x412b49:0x205,_0x4e0f9e:0x22e},_0x52c2a5={_0x1e6dbf:0x274,_0x511c4a:0x204},_0x11ec61={_0xa67460:0x1f4,_0x4368dc:0x1f4};return __async(this,null,function*(){const _0x483050=_0x5656,_0x5109ca=String(_0x4f0503||'')['toLowerCase']()['trim'](),_0x2296e1=_0x5109ca===_0x483050(_0x260d7c._0xb167a7)||_0x5109ca==='show'||_0x5109ca==='tvshow'||_0x5109ca==='tv_show'||_0x5109ca==='tv'?'tv':'movie';if(!_0x15afc7)return[];const _0x2c98a3=Number(_0x5c0f1e),_0x1e7878=Number(_0x58fa21);if(_0x2296e1==='tv'&&(!Number['isInteger'](_0x2c98a3)||_0x2c98a3<0x1||!Number[_0x483050(0x221)](_0x1e7878)||_0x1e7878<0x1))return[];try{const _0x4d08ca=yield Promise[_0x483050(_0x260d7c._0x5255e8)]([fetchDownloadSources(String(_0x15afc7),_0x2296e1,_0x2c98a3,_0x1e7878),fetchMediaDetails(String(_0x15afc7),_0x2296e1)]),_0x352839=_0x4d08ca[0x0],_0x5c0e7a=_0x4d08ca[0x1],_0x138489={'title':_0x5c0e7a[_0x483050(0x230)],'year':_0x5c0e7a[_0x483050(_0x260d7c._0x12c9d1)],'mediaType':_0x2296e1,'season':_0x2c98a3,'episode':_0x1e7878},_0x2ff607=_0x352839[_0x483050(0x208)](_0xc18641=>_0xc18641&&_0xc18641[_0x483050(0x1f4)]&&(!_0x4ed345||sourceFamily(_0xc18641[_0x483050(0x1d6)]||'',_0xc18641['url'])===_0x4ed345)&&!hasWrongYear((_0xc18641[_0x483050(0x1d6)]||'')+'\x20'+_0xc18641[_0x483050(0x1f4)],_0x138489['year'])),_0x28d699=yield Promise['all'](_0x2ff607['map'](_0x5c56ec=>resolveSource(_0x5c56ec,_0x138489))),_0x1454bd=[][_0x483050(_0x260d7c._0x35d1b7)][_0x483050(_0x260d7c._0x412b49)]([],_0x28d699),_0x358601=_0x1454bd['filter']((_0x4e5370,_0x316ee7)=>_0x4e5370&&_0x4e5370['url']&&_0x1454bd['findIndex'](_0x165b95=>_0x165b95&&_0x165b95[_0x483050(0x1f4)]===_0x4e5370[_0x483050(0x1f4)])===_0x316ee7),_0x33392f=yield Promise[_0x483050(0x214)](_0x358601['map'](_0x1c6cd5=>__async(this,null,function*(){return _0x1c6cd5&&(yield isStreamAlive(_0x1c6cd5))?_0x1c6cd5:null;}))),_0x3feb97={};for(const _0x22b49d of _0x33392f){if(!_0x22b49d)continue;const _0x3bd11f=mediaFingerprint(_0x22b49d);_0x3bd11f&&(!_0x3feb97[_0x3bd11f]||_0x22b49d['_probeMs']<_0x3feb97[_0x3bd11f]['_probeMs'])&&(_0x3feb97[_0x3bd11f]=_0x22b49d);}const _0x37a95b={};let _0x196ca3=_0x33392f['filter'](_0x370676=>{const _0x29deb5=_0x483050;if(!_0x370676||!_0x370676[_0x29deb5(_0x11ec61._0xa67460)]||_0x37a95b[_0x370676[_0x29deb5(_0x11ec61._0x4368dc)]])return![];const _0x432018=mediaFingerprint(_0x370676);if(_0x432018&&_0x3feb97[_0x432018]!==_0x370676)return![];return _0x37a95b[_0x370676[_0x29deb5(0x1f4)]]=!![],delete _0x370676['_probeMs'],!![];});return _0x196ca3[_0x483050(0x231)]((_0x59dd1d,_0x449b5e)=>{const _0x2b7d17=_0x483050;if(_0x449b5e['qualityRank']!==_0x59dd1d['qualityRank'])return _0x449b5e[_0x2b7d17(_0x52c2a5._0x1e6dbf)]-_0x59dd1d['qualityRank'];return _0x449b5e[_0x2b7d17(0x204)]-_0x59dd1d[_0x2b7d17(_0x52c2a5._0x511c4a)];}),_0x196ca3[_0x483050(_0x260d7c._0x4e0f9e)](_0x21584f=>{const _0x4a7654=_0x483050;delete _0x21584f[_0x4a7654(0x274)],delete _0x21584f[_0x4a7654(0x204)];}),_0x196ca3;}catch(_0x1a9238){return[];}});}typeof module!==_0x45f04d(0x23b)&&module[_0x45f04d(0x1fb)]?module[_0x45f04d(0x1fb)]={'getStreams':getStreams}:global['getStreams']=getStreams;

/* CLOUDBANK_1SHOWS_CURRENT_API_V1
 * Public download API protocol checked 2026-10-24 against makimaDL 8f94222afb4794c1.
 * Retains authenticated AES-GCM and existing host extractors. No Node crypto dependency.
 */
function showsLog(message) { console.log('[1Shows] ' + message); }
const showsRawFetch = fetch;
fetch = async function(url, options) {
  const opts = Object.assign({}, options || {});
  const controller = typeof AbortController === 'function' ? new AbortController() : null;
  const parent = opts.signal;
  const abort = function() { if (controller) controller.abort(); };
  if (parent && parent.aborted) throw new Error('Request cancelled');
  if (controller) opts.signal = controller.signal;
  if (parent && parent.addEventListener) parent.addEventListener('abort', abort);
  let timer;
  try {
    return await Promise.race([
      showsRawFetch(url, opts),
      new Promise(function(_, reject) { timer = setTimeout(function() { abort(); reject(new Error('HTTP timeout')); }, /^https:\/\/api\.viduki\.net\//i.test(String(url)) ? 8000 : 4500); })
    ]);
  } finally {
    clearTimeout(timer);
    if (parent && parent.removeEventListener) parent.removeEventListener('abort', abort);
  }
};
// HTTP errors are errors; never silently accept a challenge page as a download page.
fetchText = async function(url, options) {
  const response = await fetch(url, options);
  if (!response.ok) throw new Error('Page HTTP ' + response.status);
  return {html: await response.text(), url: response.url || url};
};
const showsOriginalPreferred = preferredDownloadLink;
preferredDownloadLink = function(links) {
  const preferred = showsOriginalPreferred(links);
  if (preferred) return preferred;
  // Current HubCloud pages link to this explicit download gateway.
  return links.find(function(link) {
    try {
      const url = new URL(link.href);
      return url.protocol === 'https:' && url.hostname === 'gamerxyt.com' && url.pathname === '/hubcloud.php';
    } catch (_) { return false; }
  }) || null;
};
function showsHeaders(stream) {
  return Object.assign({}, stream.behaviorHints && stream.behaviorHints.proxyHeaders && stream.behaviorHints.proxyHeaders.request || {}, stream.headers || {});
}
isStreamAlive = async function(stream) {
  const start = Date.now();
  try {
    const headers = showsHeaders(stream);
    const isHls = /\.m3u8(?:$|[?#])/i.test(stream.url) || /mpegurl/i.test(stream.type || '');
    const response = await fetch(stream.url, {method: isHls ? 'GET' : 'HEAD', headers: headers, redirect: 'follow'});
    if (!response.ok) return false;
    const mime = String(response.headers.get('content-type') || '').toLowerCase();
    if (isHls || /mpegurl/.test(mime)) {
      // A HEAD response cannot prove HLS contents; fetch its small playlist.
      const playlist = isHls ? response : await fetch(stream.url, {headers: headers});
      if (!playlist.ok || !/^\s*#EXTM3U\b/.test(await playlist.text())) return false;
      stream.type = 'application/x-mpegURL';
    } else {
      // HEAD prevents downloading a complete movie when a server ignores Range.
      if (!/^video\//.test(mime) && !/^application\/(?:octet-stream|x-matroska)(?:;|$)/.test(mime)) return false;
      const size = Number(response.headers.get('content-length') || 0);
      if (size && size < 1048576) return false;
      if (size) stream.sizeInMB = Math.floor(size / 1048576);
      if (/^video\//.test(mime)) stream.type = mime.split(';')[0];
    }
    stream._probeMs = Date.now() - start;
    return true;
  } catch (_) { return false; }
};
async function showsWithin(promise, ms) {
  let timer;
  try { return await Promise.race([promise, new Promise(function(_, reject) { timer = setTimeout(function() { reject(new Error('Resolver budget exceeded')); }, ms); })]); }
  finally { clearTimeout(timer); }
}
getStreams = async function(id, type, season, episode, family) {
  const mediaType = /^(?:tv|series|show|tvshow|tv_show)$/i.test(String(type)) ? 'tv' : 'movie';
  const s = Number(season), e = Number(episode);
  if (!/^\d+$/.test(String(id || ''))) return [];
  if (mediaType === 'tv' && (!Number.isInteger(s) || s < 1 || !Number.isInteger(e) || e < 1)) return [];
  const scanStarted = Date.now();
  showsLog('v1.1.0 exact ' + mediaType + '/' + id + (mediaType === 'tv' ? '/' + s + '/' + e : '') + '; authenticated portable decoder');
  try {
    const data = await Promise.all([fetchDownloadSources(String(id), mediaType, s, e), fetchMediaDetails(String(id), mediaType)]);
    const context = Object.assign({}, data[1], {mediaType: mediaType, season: s, episode: e});
    // TV filenames commonly carry an episode air year rather than the series year.
    const expectedYear = mediaType === 'movie' ? context.year : null;
    const seenCandidates = new Set();
    const candidates = data[0].filter(function(row) {
      if (!row || !/^https?:\/\//i.test(row.url || '') || seenCandidates.has(row.url)) return false;
      seenCandidates.add(row.url);
      return (!family || sourceFamily(row.label || '', row.url) === family) && !hasWrongYear((row.label || '') + ' ' + row.url, expectedYear);
    });
    showsLog('API candidates=' + data[0].length + '; after identity/duplicate filters=' + candidates.length);
    const resolveBudget = Math.min(12000, 17500 - (Date.now() - scanStarted));
    if (resolveBudget < 250) { showsLog('NO_RESULT: scan budget exhausted before extraction'); return []; }
    let resolvedLinks = 0, rejectedMedia = 0, failedResolvers = 0;
    const results = await Promise.all(candidates.map(async function(row) {
      try {
        return await showsWithin((async function() {
          const resolved = await resolveSource(row, context);
          resolvedLinks += resolved.length;
          const checked = await Promise.all(resolved.filter(function(stream) {
            return stream && stream.url && !hasWrongYear(filenameFromUrl(stream.url), expectedYear);
          }).map(async function(stream) { if (await isStreamAlive(stream)) return stream; rejectedMedia++; return null; }));
          return checked.filter(Boolean);
        })(), resolveBudget);
      } catch (_) { failedResolvers++; return []; }
    }));
    const seen = new Set();
    const streams = [].concat.apply([], results).filter(function(stream) {
      if (seen.has(stream.url)) return false;
      seen.add(stream.url); return true;
    });
    streams.sort(function(a,b) { return (b.qualityRank || 0) - (a.qualityRank || 0) || (b.sizeInMB || 0) - (a.sizeInMB || 0); });
    streams.forEach(function(stream) { delete stream.qualityRank; delete stream.sizeInMB; delete stream._probeMs; });
    showsLog('RESOLVE: media=' + resolvedLinks + ' rejected=' + rejectedMedia + ' failed_or_timedout=' + failedResolvers);
    showsLog('RESULT: ' + streams.length + ' HTTP-checked sources; device playback unverified');
    return streams;
  } catch (error) {
    showsLog('NO_RESULT: ' + String(error && error.message || 'API/decode failure').replace(/https?:\/\/\S+/g, '[url]'));
    return [];
  }
};
module.exports = {getStreams: getStreams};
/* CLOUDBANK_1SHOWS_CURRENT_API_END */

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "1shows", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_PLAYIMDB_DISPLAY_START */
/* CLOUDBANK_PLAYIMDB_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  if (providerId === "playimdb") return provider; // Reference output stays exactly upstream.
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name) || (lines.length ? lines[0] : "");
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    var labelledAudio = /🌍\s*([^|\n]+)/.exec(originalTitle);
    if (!audioLang && labelledAudio) audioLang = language(labelledAudio[1]);
    var filenameAudio = /(?:^|[._ -])(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese)(?=[._ -]|$)/i.exec(clean(stream.fileName || stream.filename));
    if (!audioLang && filenameAudio) audioLang = language(filenameAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage)) || /\boriginal[- ]audio\b/i.test(text)) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    var labelledServer = /📌\s*([^|\n]+)/.exec(originalTitle);
    if (!server && labelledServer) server = usable(labelledServer[1]);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    var firstLine = lines.length ? "🎬 " + lines[0] : "";
    // Match PlayIMDb's original typography and order, without its guessed defaults.
    if (displayTitle) {
      firstLine = type === "tv" ? "🎬 " + usable(meta.title || meta.name) + " - S" + Number(season) + "E" + Number(episode) + (year ? " (" + year[0] + ")" : "") :
        "🎬 " + usable(meta.title || meta.name) + (year ? " - " + year[0] : "");
    }
    var qualityDisplay = qualityLabel === "4K" ? "2160P" : qualityLabel.toUpperCase();
    var audioDisplay = audioLabel.replace(/[- ]Audio/g, "").trim();
    var infoLine = [qualityDisplay ? "💎 " + qualityDisplay : "", audioDisplay ? "🌍 " + audioDisplay : ""].filter(Boolean).join(" | ");
    var bottomLine = [formatLabel ? "🎞️ " + (formatLabel === "HLS" ? "M3U8" : formatLabel) : "", duration ? "⏱️ " + duration : "", "📌 " + server].filter(Boolean).join(" | ");
    var nameQuality = qualityLabel === "4K" ? "4K UHD" : qualityLabel === "1080p" ? "1080p FHD" : qualityLabel === "720p" ? "720p HD" : qualityLabel;
    output.name = ["🟡 " + providerName, nameQuality, audioLabel ? audioLabel.replace(/ Audio/g, "-Audio") : ""].filter(Boolean).join(" | ");
    output.title = [firstLine, infoLine, bottomLine].filter(Boolean).join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "1Shows", "1shows");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
/* CLOUDBANK_PLAYIMDB_DISPLAY_END */
