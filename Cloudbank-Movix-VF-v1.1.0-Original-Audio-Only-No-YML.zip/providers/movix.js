// Imported provider: movix; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        original_language: raw.originalLanguage || "",
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
var _0x2a35f6=_0x2bf8;(function(_0x29e659,_0x2ab58e){var _0x357f73={_0x3ee5b3:0x96,_0x3cb309:0xbd,_0x2aa0ae:0x9d,_0x5c703a:0x88,_0x1eef60:0x9b,_0x3d748c:0x87,_0x166d50:0xa6,_0x2df2be:0x8c},_0x5cb990=_0x2bf8,_0x313054=_0x29e659();while(!![]){try{var _0x3dc1fe=parseInt(_0x5cb990(0xa4))/0x1+-parseInt(_0x5cb990(_0x357f73._0x3ee5b3))/0x2+parseInt(_0x5cb990(_0x357f73._0x3cb309))/0x3+-parseInt(_0x5cb990(_0x357f73._0x2aa0ae))/0x4+parseInt(_0x5cb990(_0x357f73._0x5c703a))/0x5*(-parseInt(_0x5cb990(_0x357f73._0x1eef60))/0x6)+-parseInt(_0x5cb990(_0x357f73._0x3d748c))/0x7+-parseInt(_0x5cb990(_0x357f73._0x166d50))/0x8*(-parseInt(_0x5cb990(_0x357f73._0x2df2be))/0x9);if(_0x3dc1fe===_0x2ab58e)break;else _0x313054['push'](_0x313054['shift']());}catch(_0x2cb502){_0x313054['push'](_0x313054['shift']());}}}(_0x157f,0x418d1));var TMDB_KEY=_0x2a35f6(0xad),DOMAINS_URL='https://raw.githubusercontent.com/wooodyhood/nuvio-repo/main/domains.json',MOVIX_FALLBACK=_0x2a35f6(0x93),_cachedEndpoint=null;function _0x157f(){var _0x19afc0=['Bw92AxG','ovHryLPTrW','nZiWCa','CMvWBgfJzq','Bw92Awu','CMvMzxjLCG','zxbPC29Kzv9YDw5FDgLTzq','rhvHBc1bDwrPBW','y2fZAa','mta4mha','Dw5KzwzPBMvK','otu5mJe0EMDdEMfy','8j+nVYa','l2fWAs9JCgfZBwfSl3r2lW','8j+hUVcFH7GG4OcIipcFH6VWN4E3','r0vu','mtjSCNLnC3C','zMLYC3rFywLYx2rHDgu','mtC0odC2ognSDNzkBa','jMXHBMD1ywDLpwvUlvvt','BMfTzq','Dg9vChbLCKnHC2u','DgHLBG','ywXS','C2XPy2u','mtq5nti2AK1syNje','BgfUzW','nZKYndqZmKnTv1bwuG','mta4ma','Ahr0Chm6lY9TB3zPEc4','ig1PBG','zM9YrwfJAa','zhvYyxrPB24','yxbP','zJnKnZu3odi0zJa4zweYy2zMndvLyJHMndDJytnHmwu','Ahr0Chm6lY9HCgKUDgHLBw92AwvKyI5VCMCVmY8','jMvWAxnVzgu9','8j+hQ/cFH7C','zMLSDgvY','zxHWB3j0CW','tw92AxG','BgvUz3rO','z2v0u3rYzwfTCW','Btn1oa','ic0G','CMvSzwfZzv9KyxrL','CgXHEwvY','ChvZAa','ihWG','Aw5KzxHpzG','mte2ntiYn0nSAu9ksG','ANnVBG','sc4YnJq','BgLUA3m','tw92AxGGFca','EwvHCG','BwfW','Dg9mB3DLCKnHC2u','p2fWAv9RzxK9','C3bSAxq','vK9tvezs','CMvZB2X2zq','y2f0y2G','C291CMnLCW','DgL0Bgu','ihWG8j+oTsa','l3n0CMvHBt9ZzwfZB249','mJmZmtCYmu9dqw9owG','mJuYmJvzs0voAvK','l3n0CMvHBq','DxjS'];_0x157f=function(){return _0x19afc0;};return _0x157f();}function getTmdbMetadata(_0x27aaad,_0x579339){var _0x45457c={_0x1c7d44:0x8f,_0x50f3c4:0x9e},_0x114a35={_0x38a933:0xb8,_0x5c8a8a:0xa9},_0x319e14=_0x2a35f6,_0x22192c=_0x319e14(0xae)+(_0x579339==='tv'?'tv':_0x319e14(_0x45457c._0x1c7d44))+'/'+_0x27aaad+_0x319e14(0x7e)+TMDB_KEY+_0x319e14(_0x45457c._0x50f3c4);return fetch(_0x22192c)['then'](function(_0x276b6d){var _0x4d273b=_0x319e14;return _0x276b6d[_0x4d273b(0xbe)]();})['then'](function(_0x3077cb){var _0x4c713f=_0x319e14,_0x194fba=_0x3077cb[_0x4c713f(_0x114a35._0x38a933)]||_0x3077cb[_0x4c713f(0x9c)]||'';return{'originalLanguage':_0x3077cb.original_language||'','name':_0x3077cb[_0x4c713f(0x84)]||_0x3077cb['name']||_0x4c713f(0xb3),'year':_0x194fba?_0x194fba[_0x4c713f(0x7f)]('-')[0x0]:'','duration':_0x579339===_0x4c713f(0x8f)&&_0x3077cb['runtime']?_0x3077cb['runtime']+'\x20min':_0x579339==='tv'&&_0x3077cb[_0x4c713f(0x91)]&&_0x3077cb['episode_run_time']['length']>0x0?_0x3077cb[_0x4c713f(0x91)][0x0]+_0x4c713f(_0x114a35._0x5c8a8a):''};})['catch'](function(){var _0x4ec38a=_0x319e14;return{'name':_0x4ec38a(0xb3),'year':'','duration':''};});}function getEpisodeInfo(_0x394bd7,_0x8879af,_0x4021d4){var _0x10fe55=_0x2a35f6;if(!_0x394bd7||!_0x8879af||!_0x4021d4)return Promise[_0x10fe55(0x81)](null);var _0x4de06e='https://api.themoviedb.org/3/tv/'+_0x394bd7+'/season/'+_0x8879af+'/episode/'+_0x4021d4+_0x10fe55(0x7e)+TMDB_KEY+_0x10fe55(0x9e);return fetch(_0x4de06e)['then'](function(_0x2ec0b3){return _0x2ec0b3['json']();})['then'](function(_0x3b5101){return{'name':_0x3b5101['name']||null,'duration':_0x3b5101['runtime']?_0x3b5101['runtime']+'\x20min':null};})[_0x10fe55(0x82)](function(){return null;});}function buildTitle(_0x48dfca,_0x31f40c,_0x2fe997,_0x4e3592,_0xbff04c,_0x55b198,_0x5beac5,_0x533cb8,_0x2c55a6){var _0x1a8d32={_0x242689:0x8e,_0x23ed36:0x92,_0xef597:0x99,_0x95a154:0x97,_0x35ffa2:0x9f,_0x464df3:0xbb,_0x2c80ae:0x9f,_0x2a4eda:0xc2,_0x2d40ad:0xbc,_0x3d4541:0xab,_0x7edcb0:0xab,_0x2889ba:0xab},_0x2f90bf=_0x2a35f6,_0x146172=_0x31f40c[_0x2f90bf(0xc4)]()[_0x2f90bf(_0x1a8d32._0x242689)](/p/g,'')+'p',_0x2dd22d='⚡',_0x519a57='VF',_0x23f645=_0x2f90bf(0xb0),_0x4482f7=(String(_0x2fe997)+'\x20'+String(_0x31f40c)+'\x20'+String(_0x55b198))['toUpperCase']();if(_0x4482f7['indexOf']('MULTI')!==-0x1||_0x4482f7['indexOf']('DUAL')!==-0x1)_0x519a57=_0x2f90bf(_0x1a8d32._0x23ed36),_0x23f645=_0x2f90bf(_0x1a8d32._0xef597);else _0x4482f7['indexOf']('VOST')!==-0x1&&(_0x519a57='VOSTFR',_0x23f645=_0x2f90bf(0x99));var _0x3edf99=_0x2f90bf(_0x1a8d32._0x95a154);_0x5beac5&&_0x533cb8?_0x3edf99+='S'+_0x5beac5+'\x20E'+_0x533cb8+(_0x2c55a6&&_0x2c55a6[_0x2f90bf(_0x1a8d32._0x35ffa2)]?_0x2f90bf(0xb7)+_0x2c55a6[_0x2f90bf(0x9f)]:'')+_0x2f90bf(_0x1a8d32._0x464df3)+_0x48dfca[_0x2f90bf(_0x1a8d32._0x2c80ae)]:_0x3edf99+=_0x48dfca[_0x2f90bf(_0x1a8d32._0x2c80ae)]+(_0x48dfca[_0x2f90bf(_0x1a8d32._0x2a4eda)]?'\x20-\x20'+_0x48dfca[_0x2f90bf(_0x1a8d32._0x2a4eda)]:'');var _0x5da3b7=_0x2dd22d+'\x20'+_0x146172+'\x20|\x20💬\x20'+_0x519a57+_0x2f90bf(0x85)+_0x23f645,_0x39586b=(_0x4e3592||'M3U8')['toUpperCase'](),_0x2f4914=_0x2f90bf(0xbf);(_0x4482f7['indexOf']('HEVC')!==-0x1||_0x4482f7[_0x2f90bf(_0x1a8d32._0x2d40ad)]('X265')!==-0x1||_0x4482f7[_0x2f90bf(0xbc)]('H265')!==-0x1)&&(_0x2f4914='H.265');var _0x271807=_0x2c55a6&&_0x2c55a6[_0x2f90bf(_0x1a8d32._0x3d4541)]?_0x2c55a6[_0x2f90bf(_0x1a8d32._0x7edcb0)]:_0x48dfca[_0x2f90bf(_0x1a8d32._0x2889ba)],_0x242352=_0x271807?'\x20|\x20'+_0x271807:'',_0x3fd813='💿\x20'+_0x39586b+'\x20•\x20'+_0x2f4914+'\x20|\x20🎧\x20AAC'+_0x242352;return _0x3edf99+'\x0a'+_0x5da3b7+'\x0a'+_0x3fd813;}function _0x2bf8(_0x2113e7,_0x127d42){_0x2113e7=_0x2113e7-0x7e;var _0x157f10=_0x157f();var _0x2bf831=_0x157f10[_0x2113e7];if(_0x2bf8['YgFTRO']===undefined){var _0x44f4ba=function(_0x43a286){var _0x2a254b='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';var _0x27aaad='',_0x579339='';for(var _0x22192c=0x0,_0x276b6d,_0x3077cb,_0x194fba=0x0;_0x3077cb=_0x43a286['charAt'](_0x194fba++);~_0x3077cb&&(_0x276b6d=_0x22192c%0x4?_0x276b6d*0x40+_0x3077cb:_0x3077cb,_0x22192c++%0x4)?_0x27aaad+=String['fromCharCode'](0xff&_0x276b6d>>(-0x2*_0x22192c&0x6)):0x0){_0x3077cb=_0x2a254b['indexOf'](_0x3077cb);}for(var _0x394bd7=0x0,_0x8879af=_0x27aaad['length'];_0x394bd7<_0x8879af;_0x394bd7++){_0x579339+='%'+('00'+_0x27aaad['charCodeAt'](_0x394bd7)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x579339);};_0x2bf8['OBsBMX']=_0x44f4ba,_0x2bf8['OMzWBM']={},_0x2bf8['YgFTRO']=!![];}var _0x25b185=_0x157f10[0x0],_0xf86ad3=_0x2113e7+_0x25b185,_0x4ef7d2=_0x2bf8['OMzWBM'][_0xf86ad3];return!_0x4ef7d2?(_0x2bf831=_0x2bf8['OBsBMX'](_0x2bf831),_0x2bf8['OMzWBM'][_0xf86ad3]=_0x2bf831):_0x2bf831=_0x4ef7d2,_0x2bf831;}function detectApi(){var _0x1f944c={_0x553cf6:0xa8};if(_cachedEndpoint)return Promise['resolve'](_cachedEndpoint);return fetch(DOMAINS_URL)['then'](function(_0x4bec86){return _0x4bec86['ok']?_0x4bec86['json']():Promise['reject']();})['then'](function(_0x160061){var _0x5bcbee=_0x2bf8,_0x5b2afa=_0x160061[_0x5bcbee(0x8b)]||MOVIX_FALLBACK;return _cachedEndpoint={'api':'https://api.movix.'+_0x5b2afa,'referer':_0x5bcbee(_0x1f944c._0x553cf6)+_0x5b2afa+'/'},_cachedEndpoint;})['catch'](function(){return _cachedEndpoint={'api':'https://api.movix.'+MOVIX_FALLBACK,'referer':'https://movix.'+MOVIX_FALLBACK+'/'},_cachedEndpoint;});}function resolveRedirect(_0x19f047,_0x5d8074){var _0x42cd9a={_0xdf0824:0x9a},_0x2826cb={_0x22079c:0x8a},_0x288299=_0x2a35f6;return fetch(_0x19f047,{'method':_0x288299(_0x42cd9a._0xdf0824),'redirect':'follow','headers':{'User-Agent':'Mozilla/5.0','Referer':_0x5d8074}})['then'](function(_0x777d3d){var _0x255d76=_0x288299;return _0x777d3d[_0x255d76(_0x2826cb._0x22079c)]||_0x19f047;})[_0x288299(0x82)](function(){return _0x19f047;});}function resolveEmbed(_0x16b0f3,_0x4d4d48){var _0xc8944f={_0x5ec6f1:0xa1},_0x1570a7=_0x2a35f6;return fetch(_0x16b0f3,{'method':'GET','redirect':'follow','headers':{'User-Agent':'Mozilla/5.0','Referer':_0x4d4d48}})[_0x1570a7(_0xc8944f._0x5ec6f1)](function(_0x5f5378){return _0x5f5378['text']();})['then'](function(_0x1a4b38){var _0x357168=_0x1570a7,_0x425b97=[/file\s*:\s*["']([^"']+\.m3u8[^"']*)["']/i,/source\s+src=["']([^"']+\.m3u8[^"']*)["']/i,/["']([^"']*\.m3u8(?:\?[^"']*)?)["']/i];for(var _0x29f66c=0x0;_0x29f66c<_0x425b97[_0x357168(0xb4)];_0x29f66c++){var _0x3884f1=_0x1a4b38['match'](_0x425b97[_0x29f66c]);if(_0x3884f1)return _0x3884f1[0x1]['startsWith']('//')?'https:'+_0x3884f1[0x1]:_0x3884f1[0x1];}return null;})[_0x1570a7(0x82)](function(){return null;});}function fetchPurstream(_0x40939b,_0x3e3fa5,_0x248b98,_0x398da9,_0x26a352,_0x55dab8){var _0x4fc634={_0x1ef089:0xaf,_0x5d59f2:0x89},_0x1fbd53=_0x2a35f6,_0xdb4c55=_0x398da9==='tv'?_0x40939b+'/api/purstream/tv/'+_0x248b98+_0x1fbd53(0x86)+(_0x26a352||0x1)+_0x1fbd53(_0x4fc634._0x1ef089)+(_0x55dab8||0x1):_0x40939b+'/api/purstream/movie/'+_0x248b98+_0x1fbd53(_0x4fc634._0x5d59f2);return fetch(_0xdb4c55,{'headers':{'Referer':_0x3e3fa5}})['then'](function(_0x43751f){return _0x43751f['json']();})['then'](function(_0x29bb94){var _0x3df380=_0x1fbd53;return _0x29bb94[_0x3df380(0x83)]||[];});}function fetchCpasmal(_0x5423f9,_0x101f58,_0x44ee3d,_0x307147,_0x4b17da,_0xb7422c){var _0x2d9e61={_0x4b57c9:0x98,_0x11af41:0xa1},_0x322756={_0xcb7dc2:0xc0},_0x2f6652=_0x2a35f6,_0x2688f4=_0x307147==='tv'?_0x5423f9+_0x2f6652(_0x2d9e61._0x4b57c9)+_0x44ee3d+'/'+(_0x4b17da||0x1)+'/'+(_0xb7422c||0x1):_0x5423f9+'/api/cpasmal/movie/'+_0x44ee3d;return fetch(_0x2688f4,{'headers':{'Referer':_0x101f58}})[_0x2f6652(0xa1)](function(_0x2c9d6a){var _0x45931b=_0x2f6652;return _0x2c9d6a[_0x45931b(0xbe)]();})[_0x2f6652(_0x2d9e61._0x11af41)](function(_0x3eac4f){var _0x154f44=_0x2f6652,_0x5f404e=[];return['vf','vostfr'][_0x154f44(0xaa)](function(_0x1185e3){var _0xd1fa5={_0x2f95da:0xba,_0x10d9f5:0xb3},_0x26f0dc=_0x154f44;_0x3eac4f[_0x26f0dc(0xc0)]&&_0x3eac4f[_0x26f0dc(_0x322756._0xcb7dc2)][_0x1185e3]&&_0x3eac4f['links'][_0x1185e3]['forEach'](function(_0x45a1d3){var _0xd182b7=_0x26f0dc;_0x5f404e[_0xd182b7(_0xd1fa5._0x2f95da)]({'url':_0x45a1d3[_0xd182b7(0x8a)],'name':_0xd182b7(_0xd1fa5._0x10d9f5),'player':_0x45a1d3['server'],'lang':_0x1185e3});});}),_0x5f404e;});}function tryFetchAll(_0x3941d5,_0xc17801,_0x5b6fe6,_0x1f472a,_0x485697,_0x534552,_0x274e75,_0x5d0def){var _0x481c0c={_0x2f8c72:0x82},_0x8697ca=_0x2a35f6;return fetchPurstream(_0x3941d5,_0xc17801,_0x5b6fe6,_0x1f472a,_0x485697,_0x534552)[_0x8697ca(0xa1)](function(_0x18b303){var _0x4eb6aa={_0xec5f91:0x9f},_0x2b561c=_0x8697ca;return Promise[_0x2b561c(0xa2)](_0x18b303['map'](function(_0x1ade2a){var _0x10482c=_0x2b561c;return resolveRedirect(_0x1ade2a[_0x10482c(0x8a)],_0xc17801)['then'](function(_0x2dcf49){var _0x8459a8=_0x10482c,_0x3f5d84=(_0x1ade2a['name']||'')[_0x8459a8(0xbc)](_0x8459a8(0xa7))!==-0x1?_0x8459a8(0x94):_0x8459a8(0x8d),_0x59bf78=(_0x1ade2a[_0x8459a8(_0x4eb6aa._0xec5f91)]||'')['indexOf']('VOST')!==-0x1?_0x8459a8(0x80):(_0x1ade2a['name']||'')['indexOf']('VF')!==-0x1?'VF':'Dual-Audio',_0x16424f=buildTitle(_0x274e75,_0x3f5d84,_0x59bf78,_0x1ade2a['format']||_0x8459a8(0xb6),null,null,_0x485697,_0x534552,_0x5d0def);return{'name':_0x8459a8(0xc1)+_0x3f5d84['toLowerCase']()+_0x8459a8(0xbb)+_0x59bf78,'title':_0x16424f,'size':_0x16424f,'description':_0x16424f,'url':_0x2dcf49,'quality':'','language':'','format':_0x1ade2a['format']||'m3u8','headers':{'User-Agent':'Mozilla/5.0'}};});}));})[_0x8697ca(_0x481c0c._0x2f8c72)](function(){var _0xa52aa0={_0x198cc4:0xa1};return fetchCpasmal(_0x3941d5,_0xc17801,_0x5b6fe6,_0x1f472a,_0x485697,_0x534552)['then'](function(_0x442c5e){var _0x29de33={_0x4e7c46:0xb1},_0x357a8f={_0x437d80:0x80,_0x8d02d5:0xb6,_0x4f6f9c:0xb9},_0x33cfe9=_0x2bf8;return Promise['all'](_0x442c5e[_0x33cfe9(0xa3)](0x0,0x5)[_0x33cfe9(0xc3)](function(_0x9f0a2c){return resolveEmbed(_0x9f0a2c['url'],_0xc17801)['then'](function(_0x413b29){var _0x2a4415=_0x2bf8;if(!_0x413b29)return null;var _0x2a772c=_0x9f0a2c['lang']&&_0x9f0a2c[_0x2a4415(0xa5)][_0x2a4415(0xa0)]()==='VOSTFR'?_0x2a4415(_0x357a8f._0x437d80):'VF',_0x5d7f53=buildTitle(_0x274e75,'HD',_0x2a772c,_0x2a4415(_0x357a8f._0x8d02d5),'',_0x9f0a2c[_0x2a4415(_0x357a8f._0x4f6f9c)],_0x485697,_0x534552,_0x5d0def);return{'name':'Movix\x20|\x20hd\x20|\x20'+_0x2a772c,'title':_0x5d7f53,'size':_0x5d7f53,'description':_0x5d7f53,'url':_0x413b29,'quality':'','language':'','format':_0x2a4415(_0x357a8f._0x8d02d5),'headers':{'Referer':_0xc17801}};});}))[_0x33cfe9(_0xa52aa0._0x198cc4)](function(_0xb72cb7){var _0x56126c=_0x33cfe9;return _0xb72cb7[_0x56126c(_0x29de33._0x4e7c46)](function(_0x1aafeb){return _0x1aafeb!==null;});});});});}function getStreams(_0x1cf2d2,_0x3e20a7,_0x4c17e8,_0x334912){var _0x7cb5dd={_0x1ef100:0xac,_0x23a1e0:0x90},_0x1cefbd=_0x2a35f6;return Promise['all']([getTmdbMetadata(_0x1cf2d2,_0x3e20a7),_0x3e20a7==='tv'?getEpisodeInfo(_0x1cf2d2,_0x4c17e8,_0x334912):Promise['resolve'](null),detectApi()])[_0x1cefbd(0xa1)](function(_0xd591cb){var _0x57d453=_0x1cefbd,_0x5e17ed=_0xd591cb[0x0],_0x21195e=_0xd591cb[0x1],_0x592f09=_0xd591cb[0x2];return tryFetchAll(_0x592f09[_0x57d453(_0x7cb5dd._0x1ef100)],_0x592f09[_0x57d453(_0x7cb5dd._0x23a1e0)],_0x1cf2d2,_0x3e20a7,_0x4c17e8,_0x334912,_0x5e17ed,_0x21195e);})['catch'](function(){return[];});}typeof module!==_0x2a35f6(0x95)&&module[_0x2a35f6(0xb2)]?module['exports']={'getStreams':getStreams}:global[_0x2a35f6(0xb5)]=getStreams;

/* CLOUDBANK_MOVIX_ORIGINAL_AUDIO_V1 */
function movixOriginalLanguage(value) {
  var code = String(value || '').trim().toLowerCase().split(/[-_]/)[0];
  var aliases = {eng:'en',english:'en',fra:'fr',fre:'fr',french:'fr',jpn:'ja',japanese:'ja',kor:'ko',korean:'ko',hin:'hi',hindi:'hi',zho:'zh',chi:'zh',chinese:'zh',spa:'es',spanish:'es',deu:'de',ger:'de',german:'de',ita:'it',italian:'it',por:'pt',portuguese:'pt'};
  return aliases[code] || (/^[a-z]{2}$/.test(code) ? code : '');
}
function movixIsOriginal(source, originalLanguage) {
  if (!source || typeof source.url !== 'string' || !/^https?:\/\//i.test(source.url)) return false;
  var original = movixOriginalLanguage(originalLanguage);
  var explicit = String(source.audioLanguage || source.lang || source.language || '').trim();
  var label = [source.name, source.version, explicit].filter(Boolean).join(' ').toUpperCase();
  var frenchVersion = /^(?:VF|VFF|VFQ|TRUEFRENCH|FRENCH|FR|FRA|FRE)$/i.test(explicit);
  if (frenchVersion) return original === 'fr';
  if (/(?:^|[^A-Z])(?:VOST(?:FR|A)?|VO|ORIGINAL)(?:$|[^A-Z])/.test(label)) return true;
  var languages = Array.isArray(source.audioLanguages) ? source.audioLanguages.map(movixOriginalLanguage) : [];
  if (original && languages.indexOf(original) !== -1) return true;
  var declared = movixOriginalLanguage(explicit);
  if (declared) return !!original && declared === original;
  // A French original may legitimately be labelled VF. Unknown/dual-only labels
  // cannot prove that the original track is present and are excluded.
  return original === 'fr' && /(?:^|[^A-Z])(?:VF|VFF|VFQ|TRUEFRENCH)(?:$|[^A-Z])/.test(label);
}
function movixNeedsAudioProof(source) {
  if (!source || typeof source.url !== 'string' || !/^https?:\/\//i.test(source.url)) return false;
  return /(?:^|[^A-Z])(?:MULTI|DUAL)(?:$|[^A-Z])/.test(String(source.name || '').toUpperCase());
}
function movixManifestLanguages(text) {
  if (typeof text !== 'string') return [];
  text = text.replace(/^\uFEFF/, '').trim();
  if (text.indexOf('#EXTM3U') !== 0) return [];
  var languages = [];
  text.split(/\r?\n/).forEach(function(line) {
    if (!/^#EXT-X-MEDIA:/i.test(line) || !/TYPE=AUDIO(?:,|$)/i.test(line)) return;
    var match = /(?:^|,)LANGUAGE="([^"]+)"/i.exec(line);
    var language = match ? movixOriginalLanguage(match[1]) : '';
    if (language && languages.indexOf(language) === -1) languages.push(language);
  });
  return languages;
}
tryFetchAll = function(api, referer, id, type, season, episode, metadata, episodeInfo) {
  var original = movixOriginalLanguage(metadata.originalLanguage);
  console.log('[Movix] AUDIO_POLICY: original-only; original=' + (original || 'unknown'));
  function filterOriginal(sources) {
    return (Array.isArray(sources) ? sources : []).filter(function(source) {
      return movixIsOriginal(source, original);
    });
  }
  function stream(url, source, quality) {
    if (typeof url !== 'string' || !/^https?:\/\//i.test(url)) return null;
    var format = source.format || 'm3u8';
    // Retain the content/episode line without the upstream's guessed VF, H.264 or AAC labels.
    var firstLine = buildTitle(metadata, quality || 'HD', 'VOSTFR', format, '', source.player, season, episode, episodeInfo).split('\n')[0];
    var duration = episodeInfo && episodeInfo.duration ? episodeInfo.duration : metadata.duration;
    var title = [firstLine, quality, format.toUpperCase(), duration || ''].filter(Boolean).join('\n');
    return {
      name: 'Movix | ' + (quality || 'HD') + ' | Original',
      title: title, size: title, description: title, url: url,
      quality: quality || '', language: original, audioLanguage: original || 'original',
      format: format,
      headers: {'User-Agent':'Mozilla/5.0'},
    };
  }
  function fallback() {
    return fetchCpasmal(api, referer, id, type, season, episode).then(function(sources) {
      // Filter before the existing five-host budget, so VF cannot crowd out VOSTFR.
      return Promise.all(filterOriginal(sources).slice(0, 5).map(function(source) {
        return resolveEmbed(source.url, referer).then(function(url) {
          var result = stream(url, source, '');
          if (result) result.headers = {'Referer':referer};
          return result;
        }).catch(function() { return null; });
      }));
    }).then(function(results) { return results.filter(function(result) { return result !== null; }); });
  }
  return fetchPurstream(api, referer, id, type, season, episode).then(function(sources) {
    var candidates = (Array.isArray(sources) ? sources : []).filter(function(source) {
      return movixIsOriginal(source, original) || (original && movixNeedsAudioProof(source));
    });
    return Promise.all(candidates.map(function(source) {
      var match = /(?:^|\D)(2160|1440|1080|720|480)p?(?:$|\D)/i.exec(String(source.name || ''));
      var quality = match ? match[1] + 'p' : '';
      if (movixIsOriginal(source, original)) {
        return resolveRedirect(source.url, referer).then(function(url) {
          return stream(url, source, quality);
        }).catch(function() { return null; });
      }
      // Resolve and inspect the HLS master in the same request; never fetch segments.
      return fetch(source.url, {method:'GET', redirect:'follow', headers:{'User-Agent':'Mozilla/5.0', 'Referer':referer}}).then(function(response) {
        if (!response.ok) return null;
        return response.text().then(function(text) {
          var languages = movixManifestLanguages(text);
          if (languages.indexOf(original) === -1) return null;
          var result = stream(response.url || source.url, source, quality);
          if (result) result.audioLanguages = languages;
          return result;
        });
      }).catch(function() { return null; });
    }));
  }).catch(function() { return []; }).then(function(results) {
    var playable = results.filter(function(result) { return result !== null; });
    console.log('[Movix] ORIGINAL_PRIMARY: streams=' + playable.length);
    if (playable.length) return playable;
    console.log('[Movix] ORIGINAL_FALLBACK: no eligible primary source; checking VOSTFR/original entries');
    return fallback();
  });
};

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "movix", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_PLAYIMDB_DISPLAY_START */
/* CLOUDBANK_PLAYIMDB_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  if (providerId === "playimdb") return provider; // Reference output stays exactly upstream.
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name) || (lines.length ? lines[0] : "");
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    var labelledAudio = /🌍\s*([^|\n]+)/.exec(originalTitle);
    if (!audioLang && labelledAudio) audioLang = language(labelledAudio[1]);
    var filenameAudio = /(?:^|[._ -])(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese)(?=[._ -]|$)/i.exec(clean(stream.fileName || stream.filename));
    if (!audioLang && filenameAudio) audioLang = language(filenameAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage)) || /\boriginal[- ]audio\b/i.test(text)) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    var labelledServer = /📌\s*([^|\n]+)/.exec(originalTitle);
    if (!server && labelledServer) server = usable(labelledServer[1]);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    var firstLine = lines.length ? "🎬 " + lines[0] : "";
    // Match PlayIMDb's original typography and order, without its guessed defaults.
    if (displayTitle) {
      firstLine = type === "tv" ? "🎬 " + usable(meta.title || meta.name) + " - S" + Number(season) + "E" + Number(episode) + (year ? " (" + year[0] + ")" : "") :
        "🎬 " + usable(meta.title || meta.name) + (year ? " - " + year[0] : "");
    }
    var qualityDisplay = qualityLabel === "4K" ? "2160P" : qualityLabel.toUpperCase();
    var audioDisplay = audioLabel.replace(/[- ]Audio/g, "").trim();
    var infoLine = [qualityDisplay ? "💎 " + qualityDisplay : "", audioDisplay ? "🌍 " + audioDisplay : ""].filter(Boolean).join(" | ");
    var bottomLine = [formatLabel ? "🎞️ " + (formatLabel === "HLS" ? "M3U8" : formatLabel) : "", duration ? "⏱️ " + duration : "", "📌 " + server].filter(Boolean).join(" | ");
    var nameQuality = qualityLabel === "4K" ? "4K UHD" : qualityLabel === "1080p" ? "1080p FHD" : qualityLabel === "720p" ? "720p HD" : qualityLabel;
    output.name = ["🟡 " + providerName, nameQuality, audioLabel ? audioLabel.replace(/ Audio/g, "-Audio") : ""].filter(Boolean).join(" | ");
    output.title = [firstLine, infoLine, bottomLine].filter(Boolean).join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "Movix VF", "movix");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
/* CLOUDBANK_PLAYIMDB_DISPLAY_END */
