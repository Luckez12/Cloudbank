// Imported provider: cineby; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
const _0x1c95ef=_0x16fc;(function(_0x1413cc,_0x5ddac4){const _0x457d1e={_0x133299:0xb2,_0x118acc:0xa6,_0x44e267:0x95,_0x15e5ca:0x9e,_0x441087:0x93,_0x408756:0x71,_0xdbdc97:0x6e},_0x1da568=_0x16fc,_0x26f66a=_0x1413cc();while(!![]){try{const _0x378b43=-parseInt(_0x1da568(_0x457d1e._0x133299))/0x1*(-parseInt(_0x1da568(_0x457d1e._0x118acc))/0x2)+parseInt(_0x1da568(_0x457d1e._0x44e267))/0x3*(parseInt(_0x1da568(0x96))/0x4)+parseInt(_0x1da568(0x99))/0x5*(-parseInt(_0x1da568(0x72))/0x6)+-parseInt(_0x1da568(_0x457d1e._0x15e5ca))/0x7*(parseInt(_0x1da568(0x78))/0x8)+-parseInt(_0x1da568(_0x457d1e._0x441087))/0x9+parseInt(_0x1da568(0xb0))/0xa+parseInt(_0x1da568(_0x457d1e._0x408756))/0xb*(parseInt(_0x1da568(_0x457d1e._0xdbdc97))/0xc);if(_0x378b43===_0x5ddac4)break;else _0x26f66a['push'](_0x26f66a['shift']());}catch(_0x4f020e){_0x26f66a['push'](_0x26f66a['shift']());}}}(_0x2157,0xec9d6));var __defProp=Object[_0x1c95ef(0x98)],__defProps=Object['defineProperties'],__getOwnPropDescs=Object[_0x1c95ef(0x6d)],__getOwnPropSymbols=Object[_0x1c95ef(0xb6)],__hasOwnProp=Object['prototype'][_0x1c95ef(0xaa)],__propIsEnum=Object['prototype'][_0x1c95ef(0x77)],__defNormalProp=(_0xe10ae9,_0x3ff632,_0x3ec53f)=>_0x3ff632 in _0xe10ae9?__defProp(_0xe10ae9,_0x3ff632,{'enumerable':!![],'configurable':!![],'writable':!![],'value':_0x3ec53f}):_0xe10ae9[_0x3ff632]=_0x3ec53f,__spreadValues=(_0x119f85,_0x4b191f)=>{const _0x582889={_0x944e74:0x7b},_0x4e6c37=_0x1c95ef;for(var _0x5b5e38 in _0x4b191f||(_0x4b191f={}))if(__hasOwnProp['call'](_0x4b191f,_0x5b5e38))__defNormalProp(_0x119f85,_0x5b5e38,_0x4b191f[_0x5b5e38]);if(__getOwnPropSymbols)for(var _0x5b5e38 of __getOwnPropSymbols(_0x4b191f)){if(__propIsEnum[_0x4e6c37(_0x582889._0x944e74)](_0x4b191f,_0x5b5e38))__defNormalProp(_0x119f85,_0x5b5e38,_0x4b191f[_0x5b5e38]);}return _0x119f85;},__spreadProps=(_0x489483,_0x3766c8)=>__defProps(_0x489483,__getOwnPropDescs(_0x3766c8)),__async=(_0x2bbbbc,_0x27b479,_0x435e6f)=>{const _0x3b5e12={_0x441252:0x86},_0x1f124e={_0x35f4c8:0x86};return new Promise((_0x139466,_0x5a70a3)=>{const _0x46d254=_0x16fc;var _0x4c59f2=_0x2b7eb0=>{const _0x5b3657=_0x16fc;try{_0x3d7944(_0x435e6f[_0x5b3657(_0x1f124e._0x35f4c8)](_0x2b7eb0));}catch(_0x384c3b){_0x5a70a3(_0x384c3b);}},_0x4f2aed=_0xee2a8a=>{try{_0x3d7944(_0x435e6f['throw'](_0xee2a8a));}catch(_0xf26a55){_0x5a70a3(_0xf26a55);}},_0x3d7944=_0x4827a7=>_0x4827a7['done']?_0x139466(_0x4827a7[_0x46d254(0xb4)]):Promise['resolve'](_0x4827a7[_0x46d254(0xb4)])['then'](_0x4c59f2,_0x4f2aed);_0x3d7944((_0x435e6f=_0x435e6f['apply'](_0x2bbbbc,_0x27b479))[_0x46d254(_0x3b5e12._0x441252)]());});},DOMAINS_URL='https://raw.githubusercontent.com/sapariyaneel/nuvio-plugin/refs/heads/main/domains.json',FALLBACK_API_HOST=_0x1c95ef(0xad),TMDB_API_KEY='1865f43a0549ca50d341dd9ab8b29f49',HEADERS={'User-Agent':_0x1c95ef(0x9f),'Referer':'https://www.cineby.at/','Origin':'https://www.cineby.at'},cachedDomains=null;function getDomains(){return __async(this,null,function*(){if(cachedDomains)return cachedDomains;try{const _0x584599=yield fetch(DOMAINS_URL,{'skipSizeCheck':!![]});cachedDomains=yield _0x584599['json']();}catch(_0x37b489){cachedDomains={};}return cachedDomains;});}function getApiHost(){const _0x11524e={_0x4720c9:0x84};return __async(this,null,function*(){const _0x12d3d1=_0x16fc,_0x7e0ea9=yield getDomains();return(_0x7e0ea9['speedracelight']||_0x7e0ea9[_0x12d3d1(0xb9)]||FALLBACK_API_HOST)[_0x12d3d1(_0x11524e._0x4720c9)](/\/+$/,'');});}var SHA256_CONSTANTS=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174],MAGIC_BYTES=[0x6d,0x76,0x6d,0x31];function isCustomBranch(_0x21b2e6){return(_0x21b2e6*(_0x21b2e6+0x1)&0x1)===0x0;}function fmix32(_0x2d32ad){const _0x460932={_0x408387:0x7a},_0x411eda=_0x1c95ef;return _0x2d32ad=_0x2d32ad>>>0x0,_0x2d32ad^=_0x2d32ad>>>0x10,_0x2d32ad=Math[_0x411eda(_0x460932._0x408387)](_0x2d32ad,0x85ebca6b)>>>0x0,_0x2d32ad^=_0x2d32ad>>>0xd,_0x2d32ad=Math[_0x411eda(_0x460932._0x408387)](_0x2d32ad,0xc2b2ae35)>>>0x0,_0x2d32ad=(_0x2d32ad^_0x2d32ad>>>0x10)>>>0x0,_0x2d32ad;}function rotl32(_0x3968e5,_0x28915b){_0x3968e5=_0x3968e5>>>0x0,_0x28915b&=0x1f;if(_0x28915b===0x0)return _0x3968e5>>>0x0;return(_0x3968e5<<_0x28915b|_0x3968e5>>>0x20-_0x28915b)>>>0x0;}var BASE64_CHARS=_0x1c95ef(0x7f);function pureBase64Decode(_0x4a6253){const _0x588128={_0x5df4eb:0x88,_0x17f2c4:0x8d,_0x236c0:0xaf},_0x25fbe0=_0x1c95ef;let _0x3d9a9e='';for(let _0x26547f=0x0;_0x26547f<_0x4a6253[_0x25fbe0(0xaf)];_0x26547f++){const _0x2b39b5=_0x4a6253['charAt'](_0x26547f);if(_0x2b39b5!=='='&&BASE64_CHARS[_0x25fbe0(_0x588128._0x5df4eb)](_0x2b39b5)!==-0x1)_0x3d9a9e+=_0x2b39b5;}let _0x484e83='';for(let _0x50964b=0x0;_0x50964b<_0x3d9a9e[_0x25fbe0(0xaf)];_0x50964b+=0x4){const _0x2f56a2=BASE64_CHARS['indexOf'](_0x3d9a9e[_0x25fbe0(_0x588128._0x17f2c4)](_0x50964b)),_0x5e2513=BASE64_CHARS[_0x25fbe0(0x88)](_0x3d9a9e[_0x25fbe0(0x8d)](_0x50964b+0x1)),_0x45a55b=_0x50964b+0x2<_0x3d9a9e['length']?BASE64_CHARS[_0x25fbe0(_0x588128._0x5df4eb)](_0x3d9a9e[_0x25fbe0(0x8d)](_0x50964b+0x2)):-0x1,_0x416c65=_0x50964b+0x3<_0x3d9a9e[_0x25fbe0(_0x588128._0x236c0)]?BASE64_CHARS['indexOf'](_0x3d9a9e['charAt'](_0x50964b+0x3)):-0x1;_0x484e83+=String[_0x25fbe0(0xa3)](_0x2f56a2<<0x2|_0x5e2513>>0x4);if(_0x45a55b!==-0x1)_0x484e83+=String['fromCharCode']((_0x5e2513&0xf)<<0x4|_0x45a55b>>0x2);if(_0x416c65!==-0x1)_0x484e83+=String['fromCharCode']((_0x45a55b&0x3)<<0x6|_0x416c65);}return _0x484e83;}function _0x16fc(_0x3cfa36,_0x9b8e36){_0x3cfa36=_0x3cfa36-0x6d;const _0x215723=_0x2157();let _0x16fc13=_0x215723[_0x3cfa36];if(_0x16fc['iLDtSz']===undefined){var _0x23cf66=function(_0x2f5a30){const _0x237dfe='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0xe10ae9='',_0x3ff632='';for(let _0x3ec53f=0x0,_0x119f85,_0x4b191f,_0x5b5e38=0x0;_0x4b191f=_0x2f5a30['charAt'](_0x5b5e38++);~_0x4b191f&&(_0x119f85=_0x3ec53f%0x4?_0x119f85*0x40+_0x4b191f:_0x4b191f,_0x3ec53f++%0x4)?_0xe10ae9+=String['fromCharCode'](0xff&_0x119f85>>(-0x2*_0x3ec53f&0x6)):0x0){_0x4b191f=_0x237dfe['indexOf'](_0x4b191f);}for(let _0x489483=0x0,_0x3766c8=_0xe10ae9['length'];_0x489483<_0x3766c8;_0x489483++){_0x3ff632+='%'+('00'+_0xe10ae9['charCodeAt'](_0x489483)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x3ff632);};_0x16fc['PbarLA']=_0x23cf66,_0x16fc['hZQBqO']={},_0x16fc['iLDtSz']=!![];}const _0xc1e5a6=_0x215723[0x0],_0x248518=_0x3cfa36+_0xc1e5a6,_0x5ce843=_0x16fc['hZQBqO'][_0x248518];return!_0x5ce843?(_0x16fc13=_0x16fc['PbarLA'](_0x16fc13),_0x16fc['hZQBqO'][_0x248518]=_0x16fc13):_0x16fc13=_0x5ce843,_0x16fc13;}function base64UrlToBytes(_0x27005d){const _0x38869b=_0x1c95ef,_0x41ab19=_0x27005d['replace'](/-/g,'+')[_0x38869b(0x84)](/_/g,'/')['padEnd'](0x4*Math['ceil'](_0x27005d['length']/0x4),'='),_0x34292b=typeof atob==='function'?atob(_0x41ab19):pureBase64Decode(_0x41ab19),_0x576466=new Uint8Array(_0x34292b['length']);for(let _0x3a848b=0x0;_0x3a848b<_0x34292b['length'];_0x3a848b++)_0x576466[_0x3a848b]=_0x34292b['charCodeAt'](_0x3a848b);return _0x576466;}function fnv1a32(_0x22dd18){const _0x3177c8={_0x59f7e1:0x7a,_0x2e9cd3:0x9b},_0x15303c=_0x1c95ef;let _0x248b4b=0x811c9dc5;for(let _0x177963=0x0;_0x177963<_0x22dd18['length'];_0x177963++)_0x248b4b=Math[_0x15303c(_0x3177c8._0x59f7e1)](_0x248b4b^_0x22dd18[_0x15303c(_0x3177c8._0x2e9cd3)](_0x177963),0x1000193)>>>0x0;return fmix32(_0x248b4b);}function makeKeystreamState(_0x2e4eab,_0x152fcc){const _0xd1a525=new Array(0x3d);let _0x3ec03f=fmix32(fnv1a32(_0x2e4eab)^fmix32(_0x152fcc>>>0x0^0x9e3779b9))>>>0x0;for(let _0x35d66c=0x0;_0x35d66c<0x8;_0x35d66c++){if(isCustomBranch(_0x35d66c)){const _0x6dd951=_0x3ec03f%0x3d;_0x3ec03f=rotl32(_0x3ec03f+0x9e3779b9>>>0x0,0x7+(0x7&_0x35d66c)),_0xd1a525[_0x6dd951]=(_0x3ec03f^fmix32(_0x3ec03f))>>>0x0,_0x3ec03f=fmix32(_0x3ec03f+_0x6dd951>>>0x0);}else _0xd1a525[_0x35d66c]=SHA256_CONSTANTS[0xf&_0x35d66c];}return{'slots':_0xd1a525,'acc':fmix32(0xa5a5a5a5^_0x3ec03f)>>>0x0};}function _0x2157(){const _0x5ff6c5=['nJG0odu5nvP3DuDhza','C3vIDgL0BgvZ','owz6C2jwBW','mteWodm0nezSsfnwvq','qNL0zxm','zgvMAw5LuhjVCgvYDhK','nujgruXXAa','C2vLza','y2HHCKnVzgvbDa','C3bSAxq','zxjYB3i','odeWnZa2neHuzxzQBq','tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlZeZms4WlJaUmcbtywzHCMKVntm3lJm2','zxH0zxjUywXFAwrZ','BgfUz3vHz2u','vw5RBM93BG','zNjVBunOyxjdB2rL','zxHWB3j0CW','BMfTzq','nLjny1fjDW','Dgv4Da','zMXVB3i','jMv4DgvYBMfSx3nVDxjJzt1PBwrIx2LK','AgfZt3DUuhjVCgvYDhK','Dw5KzwzPBMvK','C291CMnLCW','Ahr0Chm6lY9HCgKUC3bLzwrYywnLBgLNAhqUy29T','q2LUzwj5ia','BgvUz3rO','mZG1mdi5mhjhtxHlva','BwfW','ntC2ntnyBhHOCNy','DgL0Bgu','DMfSDwu','l2nKBI9ZB3vYy2vZlxDPDgGTDgL0Bgu/','z2v0t3DUuhjVCgvYDhLtEw1IB2XZ','zMLSDgvY','Bg9N','yxbPlNnWzwvKCMfJzwXPz2H0lMnVBq','Aw1KyL9Pza','z2v0t3DUuhjVCgvYDhLezxnJCMLWDg9YCW','ndG2mJrrA0XkENK','y29UDgvUDc1Yyw5Nzq','p2fWAv9RzxK9','ody0nMLyENL0za','mtaXmtuWmJjJDfHPu3q','Ahr0Ca','ANnVBG','Aw1KyKLK','y2vPBa','ChjVCgvYDhLjC0vUDw1LCMfIBgu','oeTmqKnyCq','ywnJ','Aw11Ba','y2fSBa','Bw92AwvFCMvZDwX0CW','w0nPBMvIEv0GzgvJCNLWDcbMywLSzwq6','CxvHBgL0Eq','qujdrevgr0HjsKTmtu5puffsu1rvvLDywvPHyMnKzwzNAgLQA2XTBM9WCxjZDhv2D3H5EJaXmJm0nty3odKRlW','Ahr0Chm6lY9HCgKUDgHLBw92AwvKyI5VCMCVmY8','yNL0zxm9mc0X','AxngAw5PDgu','y2f0y2G','CMvWBgfJzq','Bw92Awu','BMv4Da','DxjS','Aw5KzxHpzG','C2XPy2u','C3vIyxjYyxK','AgvHzgvYCW','DhzFCMvZDwX0CW','y2HHCKf0','Dg9gAxHLza','DhjPBq','ywXS','CMvSzwfZzv9KyxrL','Cg93'];_0x2157=function(){return _0x5ff6c5;};return _0x2157();}function nextKeystreamWord(_0x30ff07,_0x34583b){const _0x5824a6={_0x1ed574:0x7a},_0x58f89e=_0x1c95ef,_0x4f18be=_0x30ff07['slots'],_0x1028bb=_0x30ff07['acc'],_0x71bdc8=_0x1028bb%0x3d,_0x369161=_0x71bdc8 in _0x4f18be?-0x1:0x0,_0x4a9be7=_0x4f18be[_0x71bdc8]>>>0x0,_0x3bd0f4=(_0x4a9be7^Math['imul'](0x9e3779b9,_0x34583b+0x1)>>>0x0)>>>0x0,_0x7bdba=((_0x1028bb^_0x3bd0f4)>>>0x0|(_0x1028bb&_0x3bd0f4&_0x369161)>>>0x0)>>>0x0,_0x3d6292=(rotl32(_0x7bdba+_0x1028bb>>>0x0,0x1f&_0x71bdc8)^rotl32(_0x1028bb,0x1f&Math[_0x58f89e(_0x5824a6._0x1ed574)](_0x71bdc8,0x7)))>>>0x0,_0x57637b=fmix32(_0x3d6292+0x9e3779b9>>>0x0);return _0x4f18be[_0x71bdc8]=_0x57637b>>>0x0,_0x30ff07[_0x58f89e(0x79)]=_0x57637b,_0x57637b>>>0x0;}function generateKeystream(_0x28cfc2,_0x1fccb6,_0x604a16){const _0xa7122b=makeKeystreamState(_0x28cfc2,_0x1fccb6),_0x34d23a=new Uint8Array(_0x604a16);let _0xeb714b=0x0,_0x2ea9d6=0x0;while(_0xeb714b<_0x604a16){const _0x20593e=nextKeystreamWord(_0xa7122b,_0x2ea9d6++);_0x34d23a[_0xeb714b++]=0xff&_0x20593e;if(_0xeb714b<_0x604a16)_0x34d23a[_0xeb714b++]=_0x20593e>>>0x8&0xff;if(_0xeb714b<_0x604a16)_0x34d23a[_0xeb714b++]=_0x20593e>>>0x10&0xff;if(_0xeb714b<_0x604a16)_0x34d23a[_0xeb714b++]=_0x20593e>>>0x18&0xff;}return _0x34d23a;}function utf8BytesToString(_0x549940){const _0x147c74={_0x215f65:0xa3},_0x31c58b=_0x1c95ef;let _0x171c8a='',_0x25f76f=0x0;while(_0x25f76f<_0x549940['length']){const _0x340df2=_0x549940[_0x25f76f++];if(_0x340df2<0x80)_0x171c8a+=String['fromCharCode'](_0x340df2);else{if((_0x340df2&0xe0)===0xc0){const _0x290fb7=_0x549940[_0x25f76f++];_0x171c8a+=String['fromCharCode']((_0x340df2&0x1f)<<0x6|_0x290fb7&0x3f);}else{if((_0x340df2&0xf0)===0xe0){const _0x1bb43a=_0x549940[_0x25f76f++],_0x37c98c=_0x549940[_0x25f76f++];_0x171c8a+=String[_0x31c58b(_0x147c74._0x215f65)]((_0x340df2&0xf)<<0xc|(_0x1bb43a&0x3f)<<0x6|_0x37c98c&0x3f);}else{if((_0x340df2&0xf8)===0xf0){const _0x325db0=_0x549940[_0x25f76f++],_0x221911=_0x549940[_0x25f76f++],_0xaa76b0=_0x549940[_0x25f76f++];let _0x4566f=(_0x340df2&0x7)<<0x12|(_0x325db0&0x3f)<<0xc|(_0x221911&0x3f)<<0x6|_0xaa76b0&0x3f;_0x4566f-=0x10000,_0x171c8a+=String[_0x31c58b(0xa3)](0xd800+(_0x4566f>>0xa),0xdc00+(_0x4566f&0x3ff));}else _0x171c8a+=String[_0x31c58b(0xa3)](_0x340df2);}}}}return _0x171c8a;}function decryptSourcesPayload(_0x219443,_0x4d7883,_0x38593b){const _0x301527={_0x269e9e:0x8a},_0x59dd82=_0x1c95ef,_0x38f1b5=base64UrlToBytes(_0x219443),_0x542810=generateKeystream(_0x4d7883,_0x38593b,_0x38f1b5[_0x59dd82(0xaf)]),_0x23ed59=new Uint8Array(_0x38f1b5['length']);for(let _0x1b7189=0x0;_0x1b7189<_0x38f1b5[_0x59dd82(0xaf)];_0x1b7189++)_0x23ed59[_0x1b7189]=_0x38f1b5[_0x1b7189]^_0x542810[_0x1b7189];for(let _0x47945=0x0;_0x47945<MAGIC_BYTES[_0x59dd82(0xaf)];_0x47945++){if(_0x23ed59[_0x47945]!==MAGIC_BYTES[_0x47945])throw new Error('decrypt\x20failed:\x20bad\x20seed\x20or\x20tampered\x20payload');}const _0x592f55=_0x23ed59[_0x59dd82(_0x301527._0x269e9e)](MAGIC_BYTES['length']);return utf8BytesToString(_0x592f55);}function getTmdbMeta(_0x143a52,_0x45ac7d){const _0x5552a4={_0x2de402:0x85,_0x1b832d:0x74,_0x5414e9:0xa5,_0x28517b:0x91,_0x5d5fce:0xa0,_0x57011c:0xba};return __async(this,null,function*(){const _0x17f3b6=_0x16fc,_0x349966=_0x45ac7d==='tv'?'tv':_0x17f3b6(_0x5552a4._0x2de402),_0xc71d90=_0x17f3b6(0x80)+_0x349966+'/'+_0x143a52+_0x17f3b6(0x70)+TMDB_API_KEY+'&append_to_response=external_ids',_0x4fe2cf=yield fetch(_0xc71d90,{'skipSizeCheck':!![]});if(!_0x4fe2cf['ok'])return null;const _0x5b2511=yield _0x4fe2cf[_0x17f3b6(_0x5552a4._0x1b832d)](),_0x1ab70b=_0x349966==='tv'?_0x5b2511[_0x17f3b6(_0x5552a4._0x5414e9)]:_0x5b2511[_0x17f3b6(0xb3)],_0x57a10a=_0x349966==='tv'?_0x5b2511['first_air_date']:_0x5b2511[_0x17f3b6(_0x5552a4._0x28517b)],_0x2595b0=_0x57a10a?_0x57a10a[_0x17f3b6(0x89)](0x0,0x4):'',_0x2222b6=_0x5b2511[_0x17f3b6(_0x5552a4._0x5d5fce)]&&_0x5b2511[_0x17f3b6(0xa0)][_0x17f3b6(0xba)]||_0x5b2511[_0x17f3b6(_0x5552a4._0x57011c)]||'';return{'title':_0x1ab70b,'year':_0x2595b0,'imdbId':_0x2222b6};});}function qualityRank(_0x5a6344){const _0x58fb0d=_0x1c95ef;if(!_0x5a6344)return 0x0;if(/4k/i['test'](_0x5a6344))return 0x870;const _0x54ce0e=parseInt(_0x5a6344,0xa);return Number[_0x58fb0d(0x82)](_0x54ce0e)?_0x54ce0e:0x0;}function formatBytes(_0x360308){const _0x572abf={_0x38738e:0xa2,_0x23d493:0x97,_0x496641:0xb8,_0x1e5879:0x92,_0x595316:0x8e},_0x37895d=_0x1c95ef;if(!_0x360308)return _0x37895d(_0x572abf._0x38738e);const _0x242179=0x400,_0x1219fa=[_0x37895d(_0x572abf._0x23d493),'KB','MB','GB','TB'],_0x40f6c5=Math[_0x37895d(0xa8)](Math['log'](_0x360308)/Math[_0x37895d(_0x572abf._0x496641)](_0x242179));return parseFloat((_0x360308/Math[_0x37895d(_0x572abf._0x1e5879)](_0x242179,_0x40f6c5))[_0x37895d(_0x572abf._0x595316)](0x2))+'\x20'+_0x1219fa[_0x40f6c5];}var SEGMENT_SAMPLE_SIZE=0x5;function getRealSegmentSize(_0x18911a){const _0x14f173={_0x4ec36f:0x81,_0x48eaaf:0x8b};return __async(this,null,function*(){const _0x35daae=_0x16fc;try{const _0x2c7977=yield fetch(_0x18911a,{'method':'HEAD','headers':HEADERS,'skipSizeCheck':!![]}),_0x1612cc=_0x2c7977['headers']['get']('content-length');if(_0x1612cc)return parseInt(_0x1612cc,0xa);}catch(_0x1e4da8){}try{const _0x37b9c0=yield fetch(_0x18911a,{'headers':__spreadProps(__spreadValues({},HEADERS),{'Range':_0x35daae(_0x14f173._0x4ec36f)}),'skipSizeCheck':!![]}),_0xb0d2fe=_0x37b9c0[_0x35daae(_0x14f173._0x48eaaf)]['get'](_0x35daae(0x6f)),_0x31f2e9=_0xb0d2fe&&_0xb0d2fe['match'](/\/(\d+)$/);if(_0x31f2e9)return parseInt(_0x31f2e9[0x1],0xa);}catch(_0x1b77af){}return null;});}function estimateHlsSize(_0x2f2291){const _0x4e3d71={_0x1287b0:0xa7,_0x32c60d:0x9c,_0xbca97d:0xb7,_0x16c00f:0x90,_0x3f8f25:0xaf};return __async(this,null,function*(){const _0x56f87b=_0x16fc;try{const _0x1c5bc=yield fetch(_0x2f2291,{'headers':HEADERS,'skipSizeCheck':!![]});if(!_0x1c5bc['ok'])return'Unknown';const _0x1f3282=yield _0x1c5bc[_0x56f87b(_0x4e3d71._0x1287b0)](),_0x30be14=_0x1f3282[_0x56f87b(_0x4e3d71._0x32c60d)]('\x0a')['map'](_0x53705d=>_0x53705d[_0x56f87b(0x8f)]())[_0x56f87b(_0x4e3d71._0xbca97d)](_0x355870=>_0x355870['startsWith'](_0x56f87b(0x73)));if(!_0x30be14[_0x56f87b(0xaf)])return'Unknown';const _0x538ed4=_0x30be14['filter']((_0x420f55,_0x1b41ec)=>_0x1b41ec%Math[_0x56f87b(0x76)](_0x30be14['length']/SEGMENT_SAMPLE_SIZE)===0x0)['slice'](0x0,SEGMENT_SAMPLE_SIZE),_0x46508a=yield Promise[_0x56f87b(_0x4e3d71._0x16c00f)](_0x538ed4[_0x56f87b(0xb1)](getRealSegmentSize)),_0x43a78c=_0x46508a[_0x56f87b(_0x4e3d71._0xbca97d)](_0x5bca19=>_0x5bca19&&_0x5bca19>0x0);if(!_0x43a78c[_0x56f87b(0xaf)])return _0x56f87b(0xa2);const _0x37be04=_0x43a78c['reduce']((_0x413c34,_0x5c108a)=>_0x413c34+_0x5c108a,0x0)/_0x43a78c[_0x56f87b(_0x4e3d71._0x3f8f25)],_0x4ce834=_0x37be04*_0x30be14['length'];return formatBytes(_0x4ce834);}catch(_0xc9f2e9){return'Unknown';}});}function getStreams(_0x1c38df,_0x4d3f49,_0x58af4c,_0x90d707){const _0x21a29f={_0x470497:0x8c,_0x1096c1:0x7c,_0x4613dd:0xaf,_0x2717cd:0xb3,_0x39d040:0x9a,_0x1f1fab:0xb5,_0x27dc89:0x9a,_0x47b779:0x9d,_0x248af3:0x7d,_0x4acd2f:0xac};return __async(this,null,function*(){const _0x49e9cc={_0x2d41d9:0x87,_0x2fa432:0x7e,_0x50aca0:0xa2},_0x31616e=_0x16fc;try{let _0x1353d6=_0x1c38df;if(typeof _0x1c38df==='string'&&_0x1c38df[_0x31616e(0x8f)]()['toLowerCase']()['startsWith']('tt')){const _0x2a50cd='https://api.themoviedb.org/3/find/'+_0x1c38df+_0x31616e(0x70)+TMDB_API_KEY+_0x31616e(0xa9),_0x79d92b=yield(yield fetch(_0x2a50cd,{'skipSizeCheck':!![]}))[_0x31616e(0x74)](),_0x5119a7=_0x4d3f49==='tv'?_0x79d92b[_0x31616e(_0x21a29f._0x470497)]:_0x79d92b[_0x31616e(_0x21a29f._0x1096c1)];_0x1353d6=_0x5119a7&&_0x5119a7[_0x31616e(_0x21a29f._0x4613dd)]?_0x5119a7[0x0]['id']:null;if(!_0x1353d6)return[];}_0x1353d6=parseInt(_0x1353d6,0xa);if(!_0x1353d6)return[];const _0x214874=yield getTmdbMeta(_0x1353d6,_0x4d3f49);if(!_0x214874||!_0x214874[_0x31616e(_0x21a29f._0x2717cd)])return[];const _0x1b29f5=yield getApiHost(),_0x355766=_0x4d3f49==='tv',_0x3599a6=yield fetch(_0x1b29f5+'/seed?mediaId='+_0x1353d6,{'headers':HEADERS,'skipSizeCheck':!![]});if(!_0x3599a6['ok'])return[];const _0x59b103=yield _0x3599a6['json']()[_0x31616e(0x83)](()=>null);if(!_0x59b103||!_0x59b103['seed'])return[];const _0x4f7d1b=new URLSearchParams({'title':_0x214874['title'],'mediaType':_0x355766?'tv':_0x31616e(0x85),'year':_0x214874['year']||'','episodeId':String(_0x355766?_0x90d707||0x1:0x1),'seasonId':String(_0x355766?_0x58af4c||0x1:0x1),'tmdbId':String(_0x1353d6),'imdbId':_0x214874[_0x31616e(0x75)]||'','enc':'2','seed':_0x59b103[_0x31616e(_0x21a29f._0x39d040)]}),_0x3b9cf6=yield fetch(_0x1b29f5+_0x31616e(_0x21a29f._0x1f1fab)+_0x4f7d1b['toString'](),{'headers':HEADERS,'skipSizeCheck':!![]});if(!_0x3b9cf6['ok'])return[];const _0x512e72=yield _0x3b9cf6['text']();let _0x1beafa;try{const _0x491ba3=decryptSourcesPayload(_0x512e72,_0x59b103[_0x31616e(_0x21a29f._0x27dc89)],_0x1353d6);_0x1beafa=JSON['parse'](_0x491ba3);}catch(_0x4214b0){return console[_0x31616e(_0x21a29f._0x47b779)](_0x31616e(_0x21a29f._0x248af3),_0x4214b0['message']),[];}const _0x103abf=_0x1beafa&&_0x1beafa[_0x31616e(_0x21a29f._0x4acd2f)]||[];if(!_0x103abf['length'])return[];const _0x3b1fdc=(_0x1beafa&&_0x1beafa[_0x31616e(0x94)]||[])[_0x31616e(0xb7)](_0x48c568=>_0x48c568&&_0x48c568['url'])['map'](_0x3cc3e6=>({'url':_0x3cc3e6['url'],'lang':_0x3cc3e6['lang']||_0x3cc3e6[_0x31616e(0xa1)]||_0x31616e(0xa2)})),_0x33247c=yield Promise[_0x31616e(0x90)](_0x103abf['filter'](_0x1785fe=>_0x1785fe&&_0x1785fe[_0x31616e(0x87)])['map'](_0x5c6fdd=>__async(this,null,function*(){const _0xae071d=_0x31616e,_0x5056fb=yield estimateHlsSize(_0x5c6fdd['url']);return{'url':_0x5c6fdd[_0xae071d(_0x49e9cc._0x2d41d9)],'quality':_0x5c6fdd['quality']||_0xae071d(0xa2),'title':_0xae071d(0xae)+(_0x5c6fdd[_0xae071d(_0x49e9cc._0x2fa432)]||_0xae071d(_0x49e9cc._0x50aca0)),'name':'Cineby','size':_0x5056fb,'headers':HEADERS,'subtitles':_0x3b1fdc};})));return _0x33247c['sort']((_0x5bb2b1,_0x3d14b6)=>qualityRank(_0x3d14b6[_0x31616e(0x7e)])-qualityRank(_0x5bb2b1['quality'])),_0x33247c;}catch(_0x485693){return console[_0x31616e(0x9d)]('[Cineby]',_0x485693),[];}});}typeof module!==_0x1c95ef(0xab)&&module['exports']?module[_0x1c95ef(0xa4)]={'getStreams':getStreams}:global['getStreams']=getStreams;

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "cineby", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_STREAM_DISPLAY_START */
/* CLOUDBANK_STREAM_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name);
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var release = /\b(WEB[ ._-]?DL|WEB[ ._-]?RIP|BLU[ ._-]?RAY|BD[ ._-]?REMUX|REMUX|DVD[ ._-]?RIP|HD[ ._-]?RIP|HDTV|HDCAM|CAM)\b/i.exec(text);
    var releaseLabel = release ? release[1].toUpperCase().replace(/[ ._]/g, "-") : "";
    if (/^WEB-?DL$/.test(releaseLabel)) releaseLabel = "WEB-DL";
    if (/^WEB-?RIP$/.test(releaseLabel)) releaseLabel = "WEBRip";
    if (/^BLU-?RAY$/.test(releaseLabel)) releaseLabel = "BluRay";
    if (/REMUX/.test(releaseLabel)) releaseLabel = "Remux";
    var codec = /\b(HEVC|H[ ._-]?265|X265|AVC|H[ ._-]?264|X264|AV1)\b/i.exec(text);
    var codecLabel = codec ? (/265|HEVC/i.test(codec[1]) ? "HEVC" : /264|AVC/i.test(codec[1]) ? "H.264" : "AV1") : "";
    var hdr = /\b(DOLBY[ ._-]?VISION|HDR10\+|HDR10|HDR|SDR)(?!\w)/i.exec(text);
    var hdrLabel = hdr ? (/DOLBY/i.test(hdr[1]) ? "Dolby Vision" : hdr[1].toUpperCase()) : "";
    var videoLine = unique([qualityLabel, releaseLabel, codecLabel, hdrLabel]).join(" · ");
    if (videoLine) lines.push(videoLine);
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage))) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var audioCodec = /\b(DOLBY[ ._-]?ATMOS|ATMOS|TRUEHD|DTS[ ._-]?HD[ ._-]?MA|DTS[ ._-]?HD|DTS[ ._-]?X|DTS|E[ ._-]?AC[ ._-]?3|DDP|AC[ ._-]?3|AAC|FLAC|OPUS)\b/i.exec(text);
    var audioCodecLabel = audioCodec ? audioCodec[1].toUpperCase().replace(/[ ._]/g, "-") : "";
    if (/ATMOS/.test(audioCodecLabel)) audioCodecLabel = "Dolby Atmos";
    if (audioCodecLabel === "TRUEHD") audioCodecLabel = "Dolby TrueHD";
    if (/^(E-?AC-?3|DDP)$/.test(audioCodecLabel)) audioCodecLabel = "Dolby Digital Plus";
    if (/^AC-?3$/.test(audioCodecLabel)) audioCodecLabel = "Dolby Digital";
    var channels = /\b(7\.1|6\.1|5\.1|2\.0)\b/.exec(text);
    var audioLine = unique([audioLabel, [audioCodecLabel, channels ? channels[1] : ""].filter(Boolean).join(" ")]).join(" · ");
    if (audioLine) lines.push(audioLine);
    var subs = Array.isArray(stream.subtitles) ? unique(stream.subtitles.map(function(sub) {
      return sub && (language(sub.language) || language(sub.lang) || language(sub.code) || language(sub.id));
    })) : [];
    if (subs.length) lines.push("Subtitles: " + subs.join(", "));
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var size = usable(stream.size || stream.fileSize || (stream.behaviorHints && stream.behaviorHints.videoSize));
    if (!size) { var sm = /\b(\d+(?:\.\d+)?)\s*(GB|MB|TB|GiB|MiB)\b/i.exec(text); if (sm) size = sm[1] + " " + sm[2]; }
    if (/^\d+(?:\.\d+)?$/.test(size)) {
      var bytes = Number(size);
      size = bytes > 0 ? (bytes >= 1073741824 ? (bytes / 1073741824).toFixed(1) + " GB" : (bytes / 1048576).toFixed(1) + " MB") : "";
    } else if (!/^\d+(?:\.\d+)?\s*(?:GB|MB|TB|GiB|MiB)$/i.test(size)) size = "";
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    lines.push(unique([formatLabel, server, size, duration]).join(" · "));
    output.name = "";
    output.title = lines.join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "Cineby", "cineby");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
/* CLOUDBANK_STREAM_DISPLAY_END */
