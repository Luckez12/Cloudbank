// Imported provider: hindmoviez; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
var _0x1ae17e=_0x24c6;(function(_0x27085b,_0x13b49d){var _0x58a9bf={_0x1f407d:0x17f},_0x34b162=_0x24c6,_0x5efc36=_0x27085b();while(!![]){try{var _0x33e198=parseInt(_0x34b162(0x15a))/0x1*(parseInt(_0x34b162(0x1ab))/0x2)+-parseInt(_0x34b162(_0x58a9bf._0x1f407d))/0x3+parseInt(_0x34b162(0x169))/0x4+parseInt(_0x34b162(0x147))/0x5+-parseInt(_0x34b162(0x19e))/0x6*(parseInt(_0x34b162(0x1a3))/0x7)+-parseInt(_0x34b162(0x170))/0x8+-parseInt(_0x34b162(0x18b))/0x9;if(_0x33e198===_0x13b49d)break;else _0x5efc36['push'](_0x5efc36['shift']());}catch(_0x2334df){_0x5efc36['push'](_0x5efc36['shift']());}}}(_0xdabc,0xd6cff));var __defProp=Object['defineProperty'],__defProps=Object['defineProperties'],__getOwnPropDescs=Object['getOwnPropertyDescriptors'],__getOwnPropSymbols=Object[_0x1ae17e(0x14f)],__hasOwnProp=Object['prototype'][_0x1ae17e(0x1a9)],__propIsEnum=Object[_0x1ae17e(0x146)][_0x1ae17e(0x17d)],__defNormalProp=(_0x164ff6,_0x400d1c,_0x4eab7e)=>_0x400d1c in _0x164ff6?__defProp(_0x164ff6,_0x400d1c,{'enumerable':!![],'configurable':!![],'writable':!![],'value':_0x4eab7e}):_0x164ff6[_0x400d1c]=_0x4eab7e,__spreadValues=(_0x20e2b6,_0x11ae31)=>{var _0x5c468d={_0x1f5422:0x161,_0x55f541:0x161},_0xbd8959=_0x1ae17e;for(var _0x45d7ca in _0x11ae31||(_0x11ae31={}))if(__hasOwnProp[_0xbd8959(_0x5c468d._0x1f5422)](_0x11ae31,_0x45d7ca))__defNormalProp(_0x20e2b6,_0x45d7ca,_0x11ae31[_0x45d7ca]);if(__getOwnPropSymbols)for(var _0x45d7ca of __getOwnPropSymbols(_0x11ae31)){if(__propIsEnum[_0xbd8959(_0x5c468d._0x55f541)](_0x11ae31,_0x45d7ca))__defNormalProp(_0x20e2b6,_0x45d7ca,_0x11ae31[_0x45d7ca]);}return _0x20e2b6;},__spreadProps=(_0x27cca9,_0xe44676)=>__defProps(_0x27cca9,__getOwnPropDescs(_0xe44676)),__async=(_0x325594,_0x3b9811,_0x1dde25)=>{var _0x25ffce={_0x1b0052:0x140};return new Promise((_0x1eecca,_0x18e90d)=>{var _0x278b85=_0x24c6,_0x3990fc=_0x58b1a5=>{var _0x385f18=_0x24c6;try{_0x3a9cd0(_0x1dde25[_0x385f18(_0x25ffce._0x1b0052)](_0x58b1a5));}catch(_0x3d4034){_0x18e90d(_0x3d4034);}},_0x46c0ea=_0x16a55b=>{try{_0x3a9cd0(_0x1dde25['throw'](_0x16a55b));}catch(_0x1e1f08){_0x18e90d(_0x1e1f08);}},_0x3a9cd0=_0x2849ee=>_0x2849ee[_0x278b85(0x1a0)]?_0x1eecca(_0x2849ee['value']):Promise[_0x278b85(0x1b0)](_0x2849ee['value'])['then'](_0x3990fc,_0x46c0ea);_0x3a9cd0((_0x1dde25=_0x1dde25['apply'](_0x325594,_0x3b9811))['next']());});},PROVIDER_NAME='🔵\x20HindMovie',BASE_URL=_0x1ae17e(0x148),TMDB_KEY='439c478a771f35c05022f9feabcca01c',MOBILE_UAS=['Mozilla/5.0\x20(Linux;\x20Android\x2014;\x20Pixel\x208\x20Pro)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/124.0.0.0\x20Mobile\x20Safari/537.36','Mozilla/5.0\x20(Linux;\x20Android\x2013;\x20SM-S918B)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/116.0.0.0\x20Mobile\x20Safari/537.36','Mozilla/5.0\x20(Linux;\x20Android\x2012;\x20Pixel\x206)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/115.0.0.0\x20Mobile\x20Safari/537.36',_0x1ae17e(0x172),'Mozilla/5.0\x20(iPad;\x20CPU\x20OS\x2017_0\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20Version/17.0\x20Mobile/15E148\x20Safari/604.1'];function _0x24c6(_0x2efb03,_0x5f04aa){_0x2efb03=_0x2efb03-0x139;var _0xdabc66=_0xdabc();var _0x24c66b=_0xdabc66[_0x2efb03];if(_0x24c6['dtNqQw']===undefined){var _0x503e92=function(_0x19ef26){var _0x4ae85c='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';var _0x164ff6='',_0x400d1c='';for(var _0x4eab7e=0x0,_0x20e2b6,_0x11ae31,_0x45d7ca=0x0;_0x11ae31=_0x19ef26['charAt'](_0x45d7ca++);~_0x11ae31&&(_0x20e2b6=_0x4eab7e%0x4?_0x20e2b6*0x40+_0x11ae31:_0x11ae31,_0x4eab7e++%0x4)?_0x164ff6+=String['fromCharCode'](0xff&_0x20e2b6>>(-0x2*_0x4eab7e&0x6)):0x0){_0x11ae31=_0x4ae85c['indexOf'](_0x11ae31);}for(var _0x27cca9=0x0,_0xe44676=_0x164ff6['length'];_0x27cca9<_0xe44676;_0x27cca9++){_0x400d1c+='%'+('00'+_0x164ff6['charCodeAt'](_0x27cca9)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x400d1c);};_0x24c6['ikhNgb']=_0x503e92,_0x24c6['smnMAr']={},_0x24c6['dtNqQw']=!![];}var _0x7451df=_0xdabc66[0x0],_0x22f287=_0x2efb03+_0x7451df,_0xbd2923=_0x24c6['smnMAr'][_0x22f287];return!_0xbd2923?(_0x24c66b=_0x24c6['ikhNgb'](_0x24c66b),_0x24c6['smnMAr'][_0x22f287]=_0x24c66b):_0x24c66b=_0xbd2923,_0x24c66b;}function getHeaders(_0x17dc9c){var _0x136b92={_0x233d4f:0x149},_0x515856=_0x1ae17e,_0x8a9dff=MOBILE_UAS[Math[_0x515856(0x171)](Math[_0x515856(_0x136b92._0x233d4f)]()*MOBILE_UAS[_0x515856(0x18d)])],_0x1b11cd={'User-Agent':_0x8a9dff,'Accept-Language':_0x515856(0x1a2),'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8'};if(_0x17dc9c)for(var _0x4bef79 in _0x17dc9c){_0x1b11cd[_0x4bef79]=_0x17dc9c[_0x4bef79];}return _0x1b11cd;}function log(_0x52e5e3){var _0x4411e3={_0x52ee93:0x156},_0x393c26=_0x1ae17e;console[_0x393c26(_0x4411e3._0x52ee93)]('['+PROVIDER_NAME+']\x20'+_0x52e5e3);}function err(_0x901757){var _0x24872c={_0x53a45c:0x151},_0x24d0bf=_0x1ae17e;console[_0x24d0bf(_0x24872c._0x53a45c)]('['+PROVIDER_NAME+']\x20'+_0x901757);}function fetchText(_0x4ab964,_0x43c38b,_0x3d0c7f){var _0x3b3413={_0x41d5b9:0x18c,_0x2cfb94:0x187,_0x5854df:0x187,_0x3c28c7:0x19d,_0x3d6e1d:0x197,_0x8b7176:0x1ae};return __async(this,null,function*(){var _0x4b594f=_0x24c6;_0x3d0c7f=_0x3d0c7f||0x2ee0;try{var _0x242a92=null;if(typeof AbortSignal!=='undefined'&&AbortSignal['timeout'])_0x242a92=AbortSignal[_0x4b594f(_0x3b3413._0x41d5b9)](_0x3d0c7f);var _0x2a38c6=getHeaders(null);if(_0x43c38b&&_0x43c38b['headers'])for(var _0x4e2c4e in _0x43c38b[_0x4b594f(_0x3b3413._0x2cfb94)]){_0x2a38c6[_0x4e2c4e]=_0x43c38b[_0x4b594f(_0x3b3413._0x5854df)][_0x4e2c4e];}var _0x41ca05=__spreadProps(__spreadValues({},_0x43c38b||{}),{'headers':_0x2a38c6});if(_0x242a92)_0x41ca05[_0x4b594f(_0x3b3413._0x3c28c7)]=_0x242a92;var _0x279be8=fetch(_0x4ab964,_0x41ca05),_0x44f48e=new Promise(function(_0x1db8ce,_0x58b1f3){setTimeout(function(){_0x58b1f3(new Error('Timeout\x20'+_0x3d0c7f+'ms'));},_0x3d0c7f);}),_0x28b597=yield Promise[_0x4b594f(0x16e)]([_0x279be8,_0x44f48e]);if(_0x28b597['ok'])return yield _0x28b597['text']();return null;}catch(_0x3a7e3c){return err(_0x4b594f(_0x3b3413._0x3d6e1d)+_0x4ab964[_0x4b594f(_0x3b3413._0x8b7176)](0x0,0x50)+_0x4b594f(0x196)+(_0x3a7e3c['message']||'')),null;}});}function fetchJson(_0x381c21,_0x1843b6,_0x1da68b){return __async(this,null,function*(){var _0xe59798=yield fetchText(_0x381c21,_0x1843b6,_0x1da68b);if(!_0xe59798)return null;try{return JSON['parse'](_0xe59798);}catch(_0x20f27c){return null;}});}function getMedia(_0x1473c7,_0x303d3b){var _0x30a702={_0x3c742a:0x17a,_0xbc2ff7:0x14b,_0x2a5b5a:0x1b1,_0x30853e:0x15f,_0x241d2f:0x1a7,_0x3bc06c:0x19c};return __async(this,null,function*(){var _0x5e674f=_0x24c6,_0x2e0bc1=String(_0x1473c7||'')['trim'](),_0xc06e8=_0x2e0bc1[_0x5e674f(0x14d)]('tt')===0x0,_0x51ce2a=_0x303d3b==='tv'||_0x303d3b===_0x5e674f(0x15c)?'tv':'movie';try{if(_0xc06e8){var _0x45aa6e=yield fetchJson(_0x5e674f(_0x30a702._0x3c742a)+_0x2e0bc1+_0x5e674f(0x19a)+TMDB_KEY+'&external_source=imdb_id',{},0x2710),_0x2753a4=_0x45aa6e?_0x51ce2a==='tv'?_0x45aa6e[_0x5e674f(_0x30a702._0xbc2ff7)]:_0x45aa6e['movie_results']:null;if(_0x2753a4&&_0x2753a4['length']>0x0){var _0x2b252f=_0x2753a4[0x0];return{'title':_0x51ce2a==='tv'?_0x2b252f['name']:_0x2b252f[_0x5e674f(0x1a7)],'year':(_0x2b252f[_0x5e674f(_0x30a702._0x2a5b5a)]||_0x2b252f[_0x5e674f(0x150)]||'')['split']('-')[0x0],'imdb':_0x2e0bc1,'runtime':_0x2b252f['runtime']||null,'episode_run_time':_0x2b252f['episode_run_time']||null};}}else{var _0x45aa6e=yield fetchJson(_0x5e674f(_0x30a702._0x30853e)+_0x51ce2a+'/'+_0x2e0bc1+'?api_key='+TMDB_KEY+_0x5e674f(0x178),{},0x2710);if(_0x45aa6e)return{'title':_0x51ce2a==='tv'?_0x45aa6e['name']:_0x45aa6e[_0x5e674f(_0x30a702._0x241d2f)],'year':(_0x45aa6e['first_air_date']||_0x45aa6e['release_date']||'')['split']('-')[0x0],'imdb':_0x45aa6e['imdb_id']||_0x45aa6e['external_ids']&&_0x45aa6e['external_ids'][_0x5e674f(0x1ad)]||null,'runtime':_0x45aa6e['runtime']||null,'episode_run_time':_0x45aa6e[_0x5e674f(0x13d)]||null};}}catch(_0x1b624c){err(_0x5e674f(_0x30a702._0x3bc06c)+_0x1b624c['message']);}return{'title':_0x2e0bc1,'year':null,'imdb':null,'runtime':null,'episode_run_time':null};});}function parseQuality(_0xce6189){var _0x3b15b0=_0x1ae17e,_0x2d8f3e=String(_0xce6189||''),_0xeb86ff=_0x2d8f3e['match'](/(2160|1080|720|480)\s*P/i);if(_0xeb86ff)return _0xeb86ff[0x1]+'p';if(/4K|UHD/i[_0x3b15b0(0x17c)](_0x2d8f3e))return'2160p';if(/1440|2K/i[_0x3b15b0(0x17c)](_0x2d8f3e))return'1440p';return'HD';}function decodeEntities(_0x1e00da){var _0x4750c1={_0x352f38:0x162,_0x3e8a9f:0x162},_0x196fbd=_0x1ae17e;return String(_0x1e00da)['replace'](/&#8211;/g,'-')[_0x196fbd(0x162)](/&#8212;/g,'-')[_0x196fbd(0x162)](/&#8216;/g,'\x27')[_0x196fbd(_0x4750c1._0x352f38)](/&#8217;/g,'\x27')['replace'](/&#8220;/g,'\x22')['replace'](/&#8221;/g,'\x22')['replace'](/&#038;/g,'&')[_0x196fbd(0x162)](/&amp;/g,'&')[_0x196fbd(_0x4750c1._0x3e8a9f)](/&#(\d+);/g,function(_0x203363,_0x387cc7){var _0x2550de=_0x196fbd;return String[_0x2550de(0x13b)](_0x387cc7);});}function _0xdabc(){var _0x46543b=['zxHWB3j0CW','iokaOIa','AgvHzgvYCW','rMfZDcbqyxrOieD1zxnZAw5NievWAxnVzguG','lM0ZDtG','qNLWyxnZifn1y2nLC3mHigyUCgHWifvstdOG','ndGYmdeZowfbA3Dgra','DgLTzw91Da','BgvUz3rO','iIaO','Agv2yW','zgf0yq','Edi2na','vgvSDwD1','C3rYAw5NAwz5','jNm9','BwvZC2fNzq','ic0+ia','zMv0y2G6ia','tuTw','C3rHCNrZv2L0Aa','p2fWAv9RzxK9','twf0y2HLzcb2AweGsu1eqIbjrce','Dg1KyJOG','C2LNBMfS','nJz6C3HQBuu','u2vHCMnOAw5NifDqluPtt04GyNKGsu1eqIbjrdOG','zg9Uzq','Dw5KzwzPBMvK','zw4TvvmSzw47Ct0WlJK','mta1ntGXBgrnCLr0','qNLWyxnZiezHAwXLzdOG','ChvZAa','CNvUDgLTzq','DgL0Bgu','DhjPBq','AgfZt3DUuhjVCgvYDhK','u2LUz2XLluf1zgLV','mteWA0rOtMP3','AM9PBG','Aw1KyL9Pza','C3vIC3rYAw5N','C29YDa','CMvZB2X2zq','zMLYC3rFywLYx2rHDgu','ic0G','y2HHCKf0','zMLSDgvY','ic0GuW','yMfUz2XH','mtbIAxq','zg93BMXVywq','rM91BMqG','zNjVBunOyxjdB2rL','z2v0vgLTzq','zxbPC29Kzv9YDw5FDgLTzq','p3m9','u2vYDMvYide','BMv4Da','Ahr0Ca','tI9b','txvSDgKTqxvKAw8','y29UDgvUDa','CMvUzgvYzwq','ChjVDg90ExbL','nZiXnJCZnujYwK5kAG','Ahr0Chm6lY9OAw5KBw92AwuUAwn1','CMfUzg9T','l3DWlwPZB24VD3aVDJiVCg9ZDhm/C2vHCMnOpq','DhzFCMvZDwX0CW','rhvHBc1bDwrPBW','Aw5KzxHpzG','ihWG','z2v0t3DUuhjVCgvYDhLtEw1IB2XZ','CMvSzwfZzv9KyxrL','zxjYB3i','lNDVCMTLCNmUzgv2','tva0','ihWG8j+mJsa','u2TPChbPBMCGndGWCcbSAw5R','Bg9N','zxHLyW','sfbHz2uGzgvJB2rLigvYCJOG','Aw5KzxG','mta4mdLJEgTsy0K','Edi2nq','C2vYAwvZ','ue9tva','Bwf0y2G','Ahr0Chm6lY9HCgKUDgHLBw92AwvKyI5VCMCVmY8','CxvHBgL0Eq','y2fSBa','CMvWBgfJzq','BwfW','ywXS','ieHtAgfYzsbjrhmGAw4GBxzSAw5RihbHz2uU','y2HHCKnVzgvbDa','C3vJy2vZCW','DxjS','ndG2odyYmhPos21xAa','CMvZB2X2zwq6ici','zw5NBgLZAa','rw5NBgLZAcdIGkiGsgLUzgK','Dg9mB3DLCKnHC2u','CMfJzq','ihWG8j+xG++4JYbtzxj2zxiGmq','mta4mJmYodHVD2TqBNy','zMXVB3i','tw96AwXSys81lJaGkgLqAg9UztSGq1bvigLqAg9UzsbpuYaXn18WigXPA2uGtwfJie9tifGPiefWCgXLv2vIs2L0lZyWns4XlJe1icHlsfrntcWGBgLRzsbhzwnRBYKGvMvYC2LVBI8XnY4Wie1VyMLSzs8XnuuXndGGu2fMyxjPlZyWnc4X','ig1PBG','y29Uy2f0','qMfUz2XH','tM8GBxzSAw5RlMjSB2CGBgLUA3mGzM91BMqGAw4GCg9ZDc4','Bwf4','jMfWCgvUzf90B19YzxnWB25Zzt1LEhrLCM5HBf9Pzhm','8j+oRca','Ahr0Chm6lY9HCgKUDgHLBw92AwvKyI5VCMCVmY9MAw5KlW','EwvHCG','DgvZDa','ChjVCgvYDhLjC0vUDw1LCMfIBgu','Aw1KyG','otyYmtKZEhDgrfjh','uMv0DxjUAw5Nia','tM8GC3rYAwn0ig1HDgnOigzVDw5KigLUifDqluPtt04','Aw5JBhvKzxm','ie12tgLUAYbKB21HAw5ZlG','igf0igLUzgv4ia'];_0xdabc=function(){return _0x46543b;};return _0xdabc();}function getCleanTitle(_0x202e18){var _0x1056de={_0x2fc5f2:0x16d,_0x50d372:0x162,_0x1a8055:0x162},_0x233590=_0x1ae17e;return decodeEntities(_0x202e18)[_0x233590(_0x1056de._0x2fc5f2)]()['replace'](/download/g,'')['replace'](/\b(dual audio|multi audio|hindi|english|tamil|telugu|malayalam|korean|japanese|chinese|spanish|french|italian|german)\b/g,'')[_0x233590(0x162)](/\b(480p|720p|1080p|2160p|4k|2k|hd|fhd|uhd)\b/g,'')['replace'](/\b(web-?dl|web-?dlrip|web-?rip|brrip|bdrip|bluray|blu-?ray|hdtv|tvrip|dvdrip|camrip|hdrip)\b/g,'')['replace'](/\b(x264|x265|hevc|10bit|12bit|aac|ac3|dd5\.1|ddp5\.1|atmos|dts)\b/g,'')['replace'](/\b(season|saison|staffel)\s*\d+(?:\s*(?:-|to)\s*\d+)?\b/g,'')[_0x233590(0x162)](/\bs\d+(?:\s*(?:-|to)\s*\d+)?\b/g,'')[_0x233590(_0x1056de._0x50d372)](/\b(episode|episodes|ep)\s*\d+(?:\s*(?:-|to)\s*\d+)?\s*(added|update|updated)?\b/g,'')[_0x233590(0x162)](/\b(complete|all episodes|pack|batch)\b/g,'')['replace'](/\b(movie|film|part\s*\d+|vol\s*\d+|volume\s*\d+)\b/g,'')[_0x233590(_0x1056de._0x50d372)](/\b(unrated|extended|directors cut|uncut|18)\b/g,'')['replace'](/\b(19\d{2}|20\d{2})\b/g,'')[_0x233590(0x162)](/[^a-z0-9]/g,'\x20')[_0x233590(_0x1056de._0x1a8055)](/\s+/g,'\x20')['trim']()[_0x233590(0x162)](/^(the|a|an)\s+/g,'');}function isStrictMatch(_0x2a2300,_0x11469d,_0x160824,_0x442a05){if(!_0x2a2300||!_0x160824)return![];var _0x924ab0=getCleanTitle(_0x2a2300),_0x3a3514=getCleanTitle(_0x160824);if(_0x924ab0===_0x3a3514)return!![];if(_0x11469d&&_0x442a05){var _0x56965c=parseInt(_0x11469d),_0x18b000=parseInt(_0x442a05);if(!isNaN(_0x56965c)&&!isNaN(_0x18b000)&&Math['abs'](_0x56965c-_0x18b000)>0x1)return![];}return![];}function searchWPJson(_0x315a5b){var _0x234876={_0x4f9d7c:0x14a,_0x52ac36:0x1a7,_0xd8403c:0x145,_0x2baae7:0x15e};return __async(this,null,function*(){var _0x474d62=_0x24c6,_0x4032bc=BASE_URL+_0x474d62(_0x234876._0x4f9d7c)+encodeURIComponent(_0x315a5b)+'&per_page=100',_0x4ca8ec=yield fetchJson(_0x4032bc);if(!_0x4ca8ec||!Array['isArray'](_0x4ca8ec))return[];var _0xa332a0=[];for(var _0xa2c8cc=0x0;_0xa2c8cc<_0x4ca8ec['length'];_0xa2c8cc++){var _0x42077a=_0x4ca8ec[_0xa2c8cc];if(_0x42077a&&_0x42077a[_0x474d62(_0x234876._0x52ac36)]&&_0x42077a['title'][_0x474d62(_0x234876._0xd8403c)]){var _0x324356=_0x42077a['title'][_0x474d62(_0x234876._0xd8403c)][_0x474d62(0x162)](/<[^>]+>/g,'')['trim'](),_0x2a215a=_0x324356[_0x474d62(_0x234876._0x2baae7)](/\b(19\d{2}|20\d{2})\b/),_0x87ff16=_0x2a215a?_0x2a215a[0x1]:null;_0xa332a0[_0x474d62(0x1a5)]({'id':_0x42077a['id'],'title':_0x324356,'year':_0x87ff16,'content':_0x42077a['content']?_0x42077a['content'][_0x474d62(_0x234876._0xd8403c)]:''});}}return _0xa332a0;});}function dedupe(_0x49a752){var _0x10178e={_0x5da1f5:0x168},_0x55b1c6={};return(_0x49a752||[])['filter'](function(_0x517c2e){var _0x34fc3f=_0x24c6;if(!_0x517c2e||!_0x517c2e['url']||_0x55b1c6[_0x517c2e['url']])return![];return _0x55b1c6[_0x517c2e[_0x34fc3f(_0x10178e._0x5da1f5)]]=!![],!![];});}function pad2(_0x3e983d){return _0x3e983d!=null&&_0x3e983d<0xa?'0'+_0x3e983d:String(_0x3e983d);}function encodeBase64(_0x4c78a6){var _0x471c83={_0x3f619b:0x166,_0x2eeeae:0x1b3,_0x1a8749:0x18d},_0x4fb7da=_0x1ae17e,_0xdec9e8='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=',_0xb03bc0,_0x8c60ac,_0x440e4a,_0x25f464,_0x5042c9,_0x5213f9,_0x3a747e,_0x585938,_0x912337=0x0,_0x11b684='';do{_0xb03bc0=_0x4c78a6[_0x4fb7da(0x166)](_0x912337++),_0x8c60ac=_0x4c78a6[_0x4fb7da(_0x471c83._0x3f619b)](_0x912337++),_0x440e4a=_0x4c78a6['charCodeAt'](_0x912337++),_0x585938=_0xb03bc0<<0x10|_0x8c60ac<<0x8|_0x440e4a,_0x25f464=_0x585938>>0x12&0x3f,_0x5042c9=_0x585938>>0xc&0x3f,_0x5213f9=_0x585938>>0x6&0x3f,_0x3a747e=_0x585938&0x3f,_0x11b684+=_0xdec9e8[_0x4fb7da(0x1b3)](_0x25f464)+_0xdec9e8['charAt'](_0x5042c9)+(isNaN(_0x8c60ac)?'=':_0xdec9e8[_0x4fb7da(0x1b3)](_0x5213f9))+(isNaN(_0x440e4a)?'=':_0xdec9e8[_0x4fb7da(_0x471c83._0x2eeeae)](_0x3a747e));}while(_0x912337<_0x4c78a6[_0x4fb7da(_0x471c83._0x1a8749)]);return _0x11b684;}function urlSafeBase64Encode(_0x3ebb15){var _0x114053={_0x45a1d5:0x162},_0x177571=_0x1ae17e,_0x1283f7=encodeBase64(_0x3ebb15);return _0x1283f7['replace'](/\+/g,'-')[_0x177571(_0x114053._0x45a1d5)](/\//g,'_')[_0x177571(0x162)](/=+$/,'');}function decodeBase64(_0x13a7e8){var _0x46a9c6={_0x2b7772:0x14d},_0x8df7a1=_0x1ae17e,_0x4f6d6a='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=',_0x49e34b='';_0x13a7e8=String(_0x13a7e8)['replace'](/=+$/,'');for(var _0x8e71cd=0x0,_0x165b21,_0x5737b8,_0x3849d8=0x0;_0x5737b8=_0x13a7e8['charAt'](_0x3849d8++);~_0x5737b8&&(_0x165b21=_0x8e71cd%0x4?_0x165b21*0x40+_0x5737b8:_0x5737b8,_0x8e71cd++%0x4)?_0x49e34b+=String['fromCharCode'](0xff&_0x165b21>>(-0x2*_0x8e71cd&0x6)):0x0){_0x5737b8=_0x4f6d6a[_0x8df7a1(_0x46a9c6._0x2b7772)](_0x5737b8);}return _0x49e34b;}function bypassHShareAPI(_0x4f1c74,_0x4895a0){var _0x2e1e23={_0x2b5bf8:0x168};return __async(this,null,function*(){var _0x54bb7c=_0x24c6,_0xf8105a=urlSafeBase64Encode(_0x4f1c74),_0x1d5e98='action=hindshare_sign&d='+encodeURIComponent(_0xf8105a);log('Bypassing\x20HShare\x20via\x20admin-ajax\x20for\x20ID:\x20'+_0x4f1c74['substring'](0x0,0x1e)+'...');var _0x47e79a=yield fetchJson('https://mvlink.blog/wp-admin/admin-ajax.php',{'method':_0x54bb7c(0x15d),'headers':{'Content-Type':'application/x-www-form-urlencoded','Referer':_0x4895a0,'X-Requested-With':'XMLHttpRequest'},'body':_0x1d5e98});if(_0x47e79a&&_0x47e79a[_0x54bb7c(0x167)]&&_0x47e79a['data']&&_0x47e79a['data']['url'])return log(_0x54bb7c(0x18a)+_0x47e79a[_0x54bb7c(0x190)]['url']),_0x47e79a['data'][_0x54bb7c(_0x2e1e23._0x2b5bf8)];return log(_0x54bb7c(0x1a4)+JSON[_0x54bb7c(0x193)](_0x47e79a)),null;});}function generateStreamLayout(_0x2f2ee2,_0x2b38cf,_0xbda8f1,_0x381071,_0x44dc30,_0x2cabfa,_0x279987,_0x59e08f,_0x3a22dc){var _0x5a173f={_0x2f9c04:0x14c,_0x5b3203:0x182,_0x21591d:0x1aa,_0xdf011f:0x153,_0x565086:0x189,_0x11a879:0x13d,_0x127560:0x173,_0x56258d:0x182,_0x594389:0x1b7,_0xcc00:0x15b,_0x3e6e4d:0x18f,_0x30b96c:0x186,_0x2edfc9:0x182,_0x39702b:0x14e},_0x10d26d=_0x1ae17e,_0x47bfd4=_0x381071['title']||'Unknown\x20Title',_0x528f84=_0x381071[_0x10d26d(0x17b)]||_0x10d26d(0x142),_0x43de95=String(_0x59e08f||_0x2f2ee2||'')['toLowerCase'](),_0xf7b45e='Single-Audio',_0x2d266e='Hindi';if(_0x43de95[_0x10d26d(0x182)]('dual')||_0x43de95['includes']('hindi')&&_0x43de95['includes'](_0x10d26d(0x16b)))_0xf7b45e=_0x10d26d(_0x5a173f._0x2f9c04),_0x2d266e=_0x10d26d(0x16c);else{if(_0x43de95['includes']('multi'))_0xf7b45e=_0x10d26d(0x143),_0x2d266e='Multilingual';else{if(_0x43de95[_0x10d26d(_0x5a173f._0x5b3203)](_0x10d26d(0x1b6)))_0x2d266e=_0x10d26d(0x175);else{if(_0x43de95['includes']('tamil'))_0x2d266e='Tamil';else{if(_0x43de95['includes']('telugu'))_0x2d266e=_0x10d26d(0x192);else _0x43de95[_0x10d26d(0x182)](_0x10d26d(0x16b))&&(_0xf7b45e=_0x10d26d(_0x5a173f._0x21591d),_0x2d266e='English');}}}}var _0x7abf4d=_0x10d26d(0x198);if(_0x43de95['includes']('.mp4'))_0x7abf4d=_0x10d26d(_0x5a173f._0xdf011f);if(_0x43de95[_0x10d26d(0x182)](_0x10d26d(_0x5a173f._0x565086)))_0x7abf4d='M3U8\x20/\x20HLS';var _0x11152c=_0x10d26d(0x142);_0x44dc30?_0x11152c=_0x381071[_0x10d26d(_0x5a173f._0x11a879)]&&_0x381071['episode_run_time'][0x0]?_0x381071[_0x10d26d(0x13d)][0x0]+'\x20min':'45\x20min':_0x11152c=_0x381071[_0x10d26d(0x1a6)]?_0x381071['runtime']+_0x10d26d(_0x5a173f._0x127560):'N/A';var _0x5bee43=[];_0x43de95[_0x10d26d(_0x5a173f._0x56258d)](_0x10d26d(_0x5a173f._0x594389))&&_0x5bee43['push']('10bit');if(_0x43de95['includes'](_0x10d26d(_0x5a173f._0xcc00))||_0x43de95['includes'](_0x10d26d(_0x5a173f._0x3e6e4d)))_0x5bee43[_0x10d26d(0x1a5)]('x265');else(_0x43de95[_0x10d26d(0x182)](_0x10d26d(0x191))||_0x43de95[_0x10d26d(0x182)]('h264'))&&_0x5bee43['push']('x264');_0x5bee43['push']('WEB-DL');var _0x4bdfae='📌\x20'+_0x5bee43[_0x10d26d(0x1ac)](_0x10d26d(_0x5a173f._0x30b96c)),_0x367a76=_0xbda8f1[_0x10d26d(_0x5a173f._0x2edfc9)]('4K')||_0xbda8f1[_0x10d26d(_0x5a173f._0x2edfc9)]('2160')?'🌟':'💎',_0x5eb0de=PROVIDER_NAME+_0x10d26d(_0x5a173f._0x39702b)+_0xbda8f1+_0x10d26d(0x14e)+_0xf7b45e,_0x2c7969=_0x3a22dc?'\x20|\x20🗃️\x20'+_0x3a22dc:_0x10d26d(0x16f),_0x5c93ab=_0x44dc30?_0x10d26d(0x179)+_0x47bfd4+_0x10d26d(0x1b5)+pad2(_0x2cabfa)+'E'+pad2(_0x279987)+'\x20('+_0x528f84+')':'🎬\x20'+_0x47bfd4+_0x10d26d(0x1b2)+_0x528f84,_0x2531e6=_0x367a76+'\x20'+_0xbda8f1+_0x10d26d(0x154)+_0x2d266e+_0x2c7969,_0x5cdc75='🎞️\x20'+_0x7abf4d+'\x20|\x20⏱️\x20'+_0x11152c+_0x10d26d(0x14e)+_0x4bdfae,_0x488917=_0x5c93ab+'\x0a'+_0x2531e6+'\x0a'+_0x5cdc75;return{'name':_0x5eb0de,'title':_0x488917,'url':_0x2f2ee2,'quality':_0xbda8f1,'behaviorHints':{'notWebReady':!![]}};}function processHShareLink(_0x2283ae,_0x239a15,_0x404864,_0x162690,_0x474321,_0x100f43,_0x3ec81f,_0x75d969,_0x190c54){var _0x3be9fd={_0x20ca15:0x199,_0xe5a0bd:0x13c,_0x3a40b8:0x152,_0x29326f:0x14d,_0xdabe82:0x13f,_0x126edc:0x1a5,_0x491716:0x158};return __async(this,null,function*(){var _0x109f5a=_0x24c6,_0x2b4927=[];for(var _0x279960=0x0;_0x279960<(_0x2283ae||[])['length'];_0x279960++){var _0x16611a=_0x2283ae[_0x279960];log('Processing\x20HPage:\x20'+_0x16611a);var _0x38f801=_0x16611a['match'](/url=([^&]+)/i);if(_0x38f801)try{var _0x3f64a8=decodeBase64(_0x38f801[0x1]);if(_0x3f64a8[_0x109f5a(_0x3be9fd._0x20ca15)](_0x109f5a(0x141))){var _0x196c67=yield fetchText(_0x3f64a8,{'headers':{'Referer':_0x162690}}),_0x339944=0x1;if(_0x196c67){var _0x299d55=/href="([^"]+\.workers\.dev[^"]+)"/ig,_0x1542a0;while((_0x1542a0=_0x299d55['exec'](_0x196c67))!==null){var _0x28b14a=_0x1542a0[0x1],_0x3706a4=_0x28b14a[_0x109f5a(0x14d)]('?')>-0x1?_0x28b14a+'&s='+new Date()[_0x109f5a(_0x3be9fd._0xe5a0bd)]():_0x28b14a+'?s='+new Date()[_0x109f5a(0x13c)](),_0x3e8526='Server\x20'+_0x339944,_0x2e8706=generateStreamLayout(_0x3706a4,_0x404864,_0x239a15,_0x100f43,_0x3ec81f,_0x75d969,_0x190c54,_0x474321||_0x28b14a,_0x3e8526);_0x2b4927['push'](_0x2e8706),_0x339944++;}}if(_0x2b4927[_0x109f5a(0x18d)]===0x0){var _0x28b14a=null;if(_0x3f64a8[_0x109f5a(0x182)](_0x109f5a(_0x3be9fd._0x3a40b8)))_0x28b14a=_0x3f64a8;else{var _0x28638e=_0x3f64a8[_0x109f5a(0x15e)](/url=([^&]+)/i);if(_0x28638e){var _0xa26e0b=decodeBase64(_0x28638e[0x1]);_0xa26e0b[_0x109f5a(0x182)](_0x109f5a(_0x3be9fd._0x3a40b8))&&(_0x28b14a=_0xa26e0b);}}if(_0x28b14a){var _0x3706a4=_0x28b14a[_0x109f5a(_0x3be9fd._0x29326f)]('?')>-0x1?_0x28b14a+_0x109f5a(0x194)+new Date()[_0x109f5a(_0x3be9fd._0xe5a0bd)]():_0x28b14a+_0x109f5a(0x13e)+new Date()[_0x109f5a(0x13c)](),_0x2e8706=generateStreamLayout(_0x3706a4,_0x404864,_0x239a15,_0x100f43,_0x3ec81f,_0x75d969,_0x190c54,_0x474321||_0x28b14a,_0x109f5a(_0x3be9fd._0xdabe82));_0x2b4927[_0x109f5a(_0x3be9fd._0x126edc)](_0x2e8706);}}}}catch(_0x1ae39a){log(_0x109f5a(_0x3be9fd._0x491716)+_0x1ae39a['message']);}}return _0x2b4927;});}function processMvlink(_0x358d67,_0x5b263c,_0x118e5f,_0x4d3446,_0x34728e,_0xdf2944,_0x21aa9a,_0x801ce6){var _0x50a6fa={_0x22dcf2:0x13a,_0x4c398c:0x188,_0x253b95:0x18d,_0x2ed696:0x163};return __async(this,null,function*(){var _0x4ff8c8={_0x4c4283:0x18d},_0x58655a=_0x24c6,_0x9c7095=[];log('Processing\x20MvLink:\x20'+_0x358d67);var _0x41882e=yield fetchText(_0x358d67,{'headers':{'Referer':_0x5b263c}});if(!_0x41882e)return _0x9c7095;var _0x1529b4=/href="(?:https:\/\/hshare\.ink\/\?id=([^"]+)|https:\/\/hshare\.ink\/dl\/([^"]+))"/ig,_0x262f1d,_0x1ac5d8=[];while((_0x262f1d=_0x1529b4['exec'](_0x41882e))!==null){if(_0x262f1d[0x1])_0x1ac5d8['push'](decodeURIComponent(_0x262f1d[0x1]));}if(_0x1ac5d8['length']===0x0)return _0x9c7095;log(_0x58655a(_0x50a6fa._0x22dcf2)+_0x1ac5d8['length']+_0x58655a(0x165));if(_0x34728e!=null){var _0x390e65=_0x34728e-0x1,_0x2f34c1=![];if(_0x390e65>=0x0&&_0x390e65<_0x1ac5d8['length']){log(_0x58655a(_0x50a6fa._0x4c398c)+_0x34728e+_0x58655a(0x184)+_0x390e65);var _0x4ddaca=_0x1ac5d8[_0x390e65],_0x4ccd7d=yield bypassHShareAPI(_0x4ddaca,_0x358d67),_0x56b8e2=yield fetchText(_0x4ccd7d,{'headers':{'Referer':_0x358d67}});if(_0x56b8e2){var _0x3f0ffe=_0x56b8e2['match'](/Name:\s*([^<]+)/i),_0x1da344=_0x3f0ffe?_0x3f0ffe[0x1]['trim']():null,_0x107ea0=[],_0x322b30=/href="([^"]+hcloud\.ink[^"]+)"/ig,_0x20a66;while((_0x20a66=_0x322b30['exec'](_0x56b8e2))!==null){if(_0x20a66[0x1])_0x107ea0['push'](_0x20a66[0x1]);}var _0x3710ce=yield processHShareLink(_0x107ea0,_0x4d3446,_0x118e5f,_0x4ccd7d,_0x1da344,_0xdf2944,_0x21aa9a,_0x801ce6,_0x34728e);_0x3710ce&&_0x3710ce[_0x58655a(_0x50a6fa._0x253b95)]>0x0&&(_0x9c7095=_0x9c7095['concat'](_0x3710ce),_0x2f34c1=!![]);}}if(!_0x2f34c1){var _0x3c09c9=_0x1ac5d8['filter'](function(_0x4d4ecd,_0x526bc){return _0x526bc!==_0x390e65;});for(var _0xda7865=0x0;_0xda7865<_0x3c09c9['length'];_0xda7865+=0x3){var _0x450997=_0x3c09c9['slice'](_0xda7865,_0xda7865+0x3),_0xd0d71=yield Promise[_0x58655a(0x164)](_0x450997[_0x58655a(_0x50a6fa._0x2ed696)](function(_0x25b588){return __async(this,null,function*(){var _0x4b2001=_0x24c6,_0x102286=yield bypassHShareAPI(_0x25b588,_0x358d67),_0x3b4637=yield fetchText(_0x102286,{'headers':{'Referer':_0x358d67}});if(!_0x3b4637)return[];var _0x2338e3=_0x3b4637['match'](/Name:\s*([^<]+)/i),_0x51f575=_0x2338e3?_0x2338e3[0x1][_0x4b2001(0x1a8)]():null,_0x223e0a=[],_0x3b9312=/href="([^"]+hcloud\.ink[^"]+)"/ig,_0x1ce842;while((_0x1ce842=_0x3b9312[_0x4b2001(0x157)](_0x3b4637))!==null){if(_0x1ce842[0x1])_0x223e0a['push'](_0x1ce842[0x1]);}return processHShareLink(_0x223e0a,_0x4d3446,_0x118e5f,_0x102286,_0x51f575,_0xdf2944,_0x21aa9a,_0x801ce6,_0x34728e);});})),_0xb382ac=![];_0xd0d71['forEach'](function(_0xdfb0e){var _0x2cfc48=_0x58655a;_0xdfb0e&&_0xdfb0e[_0x2cfc48(_0x4ff8c8._0x4c4283)]>0x0&&(_0x9c7095=_0x9c7095['concat'](_0xdfb0e),_0xb382ac=!![]);});if(_0xb382ac)break;}}}else for(var _0xda7865=0x0;_0xda7865<_0x1ac5d8[_0x58655a(0x18d)];_0xda7865++){var _0x4ddaca=_0x1ac5d8[_0xda7865],_0x4ccd7d=yield bypassHShareAPI(_0x4ddaca,_0x358d67),_0x56b8e2=yield fetchText(_0x4ccd7d,{'headers':{'Referer':_0x358d67}});if(_0x56b8e2){var _0x3f0ffe=_0x56b8e2['match'](/Name:\s*([^<]+)/i),_0x1da344=_0x3f0ffe?_0x3f0ffe[0x1]['trim']():null,_0x107ea0=[],_0x322b30=/href="([^"]+hcloud\.ink[^"]+)"/ig,_0x20a66;while((_0x20a66=_0x322b30[_0x58655a(0x157)](_0x56b8e2))!==null){if(_0x20a66[0x1])_0x107ea0['push'](_0x20a66[0x1]);}var _0x3710ce=yield processHShareLink(_0x107ea0,_0x4d3446,_0x118e5f,_0x4ccd7d,_0x1da344,_0xdf2944,_0x21aa9a,_0x801ce6,null);if(_0x3710ce)_0x9c7095=_0x9c7095[_0x58655a(0x174)](_0x3710ce);}}return _0x9c7095;});}function extractSeasonHtml(_0x158181,_0x1ed0d7){var _0x255bdf={_0x1e08d0:0x16d,_0xd0145f:0x1b4,_0x537a56:0x1ae},_0x553bdf=_0x1ae17e;if(!_0x158181||_0x1ed0d7==null)return _0x158181;var _0x25e87e=_0x158181,_0x556c9e=/(?:Season|Saison|Staffel)\s+0*(\d+)\b/gi,_0x20e76f,_0x1f934d=[];while((_0x20e76f=_0x556c9e['exec'](_0x25e87e))!==null){var _0x5f001e=_0x25e87e['lastIndexOf']('<',_0x20e76f[_0x553bdf(0x159)]);if(_0x5f001e<0x0||_0x20e76f['index']-_0x5f001e>0x1f4)_0x5f001e=_0x20e76f['index'];var _0x5400a8=_0x25e87e[_0x553bdf(0x1ae)](_0x5f001e,_0x20e76f[_0x553bdf(0x159)]+0x32);if(_0x5400a8[_0x553bdf(_0x255bdf._0x1e08d0)]()['includes'](_0x553bdf(0x139))||_0x5400a8['toLowerCase']()[_0x553bdf(0x182)]('episode'))continue;_0x1f934d[_0x553bdf(0x1a5)]({'season':parseInt(_0x20e76f[0x1]),'index':_0x5f001e});}if(_0x1f934d['length']===0x0)return _0x25e87e;var _0x503517=_0x1f934d[_0x553bdf(_0x255bdf._0xd0145f)](function(_0xdc32b1){return _0xdc32b1['season']===_0x1ed0d7;});if(_0x503517['length']===0x0)return _0x25e87e;var _0x2fb0cd=_0x503517[0x0],_0x193012=_0x2fb0cd['index'],_0x118991=null;for(var _0x1b7687=0x0;_0x1b7687<_0x1f934d[_0x553bdf(0x18d)];_0x1b7687++){if(_0x1f934d[_0x1b7687]['index']>_0x193012&&_0x1f934d[_0x1b7687]['season']!==_0x1ed0d7){_0x118991=_0x1f934d[_0x1b7687];break;}}var _0x4f288f=_0x118991?_0x118991['index']:_0x25e87e[_0x553bdf(0x18d)];return _0x25e87e[_0x553bdf(_0x255bdf._0x537a56)](_0x193012,_0x4f288f);}function getStreams(_0x258047,_0x4f3243,_0x2d1e3c,_0x5c7fa7){var _0x25d1d1={_0x40660c:0x1a7,_0xad6d99:0x16a,_0x55588c:0x18e,_0x130115:0x19f,_0x468d0d:0x1a7,_0x353e95:0x17e,_0x3b531f:0x18d,_0x1f876c:0x144,_0x5e821f:0x159,_0xb10036:0x1ae,_0x428f96:0x1a7,_0x2fd6da:0x18d};return __async(this,null,function*(){var _0x430493={_0x3b1c1b:0x160},_0x5cf01a=_0x24c6;try{log('request:\x20id='+_0x258047+'\x20type='+_0x4f3243+'\x20s='+_0x2d1e3c+'\x20e='+_0x5c7fa7);var _0x3a55cd=yield getMedia(_0x258047,_0x4f3243);if(!_0x3a55cd||!_0x3a55cd[_0x5cf01a(_0x25d1d1._0x40660c)])return[];var _0x110828=_0x4f3243==='tv'||_0x4f3243==='series',_0x562845=_0x2d1e3c!=null?Number(_0x2d1e3c):null,_0x18a5f5=_0x5c7fa7!=null?Number(_0x5c7fa7):null;log(_0x5cf01a(_0x25d1d1._0xad6d99)+_0x3a55cd[_0x5cf01a(0x1a7)]+_0x5cf01a(_0x25d1d1._0x55588c)+(_0x3a55cd['year']||'?')+')');var _0x255291=[];_0x3a55cd[_0x5cf01a(0x17e)]&&(log(_0x5cf01a(_0x25d1d1._0x130115)+_0x3a55cd['imdb']),_0x255291=yield searchWPJson(_0x3a55cd['imdb']));(!_0x255291||_0x255291[_0x5cf01a(0x18d)]===0x0)&&(log('Searching\x20WP-JSON\x20by\x20Title:\x20'+_0x3a55cd[_0x5cf01a(_0x25d1d1._0x468d0d)]),_0x255291=yield searchWPJson(_0x3a55cd['title']));var _0x2d623c=null;if(_0x3a55cd[_0x5cf01a(_0x25d1d1._0x353e95)])for(var _0xab5041=0x0;_0xab5041<_0x255291['length'];_0xab5041++){if(_0x255291[_0xab5041]['content']&&_0x255291[_0xab5041]['content']['includes'](_0x3a55cd['imdb'])){log(_0x5cf01a(0x19b)),_0x2d623c=_0x255291[_0xab5041];break;}}if(!_0x2d623c)for(var _0xab5041=0x0;_0xab5041<_0x255291[_0x5cf01a(_0x25d1d1._0x3b531f)];_0xab5041++){if(isStrictMatch(_0x3a55cd[_0x5cf01a(0x1a7)],_0x3a55cd['year'],_0x255291[_0xab5041]['title'],_0x255291[_0xab5041]['year'])){log('Matched\x20via\x20Strict\x20Title\x20Match!'),_0x2d623c=_0x255291[_0xab5041];break;}}if(!_0x2d623c)return log(_0x5cf01a(0x181)),[];log('Matched\x20Post:\x20'+_0x2d623c['title']);var _0x42b11d=_0x2d623c[_0x5cf01a(_0x25d1d1._0x1f876c)];if(_0x110828&&_0x562845!=null){var _0x1325df=extractSeasonHtml(_0x42b11d,_0x562845);if(_0x1325df)_0x42b11d=_0x1325df;}var _0x22d1d8=[],_0x4a72a0=/href="(https?:\/\/mvlink\.blog\/(?:web\/)?\d+)"/ig,_0x5ea1d0;while((_0x5ea1d0=_0x4a72a0['exec'](_0x42b11d))!==null){var _0x3611aa=_0x5ea1d0[0x1],_0x190b65=Math[_0x5cf01a(0x177)](0x0,_0x5ea1d0[_0x5cf01a(_0x25d1d1._0x5e821f)]-0x1f4),_0x45bc14=_0x42b11d[_0x5cf01a(_0x25d1d1._0xb10036)](_0x190b65,_0x5ea1d0['index']),_0xe3c218=parseQuality(_0x45bc14)||'HD';_0x22d1d8[_0x5cf01a(0x1a5)]({'url':_0x3611aa,'quality':_0xe3c218});}if(_0x22d1d8['length']===0x0)return log(_0x5cf01a(0x176)),[];log('Found\x20'+_0x22d1d8[_0x5cf01a(_0x25d1d1._0x3b531f)]+_0x5cf01a(0x183));var _0xc0efed=[],_0x5eba6d=_0x110828?_0x3a55cd[_0x5cf01a(_0x25d1d1._0x428f96)]+'\x20[S'+pad2(_0x562845)+'E'+pad2(_0x18a5f5)+']':_0x2d623c[_0x5cf01a(0x1a7)];for(var _0xab5041=0x0;_0xab5041<_0x22d1d8['length'];_0xab5041++){var _0x3d707e=_0x22d1d8[_0xab5041];if(_0x3d707e[_0x5cf01a(0x160)]==='480p'){log(_0x5cf01a(0x155));continue;}var _0x4d9f76=yield processMvlink(_0x3d707e[_0x5cf01a(0x168)],BASE_URL+'/',_0x5eba6d,_0x3d707e['quality'],_0x18a5f5,_0x3a55cd,_0x110828,_0x562845);_0x4d9f76&&_0x4d9f76['length']>0x0&&(_0xc0efed=_0xc0efed['concat'](_0x4d9f76));}_0xc0efed=dedupe(_0xc0efed);var _0x50cf6d={'2160p':0x5,'1440p':0x4,'1080p':0x3,'720p':0x2,'HD':0x1};return _0xc0efed[_0x5cf01a(0x1af)](function(_0x20f605,_0x177544){var _0x196f59=_0x5cf01a,_0x1e1e9b=_0x50cf6d[_0x20f605[_0x196f59(0x160)]]||0x0,_0x114da0=_0x50cf6d[_0x177544[_0x196f59(_0x430493._0x3b1c1b)]]||0x0;return _0x114da0-_0x1e1e9b;}),log(_0x5cf01a(0x180)+_0xc0efed[_0x5cf01a(_0x25d1d1._0x2fd6da)]+'\x20streams.'),_0xc0efed;}catch(_0x4d27f1){return err('fatal:\x20'+_0x4d27f1[_0x5cf01a(0x195)]),[];}});}typeof module!==_0x1ae17e(0x1a1)&&module[_0x1ae17e(0x185)]?module['exports']={'getStreams':getStreams}:global['getStreams']=getStreams;

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "hindmoviez", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_STREAM_DISPLAY_START */
/* CLOUDBANK_STREAM_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name);
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var release = /\b(WEB[ ._-]?DL|WEB[ ._-]?RIP|BLU[ ._-]?RAY|BD[ ._-]?REMUX|REMUX|DVD[ ._-]?RIP|HD[ ._-]?RIP|HDTV|HDCAM|CAM)\b/i.exec(text);
    var releaseLabel = release ? release[1].toUpperCase().replace(/[ ._]/g, "-") : "";
    if (/^WEB-?DL$/.test(releaseLabel)) releaseLabel = "WEB-DL";
    if (/^WEB-?RIP$/.test(releaseLabel)) releaseLabel = "WEBRip";
    if (/^BLU-?RAY$/.test(releaseLabel)) releaseLabel = "BluRay";
    if (/REMUX/.test(releaseLabel)) releaseLabel = "Remux";
    var codec = /\b(HEVC|H[ ._-]?265|X265|AVC|H[ ._-]?264|X264|AV1)\b/i.exec(text);
    var codecLabel = codec ? (/265|HEVC/i.test(codec[1]) ? "HEVC" : /264|AVC/i.test(codec[1]) ? "H.264" : "AV1") : "";
    var hdr = /\b(DOLBY[ ._-]?VISION|HDR10\+|HDR10|HDR|SDR)(?!\w)/i.exec(text);
    var hdrLabel = hdr ? (/DOLBY/i.test(hdr[1]) ? "Dolby Vision" : hdr[1].toUpperCase()) : "";
    var videoLine = unique([qualityLabel, releaseLabel, codecLabel, hdrLabel]).join(" · ");
    if (videoLine) lines.push(videoLine);
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage))) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var audioCodec = /\b(DOLBY[ ._-]?ATMOS|ATMOS|TRUEHD|DTS[ ._-]?HD[ ._-]?MA|DTS[ ._-]?HD|DTS[ ._-]?X|DTS|E[ ._-]?AC[ ._-]?3|DDP|AC[ ._-]?3|AAC|FLAC|OPUS)\b/i.exec(text);
    var audioCodecLabel = audioCodec ? audioCodec[1].toUpperCase().replace(/[ ._]/g, "-") : "";
    if (/ATMOS/.test(audioCodecLabel)) audioCodecLabel = "Dolby Atmos";
    if (audioCodecLabel === "TRUEHD") audioCodecLabel = "Dolby TrueHD";
    if (/^(E-?AC-?3|DDP)$/.test(audioCodecLabel)) audioCodecLabel = "Dolby Digital Plus";
    if (/^AC-?3$/.test(audioCodecLabel)) audioCodecLabel = "Dolby Digital";
    var channels = /\b(7\.1|6\.1|5\.1|2\.0)\b/.exec(text);
    var audioLine = unique([audioLabel, [audioCodecLabel, channels ? channels[1] : ""].filter(Boolean).join(" ")]).join(" · ");
    if (audioLine) lines.push(audioLine);
    var subs = Array.isArray(stream.subtitles) ? unique(stream.subtitles.map(function(sub) {
      return sub && (language(sub.language) || language(sub.lang) || language(sub.code) || language(sub.id));
    })) : [];
    if (subs.length) lines.push("Subtitles: " + subs.join(", "));
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var size = usable(stream.size || stream.fileSize || (stream.behaviorHints && stream.behaviorHints.videoSize));
    if (!size) { var sm = /\b(\d+(?:\.\d+)?)\s*(GB|MB|TB|GiB|MiB)\b/i.exec(text); if (sm) size = sm[1] + " " + sm[2]; }
    if (/^\d+(?:\.\d+)?$/.test(size)) {
      var bytes = Number(size);
      size = bytes > 0 ? (bytes >= 1073741824 ? (bytes / 1073741824).toFixed(1) + " GB" : (bytes / 1048576).toFixed(1) + " MB") : "";
    } else if (!/^\d+(?:\.\d+)?\s*(?:GB|MB|TB|GiB|MiB)$/i.test(size)) size = "";
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    lines.push(unique([formatLabel, server, size, duration]).join(" · "));
    output.name = "";
    output.title = lines.join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "HindMoviez", "hindmoviez");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
/* CLOUDBANK_STREAM_DISPLAY_END */
