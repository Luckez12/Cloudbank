// Imported provider: torrentio; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
'use strict';function _0x3841(){const _0x460f54=['DhjPBq','nZC1mZLuy2jzD0e','mJi1DuTcBvnA','8j+rPsa','re9mqLKGvKLtsu9o','DgHYB3C','ndmWodC2zwTowLzr','Dw5KzwzPBMvK','8j+oRca','zgvICMLKuhjVDMLKzxi','w1rVCNjLBNrPB10GrxHLy3v0Aw9UigzHAwX1CMuGy29UDgv4DdO','uMvHBerLyNjPza','rw5NBgLZAa','ywXSzgvICMLK','BgvUz3rO','yxbWBgLJyxrPB24VANnVBG','C2XPy2u','zwfZEwrLyNjPza','DwrWoI8VzxHVzhvZlMrLC3LUyY5JB206nJK2os9HBM5VDw5Jzq','seLoreK','BM9Uzq','Chv0Aw8','C3bSAxq','sers','Bwf0y2G','sersmtaR','CMvSzwfZzv9KyxrL','AM9PBG','BMfTzq','vw5RBM93BIbtAxPL','mJaYnG','odaWodrQwu1rCvC','CMvHBgrLyNjPza','nZiWua','ntm2yMHqDNzy','CMvWBgfJzq','txvSDgKTqxvKAw8','mtG2nwy0m2eWntq5y2e1mgqZndfKzdLHyJHImJLMndK','zg9Uzq','zMLYC3rFywLYx2rHDgu','8j+oPIa','ihWG4PQz77Ipia','Bw92Awu','vg9YCMvUDgLV','Dg9vChbLCKnHC2u','ChvZAa','mJe2mha','yxbWBhK','tvvmveKTqvvesu8','ueLsqvrfqKfz','ihWG','BMv4Da','wvrt','C2vYAwvZlW','DwrWoI8VDhjHy2TLCI5VCgvUDhjHy2TYlM9YzZOXmZm3l2fUBM91BMnL','mJm3mZK5mgnlzfPoqG','DgHLBG','mtqYoti2q2riruDx','uhjLBwL1BwL6zq','qwXSrgvICMLK','zM9YrwfJAa','ANnVBG','tvvmveK','DgL0Bgu','u0nsqvbfuL9trvrusu5huW','y2f0y2G','zxHWB3j0CW','sdi2nq','mta4mfa','zgvICMLKs2v5','mJa4ndCWnMXpsMvPzG','Aw5JBhvKzxm','zxjYB3i','mta4mha','sgLUzgK','ndbVqxrIEeK','Bw92AwuV','tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2ienOCM9Tzs8XmJaGu2fMyxjPlZuZnY4ZnG','Aw5MB0HHC2G','zxH0zxjUywXFAwrZ','mwfLqLPpuq','mtm5odeYmdLUvLjICw0','ihWG8j+rPca','Dg9mB3DLCKnHC2u','Ahr0Chm6lY90B3jYzw50Aw8UC3rYzw0UzNvU','tvvmveLmqu5h','Dgv4Da','uKfsqKC','vg9YqM94'];_0x3841=function(){return _0x460f54;};return _0x3841();}const _0x102190=_0x2b8c;(function(_0x3d29d3,_0x4e669c){const _0x36b519={_0x136298:0xa1,_0x154785:0x7b,_0x464518:0x88},_0x51615c=_0x2b8c,_0x4974c5=_0x3d29d3();while(!![]){try{const _0x542fac=-parseInt(_0x51615c(0x92))/0x1*(-parseInt(_0x51615c(_0x36b519._0x136298))/0x2)+parseInt(_0x51615c(_0x36b519._0x154785))/0x3+-parseInt(_0x51615c(0xba))/0x4*(-parseInt(_0x51615c(0x9d))/0x5)+parseInt(_0x51615c(0x79))/0x6+parseInt(_0x51615c(0x9c))/0x7*(-parseInt(_0x51615c(0xbd))/0x8)+parseInt(_0x51615c(_0x36b519._0x464518))/0x9*(parseInt(_0x51615c(0x8d))/0xa)+-parseInt(_0x51615c(0x93))/0xb;if(_0x542fac===_0x4e669c)break;else _0x4974c5['push'](_0x4974c5['shift']());}catch(_0x5bae71){_0x4974c5['push'](_0x4974c5['shift']());}}}(_0x3841,0x737d8));function _0x2b8c(_0x30f91e,_0x55d23c){_0x30f91e=_0x30f91e-0x78;const _0x384136=_0x3841();let _0x2b8cd3=_0x384136[_0x30f91e];if(_0x2b8c['HPjzwg']===undefined){var _0x477f4b=function(_0x1f4074){const _0x11e4fa='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0x1e04b6='',_0x44b691='';for(let _0x28b14e=0x0,_0x4ea462,_0x44acf4,_0x36bb1a=0x0;_0x44acf4=_0x1f4074['charAt'](_0x36bb1a++);~_0x44acf4&&(_0x4ea462=_0x28b14e%0x4?_0x4ea462*0x40+_0x44acf4:_0x44acf4,_0x28b14e++%0x4)?_0x1e04b6+=String['fromCharCode'](0xff&_0x4ea462>>(-0x2*_0x28b14e&0x6)):0x0){_0x44acf4=_0x11e4fa['indexOf'](_0x44acf4);}for(let _0x3af581=0x0,_0x371487=_0x1e04b6['length'];_0x3af581<_0x371487;_0x3af581++){_0x44b691+='%'+('00'+_0x1e04b6['charCodeAt'](_0x3af581)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x44b691);};_0x2b8c['KdZvnP']=_0x477f4b,_0x2b8c['ggvOZE']={},_0x2b8c['HPjzwg']=!![];}const _0x3d8572=_0x384136[0x0],_0x58fc6a=_0x30f91e+_0x3d8572,_0x1cb2b9=_0x2b8c['ggvOZE'][_0x58fc6a];return!_0x1cb2b9?(_0x2b8cd3=_0x2b8c['KdZvnP'](_0x2b8cd3),_0x2b8c['ggvOZE'][_0x58fc6a]=_0x2b8cd3):_0x2b8cd3=_0x1cb2b9,_0x2b8cd3;}var __async=(_0x1e04b6,_0x44b691,_0x28b14e)=>{const _0x467462={_0x1eccfc:0xca,_0x503dc8:0xce};return new Promise((_0x4ea462,_0x44acf4)=>{const _0x5457f9=_0x2b8c;var _0x36bb1a=_0x230a03=>{try{_0x371487(_0x28b14e['next'](_0x230a03));}catch(_0x3915f9){_0x44acf4(_0x3915f9);}},_0x3af581=_0x4179fa=>{const _0x4d87f9=_0x2b8c;try{_0x371487(_0x28b14e[_0x4d87f9(0xa0)](_0x4179fa));}catch(_0x40c437){_0x44acf4(_0x40c437);}},_0x371487=_0x2c6124=>_0x2c6124[_0x5457f9(0xc1)]?_0x4ea462(_0x2c6124['value']):Promise['resolve'](_0x2c6124['value'])['then'](_0x36bb1a,_0x3af581);_0x371487((_0x28b14e=_0x28b14e[_0x5457f9(_0x467462._0x1eccfc)](_0x1e04b6,_0x44b691))[_0x5457f9(_0x467462._0x503dc8)]());});},TMDB_API_KEY=_0x102190(0xc0),TORRENTIO_API=_0x102190(0x96),PROVIDER_NAME=_0x102190(0xc6),HEADERS={'User-Agent':_0x102190(0x8f),'Accept':_0x102190(0xaa)},TRACKERS=[_0x102190(0x78),'udp://open.stealth.si:80/announce','udp://tracker.torrent.eu.org:451/announce',_0x102190(0xad)];function getDebridSettings(){const _0x46df04={_0x36c0f6:0x82,_0x593760:0xa4,_0x472bb3:0x95,_0xba57b7:0x9b},_0x408cb8=_0x102190;let _0x5f1d92=_0x408cb8(0xaf),_0x2c483f='';try{let _0x4ac3be=null;if(typeof global!==_0x408cb8(0xa2)&&global['SCRAPER_SETTINGS'])_0x4ac3be=global['SCRAPER_SETTINGS'];else typeof window!=='undefined'&&window['SCRAPER_SETTINGS']&&(_0x4ac3be=window[_0x408cb8(_0x46df04._0x36c0f6)]);_0x4ac3be&&(_0x4ac3be[_0x408cb8(_0x46df04._0x593760)]&&(_0x5f1d92=String(_0x4ac3be['debridProvider'])[_0x408cb8(_0x46df04._0x472bb3)]()['trim']()),_0x4ac3be[_0x408cb8(0x87)]&&(_0x2c483f=String(_0x4ac3be['debridKey'])[_0x408cb8(_0x46df04._0xba57b7)]()));}catch(_0x5dde3d){console['error']('[Torrentio]\x20Error\x20reading\x20settings\x20context:',_0x5dde3d);}return{'provider':_0x5f1d92,'key':_0x2c483f};}function buildMagnet(_0xbbfeec){const _0x4dc008={_0x57f88d:0xb6},_0x5a70d7=_0x102190;if(!_0xbbfeec)return'';const _0x29a1ae=TRACKERS['map'](_0x3124d7=>'&tr='+encodeURIComponent(_0x3124d7))[_0x5a70d7(_0x4dc008._0x57f88d)]('');return'magnet:?xt=urn:btih:'+_0xbbfeec+_0x29a1ae;}function getDebridPathSegment(){const {provider:_0x3c1872,key:_0x520b07}=getDebridSettings();if(!_0x3c1872||_0x3c1872==='none'||!_0x520b07)return'';return _0x3c1872+'='+_0x520b07;}function getStreams(_0xb03d77,_0x578661=_0x102190(0xc5),_0x3056bc=null,_0x137006=null){const _0x184e34={_0x2a8c66:0x7a,_0x4ba85c:0x83,_0x427e2d:0x91,_0x2371f5:0xc2,_0x2c407a:0xb1,_0x2c0c27:0xd0,_0xddf3ef:0x8e,_0x4d6b0b:0xa9,_0x2fbf75:0xab,_0x334fad:0x7e},_0x211fe6={_0x20dd13:0xc7,_0xb3122e:0xb8,_0x1c9a05:0xb3,_0x49b314:0x8b,_0x58cfda:0x89,_0x5a7434:0xc9,_0x161d91:0x86,_0x4d05fd:0xa7,_0x330881:0x80,_0x5bc869:0xcb,_0xb145e4:0xbf,_0x2c0e7d:0x8c,_0x35bd73:0xb2,_0x2b8b5e:0xc8,_0x1d3285:0xb2,_0x3d57ba:0xb3,_0x583b39:0x89,_0x32a3c3:0xcf,_0x564b3d:0x90,_0xe47ae7:0x90,_0x5408f9:0x9e,_0x269b4c:0xc4};return __async(this,null,function*(){const _0x344263=_0x2b8c;var _0x20e4d3;const _0x581880=_0x578661==='tv'||_0x578661==='series',_0x1912f9='https://api.themoviedb.org/3/'+(_0x581880?'tv':'movie')+'/'+_0xb03d77+'?api_key='+TMDB_API_KEY+'&append_to_response=external_ids';try{const _0x121652=yield fetch(_0x1912f9)[_0x344263(_0x184e34._0x2a8c66)](_0xa18f91=>_0xa18f91[_0x344263(0x7f)]())[_0x344263(_0x184e34._0x4ba85c)](()=>null),_0x21f9b6=((_0x20e4d3=_0x121652==null?void 0x0:_0x121652[_0x344263(_0x184e34._0x427e2d)])==null?void 0x0:_0x20e4d3['imdb_id'])||(_0x121652==null?void 0x0:_0x121652['imdb_id'])||_0xb03d77,_0xbebbe3=(_0x121652==null?void 0x0:_0x121652['title'])||(_0x121652==null?void 0x0:_0x121652[_0x344263(0xb7)])||'Unknown\x20Title',_0x3be76c=(_0x121652==null?void 0x0:_0x121652[_0x344263(0xb5)])?_0x121652['release_date'][_0x344263(0xb1)]('-')[0x0]:(_0x121652==null?void 0x0:_0x121652['first_air_date'])?_0x121652[_0x344263(_0x184e34._0x2371f5)][_0x344263(_0x184e34._0x2c407a)]('-')[0x0]:_0x344263(0xb9),_0x3ce8bf=getDebridPathSegment(),_0x3995cc=_0x3ce8bf?_0x3ce8bf+'/':'',_0x4de1bc=_0x581880?_0x344263(_0x184e34._0x2c0c27)+_0x21f9b6+':'+(_0x3056bc||0x1)+':'+(_0x137006||0x1):_0x344263(_0x184e34._0xddf3ef)+_0x21f9b6,_0x17e10c=TORRENTIO_API+'/'+_0x3995cc+'stream/'+_0x4de1bc+'.json',_0x4b5348=yield fetch(_0x17e10c,{'headers':HEADERS})[_0x344263(_0x184e34._0x2a8c66)](_0x341020=>_0x341020[_0x344263(0x7f)]())['catch'](()=>null);if(!(_0x4b5348==null?void 0x0:_0x4b5348['streams'])||_0x4b5348['streams'][_0x344263(_0x184e34._0x4d6b0b)]===0x0)return[];const _0x322bd8=[];return _0x4b5348['streams'][_0x344263(_0x184e34._0x2fbf75)](0x0,0xf)[_0x344263(_0x184e34._0x334fad)](_0x22879f=>{const _0x49554e=_0x344263;var _0x1e0120;if(!_0x22879f)return;const _0x42371e=(_0x22879f[_0x49554e(0x81)]||'')[_0x49554e(0xbe)](/\n/g,'\x20'),_0x1e3856=_0x42371e[_0x49554e(_0x211fe6._0x20dd13)](),_0x440577=((_0x1e0120=_0x42371e['match'](/👤\s*(\d+)/))==null?void 0x0:_0x1e0120[0x1])||'0';let _0x573751=_0x49554e(_0x211fe6._0xb3122e);const _0x14dcbb=_0x42371e[_0x49554e(_0x211fe6._0x1c9a05)](/([0-9.]+ ?[GM]B)/i);_0x14dcbb&&(_0x573751=_0x14dcbb[0x1][_0x49554e(0xc7)]());let _0x5ed963=_0x49554e(_0x211fe6._0x49b314),_0x40a497='💎';if(_0x1e3856[_0x49554e(_0x211fe6._0x58cfda)]('2160P')||_0x1e3856['includes']('4K'))_0x5ed963=_0x49554e(_0x211fe6._0x5a7434),_0x40a497='🔥';else{if(_0x1e3856[_0x49554e(_0x211fe6._0x58cfda)](_0x49554e(_0x211fe6._0x161d91)))_0x5ed963='1080p',_0x40a497='💎';else{if(_0x1e3856[_0x49554e(0x89)](_0x49554e(0xbc)))_0x5ed963='720p',_0x40a497='⚡';else _0x1e3856[_0x49554e(_0x211fe6._0x58cfda)]('480P')&&(_0x5ed963='480p',_0x40a497='📱');}}let _0x4bec59=_0x49554e(_0x211fe6._0x4d05fd);if(_0x1e3856[_0x49554e(0x89)]('DUAL')||_0x1e3856[_0x49554e(_0x211fe6._0x58cfda)]('DUAL-AUDIO'))_0x4bec59='Dual-Audio';else{if(_0x1e3856['includes'](_0x49554e(_0x211fe6._0x330881))||_0x1e3856['includes'](_0x49554e(0x97))||_0x1e3856[_0x49554e(_0x211fe6._0x58cfda)](_0x49554e(_0x211fe6._0x5bc869)))_0x4bec59=_0x49554e(_0x211fe6._0xb145e4);else{if(_0x1e3856[_0x49554e(0x89)](_0x49554e(0xae)))_0x4bec59=_0x49554e(_0x211fe6._0x2c0e7d);}}const _0x5f119f=[];if(_0x1e3856['includes']('DV')||_0x1e3856[_0x49554e(0x89)](_0x49554e(0x9f)))_0x5f119f[_0x49554e(0xc8)]('DV');if(_0x1e3856['includes']('HDR10+'))_0x5f119f[_0x49554e(0xc8)](_0x49554e(0xb4));else{if(_0x1e3856[_0x49554e(0x89)]('HDR10'))_0x5f119f['push']('HDR10');else{if(_0x1e3856[_0x49554e(0x89)](_0x49554e(_0x211fe6._0x35bd73)))_0x5f119f[_0x49554e(_0x211fe6._0x2b8b5e)](_0x49554e(_0x211fe6._0x1d3285));}}if(_0x1e3856[_0x49554e(_0x211fe6._0x58cfda)]('HEVC')||_0x1e3856[_0x49554e(0x89)]('X265')||_0x1e3856[_0x49554e(0x89)](_0x49554e(0x85)))_0x5f119f['push']('HEVC');_0x5f119f[_0x49554e(0xc8)](_0x4bec59);const _0x168ab5=_0x5f119f['join']('\x20•\x20');let _0x35a27d=PROVIDER_NAME;const _0x23ce60=_0x42371e[_0x49554e(_0x211fe6._0x3d57ba)](/\[(.*?)\]/);if(_0x23ce60&&_0x23ce60[0x1]){const _0x420d5d=_0x23ce60[0x1]['trim']();!/\d+P|HEVC|H264|WEB|BLURAY/i['test'](_0x420d5d)&&(_0x35a27d=_0x420d5d);}if(_0x35a27d===PROVIDER_NAME){if(_0x1e3856[_0x49554e(_0x211fe6._0x583b39)](_0x49554e(0x99)))_0x35a27d='RARBG';else{if(_0x1e3856[_0x49554e(_0x211fe6._0x58cfda)](_0x49554e(_0x211fe6._0x32a3c3)))_0x35a27d='YTS';else{if(_0x1e3856[_0x49554e(0x89)](_0x49554e(0xcc))||_0x1e3856['includes']('TPB'))_0x35a27d='ThePirateBay';else{if(_0x1e3856[_0x49554e(0x89)]('1337X'))_0x35a27d='1337x';else{if(_0x1e3856[_0x49554e(0x89)]('EZTV'))_0x35a27d='EZTV';else{if(_0x1e3856['includes']('TGX'))_0x35a27d='TGX';}}}}}}const _0x5754a0=_0x22879f['url']||(_0x22879f[_0x49554e(_0x211fe6._0x564b3d)]?buildMagnet(_0x22879f[_0x49554e(_0x211fe6._0xe47ae7)]):''),_0xa094e9=_0x581880?_0x49554e(0xc3)+_0xbebbe3+'\x20|\x20S'+(_0x3056bc||0x1)+'\x20E'+(_0x137006||0x1):_0x49554e(0xa3)+_0xbebbe3+'\x20-\x20'+_0x3be76c,_0x6f1929=_0x40a497+'\x20'+_0x5ed963+'\x20|\x20'+_0x168ab5,_0xb97468=_0x49554e(_0x211fe6._0x5408f9)+_0x440577+'\x20|\x20💾\x20'+_0x573751+_0x49554e(_0x211fe6._0x269b4c)+_0x35a27d,_0x3d871c=_0xa094e9+'\x0a'+_0x6f1929+'\x0a'+_0xb97468;_0x322bd8['push']({'name':PROVIDER_NAME+_0x49554e(0x94)+_0x440577+_0x49554e(0xcd)+_0x5ed963['toUpperCase'](),'title':_0x3d871c,'size':_0x3d871c,'description':_0x3d871c,'url':_0x5754a0});}),_0x322bd8;}catch(_0x20f2e6){return console[_0x344263(0x8a)](_0x344263(0xa5),_0x20f2e6),[];}});}function onSettings(){const _0x336af6={_0x1fe74f:0xa8,_0x43dbab:0x9a,_0x5210eb:0x87};return __async(this,null,function*(){const _0x3804c0=_0x2b8c;return[{'type':'header','label':'Debrid\x20Provider\x20Configuration'},{'type':'select','key':'debridProvider','label':'Debrid\x20Provider','options':[{'label':'None','value':'none'},{'label':_0x3804c0(0xa6),'value':_0x3804c0(0xbb)},{'label':_0x3804c0(0x7c),'value':'premiumize'},{'label':_0x3804c0(0x7d),'value':_0x3804c0(_0x336af6._0x1fe74f)},{'label':'DebridLink','value':'debridlink'},{'label':'EasyDebrid','value':_0x3804c0(0xac)},{'label':'Offcloud','value':'offcloud'},{'label':_0x3804c0(_0x336af6._0x43dbab),'value':'torbox'},{'label':'Put.io','value':_0x3804c0(0xb0)}],'default':'none'},{'type':_0x3804c0(0x98),'isPassword':!![],'key':_0x3804c0(_0x336af6._0x5210eb),'label':'API\x20Key\x20/\x20Token','placeholder':'Enter\x20your\x20Debrid\x20API\x20key','description':'API\x20Key\x20or\x20Access\x20Token\x20for\x20your\x20selected\x20Debrid\x20service.'}];});}module[_0x102190(0x84)]={'getStreams':getStreams,'onSettings':onSettings};

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "torrentio", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_STREAM_DISPLAY_START */
/* CLOUDBANK_STREAM_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name);
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var release = /\b(WEB[ ._-]?DL|WEB[ ._-]?RIP|BLU[ ._-]?RAY|BD[ ._-]?REMUX|REMUX|DVD[ ._-]?RIP|HD[ ._-]?RIP|HDTV|HDCAM|CAM)\b/i.exec(text);
    var releaseLabel = release ? release[1].toUpperCase().replace(/[ ._]/g, "-") : "";
    if (/^WEB-?DL$/.test(releaseLabel)) releaseLabel = "WEB-DL";
    if (/^WEB-?RIP$/.test(releaseLabel)) releaseLabel = "WEBRip";
    if (/^BLU-?RAY$/.test(releaseLabel)) releaseLabel = "BluRay";
    if (/REMUX/.test(releaseLabel)) releaseLabel = "Remux";
    var codec = /\b(HEVC|H[ ._-]?265|X265|AVC|H[ ._-]?264|X264|AV1)\b/i.exec(text);
    var codecLabel = codec ? (/265|HEVC/i.test(codec[1]) ? "HEVC" : /264|AVC/i.test(codec[1]) ? "H.264" : "AV1") : "";
    var hdr = /\b(DOLBY[ ._-]?VISION|HDR10\+|HDR10|HDR|SDR)(?!\w)/i.exec(text);
    var hdrLabel = hdr ? (/DOLBY/i.test(hdr[1]) ? "Dolby Vision" : hdr[1].toUpperCase()) : "";
    var videoLine = unique([qualityLabel, releaseLabel, codecLabel, hdrLabel]).join(" · ");
    if (videoLine) lines.push(videoLine);
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage))) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var audioCodec = /\b(DOLBY[ ._-]?ATMOS|ATMOS|TRUEHD|DTS[ ._-]?HD[ ._-]?MA|DTS[ ._-]?HD|DTS[ ._-]?X|DTS|E[ ._-]?AC[ ._-]?3|DDP|AC[ ._-]?3|AAC|FLAC|OPUS)\b/i.exec(text);
    var audioCodecLabel = audioCodec ? audioCodec[1].toUpperCase().replace(/[ ._]/g, "-") : "";
    if (/ATMOS/.test(audioCodecLabel)) audioCodecLabel = "Dolby Atmos";
    if (audioCodecLabel === "TRUEHD") audioCodecLabel = "Dolby TrueHD";
    if (/^(E-?AC-?3|DDP)$/.test(audioCodecLabel)) audioCodecLabel = "Dolby Digital Plus";
    if (/^AC-?3$/.test(audioCodecLabel)) audioCodecLabel = "Dolby Digital";
    var channels = /\b(7\.1|6\.1|5\.1|2\.0)\b/.exec(text);
    var audioLine = unique([audioLabel, [audioCodecLabel, channels ? channels[1] : ""].filter(Boolean).join(" ")]).join(" · ");
    if (audioLine) lines.push(audioLine);
    var subs = Array.isArray(stream.subtitles) ? unique(stream.subtitles.map(function(sub) {
      return sub && (language(sub.language) || language(sub.lang) || language(sub.code) || language(sub.id));
    })) : [];
    if (subs.length) lines.push("Subtitles: " + subs.join(", "));
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var size = usable(stream.size || stream.fileSize || (stream.behaviorHints && stream.behaviorHints.videoSize));
    if (!size) { var sm = /\b(\d+(?:\.\d+)?)\s*(GB|MB|TB|GiB|MiB)\b/i.exec(text); if (sm) size = sm[1] + " " + sm[2]; }
    if (/^\d+(?:\.\d+)?$/.test(size)) {
      var bytes = Number(size);
      size = bytes > 0 ? (bytes >= 1073741824 ? (bytes / 1073741824).toFixed(1) + " GB" : (bytes / 1048576).toFixed(1) + " MB") : "";
    } else if (!/^\d+(?:\.\d+)?\s*(?:GB|MB|TB|GiB|MiB)$/i.test(size)) size = "";
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    lines.push(unique([formatLabel, server, size, duration]).join(" · "));
    output.name = "";
    output.title = lines.join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "🧲 Torrentio", "torrentio");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
/* CLOUDBANK_STREAM_DISPLAY_END */
