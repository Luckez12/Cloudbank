// Imported provider: gramcinema; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
var _0x1c6b03=_0x199d;(function(_0x18ce7f,_0x4cf4d0){var _0x1dff7c={_0x16691d:0x16f,_0x5d7b3e:0x164,_0x2c65ce:0x131,_0x961a84:0x12d,_0x26bce6:0x149,_0x3e024a:0x123,_0x26c984:0x121},_0x566082=_0x199d,_0x3e9f08=_0x18ce7f();while(!![]){try{var _0x2b552e=-parseInt(_0x566082(_0x1dff7c._0x16691d))/0x1+parseInt(_0x566082(_0x1dff7c._0x5d7b3e))/0x2+parseInt(_0x566082(0x15f))/0x3*(-parseInt(_0x566082(0x166))/0x4)+-parseInt(_0x566082(_0x1dff7c._0x2c65ce))/0x5*(parseInt(_0x566082(_0x1dff7c._0x961a84))/0x6)+parseInt(_0x566082(_0x1dff7c._0x26bce6))/0x7+parseInt(_0x566082(_0x1dff7c._0x3e024a))/0x8*(-parseInt(_0x566082(_0x1dff7c._0x26c984))/0x9)+parseInt(_0x566082(0x13b))/0xa;if(_0x2b552e===_0x4cf4d0)break;else _0x3e9f08['push'](_0x3e9f08['shift']());}catch(_0x421f21){_0x3e9f08['push'](_0x3e9f08['shift']());}}}(_0x5eb7,0x777dd));function _0x199d(_0x4e437c,_0x3381ec){_0x4e437c=_0x4e437c-0x11f;var _0x5eb7c3=_0x5eb7();var _0x199d71=_0x5eb7c3[_0x4e437c];if(_0x199d['zDDrKW']===undefined){var _0x272c05=function(_0x48819b){var _0x381195='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';var _0x2abbc7='',_0x4b7d49='';for(var _0x3042d4=0x0,_0x13949c,_0x54d5f7,_0x3ae674=0x0;_0x54d5f7=_0x48819b['charAt'](_0x3ae674++);~_0x54d5f7&&(_0x13949c=_0x3042d4%0x4?_0x13949c*0x40+_0x54d5f7:_0x54d5f7,_0x3042d4++%0x4)?_0x2abbc7+=String['fromCharCode'](0xff&_0x13949c>>(-0x2*_0x3042d4&0x6)):0x0){_0x54d5f7=_0x381195['indexOf'](_0x54d5f7);}for(var _0x1aa0f4=0x0,_0x3e7692=_0x2abbc7['length'];_0x1aa0f4<_0x3e7692;_0x1aa0f4++){_0x4b7d49+='%'+('00'+_0x2abbc7['charCodeAt'](_0x1aa0f4)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x4b7d49);};_0x199d['RiIAxi']=_0x272c05,_0x199d['WkuLtg']={},_0x199d['zDDrKW']=!![];}var _0x24fbdb=_0x5eb7c3[0x0],_0x1aecd0=_0x4e437c+_0x24fbdb,_0x39d319=_0x199d['WkuLtg'][_0x1aecd0];return!_0x39d319?(_0x199d71=_0x199d['RiIAxi'](_0x199d71),_0x199d['WkuLtg'][_0x1aecd0]=_0x199d71):_0x199d71=_0x39d319,_0x199d71;}function getToken(){var _0x4cdc62={_0xad2aa6:0x165,_0x2f06a2:0x14b};return new Promise(function(_0x2abbc7){var _0x7ff70f=_0x199d;try{if(typeof global!==_0x7ff70f(0x134)&&global[_0x7ff70f(0x165)]&&global['SCRAPER_SETTINGS']['cinemaTvToken'])return console[_0x7ff70f(0x15a)]('[CinemaTV]\x20Using\x20token\x20from\x20global.SCRAPER_SETTINGS'),_0x2abbc7(String(global['SCRAPER_SETTINGS']['cinemaTvToken'])[_0x7ff70f(0x137)]());if(typeof window!==_0x7ff70f(0x134)&&window['SCRAPER_SETTINGS']&&window[_0x7ff70f(0x165)]['cinemaTvToken'])return console['log']('[CinemaTV]\x20Using\x20token\x20from\x20window.SCRAPER_SETTINGS'),_0x2abbc7(String(window[_0x7ff70f(_0x4cdc62._0xad2aa6)][_0x7ff70f(_0x4cdc62._0x2f06a2)])['trim']());}catch(_0x4b7d49){console['error'](_0x7ff70f(0x159),_0x4b7d49[_0x7ff70f(0x138)]);}console['error'](_0x7ff70f(0x125)),_0x2abbc7('');});}function formatBytes(_0x3042d4){var _0x56ef83={_0x5009d7:0x124,_0x58f728:0x15a,_0x5b9229:0x14f},_0x2f89b1=_0x199d;if(!_0x3042d4||_0x3042d4==0x0)return'Unknown';var _0x13949c=0x400,_0x54d5f7=['Bytes','KB','MB','GB','TB'],_0x3ae674=Math[_0x2f89b1(_0x56ef83._0x5009d7)](Math[_0x2f89b1(_0x56ef83._0x58f728)](_0x3042d4)/Math['log'](_0x13949c));return parseFloat((_0x3042d4/Math['pow'](_0x13949c,_0x3ae674))[_0x2f89b1(_0x56ef83._0x5b9229)](0x2))+'\x20'+_0x54d5f7[_0x3ae674];}function _0x5eb7(){var _0x1e488c=['ihWG8j+rGE+4JYbPtufy','nJuZmdm4tgv3ANDO','u0nsqvbfuL9trvrusu5huW','mty5mdu2tNrbzgnz','Edi2na','C29YDa','BMfTzq','qufdidCUmq','ihWG8j+oPsa','8j+oNU+4JYbnudq','Ahr0Chm6lY9IB2XSExDVB2qUzxuUB3jNlW','qufdidiUma','ntqZmdKWB3z2BM1m','rhvHBc1bDwrPBW','w0nPBMvTyvrwxsbgzxrJAcbgywLSzwq6ia','C2XPy2u','C2vYAwvZ','zMLSDgvY','zxjYB3i','zxHWB3j0CW','iokaOIa','ywXS','Dg9vChbLCKnHC2u','nZC0wvzAsuDq','kI8Q','odu3odr1vhvUyNK','zMXVB3i','w0nPBMvTyvrwxsboBYb0B2TLBIbMB3vUzcbPBIbZzxr0Aw5NCYeGugXLyxnLignVBMzPz3vYzsbhCMfTq2LUzw1HihnLDhrPBMDZlG','8j+uLYbhCMfTq2LUzw1HiokaOIa','zM9YrwfJAa','sers','DgvZDa','C3vIC3rYAw5N','w0nPBMvTyvrwxsbfCNjVCJOG','mJe2mfa','mJa5odKZmMHPt1zhsG','ywfJmJa','vgfTAwW','rerqiduUmq','nwrwwe9HBW','Dgv4Da','veDblunetG','Dw5KzwzPBMvK','Dg9mB3DLCKnHC2u','sersmtaR','DhjPBq','BwvZC2fNzq','vhj1zuHeidCUmq','rw5NBgLZAa','mtKXmdeYmJb4vvvmt3m','sersmta','sevwqYb4mJy1','Aw5KzxHpzG','BgvUz3rO','AgvHzgvY','DgL0Bgu','Ahr0Chm6lY90z2eTAgqUyxbPlMHHC2HOywnRzxjZlMnVBs9TAxHFBwvKAwfFzMLSzxmVC2vHCMnOp3e9','jtiW','Bwf0y2G','v0vclurm','Ahr0Chm6lY90z2eTAgqUyxbPlMHHC2HOywnRzxjZlMnVBs9Nzw5mAw5Rp3r5Cgu9BwL4x21LzgLHjMLKpq','ihWG','DhzFCMvZDwX0CW','nJy4odaXmhDqq2PfCa','BwfW','y2LUzw1HvhzuB2TLBG','qMvHCMvYia','mta4mfa','DxjS','Dg9gAxHLza','zMLSzv9Uyw1L','ywfJ','y2f0y2G','mJe2mha','C3bSAxq','w0nPBMvTyvrwxsboBYb0B2TLBIbHDMfPBgfIBguSigfIB3j0Aw5NigDLDfn0CMvHBxm','CMvWBgfJzq','CMvZB2X2zq','ChvZAa','w0nPBMvTyvrwxsbfCNjVCIbJAgvJA2LUzYbZzxr0Aw5NCYbWyw5LBdO','Bg9N','ihWG8j+sVIa','Bw92Awu','x3jLC1DLAwDODa','8j+uHIaXmejPDa','nJnwtu1pzw4','sfruuca','DgHLBG','AM9PBG'];_0x5eb7=function(){return _0x1e488c;};return _0x5eb7();}function fetchJson(_0x1aa0f4,_0x3e7692){var _0x47b830={_0x5a66e7:0x175},_0xd24dd5={_0xd421a9:0x160},_0x4f1a68=_0x199d;return console['log']('[CinemaTV]\x20Fetching:\x20'+_0x1aa0f4),fetch(_0x1aa0f4,_0x3e7692||{})['then'](function(_0x1d8111){var _0x5e8072=_0x199d;if(!_0x1d8111['ok'])throw new Error(_0x5e8072(_0xd24dd5._0xd421a9)+_0x1d8111['status']);return _0x1d8111['json']();})[_0x4f1a68(0x152)](function(_0x47bbc0){var _0x40b7f8=_0x4f1a68;console[_0x40b7f8(_0x47b830._0x5a66e7)](_0x40b7f8(0x171)+_0x47bbc0[_0x40b7f8(0x138)]);throw _0x47bbc0;});}function makeStream(_0x34124b,_0x57f14b,_0x4c8df1,_0x4cdc1a){var _0x3e8153={_0x247a8e:0x14d,_0x1e782a:0x12f,_0x8d8ed5:0x13a,_0x3215f9:0x156,_0x17719d:0x137,_0xa1fbaf:0x12c,_0x308548:0x15b,_0x1b72bb:0x129,_0x4befac:0x13c,_0x2aaa3e:0x158,_0x309be3:0x13f,_0x45a91a:0x16c,_0x36f88e:0x13e,_0x47122f:0x139,_0x22944d:0x13e,_0x497d40:0x16a,_0x3db50f:0x130,_0x4a9d87:0x145,_0x27176c:0x129,_0x350162:0x129,_0x38b552:0x145,_0xa4810d:0x133,_0x1d1a8f:0x126,_0x3105b7:0x147},_0x529be3={_0x22fe6c:0x120},_0x4709e2=_0x199d,_0x27b0fb='';try{_0x27b0fb=decodeURIComponent(_0x57f14b)+'\x20'+_0x34124b;}catch(_0x3183f7){_0x27b0fb=_0x57f14b+'\x20'+_0x34124b;}var _0x378a0c=_0x27b0fb[_0x4709e2(0x135)](),_0x7a7df6=/[\s\.\-\+\[\]_\(\)\|]+/g,_0x308a7d=_0x378a0c['replace'](_0x7a7df6,''),_0x3dd72a=_0x4709e2(_0x3e8153._0x247a8e);if(/2160p|4k|uhd/i['test'](_0x378a0c))_0x3dd72a='2160P';else{if(/1080p/i['test'](_0x378a0c))_0x3dd72a='1080P';else{if(/720p/i['test'](_0x378a0c))_0x3dd72a='720P';else{if(/480p/i[_0x4709e2(0x129)](_0x378a0c))_0x3dd72a='480P';}}}var _0x528b99='Dual-Audio',_0x4ca506=/hindi/i['test'](_0x378a0c),_0xbb4795=/(english|eng)/i[_0x4709e2(0x129)](_0x378a0c),_0x35ebd9=/tamil/i['test'](_0x378a0c),_0x4034d6=/telugu/i['test'](_0x378a0c),_0xdb86ad=0x0;if(_0x4ca506)_0xdb86ad++;if(_0xbb4795)_0xdb86ad++;if(_0x35ebd9)_0xdb86ad++;if(_0x4034d6)_0xdb86ad++;if(/(multi|multi\-audio|multi\.audio)/i['test'](_0x378a0c)||_0xdb86ad>=0x3)_0x528b99='Multi-Audio';else{if(/(dual|dual\-audio|dual\.audio|dubbed)/i['test'](_0x378a0c)||_0xdb86ad===0x2)_0x528b99=_0x4709e2(0x170);else{if(_0xdb86ad===0x1){if(_0x4ca506)_0x528b99='Hindi';else{if(_0x35ebd9)_0x528b99=_0x4709e2(_0x3e8153._0x1e782a);else{if(_0x4034d6)_0x528b99='Telugu';else{if(_0xbb4795)_0x528b99=_0x4709e2(_0x3e8153._0x8d8ed5);}}}}}}var _0x170071=_0x34124b[_0x4709e2(_0x3e8153._0x3215f9)](/\.(mkv|mp4|avi)$/i,'')['replace'](/\./g,'\x20'),_0x31079d='',_0x56ddc6=_0x170071[_0x4709e2(0x144)](/\b(S\d{1,2}\s*E\d{1,2})\b/i);if(_0x56ddc6){_0x31079d='\x20|\x20'+_0x56ddc6[0x1]['toUpperCase']()[_0x4709e2(0x156)](/\s+/g,'');var _0x285c14=_0x170071[_0x4709e2(0x135)]()['indexOf'](_0x56ddc6[0x0]['toLowerCase']());if(_0x285c14>0x0)_0x170071=_0x170071['substring'](0x0,_0x285c14);}var _0x1b557b='',_0x4e4e43=_0x170071['match'](/\b(19|20)\d{2}\b/);if(_0x4e4e43){_0x1b557b=_0x4e4e43[0x0];var _0xe93330=_0x170071['indexOf'](_0x1b557b);if(_0xe93330>0x0)_0x170071=_0x170071[_0x4709e2(0x12a)](0x0,_0xe93330);}_0x170071=_0x170071['replace'](/AMZN|WEB\-DL|WEB|DL|AVC|x264|x265|HEVC|STAN|WEBRip|SDR|10bit|iTunes|HQ|HDRip|BluRay|6CH|Dual|Audio|Hindi|English|Tamil|Telugu|720p|1080p|2160p|4k/gi,'')[_0x4709e2(0x156)](/[-_()\[\]|]/g,'\x20')['replace'](/\s+/g,'\x20')[_0x4709e2(_0x3e8153._0x17719d)](),_0x170071=_0x170071[_0x4709e2(0x156)](/\b\w/g,function(_0x2d6e4d){var _0x487b4c=_0x4709e2;return _0x2d6e4d[_0x487b4c(_0x529be3._0x22fe6c)]();});var _0x5c4d42=_0x3dd72a===_0x4709e2(_0x3e8153._0xa1fbaf)?'🌟':'💎',_0x4d7682=_0x5c4d42+'\x20'+_0x3dd72a+'\x20|\x20🌍\x20'+_0x528b99+_0x4709e2(_0x3e8153._0x308548)+(_0x4cdc1a||'N/A'),_0x329b68='',_0x56a9ad=![];if(/hdr10\+|hdr10p/i['test'](_0x378a0c))_0x329b68=_0x4709e2(0x136),_0x56a9ad=!![];else{if(/hdr10/i[_0x4709e2(_0x3e8153._0x1b72bb)](_0x378a0c))_0x329b68=_0x4709e2(_0x3e8153._0x4befac),_0x56a9ad=!![];else/hdr(?!ip)/i['test'](_0x378a0c)&&(_0x329b68=_0x4709e2(0x128),_0x56a9ad=!![]);}var _0x3eaeb9=/10bit/i[_0x4709e2(_0x3e8153._0x1b72bb)](_0x378a0c)?_0x4709e2(0x15e):'',_0x545fb3=/(dv|dolby\s*vision|dolbyvision)/i[_0x4709e2(0x129)](_0x378a0c)?'🕵️‍♀️\x20DV':'',_0x51a343=/bluray/i['test'](_0x378a0c),_0x40f45b=_0x4709e2(0x167);if(/(hevc|x265|265|h265)/i[_0x4709e2(0x129)](_0x378a0c))_0x40f45b='HEVC\x20x265';else{if(/(x264|264|h264)/i['test'](_0x378a0c))_0x40f45b='x264';else _0x3dd72a==='2160P'&&(_0x40f45b=_0x4709e2(0x13d));}var _0x236a43=[];if(_0x329b68)_0x236a43[_0x4709e2(_0x3e8153._0x2aaa3e)](_0x329b68);if(_0x3eaeb9)_0x236a43[_0x4709e2(0x158)](_0x3eaeb9);if(_0x51a343)_0x236a43['push']('📀\x20BluRay');if(_0x545fb3)_0x236a43['push'](_0x545fb3);var _0x362c42='';if(_0x236a43[_0x4709e2(_0x3e8153._0x309be3)]>0x0){var _0x96895=_0x56a9ad?'⚡\x20':'';_0x362c42=_0x96895+_0x236a43[_0x4709e2(0x162)](_0x4709e2(0x177))+_0x4709e2(0x16b)+_0x40f45b;}else _0x362c42='🎥\x20'+_0x40f45b;var _0x2d9bd4='🎞️\x20MKV';if(/\bmp4\b/i[_0x4709e2(_0x3e8153._0x1b72bb)](_0x378a0c))_0x2d9bd4=_0x4709e2(_0x3e8153._0x45a91a);var _0x3641e3='AAC\x205.1',_0x3ed155=/atmos/i['test'](_0x378a0c);if(_0x308a7d[_0x4709e2(_0x3e8153._0x36f88e)]('ddp51')!==-0x1||_0x308a7d['indexOf']('eac351')!==-0x1||_0x308a7d['indexOf']('dd51')!==-0x1)_0x3641e3='DDP\x205.1';else{if(_0x308a7d[_0x4709e2(0x13e)]('truehd71')!==-0x1)_0x3641e3=_0x4709e2(_0x3e8153._0x47122f);else{if(_0x308a7d[_0x4709e2(_0x3e8153._0x22944d)]('aac71')!==-0x1)_0x3641e3=_0x4709e2(_0x3e8153._0x497d40);else(_0x308a7d[_0x4709e2(0x13e)](_0x4709e2(0x12e))!==-0x1||_0x308a7d['indexOf'](_0x4709e2(0x151))!==-0x1)&&(_0x3641e3=/aac\s*5\.1/i['test'](_0x378a0c)?'AAC\x205.1':_0x4709e2(0x16e));}}(/ddp\s*5\s*1/i[_0x4709e2(_0x3e8153._0x1b72bb)](_0x378a0c)||/ddp5\.1/i['test'](_0x378a0c))&&(_0x3641e3=_0x4709e2(_0x3e8153._0x3db50f));var _0xf1a207=_0x3ed155?'\x20•\x20🔊\x20Atmos':'',_0xc3d31c=_0x2d9bd4+'\x20|\x20🎧\x20'+_0x3641e3+_0xf1a207+'\x20|',_0xaf9143=_0x4709e2(_0x3e8153._0x4a9d87);if(_0x51a343)_0xaf9143='BluRay';else{if(/hdrip/i[_0x4709e2(_0x3e8153._0x27176c)](_0x378a0c))_0xaf9143='HDRip';else{if(/webrip/i[_0x4709e2(_0x3e8153._0x1b72bb)](_0x378a0c))_0xaf9143='WEB-Rip';else/(webdl|web\-dl|itunes|amzn)/i[_0x4709e2(_0x3e8153._0x350162)](_0x378a0c)&&(_0xaf9143=_0x4709e2(_0x3e8153._0x38b552));}}var _0x12c433='CDN1',_0x3bf275=_0x57f14b['match'](/cdn(\d+)/i);if(_0x3bf275)_0x12c433='CDN'+_0x3bf275[0x1];else _0x57f14b['indexOf']('tga-hd')!==-0x1&&(_0x12c433=_0x4709e2(_0x3e8153._0xa4810d));var _0x42a396=/imax/i['test'](_0x378a0c)?_0x4709e2(0x163):'',_0x3ad39f=_0x4709e2(_0x3e8153._0x1d1a8f)+_0x12c433+'\x20|\x20☁️\x20'+_0xaf9143+_0x42a396,_0x644a15='GramCinema\x20|\x20'+_0x3dd72a+_0x4709e2(_0x3e8153._0x3105b7)+_0x528b99,_0x176aa3='🎬\x20'+_0x170071+(_0x1b557b?'\x20-\x20('+_0x1b557b+')':'')+_0x31079d+'\x0a'+_0x4d7682+'\x0a'+_0x362c42+'\x0a'+_0xc3d31c+'\x0a'+_0x3ad39f;return{'name':_0x644a15,'title':_0x176aa3,'size':_0x176aa3,'url':_0x57f14b[_0x4709e2(0x156)](/ /g,_0x4709e2(0x143)),'behaviorHints':{'notWebReady':!![],'proxyHeaders':{'request':{'Referer':_0x4c8df1||_0x4709e2(0x16d)}}}};}function getStreams(_0x238989,_0x2242d2,_0x251aec,_0x1ed877){var _0x457f02={_0x1eca4f:0x15c},_0x20754b={_0x5cd093:0x173,_0x13f0c7:0x161},_0x2aa917={_0x587582:0x12b,_0x154a3c:0x138},_0x459333={_0x45acde:0x14c},_0x353120=_0x199d;console['log']('[Hashhackers]\x20getStreams:\x20'+_0x238989+'\x20|\x20Type:\x20'+_0x2242d2);if(_0x2242d2!==_0x353120(_0x457f02._0x1eca4f)&&_0x2242d2!=='tv'&&_0x2242d2!=='series')return Promise[_0x353120(0x157)]([]);return getToken()['then'](function(_0x49c4c6){var _0x4bc7b0=_0x353120;if(!_0x49c4c6)return console['error'](_0x4bc7b0(0x155)),[];var _0x4af95b=_0x2242d2==='tv'||_0x2242d2===_0x4bc7b0(_0x20754b._0x5cd093),_0x5def22=String(_0x238989)['indexOf']('tt')===0x0,_0x3aae38=_0x5def22?'https://api.themoviedb.org/3/find/'+_0x238989+'?api_key=d131017ccc6e5462a81c9304d21476de&external_source=imdb_id&language=en-US':'https://api.themoviedb.org/3/'+(_0x4af95b?'tv':'movie')+'/'+_0x238989+'?api_key=d131017ccc6e5462a81c9304d21476de&language=en-US';return fetchJson(_0x3aae38)[_0x4bc7b0(_0x20754b._0x13f0c7)](function(_0x43dba6){var _0x4cacab={_0x3a98ba:0x174,_0x3f5272:0x168,_0x24ee63:0x127},_0x2539d0={_0x3e2fa7:0x146},_0x1f96cd={_0x18e031:0x150},_0x5942fa=_0x4bc7b0,_0x2d04fa;_0x5def22?_0x2d04fa=_0x4af95b?_0x43dba6[_0x5942fa(0x148)]&&_0x43dba6['tv_results'][0x0]:_0x43dba6['movie_results']&&_0x43dba6['movie_results'][0x0]:_0x2d04fa=_0x43dba6;if(!_0x2d04fa)return[];var _0x21dfd6=_0x4af95b?_0x2d04fa[_0x5942fa(0x169)]:_0x2d04fa[_0x5942fa(0x141)],_0x29355f=_0x4af95b?_0x2d04fa['first_air_date']:_0x2d04fa['release_date'],_0x392c10=_0x29355f?_0x29355f[_0x5942fa(0x154)]('-')[0x0]:'',_0x342cb4=_0x21dfd6+'\x20'+_0x392c10;if(_0x4af95b&&_0x251aec!==void 0x0&&_0x1ed877!==void 0x0){var _0x26c796=_0x251aec<0xa?'0'+_0x251aec:''+_0x251aec,_0x2746bf=_0x1ed877<0xa?'0'+_0x1ed877:''+_0x1ed877;_0x342cb4+='\x20S'+_0x26c796+'E'+_0x2746bf;}var _0x2e80ad=encodeURIComponent(_0x342cb4['trim']()),_0x24f8fa={'User-Agent':'Mozilla/5.0\x20(iPhone;\x20CPU\x20iPhone\x20OS\x2018_7\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20Version/26.0.1\x20Mobile/15E148\x20Safari/604.1','Accept':_0x5942fa(0x122),'Authorization':_0x5942fa(_0x459333._0x45acde)+_0x49c4c6,'Origin':'https://bollywood.eu.org','Referer':'https://bollywood.eu.org/'},_0x456e3b=_0x5942fa(0x142)+_0x2e80ad+'&page=1';return fetchJson(_0x456e3b,{'headers':_0x24f8fa})[_0x5942fa(0x161)](function(_0x1dda15){var _0x47836c={_0x373a1a:0x15d},_0x4647f4={_0x12856f:0x15d},_0x388a20={_0x393800:0x141,_0x58aa35:0x15d},_0x465356=_0x5942fa,_0x38af0a=_0x1dda15['files']||[],_0x58562e=_0x38af0a['filter'](function(_0x17a79e){var _0xb7a4d0=_0x199d,_0x3ef857=_0x17a79e[_0xb7a4d0(_0x1f96cd._0x18e031)]['toLowerCase']()['trim']();return/\.(mkv|mp4)$/[_0xb7a4d0(0x129)](_0x3ef857);});if(_0x58562e[_0x465356(0x13f)]===0x0)return[];var _0x4a9dda=_0x58562e[_0x465356(0x172)](0x0,0x6),_0x2bcd51=_0x4a9dda[_0x465356(0x14a)](function(_0x2f4bf1){var _0x2e2c63={_0x4edc12:0x14e},_0x3a1ceb=_0x465356;return fetchJson(_0x3a1ceb(_0x2539d0._0x3e2fa7)+_0x2f4bf1['id'],{'headers':_0x24f8fa})['then'](function(_0x168f49){var _0x2a43e2=_0x3a1ceb;if(_0x168f49['success']&&_0x168f49['url']){var _0x4518d4=formatBytes(parseInt(_0x2f4bf1['file_size']));return makeStream(_0x2f4bf1['file_name'],_0x168f49[_0x2a43e2(_0x2e2c63._0x4edc12)],'https://bollywood.eu.org/',_0x4518d4);}return null;})['catch'](function(){return null;});});return Promise[_0x465356(0x11f)](_0x2bcd51)[_0x465356(0x161)](function(_0x206faa){var _0x2daad1=_0x465356,_0x12d18d=_0x206faa[_0x2daad1(_0x4cacab._0x3a98ba)](function(_0x4f9c86){return _0x4f9c86!==null;});return _0x12d18d['forEach'](function(_0x1d68ed){var _0x50c626=_0x2daad1,_0x51cd84=(_0x1d68ed[_0x50c626(_0x388a20._0x393800)]||'')['toLowerCase']();if(_0x51cd84['indexOf'](_0x50c626(0x153))!==-0x1||_0x51cd84['indexOf']('4k')!==-0x1)_0x1d68ed['_resWeight']=0x4;else{if(_0x51cd84[_0x50c626(0x13e)]('1080p')!==-0x1)_0x1d68ed[_0x50c626(_0x388a20._0x58aa35)]=0x3;else{if(_0x51cd84[_0x50c626(0x13e)]('720p')!==-0x1)_0x1d68ed['_resWeight']=0x2;else _0x1d68ed['_resWeight']=0x1;}}}),_0x12d18d[_0x2daad1(_0x4cacab._0x3f5272)](function(_0x43e32a,_0x32b70a){var _0x38ea33=_0x2daad1;return _0x32b70a['_resWeight']-_0x43e32a[_0x38ea33(_0x4647f4._0x12856f)];}),_0x12d18d[_0x2daad1(_0x4cacab._0x24ee63)](function(_0x8e9bb2){var _0x2f865d=_0x2daad1;delete _0x8e9bb2[_0x2f865d(_0x47836c._0x373a1a)];}),_0x12d18d;});});})['catch'](function(_0x141460){var _0x3a326d=_0x4bc7b0;return console[_0x3a326d(0x175)](_0x3a326d(_0x2aa917._0x587582)+_0x141460[_0x3a326d(_0x2aa917._0x154a3c)]),[];});});}function onSettings(){var _0x5ddc9e={_0xf32243:0x157,_0x5625af:0x140},_0xa0e3b8=_0x199d;return Promise[_0xa0e3b8(_0x5ddc9e._0xf32243)]([{'type':_0xa0e3b8(_0x5ddc9e._0x5625af),'label':'GramCinema\x20Configuration'},{'type':_0xa0e3b8(0x132),'isPassword':!![],'key':_0xa0e3b8(0x14b),'label':'CinemaTV\x20Token','placeholder':'Enter\x20token\x20here...','description':'Provide\x20the\x20authorization\x20token\x20required\x20to\x20access\x20CinemaTV\x20links.'}]);}module[_0x1c6b03(0x176)]={'getStreams':getStreams,'onSettings':onSettings};

/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "gramcinema", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_STREAM_DISPLAY_START */
/* CLOUDBANK_STREAM_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name);
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var release = /\b(WEB[ ._-]?DL|WEB[ ._-]?RIP|BLU[ ._-]?RAY|BD[ ._-]?REMUX|REMUX|DVD[ ._-]?RIP|HD[ ._-]?RIP|HDTV|HDCAM|CAM)\b/i.exec(text);
    var releaseLabel = release ? release[1].toUpperCase().replace(/[ ._]/g, "-") : "";
    if (/^WEB-?DL$/.test(releaseLabel)) releaseLabel = "WEB-DL";
    if (/^WEB-?RIP$/.test(releaseLabel)) releaseLabel = "WEBRip";
    if (/^BLU-?RAY$/.test(releaseLabel)) releaseLabel = "BluRay";
    if (/REMUX/.test(releaseLabel)) releaseLabel = "Remux";
    var codec = /\b(HEVC|H[ ._-]?265|X265|AVC|H[ ._-]?264|X264|AV1)\b/i.exec(text);
    var codecLabel = codec ? (/265|HEVC/i.test(codec[1]) ? "HEVC" : /264|AVC/i.test(codec[1]) ? "H.264" : "AV1") : "";
    var hdr = /\b(DOLBY[ ._-]?VISION|HDR10\+|HDR10|HDR|SDR)(?!\w)/i.exec(text);
    var hdrLabel = hdr ? (/DOLBY/i.test(hdr[1]) ? "Dolby Vision" : hdr[1].toUpperCase()) : "";
    var videoLine = unique([qualityLabel, releaseLabel, codecLabel, hdrLabel]).join(" · ");
    if (videoLine) lines.push(videoLine);
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage))) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var audioCodec = /\b(DOLBY[ ._-]?ATMOS|ATMOS|TRUEHD|DTS[ ._-]?HD[ ._-]?MA|DTS[ ._-]?HD|DTS[ ._-]?X|DTS|E[ ._-]?AC[ ._-]?3|DDP|AC[ ._-]?3|AAC|FLAC|OPUS)\b/i.exec(text);
    var audioCodecLabel = audioCodec ? audioCodec[1].toUpperCase().replace(/[ ._]/g, "-") : "";
    if (/ATMOS/.test(audioCodecLabel)) audioCodecLabel = "Dolby Atmos";
    if (audioCodecLabel === "TRUEHD") audioCodecLabel = "Dolby TrueHD";
    if (/^(E-?AC-?3|DDP)$/.test(audioCodecLabel)) audioCodecLabel = "Dolby Digital Plus";
    if (/^AC-?3$/.test(audioCodecLabel)) audioCodecLabel = "Dolby Digital";
    var channels = /\b(7\.1|6\.1|5\.1|2\.0)\b/.exec(text);
    var audioLine = unique([audioLabel, [audioCodecLabel, channels ? channels[1] : ""].filter(Boolean).join(" ")]).join(" · ");
    if (audioLine) lines.push(audioLine);
    var subs = Array.isArray(stream.subtitles) ? unique(stream.subtitles.map(function(sub) {
      return sub && (language(sub.language) || language(sub.lang) || language(sub.code) || language(sub.id));
    })) : [];
    if (subs.length) lines.push("Subtitles: " + subs.join(", "));
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var size = usable(stream.size || stream.fileSize || (stream.behaviorHints && stream.behaviorHints.videoSize));
    if (!size) { var sm = /\b(\d+(?:\.\d+)?)\s*(GB|MB|TB|GiB|MiB)\b/i.exec(text); if (sm) size = sm[1] + " " + sm[2]; }
    if (/^\d+(?:\.\d+)?$/.test(size)) {
      var bytes = Number(size);
      size = bytes > 0 ? (bytes >= 1073741824 ? (bytes / 1073741824).toFixed(1) + " GB" : (bytes / 1048576).toFixed(1) + " MB") : "";
    } else if (!/^\d+(?:\.\d+)?\s*(?:GB|MB|TB|GiB|MiB)$/i.test(size)) size = "";
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    lines.push(unique([formatLabel, server, size, duration]).join(" · "));
    output.name = "";
    output.title = lines.join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "GramCinema", "gramcinema");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
/* CLOUDBANK_STREAM_DISPLAY_END */
