// HDHub4u Scraper for Nuvio Local Scrapers
// React Native compatible version with full original functionality

const cheerio = require('cheerio-without-node-native');

/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
/* VUEO_PROVIDER_REPAIR_V16 */
/* VUEO_PROVIDER_REPAIR_V17 */
/* VUEO_FAST_DISCOVERY_V1 */
/* VUEO_DISCOVERY_REBUILD_V1 */
function vueoTrace(stage, details) {
  try {
    if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
      globalThis.vueoTrace(stage, details || {});
    }
  } catch (_) {}
}

function vueoContextFromRaw(raw) {
  if (!raw) return null;
  if (typeof raw === "string") {
    try { return JSON.parse(raw); } catch (_) { return null; }
  }
  return typeof raw === "object" ? raw : null;
}

function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}



// TMDB API Configuration
const TMDB_API_KEY = '439c478a771f35c05022f9feabcca01c';
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';

// HDHub4u Configuration
let MAIN_URL = "https://hdhub4u.frl";
const DOMAINS_URL = "https://raw.githubusercontent.com/phisher98/TVVVV/refs/heads/main/domains.json";
const DOMAIN_CACHE_TTL = 4 * 60 * 60 * 1000; // 4 hours
let domainCacheTimestamp = 0;
let domainFetchInFlight = null;

const HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0",
    "Cookie": "xla=s4t",
    "Referer": `${MAIN_URL}/`,
};

// =================================================================================
// UTILITY FUNCTIONS (from Utils.kt)
// =================================================================================

// Format bytes to human readable size
function formatBytes(bytes) {
    if (!bytes || bytes === 0) return 'Unknown';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

// Extract server name from source string
function extractServerName(source) {
    if (!source) return 'Unknown';

    // Handle different source formats
    if (source.startsWith('HubCloud')) {
        // Extract server type (FSL Server, S3 Server, BuzzServer, 10Gbps, etc.)
        const serverMatch = source.match(/HubCloud(?:\s*-\s*([^[\]]+))?/);
        return serverMatch ? (serverMatch[1] || 'Download') : 'HubCloud';
    }

    if (source.startsWith('Pixeldrain')) return 'Pixeldrain';
    if (source.startsWith('StreamTape')) return 'StreamTape';
    if (source.startsWith('HubCdn')) return 'HubCdn';
    if (source.startsWith('HbLinks')) return 'HbLinks';
    if (source.startsWith('Hubstream')) return 'Hubstream';

    // For other sources, clean up the hostname
    return source.replace(/^www\./, '').split('.')[0];
}

/**
 * Applies a ROT13 cipher to a string.
 * Replicates the `pen()` function from Utils.kt.
 * @param {string} value The input string.
 * @returns {string} The ROT13'd string.
 */
function rot13(value) {
    return value.replace(/[a-zA-Z]/g, function (c) {
        return String.fromCharCode((c <= "Z" ? 90 : 122) >= (c = c.charCodeAt(0) + 13) ? c : c - 26);
    });
}

// React Native-safe Base64 polyfill (no Buffer dependency)
const BASE64_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';

function atob(value) {
    if (!value) return '';
    let input = String(value).replace(/=+$/, '');
    let output = '';
    let bc = 0, bs, buffer, idx = 0;
    while ((buffer = input.charAt(idx++))) {
        buffer = BASE64_CHARS.indexOf(buffer);
        if (~buffer) {
            bs = bc % 4 ? bs * 64 + buffer : buffer;
            if (bc++ % 4) {
                output += String.fromCharCode(255 & (bs >> ((-2 * bc) & 6)));
            }
        }
    }
    return output;
}

function btoa(value) {
    if (value == null) return '';
    let str = String(value);
    let output = '';
    let i = 0;
    while (i < str.length) {
        const chr1 = str.charCodeAt(i++);
        const chr2 = str.charCodeAt(i++);
        const chr3 = str.charCodeAt(i++);

        const enc1 = chr1 >> 2;
        const enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
        let enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
        let enc4 = chr3 & 63;

        if (isNaN(chr2)) {
            enc3 = 64;
            enc4 = 64;
        } else if (isNaN(chr3)) {
            enc4 = 64;
        }

        output +=
            BASE64_CHARS.charAt(enc1) +
            BASE64_CHARS.charAt(enc2) +
            BASE64_CHARS.charAt(enc3) +
            BASE64_CHARS.charAt(enc4);
    }
    return output;
}

/**
 * Cleans title by extracting quality and codec information.
 * Replicates the `cleanTitle` function from Utils.kt.
 * @param {string} title The title string to clean.
 * @returns {string} The cleaned title with quality/codec info.
 */
function cleanTitle(title) {
    const parts = title.split(/[.\-_]/);

    const qualityTags = [
        "WEBRip", "WEB-DL", "WEB", "BluRay", "HDRip", "DVDRip", "HDTV",
        "CAM", "TS", "R5", "DVDScr", "BRRip", "BDRip", "DVD", "PDTV", "HD"
    ];

    const audioTags = [
        "AAC", "AC3", "DTS", "MP3", "FLAC", "DD5", "EAC3", "Atmos"
    ];

    const subTags = [
        "ESub", "ESubs", "Subs", "MultiSub", "NoSub", "EnglishSub", "HindiSub"
    ];

    const codecTags = [
        "x264", "x265", "H264", "HEVC", "AVC"
    ];

    const startIndex = parts.findIndex(part =>
        qualityTags.some(tag => part.toLowerCase().includes(tag.toLowerCase()))
    );

    let endIndex = -1;
    for (let e = parts.length - 1; e >= 0; e--) {
        const part = parts[e];
        if (subTags.some(tag => part.toLowerCase().includes(tag.toLowerCase())) ||
            audioTags.some(tag => part.toLowerCase().includes(tag.toLowerCase())) ||
            codecTags.some(tag => part.toLowerCase().includes(tag.toLowerCase()))) { endIndex = e; break; }
    }

    if (startIndex !== -1 && endIndex !== -1 && endIndex >= startIndex) {
        return parts.slice(startIndex, endIndex + 1).join(".");
    } else if (startIndex !== -1) {
        return parts.slice(startIndex).join(".");
    } else {
        return parts.slice(-3).join(".");
    }
}

/**
 * Fetches the latest domain for HDHub4u.
 * Replicates the `getDomains` function from the provider.
 */
function fetchAndUpdateDomain() {
    const now = Date.now();
    if (now - domainCacheTimestamp < DOMAIN_CACHE_TTL) return Promise.resolve();
    if (domainFetchInFlight) return domainFetchInFlight;
    domainFetchInFlight = fetch(DOMAINS_URL, {
        method: 'GET',
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
    }).then(function(response) {
        if (!response.ok) return null;
        return response.json();
    }).then(function(data) {
        if (data && data.HDHUB4u) {
            const newDomain = data.HDHUB4u;
            if (newDomain !== MAIN_URL) {
                MAIN_URL = newDomain;
                HEADERS.Referer = MAIN_URL + '/';
            }
        }
        domainCacheTimestamp = Date.now();
    }).catch(function(error) {
        console.error('[HDHub4u] Failed to fetch latest domains: ' + error.message);
    }).then(function() {
        domainFetchInFlight = null;
    });
    return domainFetchInFlight;
}

/**
 * Gets the current domain, ensuring it's always up to date.
 * Should be called before any main site requests.
 */
function getCurrentDomain() {
    return fetchAndUpdateDomain().then(function() {
        return MAIN_URL;
    });
}

/**
 * Resolves obfuscated redirector links (e.g., hubdrive.fit/?id=...).
 * This is a direct translation of the `getRedirectLinks` function from `Utils.kt`.
 * @param {string} url The obfuscated URL.
 * @returns {Promise<string>} The resolved direct link.
 */
function getRedirectLinks(url) {
    return fetch(url, { headers: HEADERS })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            return response.text();
        })
        .then(doc => {
            const regex = /s\('o','([A-Za-z0-9+/=]+)'|ck\('_wp_http_\d+','([^']+)'/g;
            let combinedString = '';
            let match;
            while ((match = regex.exec(doc)) !== null) {
                const extractedValue = match[1] || match[2];
                if (extractedValue) {
                    combinedString += extractedValue;
                }
            }

            if (!combinedString) {
                console.error("[getRedirectLinks] Could not find encoded strings in page.");
                return url;
            }

            const decodedString = atob(rot13(atob(atob(combinedString))));
            const jsonObject = JSON.parse(decodedString);

            const encodedUrl = atob(jsonObject.o || '').trim();
            if (encodedUrl) {
                return encodedUrl;
            }

            const data = btoa(jsonObject.data || '').trim();
            const wpHttp = (jsonObject.blog_url || '').trim();
            if (wpHttp && data) {
                return fetch(`${wpHttp}?re=${data}`, { headers: HEADERS })
                    .then(directLinkResponse => directLinkResponse.text())
                    .then(text => text.trim());
            }

            return url; // Return original url if logic fails
        })
        .catch(e => {
            console.error(`[getRedirectLinks] Error processing link ${url}:`, e.message);
            return url; // Fallback to original URL
        });
}

// =================================================================================
// EXTRACTORS (from Extractors.kt)
// =================================================================================

/**
 * Extract direct download link from Pixeldrain.
 * Pixeldrain direct link format: https://pixeldrain.com/api/file/{id}?download
 */
function pixelDrainExtractor(link) {
    return Promise.resolve().then(() => {
        let fileId;
        // link can be pixeldrain.com/u/{id} or pixeldrain.dev/... or pixeldrain.xyz/...
        const match = link.match(/(?:file|u)\/([A-Za-z0-9]+)/);
        if (match) {
            fileId = match[1];
        } else {
            fileId = link.split('/').pop();
        }
        if (!fileId) {
            return [{ source: 'Pixeldrain', quality: 'Unknown', url: link }];
        }

        // Fetch file info to get the name, size, and determine quality
        const infoUrl = `https://pixeldrain.com/api/file/${fileId}/info`;
        let fileInfo = { name: '', quality: 'Unknown', size: 0 };

        return fetch(infoUrl, { headers: HEADERS })
            .then(response => response.json())
            .then(info => {
                if (info && info.name) {
                    fileInfo.name = info.name;
                    fileInfo.size = info.size || 0;

                    // Infer quality from filename
                    const qualityMatch = info.name.match(/(\d{3,4})p/);
                    if (qualityMatch) {
                        fileInfo.quality = qualityMatch[0];
                    }
                }
                const directUrl = `https://pixeldrain.com/api/file/${fileId}?download`;
                return [{
                    source: 'Pixeldrain',
                    quality: fileInfo.quality,
                    url: directUrl,
                    name: fileInfo.name,
                    size: fileInfo.size,
                }];
            })
            .catch(e => {
                console.warn(`[Pixeldrain] Could not fetch file info for ${fileId}:`, e.message);
                const directUrl = `https://pixeldrain.com/api/file/${fileId}?download`;
                return [{
                    source: 'Pixeldrain',
                    quality: fileInfo.quality,
                    url: directUrl,
                    name: fileInfo.name,
                    size: fileInfo.size,
                }];
            });
    }).catch(e => {
        console.error('[Pixeldrain] extraction failed', e.message);
        return [{ source: 'Pixeldrain', quality: 'Unknown', url: link }];
    });
}

/**
 * Extract streamable URL from StreamTape.
 * This function normalizes the URL to streamtape.com and tries to find the direct video link.
 */
function streamTapeExtractor(link) {
    // Streamtape has many domains, but .com is usually the most reliable for video pages.
    const url = new URL(link);
    url.hostname = 'streamtape.com';
    const normalizedLink = url.toString();

    return fetch(normalizedLink, { headers: HEADERS })
        .then(res => res.text())
        .then(data => {
            // Regex to find something like: document.getElementById('videolink').innerHTML = ...
            const match = data.match(/document\.getElementById\('videolink'\)\.innerHTML = (.*?);/);

            if (match && match[1]) {
                const scriptContent = match[1];
                // The script might contain a direct URL part or a function call to build it. We look for the direct part.
                const urlPartMatch = scriptContent.match(/'(\/\/streamtape\.com\/get_video[^']+)'/);

                if (urlPartMatch && urlPartMatch[1]) {
                    const videoSrc = 'https:' + urlPartMatch[1];
                    return [{ source: 'StreamTape', quality: 'Stream', url: videoSrc }];
                }
            }

            // A simpler, secondary regex if the above fails (e.g., the script is not complex).
            const simpleMatch = data.match(/'(\/\/streamtape\.com\/get_video[^']+)'/);
            if (simpleMatch && simpleMatch[0]) {
                const videoSrc = 'https:' + simpleMatch[0].slice(1, -1); // remove quotes
                return [{ source: 'StreamTape', quality: 'Stream', url: videoSrc }];
            }

            // If we reach here, the link is likely dead or protected. Return nothing.
            return [];
        })
        .catch(e => {
            // A 404 error just means the link is dead. We can ignore it and return nothing.
            if (!e.response || e.response.status !== 404) {
                console.error(`[StreamTape] An unexpected error occurred for ${normalizedLink}:`, e.message);
            }
            return []; // Return empty array on any failure
        });
}

function hubStreamExtractor(url, referer) {
    return fetch(url, { headers: { ...HEADERS, Referer: referer } })
        .then(response => {
            // For now, return the URL as-is since VidStack extraction is complex
            return [{ source: 'Hubstream', quality: 'Unknown', url }];
        })
        .catch(e => {
            console.error(`[Hubstream] Failed to extract from ${url}:`, e.message);
            return [];
        });
}

function hbLinksExtractor(url, referer) {
    return fetch(url, { headers: { ...HEADERS, Referer: referer } })
        .then(response => response.text())
        .then(data => {
            const $ = cheerio.load(data);
            const links = $('h3 a, div.entry-content p a').map((i, el) => $(el).attr('href')).get();

            const finalLinks = [];
            const promises = links.map(link => loadExtractor(link, url));

            return Promise.all(promises)
                .then(results => {
                    results.forEach(extracted => finalLinks.push(...extracted));
                    return finalLinks;
                });
        });
}

function hubCdnExtractor(url, referer) {
    return fetch(url, { headers: { ...HEADERS, Referer: referer } })
        .then(response => response.text())
        .then(data => {
            const encodedMatch = data.match(/r=([A-Za-z0-9+/=]+)/);
            if (encodedMatch && encodedMatch[1]) {
                const m3u8Data = atob(encodedMatch[1]);
                const m3u8Link = m3u8Data.substring(m3u8Data.lastIndexOf('link=') + 5);
                return [{
                    source: 'HubCdn',
                    quality: 'M3U8',
                    url: m3u8Link,
                }];
            }
            return [];
        })
        .catch(() => []);
}

function hubDriveExtractor(url, referer) {
    return fetch(url, { headers: { ...HEADERS, Referer: referer } })
        .then(response => response.text())
        .then(data => {
            const $ = cheerio.load(data);
            const href = $('.btn.btn-primary.btn-user.btn-success1.m-1').attr('href');
            if (href) {
                return loadExtractor(href, url);
            }
            return [];
        })
        .catch(() => []);
}

function hubCloudExtractor(url, referer) {
    let currentUrl = url;
    // Replicate domain change logic from HubCloud extractor
    if (currentUrl.includes("hubcloud.ink")) {
        currentUrl = currentUrl.replace("hubcloud.ink", "hubcloud.dad");
    }

    return fetch(currentUrl, { headers: { ...HEADERS, Referer: referer } })
        .then(pageResponse => pageResponse.text())
        .then(pageData => {
            let finalUrl = currentUrl;

            if (!currentUrl.includes("hubcloud.php")) {
                const scriptUrlMatch = pageData.match(/var url = '([^']*)'/);
                if (scriptUrlMatch && scriptUrlMatch[1]) {
                    finalUrl = scriptUrlMatch[1];
                    return fetch(finalUrl, { headers: { ...HEADERS, Referer: currentUrl } })
                        .then(secondResponse => secondResponse.text())
                        .then(secondData => ({ pageData: secondData, finalUrl }));
                }
            }
            return { pageData, finalUrl };
        })
        .then(({ pageData, finalUrl }) => {
            const $ = cheerio.load(pageData);
            const size = $('i#size').text().trim();
            const header = $('div.card-header').text().trim();

            // Use the same quality detection logic as Kotlin code
            const getIndexQuality = (str) => {
                const match = (str || '').match(/(\d{3,4})[pP]/);
                return match ? parseInt(match[1]) : 2160; // Default to 4K if not found
            };

            const quality = getIndexQuality(header);
            const headerDetails = cleanTitle(header);

            // Build label extras like in Kotlin code
            const labelExtras = (() => {
                let extras = '';
                if (headerDetails) extras += `[${headerDetails}]`;
                if (size) extras += `[${size}]`;
                return extras;
            })();

            // Convert human-readable size to bytes for consistency
            const sizeInBytes = (() => {
                if (!size) return 0;
                const sizeMatch = size.match(/([\d.]+)\s*(GB|MB|KB)/i);
                if (!sizeMatch) return 0;

                const value = parseFloat(sizeMatch[1]);
                const unit = sizeMatch[2].toUpperCase();

                if (unit === 'GB') return value * 1024 * 1024 * 1024;
                if (unit === 'MB') return value * 1024 * 1024;
                if (unit === 'KB') return value * 1024;
                return 0;
            })();

            const links = [];
            const elements = $('div.card-body h2 a.btn').get();

                // Process each element, converting async operations to promises
            const processElements = elements.map(element => {
                const link = $(element).attr('href');
                const text = $(element).text();
                const sourceName = text.trim();

                // Use the actual file name from the HubCloud page header (full name, not cleaned)
                const fileName = header || headerDetails || 'Unknown';

                if (text.includes("Download File")) {
                    links.push({ source: `HubCloud ${labelExtras}`, quality, url: link, size: sizeInBytes, fileName });
                    return Promise.resolve();
                } else if (text.includes("FSL Server")) {
                    links.push({ source: `HubCloud - FSL Server ${labelExtras}`, quality, url: link, size: sizeInBytes, fileName });
                    return Promise.resolve();
                } else if (text.includes("S3 Server")) {
                    links.push({ source: `HubCloud - S3 Server ${labelExtras}`, quality, url: link, size: sizeInBytes, fileName });
                    return Promise.resolve();
                } else if (text.includes("BuzzServer")) {
                    return fetch(`${link}/download`, {
                        method: 'GET',
                        headers: { ...HEADERS, Referer: link },
                        redirect: 'manual' // Do not follow redirects automatically
                    })
                    .then(buzzResp => {
                        if (buzzResp.status >= 300 && buzzResp.status < 400) {
                            // It's a redirect, get the location header
                            const location = buzzResp.headers.get('location');
                            if (location && location.includes('hx-redirect=')) {
                                const hxRedirectMatch = location.match(/hx-redirect=([^&]+)/);
                                if (hxRedirectMatch) {
                                    const dlink = decodeURIComponent(hxRedirectMatch[1]);
                                    links.push({ source: `HubCloud - BuzzServer ${labelExtras}`, quality, url: dlink, size: sizeInBytes, fileName });
                                }
                            }
                        }
                    })
                    .catch(e => {
                        console.error("[HubCloud] BuzzServer redirect failed for", link, e.message);
                    });
                } else if (link.includes("pixeldra")) {
                    links.push({ source: `Pixeldrain ${labelExtras}`, quality, url: link, size: sizeInBytes, fileName });
                    return Promise.resolve();
                } else if (text.includes("10Gbps")) {
                    let currentRedirectUrl = link;
                    let finalLink = null;

                    const processRedirects = (i) => {
                        if (i >= 5) return Promise.resolve(finalLink);

                        return fetch(currentRedirectUrl, {
                            method: 'GET',
                            redirect: 'manual' // Don't follow redirects automatically
                        })
                            .then(response => {
                                if (response.status >= 300 && response.status < 400) {
                                    const location = response.headers.get('location');
                                    if (location) {
                                        if (location.includes("link=")) {
                                            finalLink = location.substring(location.indexOf("link=") + 5);
                                            return finalLink;
                                        }
                                        currentRedirectUrl = new URL(location, currentRedirectUrl).toString();
                                        return processRedirects(i + 1);
                                    }
                                }
                                return finalLink;
                            })
                            .catch(e => {
                                console.error("[HubCloud] 10Gbps redirect failed for", currentRedirectUrl, e.message);
                                return finalLink;
                            });
                    };

                    return processRedirects(0).then(finalLink => {
                        if (finalLink) {
                            links.push({ source: `HubCloud - 10Gbps ${labelExtras}`, quality, url: finalLink, size: sizeInBytes, fileName });
                        }
                    });
                } else {
                    // For other buttons, try the generic extractor
                    return loadExtractor(link, finalUrl).then(extracted => {
                        links.push(...extracted);
                    });
                }
            });

            return Promise.all(processElements).then(() => links);
        })
        .catch(() => []);
}

/**
 * Main extractor dispatcher. Determines which specific extractor to use based on the URL.
 * Replicates the `loadExtractor` logic flow.
 * @param {string} url The URL of the hoster page.
 * @param {string} referer The referer URL.
 * @returns {Promise<Array<{quality: string, url: string, source: string}>>} A list of final links.
 */
function loadExtractor(url, referer = MAIN_URL) {
    const hostname = new URL(url).hostname;

    // Some links from the main site are redirectors that need to be resolved first.
    if (url.includes("?id=") || hostname.includes('techyboy4u')) {
        return getRedirectLinks(url)
            .then(finalLink => {
                if (!finalLink) {
                    return []; // Stop if redirect fails
                }
                // Recursively call loadExtractor with the new link
                return loadExtractor(finalLink, url);
            });
    }

    if (hostname.includes('hubcloud')) {
        return hubCloudExtractor(url, referer);
    }
    if (hostname.includes('hubdrive')) {
        return hubDriveExtractor(url, referer);
    }
    if (hostname.includes('hubcdn')) {
        return hubCdnExtractor(url, referer);
    }
    if (hostname.includes('hblinks')) {
        return hbLinksExtractor(url, referer);
    }
    if (hostname.includes('hubstream')) {
        return hubStreamExtractor(url, referer);
    }
    if (hostname.includes('pixeldrain')) {
        return pixelDrainExtractor(url);
    }
    if (hostname.includes('streamtape')) {
        return streamTapeExtractor(url);
    }
    if (hostname.includes('hdstream4u')) {
        // This is VidHidePro, often a simple redirect. For this script, we assume it's a direct link.
        return Promise.resolve([{ source: 'HdStream4u', quality: 'Unknown', url }]);
    }

    // Skip unsupported hosts like linkrit.com
    if (hostname.includes('linkrit')) {
        return Promise.resolve([]);
    }

    // Default case for unknown extractors, use the hostname as the source.
    const sourceName = hostname.replace(/^www\./, '');
    return Promise.resolve([{ source: sourceName, quality: 'Unknown', url }]);
}

// =================================================================================
// MAIN PROVIDER LOGIC (from HDhub4uProvider.kt)
// =================================================================================

/**
 * Searches for media on HDHub4u.
 * @param {string} query The search term.
 * @returns {Promise<Array<{title: string, url: string, poster: string}>>} A list of search results.
 */
function search(query) {
    return getCurrentDomain()
        .then(currentDomain => {
            const searchUrl = `${currentDomain}/?s=${encodeURIComponent(query)}`;
            return fetch(searchUrl, { headers: HEADERS });
        })
        .then(response => response.text())
        .then(data => {
            const $ = cheerio.load(data);
            return $('.recent-movies > li.thumb').map((i, el) => {
                const element = $(el);
                const title = element.find('figcaption:nth-child(2) > a:nth-child(1) > p:nth-child(1)').text().trim();

                // Extract year from title (look for 4-digit numbers in parentheses or after title)
                const yearMatch = title.match(/\((\d{4})\)|\b(\d{4})\b/);
                const year = yearMatch ? parseInt(yearMatch[1] || yearMatch[2]) : null;

                return {
                    title: title,
                    url: element.find('figure:nth-child(1) > a:nth-child(2)').attr('href'),
                    poster: element.find('figure:nth-child(1) > img:nth-child(1)').attr('src'),
                    year: year
                };
            }).get();
        });
}

/**
 * Fetches enhanced metadata from Cinemeta API using IMDB ID.
 * Replicates the Cinemeta integration from the Kotlin provider.
 */
function getCinemetaData(imdbId, tvType) {
    if (!imdbId) return Promise.resolve(null);

    const cinemetaUrl = `https://v3-cinemeta.strem.io/meta/${tvType}/${imdbId}.json`;
    return fetch(cinemetaUrl)
        .then(response => response.json())
        .catch(e => {
            console.error(`[Cinemeta] Failed to fetch metadata for ${imdbId}:`, e.message);
            return null;
        });
}

/**
 * Fetches the media page and extracts all hoster links.
 * This combines the logic of `load()` and `loadLinks()` from the Kotlin provider.
 * @param {string} mediaUrl The URL of the movie or TV show page.
 * @returns {Promise<Array<any>>} A list of all final, extracted download links.
 */
function getDownloadLinks(mediaUrl) {
    return getCurrentDomain()
        .then(currentDomain => {
            HEADERS.Referer = `${currentDomain}/`;
            return fetch(mediaUrl, { headers: HEADERS });
        })
        .then(response => response.text())
        .then(data => {
            const $ = cheerio.load(data);

            const typeRaw = $('h1.page-title span').text();
            const isMovie = typeRaw.toLowerCase().includes('movie');

            // Extract title and season number like in Kotlin code
            const title = $('.page-body h2[data-ved="2ahUKEwjL0NrBk4vnAhWlH7cAHRCeAlwQ3B0oATAfegQIFBAM"], h2[data-ved="2ahUKEwiP0pGdlermAhUFYVAKHV8tAmgQ3B0oATAZegQIDhAM"]').text();
            const seasonMatch = title.match(/\bSeason\s*(\d+)\b/i);
            const seasonNumber = seasonMatch ? parseInt(seasonMatch[1]) : null;

            let initialLinks = [];

            if (isMovie) {
                // Replicate the exact Kotlin selector: "h3 a:matches(480|720|1080|2160|4K), h4 a:matches(480|720|1080|2160|4K)"
                // Find anchor tags inside h3/h4 whose text contains quality numbers
                const qualityLinks = $('h3 a, h4 a').filter((i, el) => {
                    const linkText = $(el).text();
                    return linkText.match(/480|720|1080|2160|4K/i);
                });

                initialLinks = qualityLinks.map((i, el) => ({ url: $(el).attr('href') })).get();

                // Remove duplicates and invalid URLs
                const seen = new Set();
                initialLinks = initialLinks.filter(link => {
                    if (!link.url || seen.has(link.url)) {
                        return false;
                    }
                    seen.add(link.url);
                    return true;
                });

                console.log(`Found ${initialLinks.length} initial hoster links. Now extracting...`);

                // Process all links in parallel
                const promises = initialLinks.map(linkInfo =>
                    loadExtractor(linkInfo.url, mediaUrl)
                        .then(extractedLinks => extractedLinks)
                        .catch(e => {
                            console.error(`Failed to extract from ${linkInfo.url}:`, e.message);
                            return [];
                        })
                );

                return Promise.all(promises)
                    .then(results => {
                        const allFinalLinks = [];
                        results.forEach(res => allFinalLinks.push(...res));

                        // Remove exact duplicate URLs and zip files
                        const seenUrls = new Set();
                        const uniqueFinalLinks = allFinalLinks.filter(link => {
                            // Filter out zip files
                            if (link.url && (link.url.includes('.zip') || (link.name && link.name.toLowerCase().includes('.zip')))) {
                                return false;
                            }
                            // Filter out duplicates
                            if (seenUrls.has(link.url)) {
                                return false;
                            }
                            seenUrls.add(link.url);
                            return true;
                        });

                        return { finalLinks: uniqueFinalLinks, isMovie };
                    });
            } else { // TV Series
                const episodeLinksMap = new Map();

                // First, look for quality-specific redirect links (like 1080p techyboy4u.com links)
                $('h3 a, h4 a').each((i, element) => {
                    const $el = $(element);
                    const text = $el.text();
                    const href = $el.attr('href');

                    // Check if this is a quality link (1080p, 720p, etc.) that might lead to episode links
                    if (text.match(/1080|720|4K|2160/i) && href && href.includes('techyboy4u.com')) {
                        // This is likely a redirect to a page with episode links
                        initialLinks.push({ url: href, isQualityRedirect: true });
                    }
                });

                // Then, try to find episode links in h4 elements (common structure)
                $('h4').each((i, element) => {
                    const $el = $(element);
                    const text = $el.text();
                    // Match both "EPiSODE 1" and "E01" formats
                    const episodeMatch = text.match(/(?:EPiSODE\s*(\d+)|E(\d+))/i);

                    if (episodeMatch) {
                        const epNum = parseInt(episodeMatch[1] || episodeMatch[2]);
                        if (!episodeLinksMap.has(epNum)) episodeLinksMap.set(epNum, []);

                        // Get all links from this h4 element
                        const links = $el.find('a').map((i, a) => $(a).attr('href')).get();
                        episodeLinksMap.get(epNum).push(...links);
                    }
                });

                // If no episodes found in h4, try the original logic with h3/h4
                if (episodeLinksMap.size === 0) {
                    const processElementsPromises = $('h3, h4').get().map(element => {
                        const $el = $(element);
                        const title = $el.text();
                        // Match both "EPiSODE 1" and "E01" formats
                        const episodeMatch = title.match(/(?:EPiSODE\s*(\d+)|E(\d+))/i);
                        const epNum = episodeMatch ? parseInt(episodeMatch[1] || episodeMatch[2]) : null;

                        const isDirectLinkBlock = $el.find('a').text().match(/1080|720|4K|2160/i);

                        if (isDirectLinkBlock) {
                            const redirectLinks = $el.find('a').map((i, a) => $(a).attr('href')).get();
                            return Promise.all(redirectLinks.map(redirectLink =>
                                getRedirectLinks(redirectLink)
                                    .then(resolvedUrl =>
                                        fetch(resolvedUrl, { headers: HEADERS })
                                            .then(episodeDocPage => episodeDocPage.text())
                                            .then(episodeDocData => {
                                                const $$ = cheerio.load(episodeDocData);
                                                $$('h5 a').each((i, linkEl) => {
                                                    const linkText = $$(linkEl).text();
                                                    const linkHref = $$(linkEl).attr('href');
                                                    const innerEpMatch = linkText.match(/Episode\s*(\d+)/i);
                                                    if (innerEpMatch && linkHref) {
                                                        const innerEpNum = parseInt(innerEpMatch[1]);
                                                        if (!episodeLinksMap.has(innerEpNum)) episodeLinksMap.set(innerEpNum, []);
                                                        episodeLinksMap.get(innerEpNum).push(linkHref);
                                                    }
                                                });
                                            })
                                    )
                                    .catch(e => {
                                        console.error(`Error resolving direct link block: ${redirectLink}`, e.message);
                                    })
                            ));
                        } else if (epNum) {
                            if (!episodeLinksMap.has(epNum)) episodeLinksMap.set(epNum, []);

                            // Get links from current h3/h4
                            const baseLinks = $el.find('a').map((i, a) => $(a).attr('href')).get();
                            episodeLinksMap.get(epNum).push(...baseLinks);

                            // Get links from sibling elements until the next <hr>
                            let nextElement = $el.next();
                            while (nextElement.length && nextElement.get(0).tagName !== 'hr' && nextElement.get(0).tagName !== 'h3' && nextElement.get(0).tagName !== 'h4') {
                                const siblingLinks = nextElement.find('a').map((i, a) => $(a).attr('href')).get();
                                episodeLinksMap.get(epNum).push(...siblingLinks);
                                nextElement = nextElement.next();
                            }
                            return Promise.resolve();
                        } else {
                            return Promise.resolve();
                        }
                    });

                    return Promise.all(processElementsPromises)
                        .then(() => {
                            // Continue with the rest of the TV series logic
                            episodeLinksMap.forEach((links, epNum) => {
                                // Flatten and unique links per episode
                                const uniqueLinks = [...new Set(links)];
                                initialLinks.push(...uniqueLinks.map(link => ({ url: link, episode: epNum })));
                            });

                            console.log(`Found ${initialLinks.length} initial hoster links. Now extracting...`);

                            // Process all links in parallel
                            const promises = initialLinks.map(linkInfo => {
                                if (linkInfo.isQualityRedirect) {
                                    // Handle quality redirect links (like techyboy4u.com)
                                    return getRedirectLinks(linkInfo.url)
                                        .then(resolvedUrl =>
                                            fetch(resolvedUrl, { headers: HEADERS })
                                                .then(episodeDocPage => episodeDocPage.text())
                                                .then(episodeDocData => {
                                                    const $$ = cheerio.load(episodeDocData);

                                                    // Extract episode links from h5 elements
                                                    const episodeLinks = [];
                                                    $$('h5 a').each((i, linkEl) => {
                                                        const linkText = $$(linkEl).text();
                                                        const linkHref = $$(linkEl).attr('href');
                                                        const episodeMatch = linkText.match(/Episode\s*(\d+)/i);
                                                        if (episodeMatch && linkHref) {
                                                            const epNum = parseInt(episodeMatch[1]);
                                                            episodeLinks.push({ url: linkHref, episode: epNum });
                                                        }
                                                    });

                                                    // Also look for h3 links (pack downloads, etc.) but exclude zip files
                                                    $$('h3 a').each((i, linkEl) => {
                                                        const linkHref = $$(linkEl).attr('href');
                                                        const linkText = $$(linkEl).text();
                                                        if (linkHref && !linkHref.includes('magnet:') && !linkHref.includes('.zip') && !linkText.toLowerCase().includes('pack')) {
                                                            episodeLinks.push({ url: linkHref, episode: null }); // Individual downloads only
                                                        }
                                                    });

                                                    // Process each episode link
                                                    const episodePromises = episodeLinks.map(epLink =>
                                                        loadExtractor(epLink.url, resolvedUrl)
                                                            .then(extractedLinks => extractedLinks.map(finalLink => ({ ...finalLink, episode: epLink.episode })))
                                                            .catch(e => {
                                                                console.error(`Failed to extract episode link ${epLink.url}:`, e.message);
                                                                return [];
                                                            })
                                                    );

                                                    return Promise.all(episodePromises)
                                                        .then(episodeResults => episodeResults.flat());
                                                })
                                        );
                                } else {
                                    // Handle regular links
                                    return loadExtractor(linkInfo.url, mediaUrl)
                                        .then(extractedLinks => extractedLinks.map(finalLink => ({ ...finalLink, episode: linkInfo.episode })))
                                        .catch(e => {
                                            console.error(`Failed to extract from ${linkInfo.url}:`, e.message);
                                            return [];
                                        });
                                }
                            });

                            return Promise.all(promises)
                                .then(results => {
                                    const allFinalLinks = [];
                                    results.forEach(res => allFinalLinks.push(...res));

                                    // Remove exact duplicate URLs and zip files
                                    const seenUrls = new Set();
                                    const uniqueFinalLinks = allFinalLinks.filter(link => {
                                        // Filter out zip files
                                        if (link.url && (link.url.includes('.zip') || (link.name && link.name.toLowerCase().includes('.zip')))) {
                                            return false;
                                        }
                                        // Filter out duplicates
                                        if (seenUrls.has(link.url)) {
                                            return false;
                                        }
                                        seenUrls.add(link.url);
                                        return true;
                                    });

                                    return { finalLinks: uniqueFinalLinks, isMovie };
                                });
                        });
                } else {
                    // Episodes found in h4, continue normally
                    episodeLinksMap.forEach((links, epNum) => {
                        // Flatten and unique links per episode
                        const uniqueLinks = [...new Set(links)];
                        initialLinks.push(...uniqueLinks.map(link => ({ url: link, episode: epNum })));
                    });

                    console.log(`Found ${initialLinks.length} initial hoster links. Now extracting...`);

                    // Process all links in parallel
                    const promises = initialLinks.map(linkInfo => {
                        if (linkInfo.isQualityRedirect) {
                            // Handle quality redirect links (like techyboy4u.com)
                            return getRedirectLinks(linkInfo.url)
                                .then(resolvedUrl =>
                                    fetch(resolvedUrl, { headers: HEADERS })
                                        .then(episodeDocPage => episodeDocPage.text())
                                        .then(episodeDocData => {
                                            const $$ = cheerio.load(episodeDocData);

                                            // Extract episode links from h5 elements
                                            const episodeLinks = [];
                                            $$('h5 a').each((i, linkEl) => {
                                                const linkText = $$(linkEl).text();
                                                const linkHref = $$(linkEl).attr('href');
                                                const episodeMatch = linkText.match(/Episode\s*(\d+)/i);
                                                if (episodeMatch && linkHref) {
                                                    const epNum = parseInt(episodeMatch[1]);
                                                    episodeLinks.push({ url: linkHref, episode: epNum });
                                                }
                                            });

                                            // Also look for h3 links (pack downloads, etc.) but exclude zip files
                                            $$('h3 a').each((i, linkEl) => {
                                                const linkHref = $$(linkEl).attr('href');
                                                const linkText = $$(linkEl).text();
                                                if (linkHref && !linkHref.includes('magnet:') && !linkHref.includes('.zip') && !linkText.toLowerCase().includes('pack')) {
                                                    episodeLinks.push({ url: linkHref, episode: null }); // Individual downloads only
                                                }
                                            });

                                            // Process each episode link
                                            const episodePromises = episodeLinks.map(epLink =>
                                                loadExtractor(epLink.url, resolvedUrl)
                                                    .then(extractedLinks => extractedLinks.map(finalLink => ({ ...finalLink, episode: epLink.episode })))
                                                    .catch(e => {
                                                        console.error(`Failed to extract episode link ${epLink.url}:`, e.message);
                                                        return [];
                                                    })
                                            );

                                            return Promise.all(episodePromises)
                                                .then(episodeResults => episodeResults.flat());
                                        })
                                );
                        } else {
                            // Handle regular links
                            return loadExtractor(linkInfo.url, mediaUrl)
                                .then(extractedLinks => extractedLinks.map(finalLink => ({ ...finalLink, episode: linkInfo.episode })))
                                .catch(e => {
                                    console.error(`Failed to extract from ${linkInfo.url}:`, e.message);
                                    return [];
                                });
                        }
                    });

                    return Promise.all(promises)
                        .then(results => {
                            const allFinalLinks = [];
                            results.forEach(res => allFinalLinks.push(...res));

                            // Remove exact duplicate URLs and zip files
                            const seenUrls = new Set();
                            const uniqueFinalLinks = allFinalLinks.filter(link => {
                                // Filter out zip files
                                if (link.url && (link.url.includes('.zip') || (link.name && link.name.toLowerCase().includes('.zip')))) {
                                    return false;
                                }
                                // Filter out duplicates
                                if (seenUrls.has(link.url)) {
                                    return false;
                                }
                                seenUrls.add(link.url);
                                return true;
                            });

                            return { finalLinks: uniqueFinalLinks, isMovie };
                        });
                }
            }
        });
}

/**
 * Get movie/TV show details from TMDB
 * @param {string} tmdbId TMDB ID
 * @param {string} mediaType "movie" or "tv"
 * @returns {Promise<Object>} Media details
 */
function getTMDBDetails(tmdbId, mediaType) {
    const endpoint = mediaType === 'movie' ? 'movie' : 'tv';
    const url = TMDB_BASE_URL + '/' + endpoint + '/' + tmdbId + '?api_key=' + TMDB_API_KEY + '&append_to_response=alternative_titles,translations,external_ids';
    return vueoSharedTmdb(url, function() {
        return fetch(url).then(function(response) { return response.json(); });
    }).then(function(data) {
        const title = mediaType === 'movie' ? data.title : data.name;
        const releaseDate = mediaType === 'movie' ? data.release_date : data.first_air_date;
        const year = releaseDate ? parseInt(releaseDate.split('-')[0]) : null;
        return {
            title: title,
            year: year,
            imdbId: data.external_ids && data.external_ids.imdb_id ? data.external_ids.imdb_id : null,
            aliases: collectTmdbAliases(data, mediaType)
        };
    });
}

/**
 * Improved title matching utilities
 */

/**
 * Normalizes a title for better matching
 * @param {string} title The title to normalize
 * @returns {string} Normalized title
 */
function normalizeTitle(title) {
    if (!title) return '';

    return title
        // Convert to lowercase
        .toLowerCase()
        // Remove common articles
        .replace(/\b(the|a|an)\b/g, '')
        // Normalize punctuation and spaces
        .replace(/[:\-_]/g, ' ')
        .replace(/\s+/g, ' ')
        // Remove special characters but keep alphanumeric and spaces
        .replace(/[^\w\s]/g, '')
        .trim();
}


/* VUEO_TITLE_PROFILE_V1 */
function collectTmdbAliases(data, mediaType) {
  var output = [];
  var seen = Object.create(null);

  function add(value, priority) {
    var text = String(value || "").trim();
    var key = normalizeTitle(text);
    if (!text || !key || seen[key]) return;
    seen[key] = true;
    output.push({ title: text, priority: Number(priority || 0) });
  }

  add(data && (data.title || data.name), 100);
  add(data && (data.original_title || data.original_name), 95);

  var altRoot = data && data.alternative_titles;
  var altItems = altRoot && Array.isArray(altRoot.titles)
    ? altRoot.titles
    : altRoot && Array.isArray(altRoot.results)
      ? altRoot.results
      : [];

  altItems.forEach(function(item) {
    if (!item) return;
    var country = String(item.iso_3166_1 || "").toUpperCase();
    var priority = country === "US" || country === "GB"
      ? 86
      : country === "MY" || country === "ID"
        ? 82
        : 72;
    add(item.title || item.name, priority);
  });

  var translations = data && data.translations && Array.isArray(data.translations.translations)
    ? data.translations.translations
    : [];

  translations.forEach(function(item) {
    var row = item && item.data && typeof item.data === "object" ? item.data : {};
    var lang = String(item && item.iso_639_1 || "").toLowerCase();
    var priority = lang === "en" ? 88 : (lang === "ms" || lang === "id" ? 80 : 68);
    add(row.title || row.name, priority);
  });

  output.sort(function(a, b) { return b.priority - a.priority; });
  return output.map(function(item) { return item.title; }).slice(0, 12);
}

/**
 * Calculates similarity score between two titles
 * @param {string} title1 First title
 * @param {string} title2 Second title
 * @returns {number} Similarity score (0-1)
 */
function calculateTitleSimilarity(title1, title2) {
    const norm1 = normalizeTitle(title1);
    const norm2 = normalizeTitle(title2);

    // Exact match after normalization
    if (norm1 === norm2) return 1.0;

    // Substring matches
    if (norm1.includes(norm2) || norm2.includes(norm1)) return 0.9;

    // Word-based similarity
    const words1 = new Set(norm1.split(/\s+/).filter(w => w.length > 2));
    const words2 = new Set(norm2.split(/\s+/).filter(w => w.length > 2));

    if (words1.size === 0 || words2.size === 0) return 0;

    const intersection = new Set([...words1].filter(w => words2.has(w)));
    const union = new Set([...words1, ...words2]);

    return intersection.size / union.size;
}

/**
 * Finds the best title match from search results
 * @param {Object} mediaInfo TMDB media info
 * @param {Array} searchResults Search results array
 * @param {string} mediaType "movie" or "tv"
 * @param {number} season Season number for TV shows
 * @returns {Object|null} Best matching result
 */
function cleanDiscoveryTitleHD(value) {
    return normalizeTitle(
        String(value || '')
            .replace(/\[(?:[^\]]{0,140})\]/g, ' ')
            .replace(/\b(?:19|20)\d{2}\b/g, ' ')
            .replace(/\bseason\s*\d{1,2}\b/gi, ' ')
            .replace(/\bs\d{1,2}\b/gi, ' ')
            .replace(/\b(?:2160p|1080p|720p|480p|4k|web[- ]?dl|webrip|bluray|hevc|h26[45]|10bit|dual audio|full movie|full series|all episodes)\b/gi, ' ')
    );
}

function bestAliasSimilarityHD(mediaInfo, candidateTitle) {
    var aliases = mediaInfo && Array.isArray(mediaInfo.aliases) && mediaInfo.aliases.length
        ? mediaInfo.aliases
        : [mediaInfo && mediaInfo.title, mediaInfo && mediaInfo.originalTitle];
    var best = 0;
    var cleanCandidate = cleanDiscoveryTitleHD(candidateTitle);
    aliases.forEach(function(alias) {
        var cleanAlias = cleanDiscoveryTitleHD(alias);
        best = Math.max(best, calculateTitleSimilarity(candidateTitle, alias));
        if (cleanCandidate && cleanAlias) {
            if (cleanCandidate === cleanAlias) best = Math.max(best, 1);
            else if (cleanCandidate.indexOf(cleanAlias) !== -1 || cleanAlias.indexOf(cleanCandidate) !== -1) best = Math.max(best, 0.92);
            else best = Math.max(best, calculateTitleSimilarity(cleanCandidate, cleanAlias));
        }
    });
    return best;
}

function buildDiscoveryQueriesHD(mediaInfo, mediaType, season) {
    var output = [];
    var seen = Object.create(null);
    var aliases = mediaInfo && Array.isArray(mediaInfo.aliases) && mediaInfo.aliases.length
        ? mediaInfo.aliases
        : [mediaInfo && mediaInfo.title, mediaInfo && mediaInfo.originalTitle];

    function add(value) {
        var text = String(value || '').trim();
        var key = normalizeTitle(text);
        if (!text || !key || seen[key]) return;
        seen[key] = true;
        output.push(text);
    }

    aliases.slice(0, 6).forEach(function(alias) {
        add(alias);
        if (mediaType === 'tv' && season) add(alias + ' season ' + season);
        if (mediaInfo && mediaInfo.year) add(alias + ' ' + mediaInfo.year);
    });

    return output.slice(0, 8);
}

function findBestTitleMatch(mediaInfo, searchResults, mediaType, season) {
    if (!searchResults || searchResults.length === 0) return null;
    var bestMatch = null;
    var bestScore = -999;

    searchResults.forEach(function(result) {
        var score = bestAliasSimilarityHD(mediaInfo, result.title) * 100;
        if (mediaInfo.year && result.year) {
            var diff = Math.abs(Number(mediaInfo.year) - Number(result.year));
            if (diff === 0) score += 24;
            else if (diff <= 1) score += 8;
            else if (diff > 4) score -= 32;
        }
        if (mediaType === 'tv' && season) {
            var raw = String(result.title || '');
            var seasonMatch = raw.match(/\bseason\s*(\d{1,2})\b/i) || raw.match(/\bs(\d{1,2})\b/i);
            if (seasonMatch) {
                if (Number(seasonMatch[1]) === Number(season)) score += 28;
                else score -= 100;
            }
        }
        if (score > bestScore) {
            bestScore = score;
            bestMatch = result;
        }
    });

    if (!bestMatch || bestScore < 55) return null;
    vueoTrace('CANDIDATE', { count: searchResults.length, title: bestMatch.title || '', score: Math.round(bestScore) });
    return bestMatch;
}

function searchDiscoveryHD(mediaInfo, mediaType, season) {
    var queries = buildDiscoveryQueriesHD(mediaInfo, mediaType, season);
    function run(index) {
        if (index >= queries.length) return Promise.resolve(null);
        return search(queries[index]).then(function(results) {
            var best = findBestTitleMatch(mediaInfo, results || [], mediaType, season);
            return best || run(index + 1);
        }).catch(function() { return run(index + 1); });
    }
    return run(0);
}

/**
 * Main function for Nuvio integration
 * @param {string} tmdbId TMDB ID
 * @param {string} mediaType "movie" or "tv"
 * @param {number} season Season number (TV only)
 * @param {number} episode Episode number (TV only)
 * @returns {Promise<Array>} Array of stream objects
 */
function slugifyHDHub(value) {
    return String(value || '')
        .toLowerCase()
        .replace(/&/g, ' and ')
        .replace(/[’'`]/g, '')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
        .replace(/-+/g, '-');
}

function pageTitleHDHub(html) {
    const $ = cheerio.load(String(html || ''));
    return ($('h1.page-title').first().text() || $('h1').first().text() || $('meta[property="og:title"]').attr('content') || '').trim();
}

function tryDirectHDHubPage(mediaInfo, mediaType, season) {
    return getCurrentDomain().then(function(domain) {
        const aliases = mediaInfo && Array.isArray(mediaInfo.aliases) && mediaInfo.aliases.length ? mediaInfo.aliases : [mediaInfo.title];
        const year = mediaInfo.year ? String(mediaInfo.year) : '';
        let paths = [];
        aliases.slice(0, 3).forEach(function(alias) {
            const slug = slugifyHDHub(alias);
            if (!slug) return;
            if (mediaType === 'movie') {
                if (year) {
                    paths.push(
                        '/' + slug + '-' + year + '-webrip-hindi-full-movie/',
                        '/' + slug + '-' + year + '-hindi-webrip-full-movie/',
                        '/' + slug + '-' + year + '-english-webrip-full-movie/',
                        '/' + slug + '-' + year + '-webrip-full-movie/'
                    );
                }
            } else if (season) {
                paths.push(
                    '/' + slug + '-season-' + season + '-hindi-webrip-all-episodes/',
                    '/' + slug + '-season-' + season + '-webrip-hindi-full-series/',
                    '/' + slug + '-season-' + season + '-webrip-all-episodes/'
                );
            }
        });
        function probe(index) {
            if (index >= paths.length) return Promise.resolve(null);
            const url = domain.replace(/\/+$/, '') + paths[index];
            return fetch(url, { headers: HEADERS }).then(function(response) {
                if (!response.ok) return null;
                return response.text().then(function(html) {
                    if (!html || html.length < 2000 || /page not found|404 not found/i.test(html)) return null;
                    const title = pageTitleHDHub(html);
                    const score = calculateTitleSimilarity(mediaInfo.title, title) + (year && title.indexOf(year) !== -1 ? 0.4 : 0);
                    if (score < 0.55) return null;
                    vueoTrace('DIRECT_MATCH', { title: title, url: url, score: Math.round(score * 100) });
                    return { title: title, url: url, year: mediaInfo.year };
                });
            }).catch(function() { return null; }).then(function(hit) {
                return hit || probe(index + 1);
            });
        }
        return probe(0);
    });
}

function getStreams(tmdbId, mediaType = 'movie', season = null, episode = null) {
    console.log(`[HDHub4u] Fetching streams for TMDB ID: ${tmdbId}, Type: ${mediaType}${mediaType === 'tv' ? `, S:${season}E:${episode}` : ''}`);

    // First, get movie/TV show details from TMDB
    return getTMDBDetails(tmdbId, mediaType).then(function(mediaInfo) {
        if (!mediaInfo.title) {
            throw new Error('Could not extract title from TMDB response');
        }

        console.log(`[HDHub4u] TMDB Info: "${mediaInfo.title}" (${mediaInfo.year || 'N/A'})`);

        console.log(`[HDHub4u] Discovery title: "${mediaInfo.title}"`);

        return tryDirectHDHubPage(mediaInfo, mediaType, season).then(function(directHit) {
            if (directHit) return directHit;
            return searchDiscoveryHD(mediaInfo, mediaType, season);
        }).then(function(selectedMedia) {
            if (!selectedMedia) {
                console.log('[HDHub4u] No confident match found');
                return [];
            }
            console.log(`[HDHub4u] Selected: "${selectedMedia.title}" (${selectedMedia.url})`);

            return getDownloadLinks(selectedMedia.url).then(function(result) {
                const { finalLinks, isMovie } = result;

                // Filter by episode if specified for TV shows
                let filteredLinks = finalLinks;
                if (mediaType === 'tv' && episode !== null) {
                    filteredLinks = finalLinks.filter(function(link) {
                        return link.episode === episode;
                    });
                    console.log(`[HDHub4u] Filtered to ${filteredLinks.length} links for episode ${episode}`);
                }

                // Convert to Nuvio format, filtering out unknown quality links
                const streams = filteredLinks
                    .filter(function(link) {
                        // Skip links with unknown quality - these are usually just redirects
                        if (typeof link.quality !== 'number' || link.quality === 0) {
                            return false;
                        }
                        return true;
                    })
                    .map(function(link) {
                        // Use the actual file name from HubCloud page if available, otherwise fallback to TMDB title
                        let mediaTitle = link.fileName && link.fileName !== 'Unknown' ? link.fileName : mediaInfo.title;
                        if (mediaType === 'tv' && season && episode && link.episode && !link.fileName) {
                            mediaTitle = `${mediaInfo.title} S${String(season).padStart(2, '0')}E${String(link.episode).padStart(2, '0')}`;
                        } else if (mediaType === 'tv' && season && episode && !link.fileName) {
                            mediaTitle = `${mediaInfo.title} S${String(season).padStart(2, '0')}E${String(episode).padStart(2, '0')}`;
                        } else if (mediaInfo.year && !link.fileName) {
                            mediaTitle = `${mediaInfo.title} (${mediaInfo.year})`;
                        }

                        // Format size and extract server name
                        const formattedSize = formatBytes(link.size);
                        const serverName = extractServerName(link.source);

                        // Create quality string
                        let qualityStr = 'Unknown';
                        if (typeof link.quality === 'number') {
                            if (link.quality >= 2160) qualityStr = '4K';
                            else if (link.quality >= 1440) qualityStr = '1440p';
                            else if (link.quality >= 1080) qualityStr = '1080p';
                            else if (link.quality >= 720) qualityStr = '720p';
                            else if (link.quality >= 480) qualityStr = '480p';
                            else if (link.quality >= 360) qualityStr = '360p';
                            else qualityStr = '240p';
                        }

                        return {
                            name: `HDHub4u ${serverName}`,
                            title: mediaTitle,
                            url: link.url,
                            quality: qualityStr,
                            size: formattedSize,
                            headers: HEADERS,
                            provider: 'hdhub4u'
                        };
                    });

                // Sort by quality
                const qualityOrder = { '4K': 4, '2160p': 4, '1440p': 3, '1080p': 2, '720p': 1, '480p': 0, '360p': -1, 'Unknown': -2 };
                streams.sort(function(a, b) {
                    return (qualityOrder[b.quality] || -3) - (qualityOrder[a.quality] || -3);
                });

                console.log(`[HDHub4u] Found ${streams.length} streams`);
                return streams;
            });
        });
    }).catch(function(error) {
        console.error(`[HDHub4u] Scraping error: ${error.message}`);
        return [];
    });
}

// Export the main function
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { getStreams };
} else {
    // For React Native environment
    global.HDHub4uScraperModule = { getStreams };
}

/* CLOUDBANK_STREAM_DISPLAY_START */
/* CLOUDBANK_STREAM_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name);
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var release = /\b(WEB[ ._-]?DL|WEB[ ._-]?RIP|BLU[ ._-]?RAY|BD[ ._-]?REMUX|REMUX|DVD[ ._-]?RIP|HD[ ._-]?RIP|HDTV|HDCAM|CAM)\b/i.exec(text);
    var releaseLabel = release ? release[1].toUpperCase().replace(/[ ._]/g, "-") : "";
    if (/^WEB-?DL$/.test(releaseLabel)) releaseLabel = "WEB-DL";
    if (/^WEB-?RIP$/.test(releaseLabel)) releaseLabel = "WEBRip";
    if (/^BLU-?RAY$/.test(releaseLabel)) releaseLabel = "BluRay";
    if (/REMUX/.test(releaseLabel)) releaseLabel = "Remux";
    var codec = /\b(HEVC|H[ ._-]?265|X265|AVC|H[ ._-]?264|X264|AV1)\b/i.exec(text);
    var codecLabel = codec ? (/265|HEVC/i.test(codec[1]) ? "HEVC" : /264|AVC/i.test(codec[1]) ? "H.264" : "AV1") : "";
    var hdr = /\b(DOLBY[ ._-]?VISION|HDR10\+|HDR10|HDR|SDR)(?!\w)/i.exec(text);
    var hdrLabel = hdr ? (/DOLBY/i.test(hdr[1]) ? "Dolby Vision" : hdr[1].toUpperCase()) : "";
    var videoLine = unique([qualityLabel, releaseLabel, codecLabel, hdrLabel]).join(" · ");
    if (videoLine) lines.push(videoLine);
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage))) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var audioCodec = /\b(DOLBY[ ._-]?ATMOS|ATMOS|TRUEHD|DTS[ ._-]?HD[ ._-]?MA|DTS[ ._-]?HD|DTS[ ._-]?X|DTS|E[ ._-]?AC[ ._-]?3|DDP|AC[ ._-]?3|AAC|FLAC|OPUS)\b/i.exec(text);
    var audioCodecLabel = audioCodec ? audioCodec[1].toUpperCase().replace(/[ ._]/g, "-") : "";
    if (/ATMOS/.test(audioCodecLabel)) audioCodecLabel = "Dolby Atmos";
    if (audioCodecLabel === "TRUEHD") audioCodecLabel = "Dolby TrueHD";
    if (/^(E-?AC-?3|DDP)$/.test(audioCodecLabel)) audioCodecLabel = "Dolby Digital Plus";
    if (/^AC-?3$/.test(audioCodecLabel)) audioCodecLabel = "Dolby Digital";
    var channels = /\b(7\.1|6\.1|5\.1|2\.0)\b/.exec(text);
    var audioLine = unique([audioLabel, [audioCodecLabel, channels ? channels[1] : ""].filter(Boolean).join(" ")]).join(" · ");
    if (audioLine) lines.push(audioLine);
    var subs = Array.isArray(stream.subtitles) ? unique(stream.subtitles.map(function(sub) {
      return sub && (language(sub.language) || language(sub.lang) || language(sub.code) || language(sub.id));
    })) : [];
    if (subs.length) lines.push("Subtitles: " + subs.join(", "));
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var size = usable(stream.size || stream.fileSize || (stream.behaviorHints && stream.behaviorHints.videoSize));
    if (!size) { var sm = /\b(\d+(?:\.\d+)?)\s*(GB|MB|TB|GiB|MiB)\b/i.exec(text); if (sm) size = sm[1] + " " + sm[2]; }
    if (/^\d+(?:\.\d+)?$/.test(size)) {
      var bytes = Number(size);
      size = bytes > 0 ? (bytes >= 1073741824 ? (bytes / 1073741824).toFixed(1) + " GB" : (bytes / 1048576).toFixed(1) + " MB") : "";
    } else if (!/^\d+(?:\.\d+)?\s*(?:GB|MB|TB|GiB|MiB)$/i.test(size)) size = "";
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    lines.push(unique([formatLabel, server, size, duration]).join(" · "));
    output.name = "";
    output.title = lines.join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "HDHub4u", "hdhub4u");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
/* CLOUDBANK_STREAM_DISPLAY_END */
