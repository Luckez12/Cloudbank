// Imported provider: movieblast; upstream commit 3f09a6ff4360498895e622877af7a32212f75038
/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  function trace(stage, details) {
    try {
      if (typeof globalThis !== "undefined" && typeof globalThis.vueoTrace === "function") {
        globalThis.vueoTrace(stage, details);
      }
    } catch (_) {}
  }
  function normalize(raw) {
    if (typeof raw === "string") {
      try { raw = JSON.parse(raw); } catch (_) { return null; }
    }
    if (!raw || typeof raw !== "object" || raw.error) return null;
    var tmdb = raw.tmdb;
    if (!tmdb || typeof tmdb !== "object") {
      if (!raw.title || (raw.mediaType !== "movie" && raw.mediaType !== "tv")) return null;
      var alternatives = Array.isArray(raw.aliases) ? raw.aliases.map(function(alias) {
        return { title: String(alias), iso_3166_1: "" };
      }) : [];
      tmdb = {
        id: raw.tmdbId,
        title: raw.mediaType === "movie" ? raw.title : undefined,
        name: raw.mediaType === "tv" ? raw.title : undefined,
        original_title: raw.mediaType === "movie" ? (raw.originalTitle || raw.title) : undefined,
        original_name: raw.mediaType === "tv" ? (raw.originalTitle || raw.title) : undefined,
        release_date: raw.mediaType === "movie" && raw.year ? String(raw.year) + "-01-01" : "",
        first_air_date: raw.mediaType === "tv" && raw.year ? String(raw.year) + "-01-01" : "",
        external_ids: { imdb_id: raw.imdbId || "" },
        alternative_titles: { titles: alternatives, results: alternatives }
      };
    }
    if (!tmdb.title && !tmdb.name) return null;
    trace("METADATA", { shared: true, title: raw.title || tmdb.title || tmdb.name || "",
      year: raw.year || "", imdbId: raw.imdbId || "",
      aliases: Array.isArray(raw.aliases) ? raw.aliases.length : 0 });
    return tmdb;
  }
  function local() {
    trace("METADATA_FALLBACK", { shared: false });
    return Promise.resolve().then(fallback);
  }
  try {
    if (typeof globalThis !== "undefined") {
      var direct = normalize(globalThis.VUEO_DISCOVERY_CONTEXT);
      if (direct) return Promise.resolve(direct);
      if (typeof globalThis.vueoDiscoveryContext === "function") {
        return Promise.resolve().then(function() {
          return globalThis.vueoDiscoveryContext(url);
        }).then(function(raw) {
          var shared = normalize(raw);
          return shared || local();
        }, local);
      }
    }
  } catch (_) {}
  return local();
}


/* VUEO_TITLE_PROFILE_V1 */
function buildTitleProfile(tmdb) {
  var primary = String(tmdb.title || tmdb.name || "").trim();
  var aliases = [];
  function add(value) {
    value = String(value || "").trim();
    if (value && aliases.indexOf(value) === -1) aliases.push(value);
  }
  add(primary);
  add(tmdb.original_title || tmdb.original_name);
  var alternate = tmdb.alternative_titles || {};
  (alternate.titles || alternate.results || []).forEach(function(item) { add(item.title); });
  return { title: primary, aliases: aliases };
}


/* CLOUDBANK_NUVIO_ADAPTER_V1 */
function cloudbankWrapProvider(provider, providerId, supportedTypes) {
  var upstream = provider.getStreams;
  var adapted = {};
  Object.keys(provider).forEach(function(key) { adapted[key] = provider[key]; });
  adapted.getStreams = function(tmdbId, mediaType, season, episode) {
    var args = Array.prototype.slice.call(arguments);
    var type = mediaType === "series" ? "tv" : mediaType;
    if (supportedTypes.indexOf(type) === -1 || !String(tmdbId || "").trim()) return Promise.resolve([]);
    if (type === "tv" && (!Number.isInteger(Number(season)) || Number(season) < 0 ||
        !Number.isInteger(Number(episode)) || Number(episode) < 1)) return Promise.resolve([]);
    args[0] = String(tmdbId);
    args[1] = type;
    if (type === "tv") { args[2] = Number(season); args[3] = Number(episode); }
    return new Promise(function(resolve) {
      var finished = false;
      var timer = setTimeout(function() { finish([]); }, 19000);
      function finish(value) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        var seen = Object.create(null);
        var streams = Array.isArray(value) ? value.filter(function(stream) {
          if (!stream || typeof stream.url !== "string" || !/^(https?:\/\/|magnet:)/i.test(stream.url)) return false;
          // Preserve separate audio/server entries sharing the same media URL.
          var key = JSON.stringify([stream.url, stream.name, stream.headers, stream.subtitles]);
          if (seen[key]) return false;
          seen[key] = true;
          return true;
        }) : [];
        resolve(streams);
      }
      Promise.resolve().then(function() { return upstream.apply(provider, args); }).then(finish, function() { finish([]); });
    });
  };
  return adapted;
}

function cloudbankMetadataFetch(nativeFetch) {
  return function(url, options) {
    var text = typeof url === "string" ? url : url && url.url;
    var match = typeof text === "string" && /^https:\/\/api\.themoviedb\.org\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(text);
    var method = options && options.method ? String(options.method).toUpperCase() : "GET";
    if (!match || method !== "GET") return nativeFetch(url, options);
    // Shared metadata covers details only; search/find/season/episode requests stay upstream.
    var response;
    return vueoSharedTmdb(text, function() {
      return nativeFetch(url, options).then(function(value) {
        response = value;
        if (!value.ok) throw new Error("TMDB HTTP " + value.status);
        return value.json();
      });
    }).then(function(tmdb) {
      var profile = buildTitleProfile(tmdb);
      if (!profile.title) throw new Error("TMDB title unavailable");
      var body = JSON.stringify(tmdb);
      return {
        ok: true, status: 200, statusText: "OK", url: text,
        headers: response ? response.headers : { get: function(name) {
          return String(name).toLowerCase() === "content-type" ? "application/json" : null;
        } },
        json: function() { return Promise.resolve(JSON.parse(body)); },
        text: function() { return Promise.resolve(body); }
      };
    });
  };
}

(function() {
  var originalModule = { exports: {} };
  var originalRequire = typeof require === "function" ? require : null;
  function portableRequire(name) {
    if (name !== "crypto-js" && name !== "cheerio-without-node-native") throw new Error("Unsupported embedded module: " + name);
    if (!originalRequire) throw new Error("Runtime module unavailable: " + name);
    return originalRequire(name);
  }
  (function(module, exports, require, fetch, self) {
/* CLOUDBANK_UPSTREAM_SOURCE_START */
const _0x5096f5=_0x2a84;(function(_0x3941bf,_0x591604){const _0x341f0e=_0x2a84,_0x1cbafa=_0x3941bf();while(!![]){try{const _0x33c0bd=parseInt(_0x341f0e(0x20a))/0x1+parseInt(_0x341f0e(0x21f))/0x2*(parseInt(_0x341f0e(0x211))/0x3)+parseInt(_0x341f0e(0x20b))/0x4+-parseInt(_0x341f0e(0x1c8))/0x5*(parseInt(_0x341f0e(0x1cb))/0x6)+-parseInt(_0x341f0e(0x1d4))/0x7+-parseInt(_0x341f0e(0x1ea))/0x8+parseInt(_0x341f0e(0x22c))/0x9;if(_0x33c0bd===_0x591604)break;else _0x1cbafa['push'](_0x1cbafa['shift']());}catch(_0x1c907d){_0x1cbafa['push'](_0x1cbafa['shift']());}}}(_0x50a4,0x70e4a));var __create=Object[_0x5096f5(0x222)],__defProp=Object['defineProperty'],__defProps=Object[_0x5096f5(0x1c5)],__getOwnPropDesc=Object[_0x5096f5(0x20f)],__getOwnPropDescs=Object[_0x5096f5(0x1d6)],__getOwnPropNames=Object[_0x5096f5(0x206)],__getOwnPropSymbols=Object[_0x5096f5(0x1ca)],__getProtoOf=Object['getPrototypeOf'],__hasOwnProp=Object[_0x5096f5(0x1ef)][_0x5096f5(0x1ee)],__propIsEnum=Object[_0x5096f5(0x1ef)][_0x5096f5(0x1c1)],__defNormalProp=(_0x2f6bc6,_0x4b6353,_0x140ba5)=>_0x4b6353 in _0x2f6bc6?__defProp(_0x2f6bc6,_0x4b6353,{'enumerable':!![],'configurable':!![],'writable':!![],'value':_0x140ba5}):_0x2f6bc6[_0x4b6353]=_0x140ba5,__spreadValues=(_0xe116ae,_0x31f087)=>{const _0x485ac7=_0x5096f5;for(var _0x26c768 in _0x31f087||(_0x31f087={}))if(__hasOwnProp[_0x485ac7(0x1fa)](_0x31f087,_0x26c768))__defNormalProp(_0xe116ae,_0x26c768,_0x31f087[_0x26c768]);if(__getOwnPropSymbols)for(var _0x26c768 of __getOwnPropSymbols(_0x31f087)){if(__propIsEnum[_0x485ac7(0x1fa)](_0x31f087,_0x26c768))__defNormalProp(_0xe116ae,_0x26c768,_0x31f087[_0x26c768]);}return _0xe116ae;},__spreadProps=(_0x29229e,_0xafc651)=>__defProps(_0x29229e,__getOwnPropDescs(_0xafc651)),__copyProps=(_0x4e4855,_0x172aab,_0x3f2bd2,_0x5a288a)=>{const _0x1d640a=_0x5096f5;if(_0x172aab&&typeof _0x172aab===_0x1d640a(0x1e3)||typeof _0x172aab===_0x1d640a(0x201)){for(let _0x2d4dd8 of __getOwnPropNames(_0x172aab))if(!__hasOwnProp[_0x1d640a(0x1fa)](_0x4e4855,_0x2d4dd8)&&_0x2d4dd8!==_0x3f2bd2)__defProp(_0x4e4855,_0x2d4dd8,{'get':()=>_0x172aab[_0x2d4dd8],'enumerable':!(_0x5a288a=__getOwnPropDesc(_0x172aab,_0x2d4dd8))||_0x5a288a[_0x1d640a(0x1f4)]});}return _0x4e4855;},__toESM=(_0x47c598,_0x5847fa,_0x25675a)=>(_0x25675a=_0x47c598!=null?__create(__getProtoOf(_0x47c598)):{},__copyProps(_0x5847fa||!_0x47c598||!_0x47c598[_0x5096f5(0x1df)]?__defProp(_0x25675a,_0x5096f5(0x22a),{'value':_0x47c598,'enumerable':!![]}):_0x25675a,_0x47c598)),__async=(_0x9f583a,_0x2a2a09,_0x5a70eb)=>{return new Promise((_0x2adea4,_0x4691ab)=>{const _0x5cc2bc=_0x2a84;var _0x469cf7=_0x3d6f15=>{const _0x13ac69=_0x2a84;try{_0x5c2342(_0x5a70eb[_0x13ac69(0x1e1)](_0x3d6f15));}catch(_0x5c07f6){_0x4691ab(_0x5c07f6);}},_0x51c245=_0x3ddc9b=>{const _0x271587=_0x2a84;try{_0x5c2342(_0x5a70eb[_0x271587(0x20e)](_0x3ddc9b));}catch(_0x5f2a47){_0x4691ab(_0x5f2a47);}},_0x5c2342=_0x3704b8=>_0x3704b8[_0x5cc2bc(0x1ff)]?_0x2adea4(_0x3704b8[_0x5cc2bc(0x212)]):Promise[_0x5cc2bc(0x21d)](_0x3704b8['value'])['then'](_0x469cf7,_0x51c245);_0x5c2342((_0x5a70eb=_0x5a70eb[_0x5cc2bc(0x228)](_0x9f583a,_0x2a2a09))[_0x5cc2bc(0x1e1)]());});},BASE_URL='https://app.cloud-mb.xyz',TOKEN=_0x5096f5(0x207),APP_ID='com.movieblast',HEADERS={'user-agent':'okhttp/5.0.0-alpha.6','x-request-x':APP_ID},SEARCH_HEADERS=__spreadProps(__spreadValues({},HEADERS),{'hash256':'86dc03244adddb3cbedbf0ae36074a736ee293a64774b18e82a6244eafd0df30','packagename':APP_ID}),SIGN_SECRET=_0x5096f5(0x20d),TMDB_API_KEY=_0x5096f5(0x1d2),TMDB_BASE_URL=_0x5096f5(0x1f0),import_crypto_js=__toESM(require('crypto-js'));function generateSignedUrl(_0x5e4203){const _0x273036=_0x5096f5;try{const _0x56b7f6=new URL(_0x5e4203),_0x1ee493=_0x56b7f6['pathname'],_0x596117=Math[_0x273036(0x1e0)](Date[_0x273036(0x1f8)]()/0x3e8)[_0x273036(0x1d1)](),_0x28999f=import_crypto_js[_0x273036(0x22a)][_0x273036(0x1fb)](_0x1ee493+_0x596117,SIGN_SECRET),_0x5b06cf=import_crypto_js[_0x273036(0x22a)][_0x273036(0x22b)][_0x273036(0x227)][_0x273036(0x1e8)](_0x28999f),_0x99067d=encodeURIComponent(_0x5b06cf);return _0x5e4203+_0x273036(0x1eb)+_0x596117+'-'+_0x99067d;}catch(_0x313287){return console[_0x273036(0x226)](_0x273036(0x21a),_0x313287[_0x273036(0x1dc)]),_0x5e4203;}}function matchQuality(_0x256200){const _0x43bb8e=_0x5096f5;if(!_0x256200)return _0x43bb8e(0x1e6);const _0x3e071e=_0x256200[_0x43bb8e(0x1c9)]();if(_0x3e071e[_0x43bb8e(0x21c)](_0x43bb8e(0x210))||_0x3e071e[_0x43bb8e(0x21c)]('4k'))return'4K';if(_0x3e071e[_0x43bb8e(0x21c)](_0x43bb8e(0x1ed)))return'2K';if(_0x3e071e[_0x43bb8e(0x21c)]('1080'))return _0x43bb8e(0x1cf);if(_0x3e071e['includes'](_0x43bb8e(0x202)))return _0x43bb8e(0x1fd);if(_0x3e071e[_0x43bb8e(0x21c)](_0x43bb8e(0x1d3)))return _0x43bb8e(0x1d8);if(_0x3e071e['includes'](_0x43bb8e(0x1ce)))return _0x43bb8e(0x221);return _0x43bb8e(0x1e6);}function normalizeTitle(_0x22fd67){const _0x8372c6=_0x5096f5;if(!_0x22fd67)return'';return _0x22fd67[_0x8372c6(0x1c9)]()[_0x8372c6(0x1cd)](/\b(the|a|an)\b/g,'')[_0x8372c6(0x1cd)](/[:\-_]/g,'\x20')[_0x8372c6(0x1cd)](/\s+/g,'\x20')[_0x8372c6(0x1cd)](/[^\w\s]/g,'')[_0x8372c6(0x1f5)]();}function getTMDBDetails(_0x3b02bc,_0x53718d){return __async(this,null,function*(){const _0x4303de=_0x2a84,_0xea0646=_0x53718d==='tv'?'tv':_0x4303de(0x214),_0x217bdb=TMDB_BASE_URL+'/'+_0xea0646+'/'+_0x3b02bc+'?api_key='+TMDB_API_KEY,_0x5e2dd7=yield fetch(_0x217bdb,{'method':_0x4303de(0x1d9),'headers':{'Accept':_0x4303de(0x1e9),'User-Agent':_0x4303de(0x219)}});if(!_0x5e2dd7['ok'])throw new Error(_0x4303de(0x1d0)+_0x5e2dd7[_0x4303de(0x1e7)]);const _0x4fcce7=yield _0x5e2dd7[_0x4303de(0x229)](),_0x53021f=_0x53718d==='tv'?_0x4fcce7['name']:_0x4fcce7[_0x4303de(0x213)],_0x3329ed=_0x53718d==='tv'?_0x4fcce7[_0x4303de(0x1f6)]:_0x4fcce7[_0x4303de(0x1fe)],_0x2bc970=_0x3329ed?parseInt(_0x3329ed[_0x4303de(0x1dd)]('-')[0x0]):null;return{'title':_0x53021f,'year':_0x2bc970};});}function calculateTitleSimilarity(_0x59be19,_0x5f4f0f){const _0xca79e1=_0x5096f5,_0x19f894=normalizeTitle(_0x59be19),_0x323850=normalizeTitle(_0x5f4f0f);if(_0x19f894===_0x323850)return 0x1;const _0x3c43cf=_0x19f894['split'](/\s+/)['filter'](_0x1c0bec=>_0x1c0bec[_0xca79e1(0x220)]>0x0),_0x1e0c83=_0x323850[_0xca79e1(0x1dd)](/\s+/)[_0xca79e1(0x223)](_0x419b2e=>_0x419b2e[_0xca79e1(0x220)]>0x0);if(_0x3c43cf['length']===0x0||_0x1e0c83['length']===0x0)return 0x0;const _0x572156=new Set(_0x3c43cf),_0x4cee15=new Set(_0x1e0c83),_0x31e7cf=_0x3c43cf[_0xca79e1(0x223)](_0xdf7475=>_0x4cee15['has'](_0xdf7475)),_0x79f074=new Set([..._0x3c43cf,..._0x1e0c83]);return _0x31e7cf[_0xca79e1(0x220)]/_0x79f074[_0xca79e1(0x1fc)];}function _0x50a4(){const _0x35cd59=['ChjVDg90ExbL','Ahr0Chm6lY9HCgKUDgHLBw92AwvKyI5VCMCVmW','BMfTzq','C2vHC29UCW','zxbPC29Kzv9UDw1Izxi','zw51BwvYywjSzq','DhjPBq','zMLYC3rFywLYx2rHDgu','ig5VDcbMB3vUzc4','BM93','zxbPC29Kzxm','y2fSBa','sg1Hy1niqti1nG','C2L6zq','nZiWCa','CMvSzwfZzv9KyxrL','zg9Uzq','C2vHCMnO','zNvUy3rPB24','nZiW','tw92AwvcBgfZDcaTia','w01VDMLLqMXHC3rDie1HDgnOiezVDw5KoIaI','ig5VDcbMB3vUzcbPBIbtzwfZB24G','z2v0t3DUuhjVCgvYDhLoyw1LCW','AMr2AgHQDJi1nxzNAgHNAgrODMzJAdi1nJu2ntzQAgrJz2HMzgy','iIaO','lcbuExbLoIa','mJy3mdiXs3v5ANPY','mJqZmJe4ogrvCeP4Bq','C2vYDMvY','r0O4CMv5zgfYstDkCwf0oxj2yKfks05rowDznerVrvfgmKG1BMz1stfNAq','DgHYB3C','z2v0t3DUuhjVCgvYDhLezxnJCMLWDg9Y','mJe2ma','nNLAt1nAsa','DMfSDwu','DgL0Bgu','Bw92Awu','iIaOsuq6ia','w01VDMLLqMXHC3rDie5VihzPzgvVigXPBMTZigzVDw5KigLUigrLDgfPBhmU','w01VDMLLqMXHC3rDifn1y2nLC3nMDwXSEsbMB3vUzca','DhLWzq','tw96AwXSys81lJa','w01VDMLLqMXHC3rDievYCM9YigDLBMvYyxrPBMCGC2LNBMvKifvstdO','w01VDMLLqMXHC3rDievWAxnVzguG','Aw5JBhvKzxm','CMvZB2X2zq','DMLKzw9Z','odGYmJuWq05yy1Hm','BgvUz3rO','mZyWCa','y3jLyxrL','zMLSDgvY','w01VDMLLqMXHC3rDifnLyxjJAgLUzYbMB3i6ici','w01VDMLLqMXHC3rDifnLyxjJAcbMywLSzwqGD2L0AcbZDgf0Dxm6ia','zxjYB3i','qMfZzty0','yxbWBhK','ANnVBG','zgvMyxvSDa','zw5J','mtG0nta5mfvIr3rKra','Ahr0Ca','ChjVCgvYDhLjC0vUDw1LCMfIBgu','BwfW','BgfUzW','ihn0CMvHBxmU','zgvMAw5LuhjVCgvYDgLLCW','zMLUza','w01VDMLLqMXHC3rDie5VignVBMzPzgvUDcbTyxrJAgvZigzVDw5KigLUie1VDMLLqMXHC3qU','ntvVBwnTC0C','Dg9mB3DLCKnHC2u','z2v0t3DUuhjVCgvYDhLtEw1IB2XZ','mta4nJC4tLfUr29f','EwvHCG','CMvWBgfJzq','mZyW','mta4mha','ve1eqIbbueKGzxjYB3i6ia','Dg9tDhjPBMC','ndm5yZq3oge3nZfMmZvJmduWmJjMowzLywjJy2eWmwm','ndGW','nteXndK3mfrRv0ruBG','tw92AwvcBgfZDa','z2v0t3DUuhjVCgvYDhLezxnJCMLWDg9YCW','w01VDMLLqMXHC3rDifnLyxnVBIa','ndGWCa','r0vu','C3rHCNrZv2L0Aa','w01VDMLLqMXHC3rDievYCM9YoIa','BwvZC2fNzq','C3bSAxq','Bg9N','x19LC01VzhvSzq','zMXVB3i','BMv4Da','Ahr0Chm6lY8','B2jQzwn0','l2fWAs9ZzwfYy2GV','BgLUAW','vw5RBM93BG','C3rHDhvZ','C3rYAw5NAwz5','yxbWBgLJyxrPB24VANnVBG','ndu1otCYmfj0qwPArW','p3zLCMLMEt0','w01VDMLLqMXHC3rDiezLDgnOAw5Nihn0CMvHBxmGzM9YifrnreiGsuq6ia','mtq0ma','AgfZt3DUuhjVCgvYDhK'];_0x50a4=function(){return _0x35cd59;};return _0x50a4();}function findBestMatch(_0x59dc1f,_0x1fc4dd){const _0x3a7f51=_0x5096f5;if(!_0x1fc4dd||_0x1fc4dd['length']===0x0)return null;let _0xc01b04=null,_0x677343=0x0;for(const _0x25db1d of _0x1fc4dd){let _0x508b5a=calculateTitleSimilarity(_0x59dc1f['title'],_0x25db1d[_0x3a7f51(0x1f1)]);if(_0x59dc1f[_0x3a7f51(0x1cc)]&&_0x25db1d['release_date']){const _0x42406b=parseInt(_0x25db1d[_0x3a7f51(0x1fe)][_0x3a7f51(0x1dd)]('-')[0x0]);if(_0x59dc1f[_0x3a7f51(0x1cc)]===_0x42406b)_0x508b5a+=0.2;}_0x508b5a>_0x677343&&_0x508b5a>0.4&&(_0x677343=_0x508b5a,_0xc01b04=_0x25db1d);}return _0xc01b04;}function _0x2a84(_0x18fa05,_0x4104fd){_0x18fa05=_0x18fa05-0x1c0;const _0x50a433=_0x50a4();let _0x2a84c4=_0x50a433[_0x18fa05];if(_0x2a84['pRCjqs']===undefined){var _0xb8bc4b=function(_0x343e0a){const _0x2f0cd4='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0x2f6bc6='',_0x4b6353='';for(let _0x140ba5=0x0,_0xe116ae,_0x31f087,_0x26c768=0x0;_0x31f087=_0x343e0a['charAt'](_0x26c768++);~_0x31f087&&(_0xe116ae=_0x140ba5%0x4?_0xe116ae*0x40+_0x31f087:_0x31f087,_0x140ba5++%0x4)?_0x2f6bc6+=String['fromCharCode'](0xff&_0xe116ae>>(-0x2*_0x140ba5&0x6)):0x0){_0x31f087=_0x2f0cd4['indexOf'](_0x31f087);}for(let _0x29229e=0x0,_0xafc651=_0x2f6bc6['length'];_0x29229e<_0xafc651;_0x29229e++){_0x4b6353+='%'+('00'+_0x2f6bc6['charCodeAt'](_0x29229e)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x4b6353);};_0x2a84['McjafT']=_0xb8bc4b,_0x2a84['nugyjY']={},_0x2a84['pRCjqs']=!![];}const _0x2a2db4=_0x50a433[0x0],_0x42811e=_0x18fa05+_0x2a2db4,_0xce7362=_0x2a84['nugyjY'][_0x42811e];return!_0xce7362?(_0x2a84c4=_0x2a84['McjafT'](_0x2a84c4),_0x2a84['nugyjY'][_0x42811e]=_0x2a84c4):_0x2a84c4=_0xce7362,_0x2a84c4;}function getStreams(_0xe0c8bd,_0xb5223a=_0x5096f5(0x214),_0x674976=null,_0xc1b764=null){return __async(this,null,function*(){const _0x17a8bb=_0x2a84;console[_0x17a8bb(0x1de)](_0x17a8bb(0x1ec)+_0xe0c8bd+_0x17a8bb(0x209)+_0xb5223a);try{const _0x221f1d=yield getTMDBDetails(_0xe0c8bd,_0xb5223a);console[_0x17a8bb(0x1de)](_0x17a8bb(0x224)+_0x221f1d[_0x17a8bb(0x213)]+_0x17a8bb(0x208)+_0x221f1d[_0x17a8bb(0x1cc)]+')');const _0x2a3c18=encodeURIComponent(_0x221f1d[_0x17a8bb(0x213)]),_0xacc299=BASE_URL+_0x17a8bb(0x1e4)+_0x2a3c18+'/'+TOKEN,_0x12ae95=yield fetch(_0xacc299,{'headers':SEARCH_HEADERS});if(!_0x12ae95['ok'])return console['error'](_0x17a8bb(0x225)+_0x12ae95[_0x17a8bb(0x1e7)]),[];const _0x1c34fb=yield _0x12ae95[_0x17a8bb(0x229)](),_0x52d56d=_0x1c34fb[_0x17a8bb(0x200)]||[],_0x31ba54=findBestMatch(_0x221f1d,_0x52d56d);if(!_0x31ba54)return console[_0x17a8bb(0x1de)](_0x17a8bb(0x1c7)),[];const _0x46aff4=_0x31ba54['id'],_0x258a41=_0x31ba54[_0x17a8bb(0x218)][_0x17a8bb(0x1c9)]()[_0x17a8bb(0x21c)]('serie')||_0xb5223a==='tv';console['log'](_0x17a8bb(0x204)+_0x31ba54[_0x17a8bb(0x1f1)]+_0x17a8bb(0x215)+_0x46aff4+')');const _0x3110f7=_0x258a41?'series/show':'media/detail',_0x1daa73=BASE_URL+'/api/'+_0x3110f7+'/'+_0x46aff4+'/'+TOKEN,_0xe0ae2e=yield fetch(_0x1daa73,{'headers':HEADERS});if(!_0xe0ae2e['ok'])return console[_0x17a8bb(0x226)]('[MovieBlast]\x20Detail\x20fetch\x20failed:\x20'+_0xe0ae2e[_0x17a8bb(0x1e7)]),[];const _0x12af3f=yield _0xe0ae2e['json']();let _0x3b8ffb=[];if(_0x258a41){const _0x75890d=_0x12af3f[_0x17a8bb(0x1f2)]||[],_0x4d1f9e=_0x75890d['find'](_0x34150d=>_0x34150d['season_number']==_0x674976);if(_0x4d1f9e){const _0x1a67f7=(_0x4d1f9e[_0x17a8bb(0x1f9)]||[])[_0x17a8bb(0x1c6)](_0x3f7514=>_0x3f7514[_0x17a8bb(0x1f3)]==_0xc1b764);_0x1a67f7?_0x3b8ffb=_0x1a67f7[_0x17a8bb(0x21e)]||[]:console['log'](_0x17a8bb(0x21b)+_0xc1b764+_0x17a8bb(0x205)+_0x674976+'.');}else console['log'](_0x17a8bb(0x1d7)+_0x674976+_0x17a8bb(0x1f7));}else _0x3b8ffb=_0x12af3f[_0x17a8bb(0x21e)]||[];if(_0x3b8ffb['length']===0x0)return console[_0x17a8bb(0x1de)](_0x17a8bb(0x216)),[];const _0x4aa62b=_0x3b8ffb[_0x17a8bb(0x1c2)](_0x553e51=>{const _0x2c50e4=_0x17a8bb,_0x3884ed=_0x553e51[_0x2c50e4(0x1e5)];if(!_0x3884ed)return null;const _0x4ae398=_0x3884ed[_0x2c50e4(0x1da)](_0x2c50e4(0x1c0))?_0x3884ed:_0x2c50e4(0x1e2)+_0x3884ed,_0x57c144=generateSignedUrl(_0x4ae398);return{'name':_0x2c50e4(0x1d5),'title':_0x2c50e4(0x203)+_0x553e51[_0x2c50e4(0x20c)]+'\x20('+(_0x553e51[_0x2c50e4(0x1c3)]||'EN')+')','url':_0x57c144,'quality':matchQuality(_0x553e51[_0x2c50e4(0x20c)]),'headers':{'User-Agent':'MovieBlast','Referer':_0x2c50e4(0x1d5),'x-request-x':'com.movieblast'},'provider':'movieblast'};})['filter'](_0x29d247=>_0x29d247!==null);return console['log'](_0x17a8bb(0x217)+_0x4aa62b[_0x17a8bb(0x220)]+_0x17a8bb(0x1c4)),_0x4aa62b;}catch(_0x2f009b){return console[_0x17a8bb(0x226)](_0x17a8bb(0x1db)+_0x2f009b[_0x17a8bb(0x1dc)]),[];}});}module['exports']={'getStreams':getStreams};
/* CLOUDBANK_UPSTREAM_SOURCE_END */
  })(originalModule, originalModule.exports, portableRequire, cloudbankMetadataFetch(fetch), typeof globalThis !== "undefined" ? globalThis : global);
  if (typeof originalModule.exports.getStreams !== "function") throw new Error("Upstream getStreams missing");
  module.exports = cloudbankWrapProvider(originalModule.exports, "movieblast", ["movie", "tv"]);
  if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
  if (typeof global !== "undefined") global.getStreams = module.exports.getStreams;
  if (typeof self !== "undefined") self.getStreams = module.exports.getStreams;
})();

/* CLOUDBANK_STREAM_DISPLAY_START */
/* CLOUDBANK_STREAM_DISPLAY_V1
 * Embedded in each provider: the app downloads standalone JavaScript files.
 * Presentation only. No network requests and no changes to playback fields.
 */
function cloudbankDisplayInstall(provider, providerName, providerId) {
  var details = Object.create(null);
  var keys = [];
  function remember(key, value) {
    if (!details[key]) keys.push(key);
    details[key] = value;
    while (keys.length > 16) delete details[keys.shift()];
  }
  if (typeof vueoSharedTmdb === "function") {
    var shared = vueoSharedTmdb;
    vueoSharedTmdb = function(url, fallback) {
      var match = /\/3\/(movie|tv)\/(\d+)(?:\?|$)/.exec(String(url));
      return Promise.resolve(shared(url, fallback)).then(function(value) {
        if (match && value && typeof value === "object") remember(match[1] + "/" + match[2], value);
        return value;
      });
    };
  }
  function clean(value) {
    if (typeof value !== "string" && typeof value !== "number") return "";
    return String(value).replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/[\uD83C-\uD83E][\uDC00-\uDFFF]|[\u2600-\u27BF\uFE0F\u200D]/g, "").replace(/\s+/g, " ").trim();
  }
  function usable(value) {
    var text = clean(value);
    return /^(?:unknown(?: title)?|n\/?a|none|null|undefined|auto|stream|original[- ]audio)$/i.test(text) ? "" : text;
  }
  function unique(list) {
    return list.filter(function(value, index) { return value && list.indexOf(value) === index; });
  }
  var languages = { en: "English", eng: "English", english: "English", ms: "Malay", msa: "Malay", may: "Malay", malay: "Malay", id: "Indonesian", ind: "Indonesian", indo: "Indonesian", indonesian: "Indonesian", hi: "Hindi", hin: "Hindi", hindi: "Hindi", ta: "Tamil", tam: "Tamil", tamil: "Tamil", te: "Telugu", tel: "Telugu", telugu: "Telugu", ja: "Japanese", jpn: "Japanese", japanese: "Japanese", ko: "Korean", kor: "Korean", korean: "Korean", zh: "Chinese", zho: "Chinese", chi: "Chinese", chinese: "Chinese", es: "Spanish", spa: "Spanish", spanish: "Spanish", fr: "French", fra: "French", fre: "French", french: "French", de: "German", deu: "German", ger: "German", german: "German", ar: "Arabic", ara: "Arabic", arabic: "Arabic", pt: "Portuguese", por: "Portuguese", portuguese: "Portuguese", ru: "Russian", rus: "Russian", russian: "Russian", it: "Italian", ita: "Italian", italian: "Italian", th: "Thai", tha: "Thai", thai: "Thai", vi: "Vietnamese", vie: "Vietnamese", vietnamese: "Vietnamese", ml: "Malayalam", mal: "Malayalam", malayalam: "Malayalam", bn: "Bengali", ben: "Bengali", bengali: "Bengali", tr: "Turkish", tur: "Turkish", turkish: "Turkish" };
  function language(value) {
    var text = clean(value).toLowerCase().replace(/[-_](?:us|gb|my|id|cn|tw|br|pt)$/, "");
    return languages[text] || "";
  }
  function metadata(id, type) {
    if (details[type + "/" + id]) return details[type + "/" + id];
    var raw = typeof globalThis !== "undefined" ? globalThis.VUEO_DISCOVERY_CONTEXT : null;
    if (typeof raw === "string") { try { raw = JSON.parse(raw); } catch (_) { raw = null; } }
    if (!raw || typeof raw !== "object") return {};
    var tmdb = raw.tmdb || raw;
    var contextId = raw.tmdbId || tmdb.id;
    if (String(contextId) !== String(id) || (raw.mediaType && raw.mediaType !== type)) return {};
    return tmdb;
  }
  function format(stream, index, meta, type, season, episode) {
    if (!stream || typeof stream !== "object" || !stream.url) return stream;
    var output = Object.assign({}, stream);
    var originalTitle = typeof stream.title === "string" ? stream.title : "";
    var displayTitle = usable(meta.title || meta.name);
    var year = /\b(?:19|20)\d{2}\b/.exec(clean(meta.release_date || meta.first_air_date || meta.year));
    var lines = [];
    if (displayTitle) {
      if (year) displayTitle += " (" + year[0] + ")";
      if (type === "tv" && Number.isInteger(Number(season)) && Number(season) >= 0 && Number(episode) >= 1) {
        displayTitle += " · S" + (Number(season) < 10 ? "0" : "") + Number(season) + "E" + (Number(episode) < 10 ? "0" : "") + Number(episode);
      }
      lines.push(displayTitle);
    } else {
      // Keep a source-provided content title when it is recognisable as one.
      var first = clean(originalTitle.split(/\r?\n/)[0]);
      var providerLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
      var isProviderTitle = providerLabel && first.toLowerCase().indexOf(providerLabel.toLowerCase()) === 0;
      var isTechnicalTitle = /^(?:\d{3,4}p|4k|Server\s+\d+|Unknown|Subtitles:|WEB[- ]DL|BluRay|HLS|M3U8|MP4|DASH)\b/i.test(first);
      if (first && /[A-Za-z\u0080-\uFFFF]/.test(first) && !isProviderTitle && !isTechnicalTitle) lines.push(first);
    }
    var text = [stream.name, originalTitle, stream.fileName, stream.filename, stream.videoCodec, stream.codec, stream.audioCodec, stream.audioChannels, stream.releaseSource, stream.sourceQuality, stream.hdr].map(clean).join(" ");
    // Film titles containing words such as English or BluRay are not technical metadata.
    var contentTitle = clean(meta.title || meta.name);
    if (contentTitle) text = text.split(contentTitle).join("");
    var quality = usable(stream.quality);
    var resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p?\b/i.exec(quality);
    if (!resolution) resolution = /\b(2160|1440|1080|720|576|480|360|240|144)p\b/i.exec(text);
    var qualityLabel = resolution ? (resolution[1] === "2160" ? "4K" : resolution[1] + "p") : (/\b4k\b/i.test(quality + " " + text) ? "4K" : "");
    var release = /\b(WEB[ ._-]?DL|WEB[ ._-]?RIP|BLU[ ._-]?RAY|BD[ ._-]?REMUX|REMUX|DVD[ ._-]?RIP|HD[ ._-]?RIP|HDTV|HDCAM|CAM)\b/i.exec(text);
    var releaseLabel = release ? release[1].toUpperCase().replace(/[ ._]/g, "-") : "";
    if (/^WEB-?DL$/.test(releaseLabel)) releaseLabel = "WEB-DL";
    if (/^WEB-?RIP$/.test(releaseLabel)) releaseLabel = "WEBRip";
    if (/^BLU-?RAY$/.test(releaseLabel)) releaseLabel = "BluRay";
    if (/REMUX/.test(releaseLabel)) releaseLabel = "Remux";
    var codec = /\b(HEVC|H[ ._-]?265|X265|AVC|H[ ._-]?264|X264|AV1)\b/i.exec(text);
    var codecLabel = codec ? (/265|HEVC/i.test(codec[1]) ? "HEVC" : /264|AVC/i.test(codec[1]) ? "H.264" : "AV1") : "";
    var hdr = /\b(DOLBY[ ._-]?VISION|HDR10\+|HDR10|HDR|SDR)(?!\w)/i.exec(text);
    var hdrLabel = hdr ? (/DOLBY/i.test(hdr[1]) ? "Dolby Vision" : hdr[1].toUpperCase()) : "";
    var videoLine = unique([qualityLabel, releaseLabel, codecLabel, hdrLabel]).join(" · ");
    if (videoLine) lines.push(videoLine);
    var audioLang = language(stream.audioLanguage || stream.language || stream.lang);
    var audioLanguages = Array.isArray(stream.audioLanguages) ? unique(stream.audioLanguages.map(language)) : [];
    if (!audioLang && audioLanguages.length === 1) audioLang = audioLanguages[0];
    var explicitAudio = /\b(English|Malay|Indonesian|Hindi|Tamil|Telugu|Japanese|Korean|Chinese|Spanish|French|Arabic)[ -]Audio\b/i.exec(text);
    if (!audioLang && explicitAudio) audioLang = language(explicitAudio[1]);
    // MovieBlast exposes its language as a trailing parenthesised code.
    var parenthesised = /\(([A-Za-z]{2,3})\)\s*$/.exec(clean(originalTitle));
    if (!audioLang && parenthesised) audioLang = language(parenthesised[1]);
    var audioLabel = audioLang ? audioLang + " Audio" : "";
    if (audioLanguages.length > 1) audioLabel = "Multi Audio (" + audioLanguages.join(", ") + ")";
    if (/^original$/i.test(clean(stream.audioLanguage))) audioLabel = "Original Audio";
    if (/\bdual[- ]audio\b/i.test(text)) audioLabel = "Dual Audio" + (audioLang ? " (" + audioLang + ")" : "");
    else if (/\b(?:multi[- ]audio|multilingual)\b/i.test(text)) audioLabel = "Multi Audio" + (audioLang ? " (" + audioLang + ")" : "");
    var audioCodec = /\b(DOLBY[ ._-]?ATMOS|ATMOS|TRUEHD|DTS[ ._-]?HD[ ._-]?MA|DTS[ ._-]?HD|DTS[ ._-]?X|DTS|E[ ._-]?AC[ ._-]?3|DDP|AC[ ._-]?3|AAC|FLAC|OPUS)\b/i.exec(text);
    var audioCodecLabel = audioCodec ? audioCodec[1].toUpperCase().replace(/[ ._]/g, "-") : "";
    if (/ATMOS/.test(audioCodecLabel)) audioCodecLabel = "Dolby Atmos";
    if (audioCodecLabel === "TRUEHD") audioCodecLabel = "Dolby TrueHD";
    if (/^(E-?AC-?3|DDP)$/.test(audioCodecLabel)) audioCodecLabel = "Dolby Digital Plus";
    if (/^AC-?3$/.test(audioCodecLabel)) audioCodecLabel = "Dolby Digital";
    var channels = /\b(7\.1|6\.1|5\.1|2\.0)\b/.exec(text);
    var audioLine = unique([audioLabel, [audioCodecLabel, channels ? channels[1] : ""].filter(Boolean).join(" ")]).join(" · ");
    if (audioLine) lines.push(audioLine);
    var subs = Array.isArray(stream.subtitles) ? unique(stream.subtitles.map(function(sub) {
      return sub && (language(sub.language) || language(sub.lang) || language(sub.code) || language(sub.id));
    })) : [];
    if (subs.length) lines.push("Subtitles: " + subs.join(", "));
    var server = usable(stream.serverName || stream.server || stream.sourceName);
    if (!server) {
      server = clean(stream.name);
      [providerName, providerName.replace(/\s+V\d+$/i, ""), providerId, providerId.replace(/-v\d+$/, "")].forEach(function(label) {
        label = clean(label);
        if (!label) return;
        if (server.toLowerCase().indexOf(label.toLowerCase()) === 0) server = server.slice(label.length).trim();
      });
      if (!server) {
        var titleServer = clean(originalTitle);
        var baseLabel = clean(providerName.replace(/\s+V\d+$/i, ""));
        if (baseLabel && titleServer.toLowerCase().indexOf(baseLabel.toLowerCase() + " - ") === 0) {
          server = titleServer.slice(baseLabel.length + 3).replace(/\([A-Za-z]{2,3}\)\s*$/, "").trim();
        }
      }
      server = server.replace(/\b\d{3,4}p\b|\b(?:4k|FHD|UHD|Auto)\b/gi, "")
        .replace(/\((?:English|Hindi|Tamil|Telugu|Malay|Indonesian|EN|HI|TA|TE|MS|ID)\)/gi, "").trim();
      // Keep descriptive host names; omit names consisting of quality/audio labels.
      if (/\b(?:\d{3,4}p|4k|audio|FHD|UHD|HLS|M3U8|MP4|BluRay|WEB-DL)\b/i.test(server)) {
        var numbered = /\bServer\s+\d+\b/i.exec(server);
        server = numbered ? numbered[0] : "";
      }
      server = usable(server.replace(/^[|·: -]+|[|·: -]+$/g, ""));
      if (server.length > 80) server = "";
    }
    if (!server) server = "Server " + (index + 1);
    var path = String(stream.url).split(/[?#]/)[0];
    var formatLabel = /\.m3u8$/i.test(path) ? "HLS" : /\.mp4$/i.test(path) ? "MP4" : /\.mkv$/i.test(path) ? "MKV" : /\.mpd$/i.test(path) ? "DASH" : "";
    if (!formatLabel) {
      var declared = clean(stream.format || stream.mimeType || stream.type);
      if (/^(?:hls|m3u8|application\/(?:vnd\.apple\.mpegurl|x-mpegurl))$/i.test(declared)) formatLabel = "HLS";
      else if (/^(?:mp4|video\/mp4)$/i.test(declared)) formatLabel = "MP4";
      else if (/^(?:dash|application\/dash\+xml)$/i.test(declared)) formatLabel = "DASH";
    }
    var size = usable(stream.size || stream.fileSize || (stream.behaviorHints && stream.behaviorHints.videoSize));
    if (!size) { var sm = /\b(\d+(?:\.\d+)?)\s*(GB|MB|TB|GiB|MiB)\b/i.exec(text); if (sm) size = sm[1] + " " + sm[2]; }
    if (/^\d+(?:\.\d+)?$/.test(size)) {
      var bytes = Number(size);
      size = bytes > 0 ? (bytes >= 1073741824 ? (bytes / 1073741824).toFixed(1) + " GB" : (bytes / 1048576).toFixed(1) + " MB") : "";
    } else if (!/^\d+(?:\.\d+)?\s*(?:GB|MB|TB|GiB|MiB)$/i.test(size)) size = "";
    var minutes = Number(stream.runtimeMinutes || (type === "movie" ? meta.runtime : 0));
    var duration = minutes > 0 && Number.isFinite(minutes) ? Math.round(minutes) + " min" : "";
    if (!duration) { var dm = /\b(\d+)\s*min(?:utes)?\b/i.exec(clean(stream.duration) + " " + text); if (dm && Number(dm[1]) > 0) duration = dm[1] + " min"; }
    lines.push(unique([formatLabel, server, size, duration]).join(" · "));
    output.name = "";
    output.title = lines.join("\n");
    return output;
  }
  var original = provider.getStreams;
  var adapted = Object.assign({}, provider);
  adapted.getStreams = function(id, type, season, episode) {
    var args = arguments;
    var mediaType = type === "series" ? "tv" : type;
    return Promise.resolve().then(function() { return original.apply(provider, args); }).then(function(streams) {
      if (!Array.isArray(streams)) return streams;
      var meta = metadata(id, mediaType);
      return streams.map(function(stream, index) {
        try { return format(stream, index, meta, mediaType, season, episode); } catch (_) { return stream; }
      });
    });
  };
  return adapted;
}
module.exports = cloudbankDisplayInstall(module.exports, "MovieBlast", "movieblast");
if (typeof globalThis !== "undefined") globalThis.getStreams = module.exports.getStreams;
/* CLOUDBANK_STREAM_DISPLAY_END */
